"""ambiguity（単位 B2.1 の案 B の試作）: B2 の 4 回目の点検で残った 6 件（b2_review/workflow_final.json の remaining）と、その形を
少し変えた形（反対の端・表・ページの区切り）の反例。文字はすべて架空。oracle/run_all.py の書式（oracle/runner.py の docstring）。
  python run_all.py <src> .../b21/ambiguity/cases/cases_amb.py --name <名前>
期待は原則だけで決める（出版版 PDF の本文と同じにする。組版の文字・図や表の中の文字・ほかの段落の文字を足さない。本文の文字を
消さない。決められないものは docx のまま 13 章に出す）。

組（名前の前置き）:
  v_*            rvB2x_principle_cases.py の 5 回目の点検の反例（残った指摘 1〜4: v_headfig・v_figtop・v_better・v_face）
  a_cpo_*        残った指摘 5 の頭の側（図〈キャプションは図の下〉の前の段落の最後の文が校正で消され、図の後ろの段落の最初の行
                 〈「話し合いの中で」→「議論の中で」〉が、キャプションのすぐ後ろ、受付日の行の前にある）。後ろの段落の直しは直す
  a_num3_*       残った指摘 6（段落が表で分断され、表のキャプション「表１」〈全角〉・「表1」〈半角〉のすぐ後ろの本文の数「12点」が
                 出版版で「13点」。docx にも PDF にもない「113点」にしない）
  a_headfig_above_*  残った指摘 1 の変わり型: 図のキャプションが図の上（docx も図の上）で、図の中の最後の行が段落の書き出しとよく
                 似ていて、書き出しが校正で直されている（キャプションをはさまずに、図の中の行のすぐ後ろに段落がある）
  a_figtop_head_*    残った指摘 3 の反対の端: 段落の最初の文が校正で消され、前のページの最後に、消された文とよく似た 1 行だけの図
                 （キャプションは図の上）がある
  a_figtop_tab_*     残った指摘 3 の表の形: 消された最後の文とよく似たセルの、1 行だけの表（キャプションは表の下）が次のページの
                 最初にある
  a_lastline_*   対照: 段落の最後の行（本当の行。校正の直しあり）のすぐ後ろに、図のキャプション（図の下。図の中の文字はない）が
                 ある。直す
"""
from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
sys.path.insert(0, str(S / "n10"))
sys.path.insert(0, str(S / "oracle"))
from runner import BREAK, Raw, flow, received_line  # noqa: E402
import cases_n10 as N  # noqa: E402

_spec = importlib.util.spec_from_file_location("rvB2x_principle_cases", S / "rvB2x_principle_cases.py")
X = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(X)

CASES = [c for c in X.CASES if c["name"].startswith("v_")]


def case(name, item, paras, pages, note, truth=None, expect="exact"):
    CASES.append({"name": name, "angle": "layout", "item": item, "paras": paras, "truth": truth or {},
                  "pages": pages, "expect": expect, "note": note})


idx = X.idx
tail_blocks = X.tail_blocks
Z_CAP = X.Z_CAP
FIG_HEAD = X.FIG_HEAD


def with_head(pages, page_no=1, head="試験　五郎"):
    """pages の page_no 番目（0 から）のページの最初（ページ番号の後ろ）に柱の行を入れる。"""
    ls = pages[page_no].split("\n")
    pages[page_no] = "\n".join(ls[:1] + [head] + ls[1:])
    return pages


def front_blocks():
    return [N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2]


def rest_blocks():
    return [N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()]


# ---------------------------------------------------------------- a_cpo_*: 指摘 5 の頭の側
HEAD_PUB = N.P_AFTER.replace("話し合いの中で", "議論の中で")
for ek, (a_docx, a_pub) in {"delsent": (N.TARGET + "その結果を表に示す。", N.TARGET),
                            "nostop": (N.TARGET[:-len("時間を取った。")] + "時間を取る",
                                       N.TARGET[:-len("時間を取った。")] + "場を設けた。")}.items():
    paras = N.article_paras(a_docx, (), [("画像", "授業の流れ"), ("図キャプション", Z_CAP)])
    hl = N.body(HEAD_PUB)
    for ak in ("date", "coldate"):
        head = [Raw(*N.body(a_pub)), Raw(*FIG_HEAD, "まとめ", Z_CAP), Raw(hl[0]), Raw(received_line())] + \
            ([BREAK] if ak == "date" else [])
        pages = flow([*front_blocks(), *head, Raw(*hl[1:]), *rest_blocks()], first=25)
        case(f"a_cpo_{ek}_{ak}", "N20", paras, pages,
             f"図（キャプションは図の下）の前の段落の最後が校正で直され（{ek}）、図の後ろの段落の最初の行「{hl[0]}」（「話し合いの"
             "中で」→「議論の中で」）が、キャプションのすぐ後ろ、1 ページ目の最後の投稿受付日の行の前にある。後ろの段落は本当の段落の"
             "行なので直す。前の段落は直すか、決められなければ docx のまま 13 章に出す。",
             truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, a_docx): a_pub, idx(paras, N.P_AFTER): HEAD_PUB},
             expect={"default": "exact", idx(paras, a_docx): "reported"})

# ---------------------------------------------------------------- a_num3_*: 指摘 6（表のキャプションの「１」と docx の「1」）
NUM_DOCX = "架空の調査の結果を表１に示す。その結果，生徒の平均は12点であり，前回の調査より高かった。"
NUM_PUB = NUM_DOCX.replace("12点", "13点")
NUM_ROWS = [["組の名前", "一回目の得点", "二回目の得点"], ["第一の組", "31", "27"], ["第二の組", "14", "23"],
            ["第三の組", "35", "16"]]
for ck, cap in (("fw", "表１　架空の組ごとの得点"), ("hw", "表1　架空の組ごとの得点")):
    paras = N.article_paras(NUM_DOCX, (), [("表キャプション", cap), ("表", NUM_ROWS)])
    cut = NUM_PUB.index("点であり") - 2
    cells = [c for row in NUM_ROWS for c in row]
    for pk in ("mid", "pb"):
        mid = [Raw(*N.body(NUM_PUB[:cut])), Raw(cap, *cells)] + ([BREAK] if pk == "pb" else []) + \
            [Raw(*N.jwrap(NUM_PUB[cut:]))]
        pages = flow([*front_blocks(), *mid, Raw(*N.body(N.P_AFTER)), *rest_blocks()], first=25)
        case(f"a_num3_{ck}_{pk}", "N20", paras, pages,
             f"段落「…平均は12点…」が、PDF では「平均は」の後ろで表（キャプション「{cap}」とセル）に分断され、表の後ろに「13点…」が"
             "続く（出版版で 12 → 13）。直すか、決められなければ docx のまま 13 章に出す（キャプションの「１」と docx の「1」を並べて"
             "「113点」にしない）。",
             truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, NUM_DOCX): NUM_PUB},
             expect={"default": "exact", idx(paras, NUM_DOCX): "reported"})

# ---------------------------------------------------------------- a_headfig_above_*: 指摘 1 の変わり型（キャプションは図の上）
for fk, fig in (("step", ["導入", "↓", "話し合いの中で考える"]), ("copy", ["導入", "↓", "話し合いの中で，ある"])):
    paras = ([("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("見出し", N.H2), ("本文", N.TARGET),
              ("図キャプション", Z_CAP), ("画像", "".join(fig)), ("本文", N.P_AFTER), ("見出し", N.H3),
              ("本文", N.P_DISC), ("本文", N.P_END), ("引用文献見出し", N.RH), ("引用文献", N.REF1), ("引用文献", N.REF2)])
    for before in ("direct", "pbhead"):
        blocks = [*front_blocks(), Raw(*N.body(N.TARGET))] + ([BREAK] if before == "pbhead" else []) + \
            [Raw(Z_CAP, *fig), Raw(*N.body(HEAD_PUB)), *rest_blocks()]
        pages = flow(blocks, first=25)
        if before == "pbhead":
            with_head(pages)
        case(f"a_headfig_above_{fk}_{before}", "N20", paras, pages,
             f"段落の書き出し「話し合いの中で」は出版版で「議論の中で」。PDF では段落のすぐ前に小さな図（キャプションは図の上）があり、"
             f"図の中の最後の行「{fig[-1]}」が書き出しとよく似ている。図の中の文字を段落に足さない。直すか、決められなければ docx の"
             "まま 13 章に出す。",
             truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.P_AFTER): HEAD_PUB},
             expect={"default": "exact", idx(paras, N.P_AFTER): "reported"})

# ---------------------------------------------------------------- a_figtop_head_*: 指摘 3 の反対の端
DEL_HEAD = "課題の提示を行った。"
for fk, fl in (("sim", "課題の把握"), ("copy", "課題の提示")):
    docx_a = DEL_HEAD + N.P_AFTER
    paras = N.article_paras(N.TARGET, (), [("図キャプション", Z_CAP), ("画像", fl)], after=docx_a)
    blocks = [*front_blocks(), Raw(*N.body(N.TARGET)), Raw(Z_CAP, fl), BREAK, Raw(*N.body(N.P_AFTER)), *rest_blocks()]
    pages = flow(blocks, first=25)
    case(f"a_figtop_head_{fk}", "N20", paras, pages,
         f"段落の最初の文「{DEL_HEAD}」は出版版で消されている。PDF では前のページの最後に、1 行だけの小さな図（キャプションは図の上。"
         f"行「{fl}」）があり、次のページの最初から段落が始まる。図の中の文字を足さない。消すか、決められなければ docx のまま 13 章に"
         "出す。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_a): N.P_AFTER},
         expect={"default": "exact", idx(paras, docx_a): "reported"})

# ---------------------------------------------------------------- a_figtop_tab_*: 指摘 3 の表の形
T_CAP = "表１　記述の数"
for rk, rows in (("row1", [["課題の把握"]]), ("row2", [["課題の把握", "12"], ["まとめ", "19"]])):
    docx_t = N.TARGET + DEL_HEAD
    paras = N.article_paras(docx_t, (), [("表", rows), ("表キャプション", T_CAP)])
    for bk in ("pb", "pbhead"):
        blocks = [*front_blocks(), Raw(*N.body(N.TARGET)), BREAK, Raw(*[" ".join(r) for r in rows], T_CAP),
                  Raw(*N.body(N.P_AFTER)), *rest_blocks()]
        pages = flow(blocks, first=25)
        if bk == "pbhead":
            with_head(pages)
        case(f"a_figtop_tab_{rk}_{bk}", "N20", paras, pages,
             f"段落の最後の文「{DEL_HEAD}」は出版版で消されている。次のページの最初に、消された文とよく似たセル「{rows[0][0]}」の"
             "表（キャプションは表の下）がある。表のセルの文字を足さない。消すか、決められなければ docx のまま 13 章に出す。",
             truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_t): N.TARGET},
             expect={"default": "exact", idx(paras, docx_t): "reported"})

# ---------------------------------------------------------------- a_lastline_*: 対照（本当の最後の行のすぐ後ろのキャプション）
for ek, pub in (("e4", N.TARGET[:-4] + "持った。"), ("e1", N.TARGET.replace("説明し合う", "説明しあう"))):
    paras = N.article_paras(N.TARGET, (), [("画像", "写真"), ("図キャプション", Z_CAP)])
    for bk in ("direct", "pb"):
        lines = N.body(pub)
        blocks = [*front_blocks(), Raw(*lines[:-1])] + ([BREAK] if bk == "pb" else []) + \
            [Raw(lines[-1], Z_CAP), Raw(*N.body(N.P_AFTER)), *rest_blocks()]
        pages = flow(blocks, first=25)
        case(f"a_lastline_{ek}_{bk}", "N20", paras, pages,
             f"対照: 段落の最後の行「{lines[-1]}」（本当の行。校正の直しあり）のすぐ後ろに、写真の図のキャプション（図の下。図の中の"
             "文字はない）がある。本当の段落の行なので直す。",
             truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): pub})
