"""ambiguity: 反例 1 つで照合（compare）だけを動かし、まとめての照合の塊（段落ごとの行）・窓・違いを出す（作業用）。
  PYTHONPATH=<src> python dbg.py <反例のファイル> <反例の名前> [段落 ID ...]
"""
import importlib.util
import sys
from pathlib import Path

cfile, name = sys.argv[1:3]
want = set(sys.argv[3:])
O = "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/oracle"
sys.path.insert(1, O)
spec = importlib.util.spec_from_file_location("cases", cfile)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
c = next(c for c in m.CASES if c["name"] == name)
import runner  # noqa: E402
import jasme_jats  # noqa: E402
from jasme_jats import pdfmatch as PM  # noqa: E402
from jasme_jats.config import JournalConfig  # noqa: E402
from jasme_jats.pipeline import _mechanical  # noqa: E402

work = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b21/ambiguity/exp/_dbg") / name
work.mkdir(parents=True, exist_ok=True)
mf = runner._fixtures(Path(jasme_jats.__file__).resolve().parents[2])
docx = work / "case.docx"
runner.build_docx(c, docx, mf)
journal = JournalConfig.load()
doc, plan, _ = _mechanical(docx, journal)
pages = list(c["pages"])
st = PM.pdf_stream(pages)
print("版", jasme_jats.__version__, jasme_jats.__file__)
for n, ln in enumerate(st.lines):
    print(f"  L{n:03d} {ln}")
# compare と同じ段落の並び
fn_marks = {}
list_marks = {}
allp = list(plan.paras.values())
paras, gaps = [], []
between = False
for p in allp:
    q, g = PM._para_seq(p, fn_marks, list_marks)
    if sum(1 for ch, _ in q if ch != PM.SKIP) >= PM.MIN_CHARS:
        paras.append((p, q, g))
        gaps.append(between)
        between = False
    else:
        between = between or not p.is_blank
jt = PM._Joint(plan, paras, st, gaps)
jt.first_pass()
jt.recheck_runs()
jt.fill_holes()
jt.release_islands()
jt.fill_holes()
jt.contests()
r = jt.result()
for n, (p, seq, _) in enumerate(paras):
    if want and p.src not in want:
        continue
    lines = {}
    for i, cc in jt.kept[n]:
        lines.setdefault(jt.line_of[cc], []).append(i)
    print(f"[{p.src}] flow={jt.flow[n]} {p.plain()[:30]}")
    for ln, idx in sorted(lines.items()):
        print(f"    L{ln:03d} seq {min(idx)}..{max(idx)} ({len(idx)}) {''.join(seq[i][0] for i in idx)}")
    u = r.unsure[n]
    print("    unsure:", {k: (sorted(v) if isinstance(v, set) else v) for k, v in u.items() if k not in ("floaty", "contested")},
          "floaty lines", sorted({st.line[k] for k in u["floaty"]}))
res = PM.compare(plan, pages)
for d in res.diffs:
    if not want or d.src in want:
        print("DIFF", d.src, repr(d.docx), "->", repr(d.pdf), "fixable", d.fixable, "why", d.why[:20], "ctx", d.context)
for s, l in res.ignored_lines:
    if not want or s in want:
        print("IGN", s, l)
print("unmatched", res.unmatched)
for s in sorted(res.width):
    if not want or s in want:
        print("width", s, res.width.get(s))
