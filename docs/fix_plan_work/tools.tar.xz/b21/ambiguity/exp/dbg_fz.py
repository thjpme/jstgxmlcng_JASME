"""ambiguity: 乱数の例（fuzz4・fuzz8 の cases.json）の 1 件で、段落ごとの照合の窓・opcodes・違い・端の見直しの印を出す（作業用）。
  python -I dbg_fz.py SRC cases.json 番号 [段落の文字の頭 ...]
"""
import json
import sys

src, cases_path, idx = sys.argv[1], sys.argv[2], int(sys.argv[3])
heads = sys.argv[4:]
sys.path.insert(0, src)
from jasme_jats import pdfmatch as PM  # noqa: E402
from jasme_jats.config import JournalConfig  # noqa: E402
from jasme_jats.pdfdocx import _mechanical  # noqa: E402

c = json.load(open(cases_path, encoding="utf-8"))[idx]
_, plan = _mechanical(c["docx"], JournalConfig.load())
st = PM.pdf_stream(c["pages"])
for n, ln in enumerate(st.lines):
    print(f"  L{n:03d} {ln}")
orig = PM._align


def wrap(seq, st, win):
    ops = orig(seq, st, win)
    text = "".join(ch for ch, _ in seq if ch != PM.SKIP)
    if not heads or any(text.startswith(h) for h in heads):
        lines = sorted({st.line[k] for k in win})
        print(f"WIN {text[:20]} lines {lines[:3]}..{lines[-3:]}")
        for op in ops or []:
            t, i1, i2, j1, j2 = op
            d = "".join(seq[i][0] for i in range(i1, i2))
            p = "".join(st.chars[win[j]] for j in range(j1, j2))
            ls = sorted({st.line[win[j]] for j in range(j1, j2)})
            print(f"   {t:7} d[{i1}:{i2}] {d[:30]!r} p{ls} {p[:30]!r}")
    return ops


PM._align = wrap
oa = PM._EdgeAudit.audit if hasattr(PM, "_EdgeAudit") else None
if oa:
    def wa(self, src, seq, pairs, material, nb):
        r = oa(self, src, seq, pairs, material, nb)
        if r[0]:
            text = "".join(ch for ch, _ in seq if ch != PM.SKIP)
            print(f"AUDIT {src} {text[:20]} lines {sorted(r[0])} material {material}")
        return r
    PM._EdgeAudit.audit = wa
pc = PM.compare(plan, c["pages"])
for d in pc.diffs:
    print("DIFF", d.src, repr(d.docx), "->", repr(d.pdf), d.fixable, d.why[:15])
for s, l in pc.ignored_lines:
    print("IGN", s, l)
print("TRUTH", {k[:30]: v[:30] for k, v in c["truth"].items() if k != v})
