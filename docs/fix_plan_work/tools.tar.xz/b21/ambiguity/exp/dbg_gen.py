"""ambiguity: 生成例（h2.py の形の gen_*.py）の 1 件で、まとめての照合の塊（段落ごとの行）・違い・直した後の文字を出す（作業用）。
  python -I dbg_gen.py SRC GENFILE 名前 [段落の文字の頭 ...]
"""
import importlib.util
import sys
import tempfile
from pathlib import Path

src, gen, name = sys.argv[1:4]
heads = sys.argv[4:]
sys.path.insert(0, src)
sys.path.insert(1, "/home/user/jstgxmlcng_JASME/tests")
import jasme_jats  # noqa: E402
spec = importlib.util.spec_from_file_location("tp", "/home/user/jstgxmlcng_JASME/tests/test_pdfmatch.py")
T = importlib.util.module_from_spec(spec)
spec.loader.exec_module(T)
from jasme_jats import pdfmatch as PM  # noqa: E402
from jasme_jats.config import JournalConfig  # noqa: E402
from jasme_jats.pdfdocx import plan_fixes  # noqa: E402
T.JOURNAL = JournalConfig.load()
sys.path.insert(2, str(Path(gen).resolve().parent))
spec2 = importlib.util.spec_from_file_location("gen", gen)
G = importlib.util.module_from_spec(spec2)
spec2.loader.exec_module(G)
c = next(c for c in G.make_cases(T) if c["name"] == name)
with tempfile.TemporaryDirectory() as td:
    plan, srcmap = T.n10_article(Path(td), T.JOURNAL, c["blocks"])
pages = c["raw_pages"] if "raw_pages" in c else T.n10_pages(*c["pages"])
st = PM.pdf_stream(pages)
print("版", jasme_jats.__version__, jasme_jats.__file__)
for n, ln in enumerate(st.lines):
    print(f"  L{n:03d} {ln}")
allp = list(plan.paras.values())
paras, gaps = [], []
between = False
for p in allp:
    q, g = PM._para_seq(p, {}, {})
    if sum(1 for ch, _ in q if ch != PM.SKIP) >= PM.MIN_CHARS:
        paras.append((p, q, g))
        gaps.append(between)
        between = False
    else:
        between = between or not p.is_blank
jt = PM._Joint(plan, paras, st, gaps)
for step in ("first_pass", "recheck_runs", "fill_holes", "release_islands", "fill_holes", "contests"):
    getattr(jt, step)()
r = jt.result()
want_src = {p.src for p, _, _ in paras if not heads or any(p.plain().startswith(h) for h in heads)}
for n, (p, seq, _) in enumerate(paras):
    if p.src not in want_src:
        continue
    lines = {}
    for i, cc in jt.kept[n]:
        lines.setdefault(jt.line_of[cc], []).append(i)
    print(f"[{p.src}] flow={jt.flow[n]} {p.plain()[:30]}")
    for ln, idx in sorted(lines.items()):
        print(f"    L{ln:03d} seq {min(idx)}..{max(idx)} ({len(idx)}) {''.join(seq[i][0] for i in idx)}")
    u = r.unsure[n]
    print("    unsure:", {k: (sorted(v) if isinstance(v, set) else v) for k, v in u.items()
                         if k not in ("floaty", "contested") and v}, "floaty lines", sorted({st.line[k] for k in u["floaty"]}))
pc = PM.compare(plan, pages)
fx = plan_fixes(plan, pc)
for d in pc.diffs:
    if d.src in want_src:
        print("DIFF", d.src, repr(d.docx), "->", repr(d.pdf), "fixable", d.fixable, "why", d.why[:20], "ctx", d.context)
for s, l in pc.ignored_lines:
    if s in want_src:
        print("IGN", s, l)
print("unmatched", pc.unmatched)
for s, p in plan.paras.items():
    if s not in want_src:
        continue
    got = T.expected_text(p.plain(), [f for f in fx if f.src == s and not f.reason])
    truth = c["want"].get(p.plain(), p.plain())
    mark = "OK" if got == truth else "NG"
    if got != p.plain() or truth != p.plain():
        print(f"{mark} {s}\n   docx : {p.plain()}\n   got  : {got}\n   truth: {truth}")
