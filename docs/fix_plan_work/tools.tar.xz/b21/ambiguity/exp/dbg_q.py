"""ambiguity: quick の形の反例の 1 件で、段落ごとの照合の窓・opcodes・違いを出す（作業用。docx は quick.py の docx の写しを使う）。
  python -I dbg_q.py SRC CASEFILE 名前 [段落の文字の頭 ...]
"""
import hashlib
import json
import sys
from pathlib import Path

src, casefile, name = sys.argv[1:4]
heads = sys.argv[4:]
sys.path.insert(0, src)
sys.path.insert(1, "/home/user/jstgxmlcng_JASME/tests")
S = "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad"
sys.path.insert(2, S + "/fixB2r4/tools")
import quick  # noqa: E402
from jasme_jats import pdfmatch as PM  # noqa: E402
from jasme_jats.config import JournalConfig  # noqa: E402
from jasme_jats.pipeline import _mechanical  # noqa: E402

c = quick.load(casefile)[name]
spec = json.dumps([c.get("body", []), c.get("refs", [])], ensure_ascii=False)
h = hashlib.sha1(spec.encode()).hexdigest()[:12]
path = Path(S + "/fixB2r4/tools/docx") / f"{h}.docx"
plan = _mechanical(path, JournalConfig.load())[1]
st = PM.pdf_stream(c["pages"])
for n, ln in enumerate(st.lines):
    print(f"  L{n:03d} {ln}")
orig = PM._align


def wrap(seq, st, win):
    ops = orig(seq, st, win)
    text = "".join(ch for ch, _ in seq if ch != PM.SKIP)
    if not heads or any(text.startswith(h) for h in heads):
        lines = sorted({st.line[k] for k in win})
        print(f"WIN {text[:20]} lines {lines[:3]}..{lines[-3:]}")
        for op in ops or []:
            t, i1, i2, j1, j2 = op
            d = "".join(seq[i][0] for i in range(i1, i2))
            p = "".join(st.chars[win[j]] for j in range(j1, j2))
            ls = sorted({st.line[win[j]] for j in range(j1, j2)})
            print(f"   {t:7} d[{i1}:{i2}] {d[:30]!r} p{ls} {p[:30]!r}")
    return ops


PM._align = wrap
pc = PM.compare(plan, c["pages"])
for d in pc.diffs:
    print("DIFF", d.src, repr(d.docx), "->", repr(d.pdf), d.fixable, d.why[:15])
for s, l in pc.ignored_lines:
    print("IGN", s, l)
print("TRUTH", {k[:30]: v[:30] for k, v in c.get("truth", {}).items() if k != v})
