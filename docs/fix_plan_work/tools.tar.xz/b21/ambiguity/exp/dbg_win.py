"""ambiguity: 生成例の 1 件で、段落ごとの照合（_align）の窓の行と opcodes を出す（作業用）。
  python -I dbg_win.py SRC GENFILE 名前 [段落の文字の頭 ...]
"""
import importlib.util
import sys
import tempfile
from pathlib import Path

src, gen, name = sys.argv[1:4]
heads = sys.argv[4:]
sys.path.insert(0, src)
sys.path.insert(1, "/home/user/jstgxmlcng_JASME/tests")
spec = importlib.util.spec_from_file_location("tp", "/home/user/jstgxmlcng_JASME/tests/test_pdfmatch.py")
T = importlib.util.module_from_spec(spec)
spec.loader.exec_module(T)
from jasme_jats import pdfmatch as PM  # noqa: E402
from jasme_jats.config import JournalConfig  # noqa: E402
T.JOURNAL = JournalConfig.load()
sys.path.insert(2, str(Path(gen).resolve().parent))
spec2 = importlib.util.spec_from_file_location("gen", gen)
G = importlib.util.module_from_spec(spec2)
spec2.loader.exec_module(G)
c = next(c for c in G.make_cases(T) if c["name"] == name)
with tempfile.TemporaryDirectory() as td:
    plan, srcmap = T.n10_article(Path(td), T.JOURNAL, c["blocks"])
pages = c["raw_pages"] if "raw_pages" in c else T.n10_pages(*c["pages"])
orig = PM._align
st0 = PM.pdf_stream(pages)


def wrap(seq, st, win):
    ops = orig(seq, st, win)
    text = "".join(ch for ch, _ in seq if ch != PM.SKIP)
    if not heads or any(text.startswith(h) for h in heads):
        lines = sorted({st.line[k] for k in win})
        print(f"WIN {text[:20]} lines {lines[:3]}..{lines[-3:]}")
        for op in ops or []:
            t, i1, i2, j1, j2 = op
            d = "".join(seq[i][0] for i in range(i1, i2))
            p = "".join(st.chars[win[j]] for j in range(j1, j2))
            ls = sorted({st.line[win[j]] for j in range(j1, j2)})
            print(f"   {t:7} d[{i1}:{i2}] {d[:30]!r} p{ls} {p[:30]!r}")
    return ops


PM._align = wrap
pc = PM.compare(plan, pages)
for d in pc.diffs:
    print("DIFF", d.src, repr(d.docx), "->", repr(d.pdf), d.fixable, d.why[:15])
for s, l in pc.ignored_lines:
    print("IGN", s, l)
