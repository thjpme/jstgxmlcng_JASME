# ---------------------------------------------------------------------------- 段落の端の見直し（ほかの説明ができるなら直さない）
# まとめての照合と段落ごとの照合は、段落の最後（最初）の docx の文字を、PDF のどこかの行に並べる。分断された段落の端の行が、すぐ
# 隣の図・表の中の行・キャプション・ほかの段落の行とよく似ていると、その並べ方が誤っていても、ほかの段落・照合の手がかりからは
# 見分けられない（0.21.0 までは、形ごとの規則〈図の中の行とキャプションの間の行、隣の段落の端の穴、もっとよく並ぶ行など〉を
# 足していたが、点検のたびに別の形が見つかった）。そこで、段落ごとの照合の後で、段落の端の行について、その行の文字を段落の文字と
# する説明と、ほかの説明を比べ、ほかの説明もほぼ同じくらいよく当てはまるなら、その行の違いを直さない（DISPLACED_WHY。13 章に出す）。
EDGE_CLEAR = 0.8     # 端の行の文字を段落の文字とする説明の当てはまりがこれ以上なら、ほかの説明と比べずに段落の文字とする
EDGE_POOR = 0.4      # 図・表の中身の位置（slot）にある端の行で、当てはまりがこれ未満なら、あいまいとする
EDGE_MARGIN = 1.25   # ほかの説明の手間が、段落の文字とする説明の手間のこの倍以下（と 1 文字の差）なら、ほぼ同じとみなす


class _EdgeAudit:
    """段落ごとの照合（_align）の結果の、段落の最後（最初）の端の行の見直し（compare の中だけで使う）。

    owner: PDF の文字の位置 -> その文字に当たった段落 ID。flow: 段落 ID -> 本文の流れの段落か。side: 段落 ID -> 本文の流れでない
    段落の、図・表の中身のある側（_material_sides）。"""

    def __init__(self, st: PdfStream, owner, flow, side):
        self.st, self.owner, self.flow, self.side = st, owner, flow, side
        self.line_start, self.line_end = {}, {}
        for k, ln in enumerate(st.line):
            self.line_start.setdefault(ln, k)
            self.line_end[ln] = k

    def chars(self, ln) -> list:
        """行 ln の文字の位置（行末のハイフンを除く）。"""
        if ln not in self.line_start:
            return []
        return [k for k in range(self.line_start[ln], self.line_end[ln] + 1) if not self.st.soft[k]]

    def kind(self, ln, src, D=()) -> str:
        """行 ln の、段落 src から見た種類: "own"（段落 src に当たった文字がある）・"flow"（ほかの本文の流れの段落に当たった文字が
        ある）・"mat"（本文の流れでない段落〈図・表のキャプション・表のセルなど〉に当たった文字だけがある）・"free"（どの段落にも
        当たらない、図・表の中の文字など）・"type"（どの段落にも当たらない、投稿受付日の文字、何ページにも出る行、ページの最初の端の行
        〈柱が出る位置〉の文字だけ。ただし、柱が出る位置の行でも、MIN_CHARS 文字未満の行〈図の中の「導入」「↓」など〉と、文字の
        半分以上が段落の端の docx の文字 D と並ぶ行は "free"）・""（文字のない行）。受付日の文字は、どの段落に当たっていても
        （docx の「，」と偶然並んだものなど）組版の文字として見る。"""
        st = self.st
        ks = self.chars(ln)
        if not ks:
            return ""
        owners = {self.owner[k] for k in ks if k in self.owner and st.date[k] < 0}
        if src in owners:
            return "own"
        if any(self.flow.get(o, True) for o in owners):
            return "flow"
        if owners:
            return "mat"
        if all(st.date[k] >= 0 for k in ks):
            return "type"
        if all(st.line_only[k] or st.date[k] >= 0 for k in ks):
            return "free" if RE_PAGE_NO.match(st.lines[ln]) else "type"     # 表の数字の行 / 何ページにも出る行（柱など）
        if all(st.date[k] >= 0 or st.top[k] for k in ks):
            text = [key(st.chars[k]) for k in ks if st.date[k] < 0]
            return "free" if len(text) < MIN_CHARS or (D and 2 * _lcs_prefix(D, text)[-1] >= len(text)) else "type"
        return "free"

    def text(self, ln, src) -> list:
        """行 ln の、段落 src に当たった文字と、どの段落にも当たらない文字（受付日の文字を除く。key の列）。"""
        return [key(self.st.chars[k]) for k in self.chars(ln)
                if self.owner.get(k, src) == src and self.st.date[k] < 0]

    def outer(self, ln, step, src, D):
        """行 ln の外（step の向き）の、文字のある最初の行（"type" の行は 3 行まで飛ばす）の (種類, 行の番号, 本文の流れでない段落の
        ID の集合)。外に行がなければ ("end", None, set())。"""
        x, skipped = ln + step, 0
        while 0 <= x < len(self.st.lines):
            kd = self.kind(x, src, D)
            if kd == "" or (kd == "type" and skipped < 3):
                skipped += kd == "type"
                x += step
                continue
            return kd, x, {self.owner[k] for k in self.chars(x) if k in self.owner and not self.flow.get(self.owner[k], True)}
        return "end", None, set()

    def enclosed(self, ln, src, D) -> bool:
        """行 ln の前と後ろの、文字のある最初の行（"type" の行は飛ばす）が、どちらも図・表など（"mat"・"free"）か。"""
        sides = []
        for step in (-1, 1):
            x = ln + step
            while 0 <= x < len(self.st.lines) and self.kind(x, src, D) in ("", "type"):
                x += step
            sides.append(self.kind(x, src, D) if 0 <= x < len(self.st.lines) else "end")
        return all(s in ("mat", "free") for s in sides)

    def gap(self, a, b, src, D) -> set:
        """行 a と b の間（a・b を除く）の行の種類の集合。"""
        lo, hi = sorted((a, b))
        return {self.kind(x, src, D) for x in range(lo + 1, hi)} - {"", "type"}

    @staticmethod
    def pairs(seq, win, ops, st: PdfStream) -> list:
        """段落ごとの照合で一致した (seq の位置, PDF の文字の位置)（受付日の文字・行末のハイフンを除く。seq の順）。"""
        return sorted((i1 + t, win[j1 + t]) for tag, i1, i2, j1, _ in ops if tag == "equal" for t in range(i2 - i1)
                      if st.date[win[j1 + t]] < 0 and not st.soft[win[j1 + t]])

    def region(self, src, seq, pairs, step):
        """段落の最後（step = 1。-1 なら最初）の端の部分: (端の行のリスト〈端から内へ。1〜2 行〉, 内側の行の端の一致 (seq の位置,
        PDF の位置), 端の docx の文字 D〈内側の一致より外。key の列〉, 端の行から内側の行までの間の行の種類〈端から内へ〉)。端の
        部分のない段落（1 行だけ）は None。端の行は、端から内へ、図・表など（"mat"・"free"）・ほかの本文の段落（"flow"）の行を
        はさんで離れた行（と、その内側にすぐ続く行）。"""
        run = pairs[::-1] if step > 0 else pairs
        lines = []
        for _, k in run:
            ln = self.st.line[k]
            if ln not in lines:
                lines.append(ln)
                if len(lines) > 3:
                    break
        if len(lines) < 2:
            return None
        D0 = [key(c) for c, _ in seq if c != SKIP]
        D0 = D0[-60:] if step > 0 else D0[:60]          # 端の近くの docx の文字（柱が出る位置の行が段落の文字かを見る）
        gaps = [self.gap(lines[t], lines[t + 1], src, D0) for t in range(len(lines) - 1)]
        det = [bool(g & {"mat", "free", "flow"}) for g in gaps]
        size = 2 if len(lines) >= 3 and det[1] else 1      # 2 行目が内側の行から図・表などで離れていれば、端の部分は 2 行
        anchor = lines[size]
        # 内側の行の一致のうち、いちばん外の文字（端の行の側）
        i_in, k_in = max(((i, k) for i, k in run if self.st.line[k] == anchor), key=lambda t: t[0] * step)
        rng = range(i_in + 1, len(seq)) if step > 0 else range(0, i_in)
        D = [key(seq[i][0]) for i in rng if seq[i][0] != SKIP]
        D = D[:120] if step > 0 else D[-120:]
        return lines[:size], (i_in, k_in), D, gaps[:size]

    def audit(self, src, seq, pairs, material, nb):
        """段落 src（本文の流れの段落）の最後と最初の端の行のうち、ほかの説明もほぼ同じくらいよく当てはまる行の番号と、その行の
        文字の位置。material: (最初の側, 最後の側) に docx で図・表などがあるか。nb: (前, 後ろ) の本文の流れの段落の
        (段落 ID, seq, pairs) か None。

        端の行 X の位置は、内側（段落の本体の側）の間の行と、外側の最初の行で決める（受付日の行・柱が出る位置の行は飛ばす）。
          enclosed: 間に図・表など（本文の流れでない段落に当たった文字、どの段落にも当たらない行）があり、外側も図・表など。X は
                    図・表の中の行と考えられ、段落の文字とよく似ていても（図の中の原稿の写し）区別できない。いつも、あいまいとする
          slot:     外側が、X の側に図・表の中身のあるキャプション（docx でキャプションの前に画像・表があれば前、後ろにあれば後ろ）か、
                    docx で段落のその側に図・表などがあり、外側がどの段落にも当たらない行（図の中の文字など）。または、X が内側の行
                    より外にない（PDF の中の順が docx の順と逆）。X は図・表の中の行かもしれないので、文字で比べる
          body:     それ以外（外側が本文の流れの段落・図・表の中身のない側のキャプション・文字の終わりなど）
        文字の比べ方: docx の端の文字 D を、端の行と内側の行の残り（内側の一致の外側の、どの段落にも当たらない文字）R に並べる説明
        （段落の文字）と、ほかの説明の直す手間（足す文字と消す文字の数）で比べる。ほかの説明は、(1) 端の部分が 2 行なら、内側の
        行（図・表などのすぐ隣）を図・表の中の行とする、(2) slot の端の行を図の中の行とし、D を R だけに並べる（R が空なら比べない）、
        (3) 行まるごとがどの段落にも当たらないほかの行 X*（図・表などに挟まれていないもの）と R に並べる（段落の本当の端の行は X*）、
        (4) D が文のまとまりならまとめて消された（段落の最後なら文の終わりの直後から始まり、最初なら文の終わりか読点で終わる。手間は
        1）、(5) X を、docx で向かい合う隣の本文の段落の文字とする（隣り合う段落に同じ文があるとき。その段落の端の、どの照合にも
        入っていない docx の文字が、X の文字の半分以上を、この段落の端の文字と同じかそれ以上に説明するか、両方の段落の端の行を
        入れ替えると、両方の段落の端の docx の文字が今より多く説明できる）。slot では、段落の文字とする説明の当てはまり（最長共通
        部分列の長さ / D と、並べた PDF の文字の長いほう）が EDGE_CLEAR 以上なら段落の文字とし、EDGE_POOR 未満ならあいまいとする。
        (1)〜(4) は、ほかの説明の手間が段落の文字とする説明の手間とほぼ同じか少ない（EDGE_MARGIN）とき、(5) はどの位置でも
        （enclosed を除く）比べる。"""
        lines_out, poss = set(), set()
        for step, mat in ((1, material[1]), (-1, material[0])):
            reg = self.region(src, seq, pairs, step)
            if reg is None:
                continue
            region, (i_in, k_in), D, gaps = reg
            st = self.st
            anchor = st.line[k_in]
            X = region[0]
            texts = {ln: self.text(ln, src) for ln in region}
            R = [key(st.chars[k]) for k in self.chars(anchor)
                 if k not in self.owner and st.date[k] < 0 and (k > k_in if step > 0 else k < k_in)]

            def order(lns):                 # PDF の中の順（最後の側なら内から外、最初の側なら外から内）に並べた文字と R
                body = [c for ln in sorted(lns) for c in texts[ln]]
                return R + body if step > 0 else body + R

            def cost(text):
                return len(D) + len(text) - 2 * _lcs_prefix(D, text)[-1]

            def near(alt, para):            # ほかの説明の手間が、段落の文字とする説明の手間とほぼ同じか少ない
                return alt <= max(para * EDGE_MARGIN, para + 1)
            para_text = order(region)
            c_para = cost(para_text)
            fit = _lcs_prefix(D, para_text)[-1] / max(1, len(D), len(para_text))
            doubt = set()
            if len(region) == 2 and near(cost(order(region[:1])), c_para) and fit < EDGE_CLEAR:
                doubt.add(region[1])        # (1) 内側の行（図・表などのすぐ隣）は図・表の中の行かもしれない
            # 端の行 X の位置
            inner_ln = region[1] if len(region) == 2 else anchor
            cross = (X - inner_ln) * step < 0
            okind, oln, mats = self.outer(X, step, src, D)
            sides = ("before", "both") if step > 0 else ("after", "both")
            faces = any(self.side.get(o) in sides for o in mats)
            if not cross and gaps[0] & {"mat", "free"} and okind in ("mat", "free"):
                pos = "enclosed"
            elif cross or (okind == "mat" and faces) or (okind == "free" and mat):
                pos = "slot"
            else:
                pos = "body"
            amb = pos == "enclosed"
            if pos == "slot" and fit < EDGE_CLEAR:
                if fit < EDGE_POOR:
                    amb = True
                else:
                    rest = order(region[1:]) if len(region) == 2 else R
                    alts = [cost(rest)] if rest else []          # (2)
                    x = oln
                    for _ in range(40):                          # (3)
                        if x is None or not 0 <= x < len(st.lines):
                            break
                        kd = self.kind(x, src, D)
                        if kd in ("flow", "own"):
                            break
                        ks = self.chars(x)
                        if kd == "free" and len(ks) <= 60 and not self.enclosed(x, src, D):
                            other = [key(st.chars[k]) for k in ks if st.date[k] < 0]
                            alts.append(cost(rest + other if step > 0 else other + rest))
                        x += step
                    if step > 0:                                 # (4)
                        unit = _ends_sentence("".join(key(c) for c, _ in seq[max(0, i_in - 3):i_in + 1] if c != SKIP))
                    else:
                        unit = _ends_sentence("".join(D)) or D[-1:] in (["、"], [","])
                    if unit:
                        alts.append(1)
                    amb = any(near(a, c_para) for a in alts)
            PX = texts[X]
            m = nb[1] if step > 0 else nb[0]
            if not amb and m is not None and len(PX) >= MIN_CHARS:     # (5)
                msrc, mseq, mpairs = m
                need = max(MIN_CHARS, 0.5 * len(PX))
                mine = _lcs_prefix(D, PX)[-1]
                kept_m = {i for i, _ in mpairs}
                real_m = [i for i, (c, _) in enumerate(mseq) if c != SKIP]
                hole = []
                for i in (real_m if step > 0 else real_m[::-1]):     # m の、段落 src に向かい合う端の、照合に入っていない文字
                    if i in kept_m:
                        break
                    hole.append(i)
                H = [key(mseq[i][0]) for i in sorted(hole)]
                got = _lcs_prefix(H, PX)[-1] if H else 0
                amb = got >= need and got >= mine
                mreg = None if amb else self.region(msrc, mseq, mpairs, -step)
                if mreg is not None:
                    m_region, (mi, mk), Dm, _ = mreg
                    mX = m_region[0]
                    Xm = self.text(mX, msrc)
                    got = _lcs_prefix(Dm, PX)[-1]
                    cur = _lcs_prefix(D, para_text)[-1] + _lcs_prefix(Dm, Xm)[-1]
                    swap = _lcs_prefix(D, Xm)[-1] + got
                    amb = got >= need and swap > cur
            if amb:
                doubt.add(X)
            lines_out |= doubt
            for ln in doubt:
                poss.update(k for k in self.chars(ln) if self.owner.get(k, src) == src)
        return lines_out, poss
