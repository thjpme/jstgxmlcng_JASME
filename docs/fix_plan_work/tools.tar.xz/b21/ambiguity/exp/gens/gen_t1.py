"""ambiguity: 失敗したテストの形を 1 件ずつ（dbg_gen.py 用）。"""
def make_cases(T):
    out = []
    pub = T.TALK.replace("話し合いの中で", "議論の中で")
    for cut in ("k7", "sentence"):
        k = 7 if cut == "k7" else pub.index("，") + 1
        blocks = [("body", T.LESSON), ("image", "fig"), ("fig_cap", T.SMALL_FIG_CAP), ("body", T.TALK), ("body", T.SURVEY)]
        rest = ["　" + pub[:k], "話し合いの場面", *T.SMALL_FIG_STEPS[1:], "まとめ", T.SMALL_FIG_CAP, *T.wrap_lines(pub[k:]),
                *T.body_lines(T.SURVEY), *T.N10_TAIL]
        first = [*T.SMALL_FRONT, *T.body_lines(T.LESSON)]
        for before in ("date-page-end", "head-next-page"):
            pages = [[*first, T.R1], rest] if before == "date-page-end" else [first, ["試験　六郎", *rest]]
            out.append({"name": f"t1_{cut}_{before}", "blocks": blocks, "pages": pages, "want": {T.TALK: pub}})
    return out
