"""ambiguity: test_last_line_taken_by_next_paragraph_with_same_sentence_is_not_fixed の形（dbg_gen.py 用）。"""
def make_cases(T):
    out = []
    b_docx = "説明し合う時間を取った。その後，教師は二つの説明を並べて板書し，違いを問うた。"
    b_pub = b_docx.replace("取った", "設けた")
    for deleted in (False, True):
        docx, pub = (T.LESSON + "その結果を表に示す。", T.LESSON) if deleted else (T.LESSON, T.LESSON)
        blocks = [("body", docx), ("image", "fig"), ("fig_cap", T.SMALL_FIG_CAP), ("body", b_docx), ("body", T.SURVEY)]
        lines = T.body_lines(pub)
        first = [*T.SMALL_FRONT, *lines[:-1], *T.SMALL_FIG_STEPS, "まとめ", T.SMALL_FIG_CAP, lines[-1], T.R1]
        out.append({"name": f"t2_{deleted}", "blocks": blocks,
                    "pages": [first, [*T.body_lines(b_pub), *T.body_lines(T.SURVEY), *T.N10_TAIL]],
                    "want": {docx: pub, b_docx: b_pub}})
    return out
