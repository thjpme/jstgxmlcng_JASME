    # ------------------------------------------------------------------ 端の行の見直し（ほかの説明ができるなら直さない）
    def line_cs(self, ln):
        """行 ln の core の位置（列の順）。"""
        return range(bisect.bisect_left(self.line_of, ln), bisect.bisect_right(self.line_of, ln))

    def line_kind(self, ln, n, D=()) -> str:
        """行 ln の、段落 n から見た種類: "own"（段落 n の塊の文字がある）・"flow"（ほかの本文の流れの段落の塊の文字がある）・
        "mat"（本文の流れでない段落〈図・表のキャプション・表のセルなど〉の塊の文字だけがある）・"free"（どの段落にも当たらない文字
        〈図の中の文字など〉がある）・"type"（どの段落にも当たらない、投稿受付日の文字と、ページの最初の端の行〈柱が出る位置〉の文字
        だけ。ただし、その行の文字の半分以上が段落 n の端の docx の文字 D と並ぶなら、柱ではなく "free"）・""（照合に使う文字のない
        行。ページ番号・行全体でしか一致させない行・空の行）。"""
        cs = self.line_cs(ln)
        if not cs:
            return ""
        owners = {self.own[c] for c in cs if self.own[c] >= 0}
        if n in owners:
            return "own"
        if any(self.flow[o] for o in owners):
            return "flow"
        if owners:
            return "mat"
        st = self.st
        if all(st.date[self.core[c]] >= 0 for c in cs):
            return "type"
        if all(st.date[self.core[c]] >= 0 or st.top[self.core[c]] for c in cs):
            text = [self.P[c] for c in cs if st.date[self.core[c]] < 0]
            return "free" if D and 2 * _lcs_prefix(D, text)[-1] >= len(text) else "type"
        return "free"

    def outer_line(self, n, e_ln, step, D=()):
        """段落 n の端の行 e_ln の外（step = 1 なら後ろ、-1 なら前）で、照合に使う文字のある最初の行（"type" の行は 3 行まで飛ばす）の
        (種類, 行の番号, その行に塊のある本文の流れでない段落の番号の集合)。外に行がなければ ("end", None, set())。"""
        ln, skipped = e_ln + step, 0
        while 0 <= ln < len(self.st.lines):
            kind = self.line_kind(ln, n, D)
            if kind == "" or (kind == "type" and skipped < 3):
                skipped += kind == "type"
                ln += step
                continue
            return kind, ln, {self.own[c] for c in self.line_cs(ln) if self.own[c] >= 0 and not self.flow[self.own[c]]}
        return "end", None, set()

    def enclosed_line(self, n, ln, D=()) -> bool:
        """行 ln の前と後ろの、照合に使う文字のある最初の行（"type" の行は飛ばす）が、どちらも図・表など（"mat"・"free"）か。"""
        sides = []
        for step in (-1, 1):
            x = ln + step
            while 0 <= x < len(self.st.lines) and self.line_kind(x, n, D) in ("", "type"):
                x += step
            sides.append(self.line_kind(x, n, D) if 0 <= x < len(self.st.lines) else "end")
        return all(s in ("mat", "free") for s in sides)

    def edge_split(self, n, step):
        """段落 n の最後（step = 1。-1 なら最初）の docx の文字を並べた行（端の行）と、その内側の塊の (seq の位置, core の位置) と、
        端の docx の文字 D（内側の塊の外から段落の端まで。key の列）。端の行だけの段落なら (端の行, None, 段落の docx の文字)。"""
        pairs = self.kept[n]
        if not pairs:
            return None, None, []
        lo, seq = self.line_of, self.paras[n][1]
        run = pairs[::-1] if step > 0 else pairs
        e_ln = lo[run[0][1]]
        k = next((x for x, (_, c) in enumerate(run) if lo[c] != e_ln), None)
        if k is None:
            return e_ln, None, [key(seq[i][0]) for i in self.real[n]]
        i_in = run[k][0]
        rng = range(i_in + 1, len(seq)) if step > 0 else range(0, i_in)
        return e_ln, run[k], [key(seq[i][0]) for i in rng if seq[i][0] != SKIP]

    def edge_audit(self, n):
        """本文の流れの段落 n の最後（最初）の docx の文字を並べた PDF の行（端の行 X）ごとに、X の文字を段落 n の文字とする説明と、
        ほかの説明（図・表の中の文字・キャプション・ほかの段落の文字・どの段落にも当たらない行）を比べ、ほかの説明もほぼ同じくらい
        よく当てはまる（あいまいな）とき、X の行の番号と、X の文字と内側の行の段落の塊の外側の文字（X といっしょに並べた違いになる
        文字）の、列の位置を返す（result が doubt に入れる。その違いは、全角・半角などの違いも直さない。DISPLACED_WHY）。

        X の位置は、内側（段落の本体の側）の間の行と、外側の最初の行で決める（受付日の行・柱が出る位置の行は飛ばす）。
          enclosed: 間に図・表など（本文の流れでない段落の塊、どの段落にも当たらない行）があり、外側も図・表など。X は図・表の中の行と
                    考えられ、段落の文字とよく似ていても（図の中の原稿の写し）区別できない。いつも、あいまいとする
          slot:     外側が、X の側に図・表の中身のあるキャプション（docx でキャプションの前に画像・表があれば前、後ろにあれば後ろ）か、
                    docx で段落のその側に図・表などがあり、外側がどの段落にも当たらない行（図の中の文字など）。または、X が内側の行
                    より外にない（PDF の中の順が docx の順と逆）。X は図・表の中の行かもしれないので、文字で比べる
          body:     それ以外（外側が本文の流れの段落・図・表の中身のない側のキャプション・表のセル・文字の終わりなど）
        文字の比べ方（slot）: docx の端の文字 D を、X と内側の行の残り（内側の塊の外側の、どの段落にも当たらない文字）R に並べる説明
        （段落の文字）の当てはまり（最長共通部分列の長さ / D と「X と R」の長いほう）が 8 割以上なら段落の文字とし、4 割未満ならあいまいと
        する。その間なら、ほかの説明（R だけに並べる〈X は図の中の文字で、D は校正で直された〉、行まるごとがどの段落にも当たらない
        ほかの行 X* と R に並べる〈段落の本当の端の行は X*〉、D が文のまとまりならまとめて消された〈段落の最後なら文の終わりの直後から
        始まり、最初なら文の終わりで終わる〉）の直す手間（足す文字と消す文字の数。まとめて消すのは 1）が、段落の文字とする説明の手間
        以下なら、あいまいとする。
        どの位置でも（enclosed を除く）、X が、docx で向かい合う隣の本文の段落の端の docx の文字に、段落 n の端の文字と同じかそれ以上に
        よく当てはまる（当てはまりが 5 割以上）なら、あいまいとする（隣り合う段落に同じ文があり、隣の段落の行を取ったかもしれない）。"""
        if not self.flow[n] or not self.kept[n]:
            return set(), set()
        lo = self.line_of
        lines, poss = set(), set()
        for step in (1, -1):
            e_ln, inner, D = self.edge_split(n, step)
            if inner is None:
                continue                         # 1 行だけの段落
            i_in, c_in = inner
            in_ln = lo[c_in]
            cross = (e_ln - in_ln) * step < 0    # X が内側の行より外にない（PDF の中の順が docx の順と逆）
            a, b = sorted((e_ln, in_ln))
            gap = [self.line_kind(ln, n, D) for ln in range(a + 1, b)]
            if "own" in gap:
                continue                         # 段落の行が入り組んでいる
            okind, oln, mats = self.outer_line(n, e_ln, step, D)
            sides = ("before", "both") if step > 0 else ("after", "both")
            faces = any(self.mat_side[o] in sides for o in mats)
            material = self.material_after[n] if step > 0 else self.material_before[n]
            if not cross and any(g in ("mat", "free") for g in gap) and okind in ("mat", "free"):
                pos = "enclosed"
            elif cross or (okind == "mat" and faces) or (okind == "free" and material):
                pos = "slot"
            else:
                pos = "body"
            xs = [c for c in self.line_cs(e_ln) if self.own[c] in (-1, n)]
            rs = [c for c in self.line_cs(in_ln) if self.own[c] < 0 and (c > c_in if step > 0 else c < c_in)]
            PX, R = [self.P[c] for c in xs], [self.P[c] for c in rs]

            def cost(text):
                return len(D) + len(text) - 2 * _lcs_prefix(D, text)[-1]
            para_text = R + PX if step > 0 else PX + R
            fit = _lcs_prefix(D, para_text)[-1] / max(1, len(D), len(para_text))
            amb = pos == "enclosed"
            if pos == "slot" and fit < 0.8:
                if fit < 0.4:
                    amb = True
                else:
                    c_para = cost(para_text)
                    alts = [cost(R)]
                    ln = oln
                    for _ in range(40):
                        if ln is None or not 0 <= ln < len(self.st.lines):
                            break
                        kind = self.line_kind(ln, n, D)
                        if kind in ("flow", "own"):
                            break
                        cs = list(self.line_cs(ln))
                        if kind == "free" and len(cs) <= 60 and not self.enclosed_line(n, ln, D):
                            other = [self.P[c] for c in cs]
                            alts.append(cost(R + other if step > 0 else other + R))
                        ln += step
                    tail_text = self.hole_text(n, max(0, i_in - 3), i_in + 1) if step > 0 else ""
                    if _ends_sentence(tail_text) if step > 0 else (_ends_sentence("".join(D)) or D[-1:] in (["、"], [","])):
                        alts.append(1)               # D が文のまとまりで、まとめて消された（X は図の中の文字）
                    amb = min(alts) <= c_para
            if not amb and self.flow[n]:
                m = self.neighbor(n, step)
                if m is not None:
                    _, _, Dm = self.edge_split(m, -step)
                    if Dm:
                        fit_m = _lcs_prefix(Dm, PX)[-1] / max(1, len(Dm), len(PX))
                        fit_n = _lcs_prefix(D, PX)[-1] / max(1, len(D), len(PX))
                        amb = fit_m >= 0.5 and fit_m >= fit_n
            if amb:
                lines.add(e_ln)
                poss.update(self.core[c] for c in xs + rs)
        return lines, poss

