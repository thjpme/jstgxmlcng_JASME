"""ambiguity: 小さな論文 100 本で、_EdgeAudit のメソッドごとの時間（作業用）。  python -I prof2.py SRC"""
import cProfile
import json
import pstats
import sys
src = sys.argv[1]
sys.path.insert(0, src)
from jasme_jats.config import JournalConfig  # noqa: E402
from jasme_jats.pdfdocx import _mechanical  # noqa: E402
from jasme_jats.pdfmatch import compare  # noqa: E402
S = "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad"
jn = JournalConfig.load()
small = json.load(open(S + "/rvB8_regress/fuzz8/m_mix_311/cases.json", encoding="utf-8"))[:100]
plans = [(_mechanical(c["docx"], jn)[1], c["pages"]) for c in small]
pr = cProfile.Profile()
pr.enable()
for plan, pages in plans:
    compare(plan, pages)
pr.disable()
st = pstats.Stats(pr)
for k, v in sorted(st.stats.items(), key=lambda kv: -kv[1][3]):
    if "pdfmatch" in k[0] and k[1] > 1440 and k[1] < 1800:
        print(f"{v[3]:7.3f} {v[2]:7.3f} {v[0]:8d}  {k[2]}:{k[1]}")
print("---- callers of _lcs_prefix")
for k, v in st.stats.items():
    if k[2] == "_lcs_prefix":
        for ck, cv in v[4].items():
            print(f"{cv[3]:7.3f} {cv[0]:6d}  {ck[2]}:{ck[1]}")
print("---- callers of key")
for k, v in st.stats.items():
    if k[2] == "key" and "pdfmatch" in k[0]:
        for ck, cv in sorted(v[4].items(), key=lambda kv: -kv[1][3])[:8]:
            print(f"{cv[3]:7.3f} {cv[0]:8d}  {ck[2]}:{ck[1]}")
