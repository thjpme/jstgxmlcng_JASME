"""ambiguity: test_route2_keeps_note_marks_when_fixing_breaks_notes の照合の違いと skipped を出す（作業用）。 python -I t_notes.py SRC"""
import sys
import tempfile
from pathlib import Path
src = sys.argv[1]
sys.path.insert(0, src)
from jasme_jats import pdfmatch  # noqa: E402
from jasme_jats.config import ArticleMeta, JournalConfig  # noqa: E402
from jasme_jats.pipeline import convert, Options  # noqa: E402
NOTES = Path("/home/user/jstgxmlcng_JASME/tests/fixtures/sample_notes.docx")
pages = ["本文の大きさで書いた注番号1）と，角括弧の注番号［注2］がある文。\n"
         "箇条の番号（1）と（2）は注へのリンクにしない。2 段落からなる注3）もある。\n"
         "注\n１）本文の大きさで書かれた注番号の注である。\n［注2］角括弧で書かれた注番号の注である。\n"
         "３）2 段落からなる注の 1 段落目である。\n"]
pdfmatch.extract_pages = lambda path: pages
meta = ArticleMeta.from_dict({"volume": "31", "issue": "1", "fpage": "1", "lpage": "12", "pub_date": "2026-03-31",
                              "received": "2025-06-01", "accepted": "2025-11-20", "peer_review": "あり",
                              "keywords": "proof; 論証; 数学的探究"})
with tempfile.TemporaryDirectory() as td:
    t = Path(td)
    (t / "dummy.pdf").write_bytes(b"%PDF-1.4\n")
    res = convert(NOTES, meta, JournalConfig.load(), Options(out_dir=t, pdf_path=t / "dummy.pdf", route="pdf",
                                                             convert_metafiles=False))
    for f in res.docx_fix.skipped:
        print("SKIP", f.src, f.kind, repr(f.old), "->", repr(f.new), f.reason[:40])
    for d in res.pdf_check.diffs:
        print("DIFF", d.src, repr(d.docx), "->", repr(d.pdf), d.fixable, d.why[:20])
# まとめての照合の塊（作業用）
from jasme_jats.pipeline import _mechanical  # noqa: E402
P = pdfmatch
_, plan, _ = _mechanical(NOTES, JournalConfig.load())
st = P.pdf_stream(pages)
for n_, ln in enumerate(st.lines):
    print(f"  L{n_:03d} {ln}")
paras, gaps, between = [], [], False
for p in plan.paras.values():
    q, g = P._para_seq(p, {}, {})
    if sum(1 for ch, _ in q if ch != P.SKIP) >= P.MIN_CHARS:
        paras.append((p, q, g)); gaps.append(between); between = False
    else:
        between = between or not p.is_blank
jt = P._Joint(plan, paras, st, gaps)
for step in ("first_pass", "recheck_runs", "fill_holes", "release_islands", "fill_holes", "contests"):
    getattr(jt, step)()
for n_, (p, seq, _) in enumerate(paras):
    lines = {}
    for i, cc in jt.kept[n_]:
        lines.setdefault(jt.line_of[cc], []).append(i)
    print(f"[{p.src}] flow={jt.flow[n_]} side={jt.mat_side[n_] if hasattr(jt, 'mat_side') else '-'} {p.plain()[:30]}")
    for ln, idx in sorted(lines.items()):
        print(f"    L{ln:03d} seq {min(idx)}..{max(idx)} ({len(idx)}) {''.join(seq[i][0] for i in idx)}")
    if hasattr(jt, "edge_audit"):
        print("    audit", jt.edge_audit(n_))
