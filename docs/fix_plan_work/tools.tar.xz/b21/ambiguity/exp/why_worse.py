"""ambiguity: sum_fz.py -v の worse の行（ファイル）の段落ごとに、dbg_fz.py（印を出す src）で、端の見直しの判断の印を出す（作業用）。
  python3 why_worse.py SRC worse.txt f4|f8
"""
import ast
import re
import subprocess
import sys
from collections import Counter

S = "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad"
src, path, what = sys.argv[1:4]
kinds = Counter()
for line in open(path, encoding="utf-8"):
    t = ast.literal_eval(line.split("worse:", 1)[1].strip())
    g, k, doc = t[0], t[1], t[2]
    cases = f"{S}/rvB4_regress/fuzz/{g}/cases.json" if what == "f4" else f"{S}/rvB8_regress/fuzz8/{g}/cases.json"
    out = subprocess.run(["python", "-I", f"{S}/b21/ambiguity/exp/dbg_fz.py", src, cases, str(k), doc[:12]],
                         capture_output=True, text=True).stdout + ""
    err = subprocess.run(["python", "-I", f"{S}/b21/ambiguity/exp/dbg_fz.py", src, cases, str(k), doc[:12]],
                         capture_output=True, text=True).stderr
    srcs = {m.group(1) for m in re.finditer(r"^DIFF (d\d+) .* False PDF の中で", out, re.M)}
    srcs |= {m.group(1) for m in re.finditer(r"^DIFF (d\d+) .* False PDF では", out, re.M)}
    dec = [l for l in err.splitlines() if l.split(" ")[0] in ("RULE0", "RULE1", "POS", "ALTS", "NBHOLE", "NBSWAP") and
           len(l.split(" ")) > 1 and l.split(" ")[1] in srcs]
    hit = [l for l in dec if l.startswith("RULE0") or (l.startswith("POS") and " enclosed " in l) or l.startswith("RULE1") or
           (l.startswith("ALTS") and l.endswith("True")) or (l.startswith("NB") and l.endswith("True"))]
    why = [d for d in out.splitlines() if d.startswith("DIFF") and " False " in d]
    key = hit[0].split(" ")[0] + (":" + hit[0].split(" ")[3] if hit and hit[0].startswith("POS") else "") if hit else "?"
    kinds[key] += 1
    print(g, k, sorted(srcs), "|", " ; ".join(hit)[:200], "|", " ; ".join(w[5:80] for w in why)[:200])
print(dict(kinds))
