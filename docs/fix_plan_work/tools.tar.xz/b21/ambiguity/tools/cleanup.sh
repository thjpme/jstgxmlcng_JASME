#!/bin/sh
# ambiguity: 担当の最後の後片付け。自分が作った oracle/_work の作業フォルダと、大きな出力（docx・pdf・xml・zip、変換の出力フォルダ）、
# 古い src の写しを消す（結果の JSON・ログ・スクリプトと、最後の試作 src〈b21/ambiguity/src〉は残す）。
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
A=$S/b21/ambiguity
cd $S/oracle/_work && for d in $(ls | grep -E "_amb[0-9]+$|^amb_"); do rm -rf "$S/oracle/_work/$d"; done
rm -rf $A/td/*_r1 $A/td/*_r2
rm -rf $A/realpdf/out/docx $A/realpdf/out/run_*
for g in $A/golden_p19 $A/golden_final; do [ -d $g ] && find $g -mindepth 1 -maxdepth 1 -type d -exec rm -rf {} +; done
rm -rf $A/exp/_dbg $A/exp/*_src
rm -rf $A/p*_src
find $A -name __pycache__ -prune -exec rm -rf {} \;
find $A \( -name "*.docx" -o -name "*.pdf" -o -name "*.xml" -o -name "*.zip" \) -print -delete
echo "cleanup done"; du -sh $A
