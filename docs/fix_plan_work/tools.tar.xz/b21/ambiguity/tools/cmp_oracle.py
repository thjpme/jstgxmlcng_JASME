"""ambiguity: 反例集（run_oracle.sh の結果 oracle/results_f4r_<組>_<TAG>.json）を、TAG ごとに反例の判定で比べる。
  python cmp_oracle.py TAG_A TAG_B [組 ...]   （組を省くと o34 n10 n10g rv89 cj cj2 b2 x xm r1 y y2）
TAG_A を基準に、判定が悪くなった（OK < REPORTED < FAIL）・よくなった反例を出す。段落ごとの判定の数も出す。"""
import json
import sys
from collections import Counter
from pathlib import Path

O = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/oracle")
RANK = {"OK": 0, "REPORTED": 1, "FAIL": 2}
a, b = sys.argv[1:3]
sets = sys.argv[3:] or "o34 n10 n10g rv89 cj cj2 b2 x xm r1 y y2".split()
tot = {a: Counter(), b: Counter()}
ptot = {a: Counter(), b: Counter()}
for s in sets:
    fa, fb = O / f"results_f4r_{s}_{a}.json", O / f"results_f4r_{s}_{b}.json"
    if not fa.exists() or not fb.exists():
        print(f"{s}: 結果なし ({fa.exists()}, {fb.exists()})")
        continue
    ra = {r["name"]: r for r in json.load(open(fa, encoding="utf-8"))["cases"]}
    rb = {r["name"]: r for r in json.load(open(fb, encoding="utf-8"))["cases"]}
    ca = Counter(r["verdict"] for r in ra.values())
    cb = Counter(r["verdict"] for r in rb.values())
    tot[a] += ca
    tot[b] += cb
    for t, rr in ((a, ra), (b, rb)):
        ptot[t] += Counter(p["verdict"] for r in rr.values() for p in r["paras"] if p["original"] != p["truth"] or
                           p["verdict"] != "OK")
    worse = [n for n in ra if n in rb and RANK[rb[n]["verdict"]] > RANK[ra[n]["verdict"]]]
    better = [n for n in ra if n in rb and RANK[rb[n]["verdict"]] < RANK[ra[n]["verdict"]]]
    only = sorted(set(rb) - set(ra))
    print(f"{s}: {a} OK {ca['OK']}・REP {ca['REPORTED']}・FAIL {ca['FAIL']} | {b} OK {cb['OK']}・REP {cb['REPORTED']}・"
          f"FAIL {cb['FAIL']} | 悪くなった {len(worse)}・よくなった {len(better)}" + (f"・{b} だけ {len(only)}" if only else ""))
    for n in worse:
        bad = [p for p in rb[n]["paras"] if p["verdict"] != "OK"]
        print(f"   worse {n}: {ra[n]['verdict']}→{rb[n]['verdict']}  " + "; ".join(p["reason"][:90] for p in bad))
    for n in better:
        print(f"   better {n}: {ra[n]['verdict']}→{rb[n]['verdict']}")
print(f"合計 {a}: {dict(tot[a])}  段落 {dict(ptot[a])}")
print(f"合計 {b}: {dict(tot[b])}  段落 {dict(ptot[b])}")
