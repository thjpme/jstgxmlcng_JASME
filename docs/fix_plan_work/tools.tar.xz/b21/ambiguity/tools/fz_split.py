"""ambiguity: fuzz4・fuzz8 の結果を、判定（judge8）と 13 章に出たかで分けて数える（sum_fz.py と同じ判定）。
  python3 fz_split.py f4|f8 TAG..."""
import json
import sys
from collections import Counter
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
V = S / "fixB2r4" / "v"
sys.path.insert(0, str(S / "oracle"))
sys.path.insert(0, str(S / "rvB8_regress" / "fuzz8"))
import judge8  # noqa: E402

what, tags = sys.argv[1], sys.argv[2:]
if what == "f4":
    groups = [(S / "rvB4_regress" / "fuzz" / c / "cases.json", c) for c in
              ("c1", "c8", "c9", "c10", "dense31", "dense32", "h39", "h60")]
    sub = V / "f4"
else:
    groups = [(d / "cases.json", d.name) for d in sorted((S / "rvB8_regress" / "fuzz8").glob("*_3[0-9][0-9]"))
              if (d / "cases.json").exists()]
    sub = V / "f8"
for t in tags:
    cnt = Counter()
    for cases_path, g in groups:
        f = sub / f"{g}_{t}.json"
        if not f.exists():
            cnt["結果なし"] += 1
            continue
        res = json.load(open(f, encoding="utf-8"))
        cases = json.load(open(cases_path, encoding="utf-8"))
        for k, c in enumerate(cases):
            for doc, p in c["truth"].items():
                x = res["cases"][k]["paras"].get(doc)
                if x is None:
                    continue
                vv, _, _ = judge8.verdict(doc, p, x)
                rep = bool(x["skipped"] or x["whys"] or x["unmatched"])
                cnt[vv if vv == "OK" else f"{vv}({'13章' if rep else '黙って'})"] += 1
    print(t, dict(sorted(cnt.items())))
