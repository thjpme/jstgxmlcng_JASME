"""ambiguity: quick の結果で、VIOLATION（足した・消した）の段落を TAG ごとに出す（sum_q.py と同じ判定）。
  python3 q_viol.py TAG"""
import json
import sys
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
V = S / "fixB2r4" / "v" / "q"
sys.path.insert(0, str(S / "oracle"))
sys.path.insert(0, str(S / "fixB2r4" / "tools"))
import quick  # noqa: E402
from runner import describe  # noqa: E402

tag = sys.argv[1]
for line in open(S / "fixB2r4" / "tools" / "qfiles.sh", encoding="utf-8").read().split('"')[1].split():
    p = Path(line.replace("$S", str(S)).strip("\\"))
    if p.suffix not in (".py", ".json"):
        continue
    base = f"{p.parent.name}_{p.stem}"
    f = V / f"{base}_{tag}.json"
    if not f.exists():
        continue
    data = json.loads(f.read_text(encoding="utf-8"))["cases"]
    for name, c in quick.load(p).items():
        r = data.get(name)
        if not r:
            continue
        for src, x in r["paras"].items():
            want = c.get("truth", {}).get(x["orig"], x["orig"])
            if x["fixed"] == want:
                continue
            d = describe(x["orig"], x["fixed"], want)
            if d["added"] or d["deleted"]:
                print(base, name, src, "added", d["added"][:3], "deleted", d["deleted"][:3])
