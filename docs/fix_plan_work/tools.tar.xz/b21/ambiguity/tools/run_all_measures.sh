#!/bin/sh
# ambiguity: 試作 SRC を、生成例・反例集すべて・自分の反例・fuzz4・fuzz8・quick・210 件で測る。 sh run_all_measures.sh SRC TAG
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
A=$S/b21/ambiguity; SRC=$1; TAG=$2
cd /tmp
date
sh $A/tools/gen_all.sh $SRC $TAG > $A/logs/genall_$TAG.log 2>&1
echo "gen done"; date
sh $S/fixB2r4/tools/run_oracle.sh $SRC $TAG o34 n10 n10g rv89 judge judge2 b2 x xm r1 y y2 > $A/logs/oracle_$TAG.log 2>&1
(cd $S/oracle && python run_all.py $SRC $A/cases/cases_amb.py $S/b2_review/r4p/cases_w_only.py --name amb_ca_$TAG > $A/logs/ca_$TAG.log 2>&1)
echo "oracle done"; date
for w in f4 f8 quick b210; do sh $S/fixB2r4/tools/run_suites.sh $SRC $TAG $w 4 > /dev/null 2>&1; echo "$w done"; done
date
echo "ALL DONE $TAG"
