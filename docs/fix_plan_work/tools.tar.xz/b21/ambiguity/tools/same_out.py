"""ambiguity: 2 つの TAG の結果（生成例・反例集・自分の反例・fuzz4・fuzz8・quick・210 件）が同じかを確かめる（速さのための書き換えで
出力が変わっていないことの確かめ）。  python3 same_out.py TAG_A TAG_B"""
import glob
import json
import sys
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
a, b = sys.argv[1:3]


def strip(x):
    """一番上の、版・コードの場所・時間の項目を除く（中の段落の項目はそのまま比べる）。"""
    if isinstance(x, dict):
        return {k: v for k, v in x.items() if k not in ("seconds", "file", "jasme_jats", "version", "src", "time", "elapsed")}
    return x


pairs = []
for fa in glob.glob(str(S / "b21/ambiguity/gen" / f"fz_*_{a}.json")):
    pairs.append((fa, fa.replace(f"_{a}.json", f"_{b}.json")))
for fa in glob.glob(str(S / "oracle" / f"results_f4r_*_{a}.json")) + [str(S / "oracle" / f"results_amb_ca_{a}.json")]:
    pairs.append((fa, fa.replace(f"_{a}.json", f"_{b}.json")))
for sub in ("f4", "f8", "q"):
    for fa in glob.glob(str(S / "fixB2r4/v" / sub / f"*_{a}.json")):
        pairs.append((fa, fa.replace(f"_{a}.json", f"_{b}.json")))
pairs.append((str(S / "fixB2r4/v" / f"fixB210_{a}.json"), str(S / "fixB2r4/v" / f"fixB210_{b}.json")))
same = diff = missing = 0
for fa, fb in pairs:
    if not Path(fb).exists() or not Path(fa).exists():
        missing += 1
        print("ない:", fb)
        continue
    if strip(json.load(open(fa, encoding="utf-8"))) == strip(json.load(open(fb, encoding="utf-8"))):
        same += 1
    else:
        diff += 1
        print("違う:", fb)
print(f"同じ {same}・違う {diff}・ない {missing}")
