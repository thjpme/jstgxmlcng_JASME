"""ambiguity: 生成例（gen_all.sh の結果）を、版（TAG）ごとに数えて比べる。
  python sum_gen.py TAG_A TAG_B [TAG_C ...] [-v 名前の前置き]
反例ごとの判定（いちばん悪い段落）と、段落ごとの判定（OK・REP〈13 章に出して直さない〉・SILENT・FAIL）を数える。
2 つ目以降の TAG は、最初の TAG と段落ごとに比べ、悪くなった・よくなった段落を数える（OK < REP < SILENT < FAIL）。
"""
import json
import sys
from collections import Counter
from pathlib import Path

A = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b21/ambiguity/gen")
RANK = {"OK": 0, "REP": 1, "SILENT": 2, "FAIL": 3}
args = sys.argv[1:]
verbose = None
if "-v" in args:
    k = args.index("-v")
    verbose = args[k + 1] if k + 1 < len(args) else ""
    args = args[:k] + args[k + 2:]
tags = args
kinds = sorted({p.name[3:].rsplit("_", 1)[0] for p in A.glob("fz_*.json")})
tot_case = {t: Counter() for t in tags}
tot_para = {t: Counter() for t in tags}
worse_tot = {t: 0 for t in tags[1:]}
better_tot = {t: 0 for t in tags[1:]}
trans = {t: Counter() for t in tags[1:]}
rows = []
for k in kinds:
    res = {}
    for t in tags:
        f = A / f"fz_{k}_{t}.json"
        if f.exists():
            res[t] = json.load(open(f, encoding="utf-8"))["cases"]
    if len(res) != len(tags):
        continue
    line = [f"{k:14}"]
    for t in tags:
        cc = Counter(v["verdict"] for v in res[t].values())
        pc = Counter(p["v"] for v in res[t].values() for p in v.get("paras", {}).values())
        tot_case[t] += cc
        tot_para[t] += pc
        line.append(f"{t}: case {cc.get('OK',0)}/{cc.get('REP',0)}/{cc.get('SILENT',0)}/{cc.get('FAIL',0)}"
                    f" para {pc.get('OK',0)}/{pc.get('REP',0)}/{pc.get('SILENT',0)}/{pc.get('FAIL',0)}")
    base = res[tags[0]]
    for t in tags[1:]:
        w = b = 0
        for name, v in res[t].items():
            bv = base.get(name, {})
            keys = set(v.get("paras", {})) | set(bv.get("paras", {}))
            for s in keys:
                x = bv.get("paras", {}).get(s, {"v": "OK"})["v"]
                y = v.get("paras", {}).get(s, {"v": "OK"})["v"]
                if x != y:
                    trans[t][f"{x}→{y}"] += 1
                if RANK[y] > RANK[x]:
                    w += 1
                    if verbose is not None and name.startswith(verbose):
                        print(f"  worse {t} {name} {s}: {x}→{y}", v["paras"].get(s, {}).get("fixed", "")[:60])
                elif RANK[y] < RANK[x]:
                    b += 1
        worse_tot[t] += w
        better_tot[t] += b
        line.append(f"[{t} vs {tags[0]}: worse {w} better {b}]")
    rows.append("  ".join(line))
for r in rows:
    print(r)
print()
for t in tags:
    cc, pc = tot_case[t], tot_para[t]
    print(f"合計 {t}: case OK {cc['OK']}・REP {cc['REP']}・SILENT {cc['SILENT']}・FAIL {cc['FAIL']}"
          f"  | para OK {pc['OK']}・REP {pc['REP']}・SILENT {pc['SILENT']}・FAIL {pc['FAIL']}")
for t in tags[1:]:
    print(f"{t} vs {tags[0]}: 悪くなった段落 {worse_tot[t]}・よくなった段落 {better_tot[t]}  ", dict(trans[t].most_common()))
