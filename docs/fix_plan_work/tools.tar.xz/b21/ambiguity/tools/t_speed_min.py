"""ambiguity: 照合（compare）の速さ（n10/judge/tools/t_speed.py と同じもの。小さな論文 100 本も 3 回の最小にする）。
  python -I t_speed_min.py SRC"""
import json
import sys
import time
from pathlib import Path
src = sys.argv[1]
sys.path.insert(0, src)
from jasme_jats.config import JournalConfig  # noqa: E402
from jasme_jats.pdfdocx import _mechanical  # noqa: E402
from jasme_jats.pdfmatch import compare, extract_pages  # noqa: E402
J = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/n10/judge")
S = J.parents[1]
jn = JournalConfig.load()
real = []
for d in sorted((J / "realpdf" / "out" / "docx").glob("*.docx")):
    stem = "_".join(d.stem.split("_")[:4])
    real.append((extract_pages(Path("/home/user/jstgxmlcng_JASME/tests/private/pdf") / f"{stem}.pdf"), _mechanical(d, jn)[1]))
small = json.load(open(S / "rvB8_regress" / "fuzz8" / "m_mix_311" / "cases.json", encoding="utf-8"))[:100]
plans = [(_mechanical(c["docx"], jn)[1], c["pages"]) for c in small]


def run(items, reps=3):
    best = None
    for _ in range(reps):
        t0 = time.perf_counter()
        for a, b in items:
            compare(b, a) if items is real else compare(a, b)
        t = time.perf_counter() - t0
        best = t if best is None else min(best, t)
    return best


print(json.dumps({"real_total": run(real), "small100": run(plans)}))
