"""ambiguity: td_cmp_compare.py の結果（cmp_<TAG>.json）を 2 つ比べ、直す箇所（理由なし）が増えた・減ったもの、直せない違い
（fixable=False）が増えた・減ったものを数える（作業用。文字は出さず、段落 ID と位置と長さだけ出す）。
  python3 tdcmp.py A.json B.json [-v]"""
import json
import sys

a, b = (json.load(open(p, encoding="utf-8")) for p in sys.argv[1:3])
verbose = "-v" in sys.argv
for t in sorted(a):
    fa = {(f[0], f[1], f[2], f[3], f[4]) for f in a[t]["fixes"] if not f[5]}
    fb = {(f[0], f[1], f[2], f[3], f[4]) for f in b[t]["fixes"] if not f[5]}
    sa = {(f[0], f[1], f[2], f[3], f[4]) for f in a[t]["fixes"] if f[5]}
    sb = {(f[0], f[1], f[2], f[3], f[4]) for f in b[t]["fixes"] if f[5]}
    da = {(d[0], d[3], d[4], d[1], d[2]) for d in a[t]["diffs"] if not d[5]}
    db = {(d[0], d[3], d[4], d[1], d[2]) for d in b[t]["diffs"] if not d[5]}
    print(f"{t}: 直す箇所 {len(fa)}→{len(fb)}（減 {len(fa - fb)}・増 {len(fb - fa)}） 直さない箇所 {len(sa)}→{len(sb)} "
          f"直せない違い {len(da)}→{len(db)}（減 {len(da - db)}・増 {len(db - da)}） 照合に使わなかった文字 "
          f"{len(a[t]['ignored'])}→{len(b[t]['ignored'])}")
    if verbose:
        for x in sorted(fa - fb):
            print("   直さなくなった", x[0], x[1], x[2], "長さ", len(x[3]), x[4])
        for x in sorted(fb - fa):
            print("   直すようになった", x[0], x[1], x[2], "長さ", len(x[3]), x[4])
        for x in sorted(db - da):
            print("   直せない違いが増えた", x[0], x[1], x[2], "docx", len(x[3]), "pdf", len(x[4]))
