"""反例集（b21/evidence: 単位 B2.1〈0.21.1〉の設計の試作「証拠の重み」の担当）。文字はすべて架空。

oracle/run_all.py の書式（oracle/runner.py の docstring）。実行（scratchpad の oracle/ で）:
  python run_all.py <src> ../b21/evidence/cases_ev.py --name <名前>
期待は原則だけで決める（出版版 PDF の本文と同じにする。組版の文字・図や表の中の文字・ほかの段落の文字を足さない。本文の文字を
消さない。決められないものは docx のまま 13 章に出す）。

B2 の 4 回目の点検で残った 6 件（b2_review/workflow_final.json の remaining）と、それまでの点検の指摘の形を、組み合わせを広げて
作り直したもの:
  ev_hf_*     残り 1（blocking）: 段落 P_AFTER のすぐ前に小さな図（docx では画像。キャプションは図の下）があり、PDF では図の中の
              文字・キャプション・P_AFTER の順。図の中の行が P_AFTER の書き出しとよく似ている（手順・写し）か、似ていない（対照）。
              書き出しは校正で直されている（置き換え・大きな書き換え・1 文字の削除・足した語・消した語）か、直されていない（対照）
  ev_face_*   残り 2・5（should）: 段落の最後の 1 行が受付日の行（・柱）の後ろに出て、すぐ後ろに表・図のキャプション（本当の
              段落の行）。その後ろの段落の書き出しも校正で直されている。頭の側（段落の最初の行が図のキャプションと受付日の行の
              間）で、前の段落の最後の文が消されている形も
  ev_st_*     残り 3（should）: 段落の最後の文が校正で消され、消された文とよく似た 1〜2 行の図（・1 行だけの表）が次のページの
              最初にある
  ev_bl_*     残り 4（nit）: 本当の最後の行が校正で大きく書き換えられ、すぐ後ろに図の上のキャプション、その下に docx の最後の
              語句とよく似た図の中の行がある（同じページ・ページの区切り）
  ev_num_*    残り 6（nit）: 段落が表で分断され、表のすぐ後ろの数が直されている（「12点」→「13点」）。表のキャプションの「１」
              （全角・半角）と docx の「1」が並ぶ
  ev_pos_*    本当の直し（13.2 に回すと手で確かめる箇所が増える）: 段落の最後の行が小さな図・表の後ろに出る、受付日の行の後ろに
              出る、段落の最初の行が図の前に出る形で、その行に校正の直しがある（直すのが望ましい）
"""
from __future__ import annotations

import sys
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
sys.path.insert(0, str(S / "n10"))
sys.path.insert(0, str(S / "oracle"))

from runner import BREAK, Raw, flow, received_line  # noqa: E402
import cases_n10 as N  # noqa: E402

CASES = []
Z_CAP = "図１　架空の授業の流れ"
HEAD = "試験　五郎"            # 次のページの最初の柱（8 文字未満の著者名）


def case(name, paras, pages, note, truth=None, expect="exact", item="N20"):
    CASES.append({"name": name, "angle": "layout", "item": item, "paras": paras, "truth": truth or {},
                  "pages": pages, "expect": expect, "note": note})


def idx(paras, text):
    found = [i for i, (_, t) in enumerate(paras) if t == text]
    if len(found) != 1:
        raise ValueError(f"段落「{str(text)[:16]}」が {len(found)} 個")
    return found[0]


def tail_blocks():
    return [N.RH, Raw(*N.REF1_LINES), Raw(*N.REF2_LINES), BREAK, N.en_block()]


def front_blocks():
    return [N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2]


def put_head(pages, k=1, head=HEAD):
    """k 番目のページの最初（ページ番号の行の後ろ）に柱を入れる。"""
    ls = pages[k].split("\n")
    pages[k] = "\n".join(ls[:1] + [head] + ls[1:])
    return pages


def paras_with(target, between, after=N.P_AFTER, extra_after=()):
    return ([("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("見出し", N.H2), ("本文", target),
             *between, ("本文", after), *extra_after, ("見出し", N.H3), ("本文", N.P_DISC), ("本文", N.P_END),
             ("引用文献見出し", N.RH), ("引用文献", N.REF1), ("引用文献", N.REF2)])


def base_truth(paras, extra):
    t = {idx(paras, N.CTRL_DOCX): N.CTRL_PUB}
    t.update(extra)
    return t


# ============================================================================ ev_hf_*（残り 1）
HF_FIGS = {
    "step": ["導入", "↓", "話し合いの中で考える", "↓", "まとめ"],
    "step2": ["導入", "話し合いの中で考える", "まとめ"],
    "copy": ["導入", "↓", "話し合いの中で，ある", "↓", "まとめ"],
    "copylong": ["導入", "↓", "話し合いの中で，ある生徒は", "↓", "まとめ"],
    "far": ["導入", "↓", "課題の提示", "↓", "まとめ"],          # 対照（似ていない図）
}
HF_EDITS = {
    "none": None,
    "w1": ("話し合いの中で", "議論の中で"),
    "heavy": ("話し合いの中で，ある生徒は", "議論の場で，一人の生徒が"),
    "c1": ("話し合いの", "話合いの"),
    "add": ("", "その後，"),
    "del": ("そこで，", ""),
}
for fk, fig in HF_FIGS.items():
    for ek, e in HF_EDITS.items():
        if e is None:
            dt = pt = N.P_AFTER
        elif e[0] == "":
            dt, pt = N.P_AFTER, e[1] + N.P_AFTER
        elif e[1] == "":
            dt, pt = e[0] + N.P_AFTER, N.P_AFTER
        else:
            dt, pt = N.P_AFTER, N.P_AFTER.replace(e[0], e[1], 1)
        paras = paras_with(N.TARGET, [("画像", "".join(fig)), ("図キャプション", Z_CAP)], after=dt)
        for bk in ("direct", "pbhead", "date"):
            first = [*front_blocks(), Raw(*N.body(N.TARGET))]
            if bk == "date":
                first += [Raw(received_line()), BREAK]
            elif bk == "pbhead":
                first += [BREAK]
            pages = flow(first + [Raw(*fig, Z_CAP), Raw(*N.body(pt)), N.H3, Raw(*N.body(N.P_DISC)),
                                  Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
            if bk == "pbhead":
                put_head(pages)
            truth = base_truth(paras, {idx(paras, dt): pt} if dt != pt else {})
            exp = {"default": "exact", idx(paras, dt): "reported"} if dt != pt else "exact"
            case(f"ev_hf_{fk}_{ek}_{bk}", paras, pages,
                 f"段落の書き出し（{'直しなし' if e is None else f'「{e[0]}」→「{e[1]}」'}）のすぐ前に小さな図（行「"
                 f"{'／'.join(fig)}」。キャプションは図の下）がある。図の中の文字を足さない・本文を消さない。直すか、決められなければ "
                 "docx のまま 13 章に出す。", truth=truth, expect=exp)

# ============================================================================ ev_face_*（残り 2・5）
W_DEL = "その結果を表に示す。"
F_TCAP, F_ROWS = N.table_rows(20)
F_TAIL_EDITS = {"e4": (N.TARGET, N.TARGET[:-4] + "持った。"), "delsent": (N.TARGET + W_DEL, N.TARGET)}
F_HEAD_EDITS = {"none": (N.P_AFTER, N.P_AFTER), "w1": (N.P_AFTER, N.P_AFTER.replace("話し合いの中で", "議論の中で")),
                "del": ("そこで，" + N.P_AFTER, N.P_AFTER), "add": (N.P_AFTER, "その後，" + N.P_AFTER)}
for ek, (dt, pt) in F_TAIL_EDITS.items():
    lines = N.body(pt)
    for hk, (da, pa) in F_HEAD_EDITS.items():
        for mk in ("tab", "figabove"):
            if mk == "tab":
                mat = [("表キャプション", F_TCAP), ("表", F_ROWS)]
                mid = N.table_lines(F_TCAP, F_ROWS)
            else:
                mat = [("図キャプション", Z_CAP), ("画像", "授業の流れ")]
                mid = [Z_CAP, "導入", "↓", "課題の提示", "↓", "まとめ"]
            paras = paras_with(dt, mat, after=da)
            for ak in ("date", "coldate", "datehead"):
                head = [Raw(*lines[:-1]), Raw(received_line())] + ([] if ak == "coldate" else [BREAK])
                pages = flow([*front_blocks(), *head, Raw(lines[-1]), Raw(*mid), Raw(*N.body(pa)), N.H3,
                              Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
                if ak == "datehead":
                    put_head(pages)
                ex = {idx(paras, dt): pt}
                if da != pa:
                    ex[idx(paras, da)] = pa
                case(f"ev_face_{ek}_{hk}_{mk}_{ak}", paras, pages,
                     f"段落の最後の行「{lines[-1]}」が受付日の行の後ろに出て、すぐ後ろに"
                     f"{'表のキャプション' if mk == 'tab' else '図の上のキャプション'}がある（本当の段落の行）。後ろの段落の書き出しは"
                     f"{'直されていない' if da == pa else '校正で直されている'}。どちらも出版版の文字に直す（0.20.0 は直す）。",
                     truth=base_truth(paras, ex))

# 頭の側: 段落 P_AFTER の最初の行が、図のキャプション（図の下）のすぐ後ろ、1 ページ目の最後の受付日の行の前にある。前の段落
# TARGET の最後の文が消されている（delsent）か、最後の語句が書き換えられている（nostop）か、直されていない（none）
FH_PREV = {"none": (N.TARGET, N.TARGET), "delsent": (N.TARGET + W_DEL, N.TARGET),
           "nostop": (N.TARGET, N.TARGET.replace("時間を取った。", "場を設けた。"))}
FH_HEAD = N.P_AFTER.replace("話し合いの中で", "議論の中で")
for pk, (dt, pt) in FH_PREV.items():
    for ak in ("date", "coldate"):
        hl = N.body(FH_HEAD)
        paras = paras_with(dt, [("画像", "授業の流れ"), ("図キャプション", Z_CAP)])
        head = [Raw(*N.body(pt)), Raw("導入", "↓", "課題の提示", "↓", "まとめ", Z_CAP), Raw(hl[0]), Raw(received_line())]
        head += [] if ak == "coldate" else [BREAK]
        pages = flow([*front_blocks(), *head, Raw(*hl[1:]), N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)),
                      *tail_blocks()], first=25)
        ex = {idx(paras, N.P_AFTER): FH_HEAD}
        if dt != pt:
            ex[idx(paras, dt)] = pt
        case(f"ev_facehead_{pk}_{ak}", paras, pages,
             f"段落の最初の行「{hl[0]}」（「話し合いの中で」→「議論の中で」）が、図のキャプションのすぐ後ろ、受付日の行の前にある"
             "（本当の段落の行）。前の段落の最後は" + {"none": "直されていない", "delsent": "最後の文が消されている",
                                                        "nostop": "語句が書き換えられている"}[pk] + "。出版版の文字に直す。",
             truth=base_truth(paras, ex))

# ============================================================================ ev_st_*（残り 3）
ST_DELS = {
    "s1": ("課題の提示を行った。", ["課題の把握"]),
    "s2": ("課題の提示を行った。", ["導入", "課題の把握"]),
    "copy": ("課題の提示を行った。", ["課題の提示"]),
    "s5": ("その後，表にまとめた。", ["表にまとめる"]),
}
for dk, (dele, fig) in ST_DELS.items():
    dt = N.TARGET + dele
    for mk in ("fig", "tab"):
        if mk == "fig":
            mat = [("画像", "".join(fig)), ("図キャプション", Z_CAP)]
            mid = [*fig, Z_CAP]
        else:
            mat = [("表", [[x] for x in fig]), ("表キャプション", N.TAB_CAP20)]
            mid = [*fig, N.TAB_CAP20]
        paras = paras_with(dt, mat)
        for bk in ("pb", "pbhead", "datepb", "col"):
            first = [*front_blocks(), Raw(*N.body(N.TARGET))]
            if bk in ("datepb", "col"):
                first.append(Raw(received_line()))
            if bk != "col":
                first.append(BREAK)
            pages = flow(first + [Raw(*mid), Raw(*N.body(N.P_AFTER)), N.H3, Raw(*N.body(N.P_DISC)),
                                  Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
            if bk == "pbhead":
                put_head(pages)
            case(f"ev_st_{dk}_{mk}_{bk}", paras, pages,
                 f"docx の段落の最後の文「{dele}」は出版版で消されている。次のページの最初（区切り: {bk}）に、消された文とよく似た"
                 f"{'小さな図' if mk == 'fig' else '小さな表'}（行「{'／'.join(fig)}」）がある。図・表の文字を足さない。消すか、"
                 "決められなければ docx のまま 13 章に出す。",
                 truth=base_truth(paras, {idx(paras, dt): N.TARGET}),
                 expect={"default": "exact", idx(paras, dt): "reported"})

# ============================================================================ ev_bl_*（残り 4）
BL_PUB = N.TARGET.replace("で説明し合う時間を取った。", "で議論する場を設けた。")
for fk, figline in (("sim", "説明し合う時間を取る"), ("copy", "説明し合う時間を取った"), ("far", "課題の提示")):
    paras = paras_with(N.TARGET, [("図キャプション", Z_CAP), ("画像", figline)])
    lines = N.body(BL_PUB)
    for bk in ("direct", "pb", "pbhead"):
        first = [*front_blocks(), Raw(*lines)]
        if bk != "direct":
            first = [*front_blocks(), Raw(*lines[:-1]), BREAK, Raw(lines[-1])]
        pages = flow(first + [Raw(Z_CAP, "導入", "↓", figline, "↓", "まとめ"), Raw(*N.body(N.P_AFTER)), N.H3,
                              Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
        if bk == "pbhead":
            put_head(pages)
        case(f"ev_bl_{fk}_{bk}", paras, pages,
             "段落の最後の行（本当の段落の行）が校正で「で説明し合う時間を取った。」→「で議論する場を設けた。」と書き換えられ、"
             f"すぐ後ろに図の上のキャプション、その下に図の中の行「{figline}」がある。出版版の文字に直す。",
             truth=base_truth(paras, {idx(paras, N.TARGET): BL_PUB}))

# ============================================================================ ev_num_*（残り 6）
NUM_BODY = "架空の調査の結果を表１に示す。その結果，生徒の平均は12点であり，前回の調査より高かった。"
NUM_ROWS = [["組の名前", "一回目の得点", "二回目の得点"], ["第一の組", "31", "27"], ["第二の組", "14", "23"]]
for ck, cap in (("zen", "表１　架空の組ごとの得点"), ("han", "表1　架空の組ごとの得点")):
    for nk, new in (("13", "13点"), ("fw13", "１３点"), ("same", "12点")):
        pub = NUM_BODY.replace("12点", new)
        paras = paras_with(NUM_BODY, [("表キャプション", cap), ("表", NUM_ROWS)])
        cut = pub.index(new)
        cells = [c for row in NUM_ROWS for c in row]
        for bk in ("mid", "pb"):
            blocks = [*front_blocks(), Raw(*N.body(N.TARGET)), Raw(*N.body(pub[:cut])), Raw(cap, *cells)]
            if bk == "pb":
                blocks.append(BREAK)
            blocks += [Raw(*N.jwrap(pub[cut:])), Raw(*N.body(N.P_AFTER)), N.H3, Raw(*N.body(N.P_DISC)),
                       Raw(*N.body(N.P_END)), *tail_blocks()]
            pages = flow(blocks, first=25)
            truth = base_truth(paras, {idx(paras, NUM_BODY): pub} if pub != NUM_BODY else {})
            exp = {"default": "exact", idx(paras, NUM_BODY): "reported"} if pub != NUM_BODY else "exact"
            case(f"ev_num_{ck}_{nk}_{bk}", paras, pages,
                 f"段落が表（キャプション「{cap}」）で分断され、表のすぐ後ろの数が「12点」→「{new}」。キャプションの数字と docx の"
                 "数字を並べて、docx にも PDF にもない数（「113点」）にしない。直すか、決められなければ docx のまま 13 章に出す。",
                 truth=truth, expect=exp)

# ============================================================================ ev_pos_*（本当の直し）
FLOW_FIGS = {"recall": ["導入", "↓", "前時の表を振り返る"], "task": ["課題の提示", "↓", "個人で考える時間"],
             "seeline": ["導入", "↓", "時間を見る"]}
for fk, fig in FLOW_FIGS.items():
    for cut, tail in ((7, "時間を設けた。"), (4, "持った。"), (9, "合う場を設けた。")):
        pub = N.TARGET[:-cut] + tail
        paras = paras_with(N.TARGET, [("画像", "".join(fig)), ("図キャプション", Z_CAP)])
        for bk in ("direct", "pb"):
            blocks = [*front_blocks(), Raw(*N.body(N.TARGET[:-cut])), Raw(*fig, Z_CAP)]
            if bk == "pb":
                blocks.insert(-1, BREAK)
            blocks += [Raw(tail), Raw(*N.body(N.P_AFTER)), N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)),
                       *tail_blocks()]
            pages = flow(blocks, first=25)
            case(f"ev_pos_figtail_{fk}_{cut}_{bk}", paras, pages,
                 f"段落の最後の {len(tail)} 文字「{tail}」（docx「{N.TARGET[-cut:]}」の校正の直し）が、小さな図（行「{'／'.join(fig)}」"
                 "とキャプション）の後ろに出る。本当の段落の行なので直す。",
                 truth=base_truth(paras, {idx(paras, N.TARGET): pub}),
                 expect={"default": "exact", idx(paras, N.TARGET): "reported"})
# 段落の最後の行が受付日の行（・柱）の後ろに出て、すぐ後ろが次の段落（キャプションなし）
for cut, tail in ((4, "持った。"), (7, "時間を設けた。")):
    pub = N.TARGET[:-cut] + tail
    paras = paras_with(N.TARGET, [])
    lines = N.body(N.TARGET[:-cut])
    for ak in ("date", "datehead", "coldate"):
        blocks = [*front_blocks(), Raw(*lines), Raw(received_line())] + ([] if ak == "coldate" else [BREAK])
        blocks += [Raw(tail), Raw(*N.body(N.P_AFTER)), N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)),
                   *tail_blocks()]
        pages = flow(blocks, first=25)
        if ak == "datehead":
            put_head(pages)
        case(f"ev_pos_datetail_{cut}_{ak}", paras, pages,
             f"段落の最後の {len(tail)} 文字「{tail}」（校正の直し）が受付日の行の後ろに出て、すぐ後ろが次の段落。直す。",
             truth=base_truth(paras, {idx(paras, N.TARGET): pub}))
# 段落の最初の行が図の前に出る（docx では図が段落のすぐ前）。最初の行に校正の直しがあり、図の中の行は似ていない
for ek, (old, new) in (("w1", ("話し合いの中で", "議論の中で")), ("c1", ("話し合いの", "話合いの"))):
    pa = N.P_AFTER.replace(old, new, 1)
    paras = paras_with(N.TARGET, [("画像", "導入課題の提示まとめ"), ("図キャプション", Z_CAP)])
    hl = N.body(pa)
    for bk in ("direct", "pb"):
        blocks = [*front_blocks(), Raw(*N.body(N.TARGET)), Raw(hl[0])]
        if bk == "pb":
            blocks.append(BREAK)
        blocks += [Raw("導入", "↓", "課題の提示", "↓", "まとめ", Z_CAP), Raw(*hl[1:]), N.H3, Raw(*N.body(N.P_DISC)),
                   Raw(*N.body(N.P_END)), *tail_blocks()]
        pages = flow(blocks, first=25)
        case(f"ev_pos_headfig_{ek}_{bk}", paras, pages,
             f"段落の最初の行「{hl[0]}」（「{old}」→「{new}」）の後ろに小さな図（docx では段落のすぐ前）がある。本当の段落の行なので"
             "直す。", truth=base_truth(paras, {idx(paras, N.P_AFTER): pa}),
             expect={"default": "exact", idx(paras, N.P_AFTER): "reported"})
