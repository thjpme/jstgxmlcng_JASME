"""evidence: 乱数の例（fuzz4・fuzz8）の段落の判定を、OK / MISS(13章) / MISS(黙って) / VIOLATION(13章) / VIOLATION(黙って) に
分けて版ごとに数える（sum_fz.py と同じ判定。judge8.verdict と、13 章に出るか〈直さなかった箇所・直せない違い・見つからない段落〉）。
  python fz4way.py f4|f8 TAG..."""
import json
import sys
from collections import Counter
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
V = S / "fixB2r4" / "v"
sys.path.insert(0, str(S / "oracle"))
sys.path.insert(0, str(S / "rvB8_regress" / "fuzz8"))
import judge8  # noqa: E402

what, tags = sys.argv[1], sys.argv[2:]
if what == "f4":
    groups = [(S / "rvB4_regress" / "fuzz" / c / "cases.json", c) for c in
              ("c1", "c8", "c9", "c10", "dense31", "dense32", "h39", "h60")]
    sub = V / "f4"
else:
    groups = [(d / "cases.json", d.name) for d in sorted((S / "rvB8_regress" / "fuzz8").glob("*_3[0-9][0-9]"))
              if (d / "cases.json").exists()]
    sub = V / "f8"
tot = {t: Counter() for t in tags}
for cases_path, g in groups:
    res = {t: json.load(open(sub / f"{g}_{t}.json", encoding="utf-8")) for t in tags}
    cases = json.load(open(cases_path, encoding="utf-8"))
    for k, c in enumerate(cases):
        for doc, p in c["truth"].items():
            if any(doc not in res[t]["cases"][k]["paras"] for t in tags):
                continue
            for t in tags:
                x = res[t]["cases"][k]["paras"][doc]
                vv, _, _ = judge8.verdict(doc, p, x)
                rep = bool(x["skipped"] or x["whys"] or x["unmatched"])
                tot[t][vv if vv == "OK" else f"{vv}({'13章' if rep else '黙って'})"] += 1
keys = ["OK", "MISS(13章)", "MISS(黙って)", "VIOLATION(13章)", "VIOLATION(黙って)"]
print("版  " + " / ".join(keys))
for t in tags:
    print(t, " / ".join(str(tot[t][k]) for k in keys))
