"""evidence: oracle（run_all.py）の結果を、反例の名前の組（前置き）ごとに、段落の判定（osum.py と同じ分け方: OK・VIOL・SILENT・
MISS）で数えて版を並べる。

  python gsum_cases.py 名前... [--depth N] [--only 前置き] [-v]

名前は oracle/results_<名前>.json。--depth は組の名前に使う「_」で区切った部分の数（既定 3。ev_hf_step_w1_direct → ev_hf_step）。
-v を付けると、版ごとに OK でない段落を出す。
"""
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

O = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/oracle")
argv = sys.argv[1:]
depth = 3
only = ""
if "--depth" in argv:
    k = argv.index("--depth")
    depth = int(argv[k + 1])
    del argv[k:k + 2]
if "--only" in argv:
    k = argv.index("--only")
    only = argv[k + 1]
    del argv[k:k + 2]
verbose = "-v" in argv
names = [a for a in argv if not a.startswith("-")]


def sections(r13):
    out, cur = {}, None
    for ln in (r13 or "").splitlines():
        m = re.match(r"### (13\.\d)", ln)
        if m:
            cur = m.group(1)
            out[cur] = ""
            continue
        if cur:
            out[cur] += ln + "\n"
    return out


def kind(case, p):
    if p["verdict"] == "OK":
        return "OK"
    reason = p.get("reason") or ""
    if "足した" in reason or "消した" in reason or "truth を書いていない" in reason or p.get("fixed") is None:
        return "VIOL"
    sec = sections(case.get("report13"))
    src = p["src"]
    hit = any(re.search(rf"(?<![0-9A-Za-z_]){re.escape(src)}(?![0-9])", sec.get(s, "")) for s in ("13.2", "13.4", "13.5", "13.6"))
    return "MISS" if hit else "SILENT"


table = defaultdict(lambda: defaultdict(Counter))
bad = defaultdict(list)
for name in names:
    d = json.loads((O / f"results_{name}.json").read_text(encoding="utf-8"))
    for c in d["cases"]:
        if not c["name"].startswith(only):
            continue
        g = "_".join(c["name"].split("_")[:depth])
        for p in c["paras"]:
            if p.get("truth") is None and p["verdict"] == "OK":
                continue
            k = kind(c, p)
            if k == "OK" and p.get("original") == p.get("fixed") and p.get("truth") in (None, p.get("original")):
                continue
            table[g][name][k] += 1
            if k != "OK":
                bad[name].append((c["name"], p["src"], k, (p.get("reason") or "")[:140]))
w = max([len(g) for g in table] + [4])
print("組".ljust(w) + "  " + "  ".join(f"{n[-14:]:>22}" for n in names))
print(" " * w + "  " + "  ".join(f"{'OK/MISS/SIL/VIOL':>22}" for _ in names))
tot = {n: Counter() for n in names}
for g in sorted(table):
    cells = []
    for n in names:
        c = table[g][n]
        tot[n].update(c)
        cells.append(f"{c['OK']:>4}/{c['MISS']:>4}/{c['SILENT']:>4}/{c['VIOL']:>4}".rjust(22))
    print(g.ljust(w) + "  " + "  ".join(cells))
print("合計".ljust(w) + "  " + "  ".join(f"{tot[n]['OK']:>4}/{tot[n]['MISS']:>4}/{tot[n]['SILENT']:>4}/{tot[n]['VIOL']:>4}".rjust(22)
                                         for n in names))
if verbose:
    for n in names:
        print(f"\n[{n}]")
        for cn, src, k, r in bad[n]:
            print(f"  {k:6} {cn} {src}: {r}")
