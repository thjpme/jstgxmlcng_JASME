#!/bin/sh
# evidence: 1 つの版（SRC・TAG）で、物差しをすべて順に実行する。  sh master_ev.sh SRC TAG [real]
# 結果: 点検の例・乱数の例・210 件は fixB2r4/v（TAG 付き）、反例集は oracle/results_*_TAG.json、生成例は fixB2r4/gen と
# b21/evidence/gen、golden は b21/evidence/v/golden_TAG、ログは fixB2r4/logs と b21/evidence/logs。
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
F=$S/fixB2r4; E=$S/b21/evidence; L=$E/logs; SRC=$1; TAG=$2
echo "start $TAG $(date +%T)"
sh $F/tools/run_suites.sh $SRC $TAG quick 4 > /dev/null; echo "quick $(date +%T)"
sh $F/tools/run_oracle.sh $SRC $TAG o34 n10 n10g rv89 judge judge2; rm -rf $S/oracle/_work/f4r_*_$TAG
sh $F/tools/run_oracle.sh $SRC $TAG b2 x xm r1 y y2; rm -rf $S/oracle/_work/f4r_*_$TAG
(cd $S/oracle && python run_all.py $SRC $E/cases_ev.py $S/b2_review/r5p/cases_v_only.py $S/b2_review/r4p/cases_w_only.py --name ev_rem_$TAG > $L/rem_$TAG.log 2>&1; grep "^合計" $L/rem_$TAG.log); rm -rf $S/oracle/_work/ev_rem_$TAG
echo "oracle $(date +%T)"
sh $F/tools/run_suites.sh $SRC $TAG f4 4 > /dev/null; echo "f4 $(date +%T)"
(cd $E && PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=$SRC python $S/golden/golden.py $E/v/golden_$TAG > $L/golden_$TAG.log 2>&1); echo "golden $(date +%T)"
sh $F/tools/run_suites.sh $SRC $TAG b210 1 > /dev/null; echo "b210 $(date +%T)"
sh $F/tools/run_suites.sh $SRC $TAG f8 4 > /dev/null; echo "f8 $(date +%T)"
sh $F/gen.sh $SRC $TAG; sh $E/tools/run_gen5.sh $SRC $TAG; echo "gen $(date +%T)"
if [ "$3" = real ]; then
  (cd $E/realpdf && python -I check.py --before-src $S/n10/judge/base_src --after-src $SRC --route1 --tag _$TAG > $L/real_$TAG.log 2>&1); echo "real $(date +%T)"
  sh $E/tools/run_td.sh $SRC $TAG; echo "td $(date +%T)"
fi
echo "end $TAG $(date +%T)"
