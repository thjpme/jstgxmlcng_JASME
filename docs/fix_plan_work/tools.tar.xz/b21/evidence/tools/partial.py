"""evidence（isolate の道具の写し）: 直した後の文字 fixed が、docx から truth への違い（difflib の opcodes の違う部分）の一部だけを当てはめた文字か
（部分的に直しただけで、足し・消しのないものか）を確かめる。  from partial import is_partial"""
import difflib
from itertools import combinations


def is_partial(docx: str, fixed: str, truth: str, limit: int = 12) -> bool:
    ops = [o for o in difflib.SequenceMatcher(None, docx, truth, autojunk=False).get_opcodes()]
    regions = [o for o in ops if o[0] != "equal"]
    if len(regions) > limit:
        return False
    for r in range(len(regions) + 1):
        for sub in combinations(range(len(regions)), r):
            out, x = [], 0
            chosen = {regions[i][1:] for i in sub}
            for tag, i1, i2, j1, j2 in ops:
                if tag == "equal":
                    out.append(docx[i1:i2])
                elif (i1, i2, j1, j2) in chosen:
                    out.append(truth[j1:j2])
                else:
                    out.append(docx[i1:i2])
            if "".join(out) == fixed:
                return True
    return False
