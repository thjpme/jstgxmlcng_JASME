"""isolate: pytest のプラグイン。tests/test_pdfmatch.py の changed_paragraphs が空でない（落ちる）ときの段落の文字を記録する。
  ISO_LOG=<json> で、テストごとに [{"src", "got", "want", "docx", "reported"}] を書く。"""
import json
import os

import pytest

REC = {}


def pytest_runtest_setup(item):
    mod = getattr(item, "module", None)
    if mod is None or not hasattr(mod, "changed_paragraphs"):
        return
    if not getattr(mod, "_iso_orig", None):
        mod._iso_orig = mod.changed_paragraphs

    def wrapped(plan, pc, want, _orig=mod._iso_orig, _id=item.nodeid):
        out = _orig(plan, pc, want)
        for s, t in out.items():
            REC.setdefault(_id, []).append({
                "src": s, "got": t, "want": want.get(s, plan.paras[s].plain()), "docx": plan.paras[s].plain(),
                "reported": bool(any(d.src == s and not d.fixable for d in pc.diffs) or s in pc.unmatched
                                 or any(x[0] == s for x in pc.ignored_lines)),
                "whys": sorted({(d.why or "")[:12] for d in pc.diffs if d.src == s and not d.fixable})})
        return out
    mod.changed_paragraphs = wrapped


def pytest_sessionfinish(session):
    path = os.environ.get("ISO_LOG")
    if path:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(REC, f, ensure_ascii=False, indent=1)
