#!/bin/sh
# evidence（isolate の道具の写し）: 本体の tests を SRC のコードで実行し、落ちたテストの段落の文字を LOG に記録する。 sh pytest_iso.sh SRC PY LOG [pytest の引数...]
SRC=$(cd "$1" && pwd); PY=$2; LOG=$3; shift 3
H=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
cd /home/user/jstgxmlcng_JASME && ISO_LOG=$LOG PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$H/fixB2r4/tools/pt:$H/b21/evidence/tools/pt:$SRC" \
  $PY -m pytest -p no:cacheprovider -p judge_which -p isoplug -o pythonpath="$SRC /home/user/jstgxmlcng_JASME/tests" "$@"
