"""evidence: 本誌の出版版 PDF の確かめ（realpdf/check.py）の results_after_<TAG>.json を 2 つ比べ、仕事（PDF・docx の種類）ごとに、
直した箇所・違い（直せる・直さない）・照合に使わなかった文字・見つからない段落・XML の文字が同じかを出す（数とハッシュだけ。本文の
文字は出さない）。
  python realcmp.py A.json B.json"""
import hashlib
import json
import sys


def h(x):
    return hashlib.sha1(json.dumps(x, ensure_ascii=False, sort_keys=True).encode()).hexdigest()[:10]


a, b = (json.load(open(p, encoding="utf-8"))["jobs"] for p in sys.argv[1:3])
for job in sorted(set(a) | set(b)):
    x, y = a.get(job), b.get(job)
    if not x or not y:
        print(job, "片方にない")
        continue
    row = []
    for k in ("fixes", "diffs", "ignored", "unmatched", "xml_text", "report13"):
        same = h(x.get(k)) == h(y.get(k))
        n1 = len(x.get(k) or [])
        n2 = len(y.get(k) or [])
        row.append(f"{k}:{'同' if same else f'違 {n1}→{n2}'}")
    nfx = sum(1 for d in y.get("diffs") or [] if isinstance(d, dict) and not d.get("fixable", True))
    print(job, " ".join(row), f"直さない違い(後) {nfx}")
