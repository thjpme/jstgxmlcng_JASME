#!/bin/sh
# evidence: 版ごとの物差しの数を並べる。 sh report_ev.sh TAG...（最初の TAG が比べる相手。0.20.0 は isobase、0.21.0 は isov021）
# 0.20.0・0.21.0 の数は、isolate の担当が同じ道具で測ったもの（isobase・isov021。fixB2r4/v・oracle/results_*・gen）を使う。
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
F=$S/fixB2r4; E=$S/b21/evidence
echo "== quick"; python3 $F/tools/sum_q.py "$@" 2>&1 | tail -4
echo "== fuzz4"; python3 $F/tools/sum_fz.py f4 "$@" 2>&1 | grep -v "^     " | head -12
echo "== fuzz8"; python3 $F/tools/sum_fz.py f8 "$@" 2>&1 | grep -v "^     " | head -12
echo "== fuzz8 足した段落"; python3 -I $F/tools/added_count.py "$@"
echo "== oracle"
for set in o34 n10 n10g rv89 cj cj2 b2 x xm r1 y y2; do
  args=""; for t in "$@"; do args="$args f4r_${set}_$t"; done
  echo "-- $set"; python3 $E/tools/osum.py $args 2>&1 | sed -n '/^版/,/^$/p' | grep -v "^$"
done
echo "== gen"; python3 $E/tools/gsum.py "$@" 2>&1 | sed -n '/^版/,/^$/p'
