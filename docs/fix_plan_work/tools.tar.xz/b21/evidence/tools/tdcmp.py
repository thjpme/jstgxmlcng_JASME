"""evidence（isolate の道具の写し）: td1〜3 の照合の結果（run_td.sh の cmp_<TAG>.json）を版で比べる（段落 ID と数だけを出す。本文の文字は出さない）。
  python tdcmp.py TAG_A TAG_B"""
import json
import sys
from collections import Counter
from pathlib import Path

D = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b21/evidence/td")
a = json.loads((D / f"cmp_{sys.argv[1]}.json").read_text(encoding="utf-8"))
b = json.loads((D / f"cmp_{sys.argv[2]}.json").read_text(encoding="utf-8"))
for k in a:
    x, y = a[k], b[k]

    def stats(r):
        nf = sum(1 for d in r["diffs"] if not d[5])
        why = Counter(d[6] for d in r["diffs"] if not d[5])
        applied = [tuple(f) for f in r["fixes"] if not f[5]]
        skipped = [tuple(f) for f in r["fixes"] if f[5]]
        return nf, why, applied, skipped
    nfa, wa, apa, ska = stats(x)
    nfb, wb, apb, skb = stats(y)
    print(f"{k}: 直せない違い {nfa}→{nfb}  直す箇所 {len(apa)}→{len(apb)}  直さない箇所 {len(ska)}→{len(skb)}  "
          f"照合に使わなかった文字 {len(x['ignored'])}→{len(y['ignored'])}  同じ: {x == y}")
    if wa != wb:
        print("   直せない違いの理由:", dict(wa), "→", dict(wb))
    gone = set(apa) - set(apb)
    new = set(apb) - set(apa)
    if gone or new:
        print("   直さなくなった段落:", sorted({f[0] for f in gone}), " 新しく直す段落:", sorted({f[0] for f in new}))
