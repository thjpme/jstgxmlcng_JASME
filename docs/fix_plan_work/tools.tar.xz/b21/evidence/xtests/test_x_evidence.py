"""evidence（単位 B2.1 の設計の試作「証拠の重み」）のテストの案。本体に入れるときは tests/test_pdfmatch.py に足す。文字はすべて架空。

B2 の 4 回目の点検で残った 6 件（N20）の形と、試作で足した守り（隣の段落の照合で使われなかった行と並ぶ docx の端の文字を
消さない）の形。どれも、出版版の文字に直すか、決められなければ docx のまま直さない違いとして 13 章に出すことを確かめる
（図・表の中の文字・ほかの段落の文字を足さない。本文の文字を消さない）。

  sh .../fixB2r4/tools/pytest_src.sh <src> python3 -q .../b21/evidence/xtests/test_x_evidence.py
"""
import pytest

from jasme_jats.config import JournalConfig
from test_pdfmatch import (LESSON, N10_TAIL, R1, SHORT_CAP, SHORT_CELLS, SMALL_FIG_CAP, SMALL_FIG_STEPS, SMALL_FRONT,
                           SURVEY, TALK, body_lines, compare, fixed_texts, n10_article, n10_pages, wrap_lines)


@pytest.fixture
def journal():
    return JournalConfig.load()


def check(plan, pc, src, docx, pub):
    """直した後の段落 src の文字が docx か pub で、ほかの段落は変わらない。docx のままなら、直さない違いが 13 章に出る。"""
    got = fixed_texts(plan, pc)
    assert got[src] in (docx, pub), got[src]
    assert all(t == plan.paras[s].plain() for s, t in got.items() if s != src)
    if got[src] == docx and docx != pub:
        assert any(d.src == src and not d.fixable for d in pc.diffs)
    return got[src]


HEAD_FIGS = {"step": ["導入", "↓", "話し合いの中で考える", "↓", "まとめ"],
             "copy": ["導入", "↓", "話し合いの中で，ある", "↓", "まとめ"]}
HEAD_EDITS = {"w1": ("話し合いの中で", "議論の中で"), "heavy": ("話し合いの中で，ある生徒は", "議論の場で，一人の生徒が")}


@pytest.mark.parametrize("before", ["direct", "head-next-page", "date-page-end"])
@pytest.mark.parametrize("edit", list(HEAD_EDITS))
@pytest.mark.parametrize("fig", list(HEAD_FIGS))
def test_figure_line_before_caption_is_not_used_as_first_line(fig, edit, before, journal, tmp_path):
    """N20 の残り 1（blocking）: 段落のすぐ前に小さな図（キャプションは図の下）があり、図の中の行が段落の書き出しとよく似ている
    （手順「話し合いの中で考える」・写し「話し合いの中で，ある」）。書き出しが校正で直されていても、図の中の文字を段落に足さない
    （0.21.0 は「話し合いの中で考える議論の中で，…」にしていた。0.20.0 は直す）。"""
    pub = TALK.replace(*HEAD_EDITS[edit], 1)
    plan, src = n10_article(tmp_path, journal, [("body", LESSON), ("image", "fig"), ("fig_cap", SMALL_FIG_CAP),
                                                ("body", TALK), ("body", SURVEY)])
    first = [*SMALL_FRONT, *body_lines(LESSON)]
    rest = [*HEAD_FIGS[fig], SMALL_FIG_CAP, *body_lines(pub), *body_lines(SURVEY), *N10_TAIL]
    pages = {"direct": lambda: n10_pages([*first, *rest]), "head-next-page": lambda: n10_pages(first, ["試験　六郎", *rest]),
             "date-page-end": lambda: n10_pages([*first, R1], rest)}[before]()
    check(plan, compare(plan, pages), src[TALK], TALK, pub)


@pytest.mark.parametrize("after", ["date-page-end", "date-column", "date-head-next-page"])
@pytest.mark.parametrize("next_edit", ["word", "deleted-head"])
@pytest.mark.parametrize("material", ["table", "figure-above"])
def test_last_line_after_date_line_is_fixed_when_next_head_is_edited(material, next_edit, after, journal, tmp_path):
    """N20 の残り 2・5: 段落の最後の 1 行（本当の段落の行。「取った」→「持った」）が受付日の行の後ろに出て、すぐ後ろに表・図の
    キャプションがある。表・図の後ろの段落の書き出しも校正で直されていても（「話し合いの中で」→「議論の中で」、頭の「そこで，」を
    消す）、両方を出版版の文字に直す（0.21.0 は前の段落の直しを直さずに 13.2 に回していた。0.20.0 は直す）。"""
    docx, pub = LESSON, LESSON.replace("時間を取った", "時間を持った")
    t_docx, t_pub = (TALK, TALK.replace("話し合いの中で", "議論の中で")) if next_edit == "word" else ("そこで，" + TALK, TALK)
    if material == "table":
        mat, mid = [("tab_cap", SHORT_CAP), ("table", SHORT_CELLS)], [SHORT_CAP] + [" ".join(r) for r in SHORT_CELLS]
    else:
        mat, mid = [("fig_cap", SMALL_FIG_CAP), ("image", "fig")], [SMALL_FIG_CAP, *SMALL_FIG_STEPS, "まとめ"]
    plan, src = n10_article(tmp_path, journal, [("body", docx), *mat, ("body", t_docx), ("body", SURVEY)])
    lines = body_lines(pub)
    first = [*SMALL_FRONT, *lines[:-1], R1]
    rest = [lines[-1], *mid, *body_lines(t_pub), *body_lines(SURVEY), *N10_TAIL]
    pages = {"date-page-end": lambda: n10_pages(first, rest), "date-column": lambda: n10_pages([*first, *rest]),
             "date-head-next-page": lambda: n10_pages(first, ["試験　六郎", *rest])}[after]()
    pc = compare(plan, pages)
    got = fixed_texts(plan, pc)
    assert got[src[docx]] == pub
    # 後ろの段落の頭の「そこで，」は、図の上のキャプションの後ろの図の中の文字に続くので、決められずに docx のまま 13 章に出ることがある
    # （0.20.0・0.21.0 と同じ）
    assert got[src[t_docx]] == t_pub or (got[src[t_docx]] == t_docx and any(d.src == src[t_docx] and not d.fixable
                                                                              for d in pc.diffs))


@pytest.mark.parametrize("prev_edit", ["deleted-sentence", "rewritten-end"])
@pytest.mark.parametrize("after", ["date-page-end", "date-column"])
def test_first_line_before_date_line_is_fixed_when_prev_tail_is_edited(prev_edit, after, journal, tmp_path):
    """N20 の残り 2・5 の頭の側: 段落の最初の行（「話し合いの中で」→「議論の中で」）が、図のキャプション（図の下）のすぐ後ろ、
    1 ページ目の最後の受付日の行の前にある。図の前の段落の最後の文が消されている・最後の語句が書き換えられていても、段落の
    最初の行の直しを直す（0.21.0 は直さずに 13.2 に回していた）。前の段落も出版版の文字にするか、docx のまま 13 章に出す。"""
    l_docx, l_pub = ((LESSON + "その結果を表に示す。", LESSON) if prev_edit == "deleted-sentence" else
                     (LESSON, LESSON.replace("時間を取った。", "場を設けた。")))
    pub = TALK.replace("話し合いの中で", "議論の中で")
    plan, src = n10_article(tmp_path, journal, [("body", l_docx), ("image", "fig"), ("fig_cap", SMALL_FIG_CAP),
                                                ("body", TALK), ("body", SURVEY)])
    hl = body_lines(pub)
    first = [*SMALL_FRONT, *body_lines(l_pub), *SMALL_FIG_STEPS, "まとめ", SMALL_FIG_CAP, hl[0], R1]
    rest = [*hl[1:], *body_lines(SURVEY), *N10_TAIL]
    pages = n10_pages(first, rest) if after == "date-page-end" else n10_pages([*first, *rest])
    pc = compare(plan, pages)
    got = fixed_texts(plan, pc)
    assert got[src[TALK]] == pub
    assert got[src[l_docx]] in (l_docx, l_pub)


SIM_TOP = {"sim": ["課題の把握"], "sim2": ["導入", "課題の把握"], "copy": ["課題の提示"]}


@pytest.mark.parametrize("brk", ["page", "head-next-page", "date-page-end"])
@pytest.mark.parametrize("material", ["figure", "table"])
@pytest.mark.parametrize("fig", list(SIM_TOP))
def test_deleted_last_sentence_with_similar_figure_at_next_page_top(fig, material, brk, journal, tmp_path):
    """N20 の残り 3: 段落の最後の文（「課題の提示を行った。」）が校正で消され、次のページの最初に、消された文とよく似た 1〜2 行の
    小さな図・1 行だけの表（「課題の把握」）がある。図・表の文字を足さない（0.21.0 は「…取った。課題の把握」にしていた。1 行
    だけの表は 0.20.0 も足していなかった）。消すか、決められなければ docx のまま 13 章に出す。"""
    docx = LESSON + "課題の提示を行った。"
    if material == "figure":
        mat, mid = [("image", "fig"), ("fig_cap", SMALL_FIG_CAP)], [*SIM_TOP[fig], SMALL_FIG_CAP]
    else:
        mat, mid = [("table", [[x] for x in SIM_TOP[fig]]), ("tab_cap", SHORT_CAP)], [*SIM_TOP[fig], SHORT_CAP]
    plan, src = n10_article(tmp_path, journal, [("body", docx), *mat, ("body", TALK), ("body", SURVEY)])
    p1 = [*SMALL_FRONT, *body_lines(LESSON)]
    p2 = [*mid, *body_lines(TALK), *body_lines(SURVEY), *N10_TAIL]
    pages = {"page": lambda: n10_pages(p1, p2), "head-next-page": lambda: n10_pages(p1, ["試験　六郎", *p2]),
             "date-page-end": lambda: n10_pages([*p1, R1], p2)}[brk]()
    check(plan, compare(plan, pages), src[docx], docx, LESSON)


@pytest.mark.parametrize("brk", ["direct", "page", "head-next-page"])
@pytest.mark.parametrize("figline", ["説明し合う時間を取る", "説明し合う時間を取った"])
def test_rewritten_last_line_before_caption_above_similar_figure_is_not_mixed(figline, brk, journal, tmp_path):
    """N20 の残り 4（nit）: 本当の最後の行が校正で大きく書き換えられ（「で説明し合う時間を取った。」→「で議論する場を設けた。」）、
    すぐ後ろに図の上のキャプション、その下に docx の最後の語句とよく似た図の中の行がある。図の中の行の文字を段落に足さない
    （0.20.0 は足していた）。図の中の行と並べた docx の最後の語句が段落の文字だという証拠が足りないので、直さずに 13.2 に出してよい
    （0.21.0 と同じ。図の中の行を外して照合し直すと、本当の段落の行を外したときに、docx の文字をほかの文字に置き換えてしまう）。"""
    pub = LESSON.replace("で説明し合う時間を取った。", "で議論する場を設けた。")
    plan, src = n10_article(tmp_path, journal, [("body", LESSON), ("fig_cap", SMALL_FIG_CAP), ("image", "fig"),
                                                ("body", TALK), ("body", SURVEY)])
    lines = body_lines(pub)
    fig = [SMALL_FIG_CAP, "導入", "↓", figline, "↓", "まとめ"]
    rest = [*fig, *body_lines(TALK), *body_lines(SURVEY), *N10_TAIL]
    pages = {"direct": lambda: n10_pages([*SMALL_FRONT, *lines, *rest]),
             "page": lambda: n10_pages([*SMALL_FRONT, *lines[:-1]], [lines[-1], *rest]),
             "head-next-page": lambda: n10_pages([*SMALL_FRONT, *lines[:-1]], ["試験　六郎", lines[-1], *rest])}[brk]()
    check(plan, compare(plan, pages), src[LESSON], LESSON, pub)


NUM_BODY = "架空の調査の結果を表１に示す。その結果，生徒の平均は12点であり，前回の調査より高かった。"
NUM_NEXT = "次の段落は表の後ろに続く本文の段落であり，照合の確かめに使う。"
NUM_ROWS = [["組の名前", "一回目の得点", "二回目の得点"], ["第一の組", "31", "27"], ["第二の組", "14", "23"]]


@pytest.mark.parametrize("brk", ["same-page", "next-page"])
@pytest.mark.parametrize("new", ["13点", "１３点"])
@pytest.mark.parametrize("cap", ["表１　架空の組ごとの得点", "表1　架空の組ごとの得点"], ids=["cap-zen", "cap-han"])
def test_number_next_to_caption_digit_is_not_mixed(cap, new, brk, journal, tmp_path):
    """N20 の残り 6（nit）: 段落が表（キャプション「表１…」）で分断され、表のすぐ後ろの数が直されている（「12点」→「13点」）。
    キャプションの「１」と並べた docx の「1」を残したまま隣の「2」を「13」にして、docx にも PDF の本文にもない「113点」に
    しない（0.21.0・0.20.0 はそうしていた。キャプションが半角の「表1」なら 13 章にも出なかった）。"""
    pub = NUM_BODY.replace("12点", new)
    plan, src = n10_article(tmp_path, journal, [("body", NUM_BODY), ("tab_cap", cap), ("table", NUM_ROWS),
                                                ("body", NUM_NEXT)])
    cut = pub.index(new)
    cells = [c for row in NUM_ROWS for c in row]
    head = [*SMALL_FRONT, *body_lines(pub[:cut]), cap, *cells]
    tail = [*wrap_lines(pub[cut:]), *body_lines(NUM_NEXT), *N10_TAIL]
    pages = n10_pages([*head, *tail]) if brk == "same-page" else n10_pages(head, tail)
    check(plan, compare(plan, pages), src[NUM_BODY], NUM_BODY, pub)


def test_tail_taken_by_next_paragraph_with_same_sentence_is_not_deleted(journal, tmp_path):
    """試作で足した守り: 段落 A の最後の行（「時間を取った。」。docx は「取った．」）がページの最後にあり、次の段落 B が同じ文
    （「説明し合う時間を取った。…」）で始まって書き出しが直されている（「取った」→「設けた」）。まとめての照合が A の最後の行を
    B に置き、B の照合ではその行が使われないとき、A の最後の docx の文字を消さない（0.21.0 は「…説明し合う」に消していた。
    0.20.0 は直す）。"""
    docx = LESSON.replace("時間を取った。", "時間を取った．")
    b_docx = "説明し合う時間を取った。その後，教師は二つの説明を並べて板書し，違いを問うた。"
    b_pub = b_docx.replace("取った", "設けた")
    plan, src = n10_article(tmp_path, journal, [("body", docx), ("body", b_docx), ("body", SURVEY)])
    p1 = [*SMALL_FRONT, *body_lines(LESSON[:-7]), LESSON[-7:]]
    p2 = ["試験　六郎", *body_lines(b_pub), *body_lines(SURVEY), *N10_TAIL]
    pc = compare(plan, n10_pages(p1, p2))
    got = fixed_texts(plan, pc)
    assert got[src[docx]] in (docx, LESSON)
    assert got[src[b_docx]] in (b_docx, b_pub)


FIG_INNER = {"tail3": "時間を取る", "copy7": "説明し合う時間", "pre4": "時間を取"}
CONT_EDITS = {"w1": ("時間を取った。", "時間を持った。"), "w3": ("時間を取った。", "場を設けた。")}


@pytest.mark.parametrize("brk", ["direct", "date-page-end", "head-next-page"])
@pytest.mark.parametrize("edit", list(CONT_EDITS))
@pytest.mark.parametrize("inner", list(FIG_INNER))
def test_matched_line_inside_figure_before_continuation_is_not_used(inner, edit, brk, journal, tmp_path):
    """試作で足した見方（図の中の小さな部分）: 段落の最後の 7 文字が小さな図（キャプションは図の下）の後ろに分断され、図の中の
    最後の行（キャプションのすぐ前）が docx の最後の語句とよく似ている。続きの行は校正で直されている。図の中の行と並べた docx の
    文字を残して続きの行の文字を足し、docx にも PDF にもない「…時間を取る時間を持った。」にしない（0.21.0・0.20.0 はそうして
    いた）。図の中の短い行は段落の文字だという証拠が足りないので、その位置の違いは直さずに docx のまま 13 章に出す。"""
    pub = LESSON.replace(*CONT_EDITS[edit])
    plan, src = n10_article(tmp_path, journal, [("body", LESSON), ("image", "fig"), ("fig_cap", SMALL_FIG_CAP),
                                                ("body", TALK), ("body", SURVEY)])
    p1 = [*SMALL_FRONT, *body_lines(pub[:-7]), *SMALL_FIG_STEPS, FIG_INNER[inner], SMALL_FIG_CAP, pub[-7:]]
    rest = [*body_lines(TALK), *body_lines(SURVEY), *N10_TAIL]
    pages = {"direct": lambda: n10_pages([*p1, *rest]), "date-page-end": lambda: n10_pages([*p1, R1], rest),
             "head-next-page": lambda: n10_pages(p1, ["試験　六郎", *rest])}[brk]()
    check(plan, compare(plan, pages), src[LESSON], LESSON, pub)



FAR_NEW = {"w2": "話し合わせた。", "w4": "議論が深まる場面もみられる。"}


@pytest.mark.parametrize("new", list(FAR_NEW))
def test_rewritten_last_sentence_after_table_is_not_deleted(new, journal, tmp_path):
    """試作で足した見方（消す前の証拠）: 段落の最後の語句（「時間を取った。」）が、PDF では表（キャプションとセル）の後ろに出て、
    校正で大きく書き換えられている（docx の文字と 3 分の 1 も似ていない）。表の後ろの、次の段落のすぐ前の行は文の終わりで終わる
    （段落の最後の行らしい）ので、docx の文字を校正で消されたものとして消さない（0.21.0・0.20.0 は消していた）。直すか、決められ
    なければ docx のまま 13 章に出す。"""
    head = LESSON[:-len("時間を取った。")]
    pub = head + FAR_NEW[new]
    plan, src = n10_article(tmp_path, journal, [("body", LESSON), ("tab_cap", SHORT_CAP), ("table", SHORT_CELLS),
                                                ("body", TALK), ("body", SURVEY)])
    cells = [" ".join(r) for r in SHORT_CELLS]
    pages = n10_pages([*SMALL_FRONT, *body_lines(head), SHORT_CAP, *cells, *wrap_lines(FAR_NEW[new]), *body_lines(TALK),
                       *body_lines(SURVEY), *N10_TAIL])
    check(plan, compare(plan, pages), src[LESSON], LESSON, pub)


def test_deleted_last_sentence_before_table_is_still_deleted(journal, tmp_path):
    """上の対照: 段落の最後の文（「以上が第三時の流れである。」）が校正で消され、段落のすぐ後ろに表があり、表の後ろはすぐ次の
    段落（文の終わりで終わる行はない）。今までどおり消す（0.21.0 と同じ）。"""
    docx = LESSON + "以上が第三時の流れである。"
    plan, src = n10_article(tmp_path, journal, [("body", docx), ("tab_cap", SHORT_CAP), ("table", SHORT_CELLS),
                                                ("body", TALK), ("body", SURVEY)])
    cells = [" ".join(r) for r in SHORT_CELLS]
    pages = n10_pages([*SMALL_FRONT, *body_lines(LESSON), SHORT_CAP, *cells, *body_lines(TALK), *body_lines(SURVEY), *N10_TAIL])
    assert fixed_texts(plan, compare(plan, pages))[src[docx]] == LESSON
