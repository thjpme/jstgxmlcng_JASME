"""judge（B2.1）: 2 つの py ファイルの、docstring を除いた AST の違う関数・文を出す（docstring とコメントだけの変更か確かめる）。
  python astdiff.py A.py B.py"""
import ast
import sys


def strip(tree):
    for n in ast.walk(tree):
        if isinstance(n, (ast.FunctionDef, ast.ClassDef, ast.Module, ast.AsyncFunctionDef)) and n.body and \
                isinstance(n.body[0], ast.Expr) and isinstance(getattr(n.body[0], "value", None), ast.Constant) and \
                isinstance(n.body[0].value.value, str):
            n.body = n.body[1:] or [ast.Pass()]
    return tree


a, b = (strip(ast.parse(open(p, encoding="utf-8").read())) for p in sys.argv[1:3])


def items(t):
    out = {}
    for n in t.body:
        name = getattr(n, "name", None) or ast.dump(n)[:60]
        out[name] = ast.dump(n)
    return out


ia, ib = items(a), items(b)
for k in sorted(set(ia) | set(ib)):
    if ia.get(k) != ib.get(k):
        print("違う:", k[:80], "" if k in ia else "(B だけ)", "" if k in ib else "(A だけ)")
