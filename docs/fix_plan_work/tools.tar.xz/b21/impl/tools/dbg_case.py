"""judge（B2.1）: 反例 1 件を SRC のコードで動かし、_isolate と _plain_tail の判定を出す（作業用）。
  python dbg_case.py SRC 反例のファイル 反例の名前"""
import importlib.util
import sys
from pathlib import Path
src, cf, name = sys.argv[1:4]
sys.path.insert(0, src)
O = "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/oracle"
sys.path.insert(1, O)
import jasme_jats.pdfmatch as pm  # noqa: E402
spec = importlib.util.spec_from_file_location("cf", cf)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
case = next(c for c in m.CASES if c["name"] == name)
for i, p in enumerate(case["pages"]):
    print(f"--- page {i}")
    print(p)
orig_iso = pm._isolate
def iso(*a, **k):
    r = orig_iso(*a, **k)
    st = a[4]
    if r[3] or r[2]:
        print("ISOLATE", a[0], "fb,fe", r[0], r[1], "head_far", r[2], "tail_far", r[3],
              "lines", {ln: st.lines[ln] for ln in sorted((r[3] or (0, set()))[1])})
    return r
pm._isolate = iso
if hasattr(pm, "_plain_tail"):
    orig_pt = pm._plain_tail
    def pt(*a, **k):
        r = orig_pt(*a, **k)
        st = a[4]
        body_ln = a[3][0]
        print("PLAIN_TAIL", a[0], r, "body_ln", body_ln, repr(st.lines[body_ln]), "ends_flow", pm._ends_flow(st, body_ln, a[7]),
              "width", a[7])
        return r
    pm._plain_tail = pt
import runner  # noqa: E402
r = runner.run_case(case, Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b21/judge/work") / name)
print(r["verdict"])
for p in r["paras"]:
    if p["verdict"] != "OK":
        print(p["src"], p["verdict"], p["reason"][:200])
