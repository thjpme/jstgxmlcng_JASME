"""judge（B2.1）: 生成例 1 件を SRC のコードで動かし、PDF の行と、_isolate・_plain_tail の判定と、直した文字を出す（作業用）。
  python -I dbg_gen.py SRC GENFILE 名前"""
import importlib.util
import sys
import tempfile
from pathlib import Path
src, gen, name = sys.argv[1:4]
sys.path.insert(0, src)
sys.path.insert(1, "/home/user/jstgxmlcng_JASME/tests")
spec = importlib.util.spec_from_file_location("tp", "/home/user/jstgxmlcng_JASME/tests/test_pdfmatch.py")
T = importlib.util.module_from_spec(spec)
spec.loader.exec_module(T)
from jasme_jats.config import JournalConfig  # noqa: E402
import jasme_jats.pdfmatch as pm  # noqa: E402
T.JOURNAL = JournalConfig.load()
sys.path.insert(2, str(Path(gen).resolve().parent))
spec2 = importlib.util.spec_from_file_location("gen", gen)
G = importlib.util.module_from_spec(spec2)
spec2.loader.exec_module(G)
case = next(c for c in G.make_cases(T) if c["name"] == name)
if hasattr(pm, "_isolate"):
    orig_iso = pm._isolate

    def iso(*a, **k):
        r = orig_iso(*a, **k)
        st = a[4]
        if r[2] or r[3]:
            print("ISOLATE", a[0], "b,e", r[0], r[1], "head_far", r[2], "tail_far", r[3])
        return r
    pm._isolate = iso
if hasattr(pm, "_plain_tail"):
    orig_pt = pm._plain_tail

    def pt(*a, **k):
        r = orig_pt(*a, **k)
        print("PLAIN_TAIL", a[0], r)
        return r
    pm._plain_tail = pt
with tempfile.TemporaryDirectory() as tmp:
    plan, s = T.n10_article(Path(tmp), T.JOURNAL, case["blocks"])
    pages = T.n10_pages(*case["pages"])
    for i, p in enumerate(pages):
        print(f"--- page {i}")
        for n, ln in enumerate(p.splitlines()):
            print(f"  {n:2} {ln}")
    pc = pm.compare(plan, pages)
    got = T.fixed_texts(plan, pc)
    for d, pub in case["want"].items():
        print("docx :", d[-40:])
        print("pub  :", pub[-40:])
        print("fixed:", got[s[d]][-40:])
    for d in pc.diffs:
        print(" diff", d.src, d.fixable, repr(d.docx[-15:]), repr(d.pdf[-30:]), (d.why or "")[:20])
