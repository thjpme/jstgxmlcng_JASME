"""judge（B2.1）: test_heavily_edited_tail_after_split_is_not_deleted の 1 つの形の、照合の違いを出す（作業用）。
  python dbg_heavy.py SRC split after"""
import sys
import tempfile
from pathlib import Path
src, split, after = sys.argv[1:4]
sys.path.insert(0, src)
sys.path.insert(1, "/home/user/jstgxmlcng_JASME/tests")
import importlib.util
spec = importlib.util.spec_from_file_location("tp", "/home/user/jstgxmlcng_JASME/tests/test_pdfmatch.py")
T = importlib.util.module_from_spec(spec)
spec.loader.exec_module(T)
from jasme_jats.config import JournalConfig
j = JournalConfig.load()
old, new = "時間を取った。", "場を設けて話し合わせた。"
pub = T.LESSON[:-len(old)] + new
blocks, middle, rest = T.split_tail_blocks(split)
with tempfile.TemporaryDirectory() as td:
    plan, srcmap = T.n10_article(Path(td), j, blocks)
    head = [*T.SMALL_FRONT, *T.body_lines(T.LESSON[:-len(old)]), *middle, *T.wrap_lines(new)]
    pages = {"none": lambda: T.n10_pages([*head, *rest, *T.N10_TAIL]),
             "date-page-end": lambda: T.n10_pages([*head, T.R1], [*rest, *T.N10_TAIL]),
             "head-next-page": lambda: T.n10_pages(head, ["試験　六郎", *rest, *T.N10_TAIL])}[after]()
    print(pages[0][-400:])
    pc = T.compare(plan, pages)
    for d in pc.diffs:
        if d.src == srcmap[T.LESSON]:
            print("DIFF", repr(d.docx), "->", repr(d.pdf), d.fixable, d.why[:30])
    print("GOT", T.fixed_texts(plan, pc)[srcmap[T.LESSON]][-30:])
