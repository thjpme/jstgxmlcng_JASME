"""judge（B2.1）: test_heavily_edited_tail_after_split_is_not_deleted の paragraph の形で、段落 LESSON の違い（diffs）を出す（作業用）。
  python dbg_heavy2.py SRC after"""
import sys
from pathlib import Path
src, after = sys.argv[1:3]
sys.path.insert(0, src)
sys.path.insert(1, "/home/user/jstgxmlcng_JASME/tests")
from jasme_jats.config import JournalConfig  # noqa: E402
import test_pdfmatch as T  # noqa: E402
journal = JournalConfig.load()
old, new = "時間を取った。", "場を設けて話し合わせた。"
pub = T.LESSON[:-len(old)] + new
blocks, middle, rest = T.split_tail_blocks("paragraph")
tmp = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b21/judge/work/heavy")
plan, s = T.n10_article(tmp, journal, blocks)
head = [*T.SMALL_FRONT, *T.body_lines(T.LESSON[:-len(old)]), *middle, *T.wrap_lines(new)]
pages = {"none": lambda: T.n10_pages([*head, *rest, *T.N10_TAIL]),
         "date-page-end": lambda: T.n10_pages([*head, T.R1], [*rest, *T.N10_TAIL]),
         "head-next-page": lambda: T.n10_pages(head, ["試験　六郎", *rest, *T.N10_TAIL])}[after]()
pc = T.compare(plan, pages)
got = T.fixed_texts(plan, pc)[s[T.LESSON]]
print("kept docx" if got == T.LESSON else "fixed" if got == pub else "OTHER " + got[-30:])
for d in pc.diffs:
    if d.src == s[T.LESSON]:
        print(" diff fixable=%s docx=%r pdf=%r why=%s" % (d.fixable, d.docx[-20:], d.pdf[-30:], (d.why or "")[:30]))
for line in pages[0].splitlines()[-12:]:
    print("  |", line)
