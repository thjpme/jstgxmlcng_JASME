"""judge（B2.1。b21/isolate/tools から写したもの）: 乱数の例（fuzz4・fuzz8）を版ごとに数える。judge8 の VIOLATION のうち、docx から truth への違いの一部だけを当てはめた
もの（部分的に直しただけで、足し・消しのないもの。judge8 の比べ方では、truth に同じ文字が並ぶと「消した」に見える）を PARTIAL として
分ける（tools/partial.py）。段落の文字は出さない。
  python fzsum2.py f4|f8 TAG...      # 最初の TAG が比べる相手"""
import json
import sys
from collections import Counter
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
sys.path.insert(0, str(S / "oracle"))
sys.path.insert(0, str(S / "rvB8_regress" / "fuzz8"))
sys.path.insert(0, str(Path(__file__).parent))
import judge8  # noqa: E402
from partial import is_partial  # noqa: E402

what, tags = sys.argv[1], sys.argv[2:]
V = S / "fixB2r4" / "v"
if what == "f4":
    groups = [(S / "rvB4_regress" / "fuzz" / c / "cases.json", c) for c in
              ("c1", "c8", "c9", "c10", "dense31", "dense32", "h39", "h60")]
    sub = V / "f4"
else:
    groups = [(d / "cases.json", d.name) for d in sorted((S / "rvB8_regress" / "fuzz8").glob("*_3[0-9][0-9]"))
              if (d / "cases.json").exists()]
    sub = V / "f8"
tot = {t: Counter() for t in tags}
trans = {t: Counter() for t in tags[1:]}
worse = {t: [] for t in tags[1:]}
for cases_path, g in groups:
    res = {t: json.load(open(sub / f"{g}_{t}.json", encoding="utf-8")) for t in tags}
    cases = json.load(open(cases_path, encoding="utf-8"))
    for k, c in enumerate(cases):
        for doc, p in c["truth"].items():
            if any(doc not in res[t]["cases"][k]["paras"] for t in tags):
                continue
            v = {}
            for t in tags:
                x = res[t]["cases"][k]["paras"][doc]
                vv, _, _ = judge8.verdict(doc, p, x)
                if vv == "VIOLATION" and is_partial(doc, x["fixed"], p):
                    vv = "PARTIAL"
                rep = bool(x["skipped"] or x["whys"] or x["unmatched"])
                v[t] = vv + ("" if vv == "OK" else ("(13章)" if rep else "(黙って)"))
                tot[t][v[t]] += 1
            for t in tags[1:]:
                if v[t] != v[tags[0]]:
                    trans[t][(v[tags[0]], v[t])] += 1
                    if v[t].startswith("VIOL"):
                        worse[t].append((g, k))
keys = ["OK", "MISS(13章)", "MISS(黙って)", "PARTIAL(13章)", "PARTIAL(黙って)", "VIOLATION(13章)", "VIOLATION(黙って)"]
print(f"=== {what}")
print("版".ljust(10) + "".join(k.rjust(16) for k in keys))
for t in tags:
    print(t.ljust(10) + "".join(str(tot[t][k]).rjust(16) for k in keys))
for t in tags[1:]:
    print(f"{tags[0]} -> {t}:", ", ".join(f"{a}→{b} {n}" for (a, b), n in trans[t].most_common(10)))
    if worse[t]:
        print("   新しい VIOLATION:", worse[t][:10])
