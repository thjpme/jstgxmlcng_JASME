"""judge（B2.1）: oracle（run_all.py）の結果を段落ごとに分けて数え、版を比べる（osum.py と同じ分け方。osum.py は、比べる相手で
truth のない OK の段落を数えないので、そこが悪くなった段落を見落とす。ここでは、すべての段落を比べる）。

  python ocmp.py [-v] [--sets 名前,名前...] 版の名前...      # 最初の版が比べる相手
  結果のファイルは oracle/results_<集の名前>_<版の名前>.json（集の名前を省くと、版の名前をそのまま結果の名前とする）
段落の分け方（osum.py と同じ）:
  OK      直した後の文字が truth と同じ（truth のない段落は docx のまま）
  VIOL    足した・消した（docx にも truth にもない文字を入れた・truth にある docx の文字を除いた）か、truth のない段落が変わった
  SILENT  足し・消しはないが truth と違い、その段落が 13 章（13.2・13.4・13.5・13.6）に出ていない
  MISS    足し・消しはないが truth と違い、13 章に出ている（直さずに 13.2 などに回した）
"""
import json
import re
import sys
from collections import Counter
from pathlib import Path

O = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/oracle")
argv = sys.argv[1:]
verbose = "-v" in argv
argv = [a for a in argv if a != "-v"]
sets = [""]
if "--sets" in argv:
    k = argv.index("--sets")
    sets = argv[k + 1].split(",")
    argv = argv[:k] + argv[k + 2:]
vers = argv
RANK = {"OK": 0, "MISS": 1, "SILENT": 2, "VIOL": 3}


def sections(r13):
    out, cur = {}, None
    for ln in (r13 or "").splitlines():
        m = re.match(r"### (13\.\d)", ln)
        if m:
            cur = m.group(1)
            out[cur] = ""
            continue
        if cur:
            out[cur] += ln + "\n"
    return out


def kind(case, p):
    if p["verdict"] == "OK":
        return "OK"
    reason = p.get("reason") or ""
    if "足した" in reason or "消した" in reason or "truth を書いていない" in reason or p.get("fixed") is None:
        return "VIOL"
    sec = sections(case.get("report13"))
    src = p["src"]
    hit = any(re.search(rf"(?<![0-9A-Za-z_]){re.escape(src)}(?![0-9])", sec.get(s, "")) for s in ("13.2", "13.4", "13.5", "13.6"))
    return "MISS" if hit else "SILENT"


for s in sets:
    data = {}
    for v in vers:
        name = f"{s}_{v}" if s else v
        d = json.loads((O / f"results_{name}.json").read_text(encoding="utf-8"))
        data[v] = {}
        for c in d["cases"]:
            for p in c["paras"]:
                data[v][(c["name"], p.get("label") or p["src"])] = (kind(c, p), c, p)
    print(f"=== {s or '(名前そのまま)'}")
    for v in vers:
        cnt = Counter(k for k, _, _ in data[v].values())
        cases = Counter()
        for (cn, _), (k, c, _) in data[v].items():
            cases[cn] = max(cases[cn], RANK[k])
        print(f"  {v:10} 段落 VIOL {cnt['VIOL']:4}  SILENT {cnt['SILENT']:4}  MISS {cnt['MISS']:4}  OK {cnt['OK']:5}"
              f"   反例（いちばん悪い段落）: VIOL {sum(1 for x in cases.values() if x == 3)}・SILENT "
              f"{sum(1 for x in cases.values() if x == 2)}・MISS {sum(1 for x in cases.values() if x == 1)}・OK "
              f"{sum(1 for x in cases.values() if x == 0)}")
    base = vers[0]
    for v in vers[1:]:
        worse = [(key, data[base][key][0], data[v][key][0]) for key in data[base] if key in data[v]
                 and RANK[data[v][key][0]] > RANK[data[base][key][0]]]
        better = [(key, data[base][key][0], data[v][key][0]) for key in data[base] if key in data[v]
                  and RANK[data[v][key][0]] < RANK[data[base][key][0]]]
        tr = Counter(f"{a}→{b}" for _, a, b in worse + better)
        print(f"  {base} -> {v}: 悪くなった段落 {len(worse)}・よくなった段落 {len(better)}  {dict(tr)}")
        for key, a, b in (worse if verbose else [w for w in worse if w[2] in ("VIOL", "SILENT")][:12]):
            p = data[v][key][2]
            print(f"     悪 {key[0]} {p['src']} {a}→{b}: {(p.get('reason') or '')[:120]}")
