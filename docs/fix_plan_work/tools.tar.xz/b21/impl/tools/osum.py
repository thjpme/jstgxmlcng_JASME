"""judge（B2.1。b21/isolate/tools から写したもの）: oracle（run_all.py）の結果を段落ごとに、原則違反と 13.2 に回った直しに分けて数え、版を比べる。

  python osum.py 名前... [-v] [--only 前置き]

名前は oracle/results_<名前>.json。最初の名前が比べる相手。段落の分け方:
  OK      直した後の文字が truth と同じ（truth のない段落は docx のまま）
  VIOL    足した・消した（docx にも truth にもない文字を入れた・truth にある docx の文字を除いた）か、truth のない段落が変わった
  SILENT  足し・消しはないが truth と違い、その段落が 13 章（13.2・13.4・13.5・13.6）に出ていない（黙った違い）
  MISS    足し・消しはないが truth と違い、13 章に出ている（直すべき違いを直さずに 13.2 などに回した。expect が reported でも数える）
反例の判定（oracle の OK・REPORTED・FAIL）も並べる。
"""
import json
import re
import sys
from collections import Counter
from pathlib import Path

O = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/oracle")
args = [a for a in sys.argv[1:] if not a.startswith("-")]
only = ""
if "--only" in sys.argv:
    only = sys.argv[sys.argv.index("--only") + 1]
    args = [a for a in args if a != only]
verbose = "-v" in sys.argv


def sections(r13):
    """13 章の節ごとの文字（### 13.x の見出しで分ける）。"""
    out, cur = {}, None
    for ln in r13.splitlines():
        m = re.match(r"### (13\.\d)", ln)
        if m:
            cur = m.group(1)
            out[cur] = ""
            continue
        if cur:
            out[cur] += ln + "\n"
    return out


def kind(case, p):
    if p["verdict"] == "OK":
        return "OK"
    reason = p.get("reason") or ""
    if "足した" in reason or "消した" in reason or "truth を書いていない" in reason or p.get("fixed") is None:
        return "VIOL"
    sec = sections(case.get("report13") or "")
    src = p["src"]
    hit = any(re.search(rf"(?<![0-9A-Za-z_]){re.escape(src)}(?![0-9])", sec.get(s, "")) for s in ("13.2", "13.4", "13.5", "13.6"))
    return "MISS" if hit else "SILENT"


data = {}
for name in args:
    d = json.loads((O / f"results_{name}.json").read_text(encoding="utf-8"))
    data[name] = {c["name"]: c for c in d["cases"] if c["name"].startswith(only)}
    print(f"{name}: {d['jasme_jats']}（版 {d['version']}）")
base = args[0]
names = list(data[base])
print()
hdr = "版".ljust(20) + "  反例(OK/REP/FAIL)      段落: VIOL SILENT MISS  (OK)"
print(hdr)
per = {}
for name in args:
    cv = Counter(c["verdict"] for c in data[name].values())
    pk = Counter()
    per[name] = {}
    for cn, c in data[name].items():
        for p in c["paras"]:
            if p.get("truth") is None and p["verdict"] == "OK":
                continue
            k = kind(c, p)
            if k == "OK" and p.get("original") == p.get("fixed") and p.get("truth") in (None, p.get("original")):
                continue
            pk[k] += 1
            per[name][(cn, p["src"])] = k
    print(f"{name:20}  {cv['OK']:3}/{cv['REPORTED']:3}/{cv['FAIL']:3}            {pk['VIOL']:4} {pk['SILENT']:6} {pk['MISS']:4}  ({pk['OK']})")
rank = {"OK": 0, "MISS": 1, "SILENT": 2, "VIOL": 3}
for name in args[1:]:
    worse = [k for k in per[base] if k in per[name] and rank[per[name][k]] > rank[per[base][k]]]
    better = [k for k in per[base] if k in per[name] and rank[per[name][k]] < rank[per[base][k]]]
    print(f"\n{base} -> {name}: 悪くなった段落 {len(worse)}・よくなった段落 {len(better)}")
    for k in (worse if verbose else worse[:25]):
        c = data[name][k[0]]
        p = next(p for p in c["paras"] if p["src"] == k[1])
        print(f"  悪 {k[0]} {k[1]} {per[base][k]}→{per[name][k]}: {(p.get('reason') or '')[:150]}")
    if verbose:
        for k in better:
            print(f"  良 {k[0]} {k[1]} {per[base][k]}→{per[name][k]}")
if verbose:
    for name in args:
        print(f"\n[{name}] OK でない段落")
        for (cn, src), k in per[name].items():
            if k != "OK":
                c = data[name][cn]
                p = next(p for p in c["paras"] if p["src"] == src)
                print(f"  {k:6} {cn} {src}: {(p.get('reason') or '')[:160]}")
