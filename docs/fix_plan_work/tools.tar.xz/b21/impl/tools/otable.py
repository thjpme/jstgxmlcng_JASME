"""judge（B2.1）: 反例集ごとに、版ごとの段落の数（VIOL・SILENT・MISS）と、比べる相手（最初の版）より悪くなった・よくなった段落を
1 行ずつ出す（ocmp.py と同じ分け方。DESIGN_B21.md の表にする）。  python otable.py 集,集,... 版...
  悪くなった段落の内訳: V = VIOL・SILENT が増えた段落（OK/MISS→VIOL/SILENT、SILENT→VIOL）、M = OK→MISS の段落"""
import json
import sys
from pathlib import Path
sys.argv, args = sys.argv[:1], sys.argv[1:]
exec(open(Path(__file__).with_name("ocmp.py"), encoding="utf-8").read().split("for s in sets:")[0])
sets, vers = args[0].split(","), args[1:]
tot = {v: [0, 0, 0, 0, 0, 0] for v in vers}
print(f"{'集':12}" + "".join(f"| {v:^22}" for v in vers))
for s in sets:
    data = {}
    for v in vers:
        p = O / f"results_{s}_{v}.json"
        if not p.exists():
            data[v] = None
            continue
        d = json.loads(p.read_text(encoding="utf-8"))
        data[v] = {(c["name"], q.get("label") or q["src"]): kind(c, q) for c in d["cases"] for q in c["paras"]}
    row = f"{s:12}"
    base = data[vers[0]]
    for v in vers:
        if data[v] is None:
            row += f"| {'なし':^20}"
            continue
        cnt = {k: sum(1 for x in data[v].values() if x == k) for k in ("VIOL", "SILENT", "MISS")}
        wv = wm = b = 0
        if base is not None and v != vers[0]:
            for key, a in base.items():
                if key not in data[v]:
                    continue
                c = data[v][key]
                if RANK[c] > RANK[a]:
                    if c in ("VIOL", "SILENT"):
                        wv += 1
                    else:
                        wm += 1
                elif RANK[c] < RANK[a]:
                    b += 1
        t = tot[v]
        for i, x in enumerate((cnt["VIOL"], cnt["SILENT"], cnt["MISS"], wv, wm, b)):
            t[i] += x
        row += f"| {cnt['VIOL']:3} {cnt['SILENT']:3} {cnt['MISS']:4}" + (f" +V{wv} +M{wm} -{b}" if v != vers[0] else "")
    print(row)
print(f"{'合計':12}" + "".join(f"| {t[0]:3} {t[1]:3} {t[2]:4}" + (f" +V{t[3]} +M{t[4]} -{t[5]}" if v != vers[0] else "")
                              for v, t in tot.items()))
