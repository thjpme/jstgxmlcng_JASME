"""judge（B2.1）: 本誌の出版版 PDF 7 通り（fixB2r4/realpdf/check.py の results_after_<TAG>.json・results_route1_<TAG>.json）を
版ごとに比べる。本文の文字は出さず、数と、比べる相手（最初の TAG）と同じかだけを出す。
  python realcmp.py TAG...      # 最初の TAG が比べる相手"""
import hashlib
import json
import sys
from pathlib import Path

OUT = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/fixB2r4/realpdf/out")
tags = sys.argv[1:]


def h(x):
    return hashlib.sha1(json.dumps(x, ensure_ascii=False, sort_keys=True).encode()).hexdigest()[:8]


for kind in ("after", "route1"):
    data = {t: json.loads((OUT / f"results_{kind}_{t}.json").read_text(encoding="utf-8"))["jobs"] for t in tags}
    print(f"=== {kind}")
    base = data[tags[0]]
    for job in base:
        row = [job]
        for t in tags:
            j = data[t][job]
            if "error" in j:
                row.append(f"{t}: ERROR")
                continue
            nf = sum(1 for d in j["diffs"] if not d.get("fixable", True)) if j["diffs"] and isinstance(j["diffs"][0], dict) \
                else sum(1 for d in j["diffs"] if isinstance(d, (list, tuple)) and len(d) > 5 and not d[5])
            same = {k: h(j[k]) == h(base[job][k]) for k in ("fixes", "diffs", "ignored", "unmatched", "xml_text", "report13")
                    if k in j}
            diff_keys = [k for k, v in same.items() if not v]
            row.append(f"{t}: ok={j['ok'][:4] if isinstance(j['ok'], list) else j['ok']} 直す {len(j['fixes'])} 違い {len(j['diffs'])}"
                       f"（直さない {nf}） 使わなかった {len(j['ignored'])} 見つからない {len(j['unmatched'])}"
                       + ("" if t == tags[0] else ("  同じ" if not diff_keys else f"  違う: {','.join(diff_keys)}")))
        print("\n   ".join(row))
