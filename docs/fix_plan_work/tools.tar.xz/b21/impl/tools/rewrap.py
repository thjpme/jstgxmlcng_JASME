"""judge（B2.1）: pdfmatch.py の docstring の段落の一部（start で始まる行から、end で始まる行の前まで）を、表示の幅 W で
折り返し直す（作業用）。英数字の語・カタカナの並びは切らず、なるべく「、。）」の後ろ・「（」の前・助詞の後ろで切る。
行の変わり目の、和文と英数字の間は空白 1 つとみなす（元の書き方と同じ）。
  python rewrap.py ファイル 最初の行の文字列 次の行の最初の文字列 [W]"""
import re
import sys
import unicodedata
from pathlib import Path
path, start, end = sys.argv[1:4]
W = int(sys.argv[4]) if len(sys.argv) > 4 else 128
lines = Path(path).read_text(encoding="utf-8").split("\n")
a = next(i for i, x in enumerate(lines) if x.startswith(start))
b = next(i for i in range(a + 1, len(lines)) if lines[i].startswith(end))
lead = re.match(r"^(\s*(?:・)?)", lines[a]).group(1)
cont = "    " if lead.strip() == "・" else lead
text = lines[a][len(lead):]
for x in lines[a + 1:b]:
    y = x.lstrip()
    if text and y and ((ord(text[-1]) < 128) != (ord(y[0]) < 128)) and text[-1] not in "（「、。）" and y[0] not in "（「、。）_":
        text += " "
    text += y


def w(s):
    return sum(2 if unicodedata.east_asian_width(c) in "FW" else 1 for c in s)


toks = re.findall(r" ?[\x21-\x7e]+| ?[ァ-ヴー]+| ?[^\x21-\x7e ]| ", text)
GOOD_AFTER = set("、。）」』") | set("をがはにで")
out, cur = [], []
for t in toks:
    if w(lead if not out else cont) + w("".join(cur + [t]).rstrip()) > W and cur:
        # 行の最後の 14 の幅の中で、よい切れ目を探す
        best = None
        acc = w(lead if not out else cont) + w("".join(cur))
        for k in range(len(cur) - 1, 0, -1):
            acc -= w(cur[k])
            if w(lead if not out else cont) + w("".join(cur)) - acc > 14:
                break
            prev, nxt = cur[k - 1], cur[k]
            if (prev[-1] in GOOD_AFTER or nxt.lstrip()[:1] in "（「") and nxt.lstrip()[:1] not in "、。）」』":
                best = k
                break
        k = best or len(cur)
        if t.strip() in list("、。）」』") and k == len(cur):
            cur.append(t)
            t = None
            k = len(cur)
        out.append("".join(cur[:k]).rstrip())
        cur = [x.lstrip() if i == 0 else x for i, x in enumerate(cur[k:])]
    if t is not None:
        cur.append(t.lstrip() if not cur else t)
out.append("".join(cur).rstrip())
res = [(lead if i == 0 else cont) + x for i, x in enumerate(out)]
lines[a:b] = res
Path(path).write_text("\n".join(lines), encoding="utf-8")
print("\n".join(f"{w(x):4} {x}" for x in res))
