"""judge（B2.1）: 反例 1 件を SRC のコードで動かし、判定と 13 章を出す（作業用）。  python run1.py SRC 反例のファイル 反例の名前 [13章を出す]"""
import importlib.util
import sys
from pathlib import Path
src, cf, name = sys.argv[1:4]
sys.path.insert(0, src)
O = "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/oracle"
sys.path.insert(1, O)
spec = importlib.util.spec_from_file_location("cf", cf)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
case = next(c for c in m.CASES if c["name"] == name)
import runner  # noqa: E402
r = runner.run_case(case, Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b21/judge/work") / name)
print(r["verdict"])
for p in r["paras"]:
    if p["verdict"] != "OK":
        print(p["src"], p["verdict"], (p.get("reason") or "")[:200])
if len(sys.argv) > 4:
    print(r.get("report13", "")[:3000])
