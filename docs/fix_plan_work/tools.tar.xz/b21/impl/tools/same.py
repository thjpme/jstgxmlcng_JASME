"""impl（B2.1）: 2 つの版（TAG）の oracle の結果が、反例ごとに同じか（判定・直した後の段落の文字・13 章）を比べる。
  python same.py TAG_A TAG_B 集...   （集は results_<集>_<TAG>.json の <集>）"""
import json
import sys
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
a, b, sets = sys.argv[1], sys.argv[2], sys.argv[3:]
for name in sets:
    pa, pb = S / "oracle" / f"results_{name}_{a}.json", S / "oracle" / f"results_{name}_{b}.json"
    if not pa.exists() or not pb.exists():
        print(f"{name}: 結果がない（{pa.exists()} {pb.exists()}）")
        continue
    ra = {c["name"]: c for c in json.load(open(pa))["cases"]}
    rb = {c["name"]: c for c in json.load(open(pb))["cases"]}
    diff = []
    for n in ra:
        x, y = ra[n], rb.get(n)
        if y is None:
            diff.append((n, "なし"))
            continue
        if x["verdict"] != y["verdict"]:
            diff.append((n, f"判定 {x['verdict']} -> {y['verdict']}"))
        elif [p.get("fixed") for p in x.get("paras", [])] != [p.get("fixed") for p in y.get("paras", [])]:
            diff.append((n, "直した文字"))
        elif x.get("report13") != y.get("report13"):
            diff.append((n, "13 章"))
    print(f"{name}: {len(ra)} 件、違う {len(diff)} {diff[:5]}")
