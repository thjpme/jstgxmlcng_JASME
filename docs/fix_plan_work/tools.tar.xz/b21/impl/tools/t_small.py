"""impl（B2.1）: 小さな論文 100 本（fuzz8 の 1 組）の照合の速さを、5 回の最小で測る（t_speed.py の small100 の、回数を増やしたもの）。
  python -I t_small.py SRC"""
import json
import sys
import time
from pathlib import Path
sys.path.insert(0, sys.argv[1])
from jasme_jats.config import JournalConfig  # noqa: E402
from jasme_jats.pdfdocx import _mechanical  # noqa: E402
from jasme_jats.pdfmatch import compare  # noqa: E402
S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
jn = JournalConfig.load()
small = json.load(open(S / "rvB8_regress" / "fuzz8" / "m_mix_311" / "cases.json", encoding="utf-8"))[:100]
plans = [(_mechanical(c["docx"], jn)[1], c["pages"]) for c in small]
best = None
for _ in range(5):
    t0 = time.perf_counter()
    for plan, pages in plans:
        compare(plan, pages)
    t = time.perf_counter() - t0
    best = t if best is None else min(best, t)
print(round(best, 3))
