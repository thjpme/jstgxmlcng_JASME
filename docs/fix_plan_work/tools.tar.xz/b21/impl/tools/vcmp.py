"""judge（B2.1）: 反例集の判定（oracle の verdict: OK・REPORTED・FAIL。反例を作った担当の期待〈exact・fix_or_keep・keep〉で
判定したもの）を、版ごとに数え、比べる相手（最初の版）より悪くなった・よくなった反例を出す（ocmp.py の段落の分け方を補う。
ocmp.py は、段落 ID が 13 章のどこかに出ていれば MISS と数えるが、oracle は違いそのものが 13 章に出ているかを見る）。
  python vcmp.py 集,集,... 版..."""
import json
import sys
from pathlib import Path
O = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/oracle")
R = {"OK": 0, "REPORTED": 1, "FAIL": 2}
sets, vers = sys.argv[1].split(","), sys.argv[2:]
tot = {v: [0, 0, 0, 0, 0] for v in vers}
for s in sets:
    data = {}
    for v in vers:
        p = O / f"results_{s}_{v}.json"
        data[v] = {c["name"]: c["verdict"] for c in json.loads(p.read_text(encoding="utf-8"))["cases"]} if p.exists() else None
    base = data[vers[0]]
    row = f"{s:10}"
    for v in vers:
        d = data[v]
        if d is None:
            row += " | なし"
            continue
        n = [sum(1 for x in d.values() if x == k) for k in ("OK", "REPORTED", "FAIL")]
        w = [k for k, x in d.items() if base and k in base and R[x] > R[base[k]]]
        b = [k for k, x in d.items() if base and k in base and R[x] < R[base[k]]]
        for i, x in enumerate(n + [len(w), len(b)]):
            tot[v][i] += x
        row += f" | {n[0]:3}/{n[1]:3}/{n[2]:3}" + (f" 悪{len(w)} 良{len(b)}" if v != vers[0] else "")
        if v != vers[0] and w and "-v" not in sys.argv:
            pass
    print(row)
    if len(vers) > 1:
        for v in vers[1:]:
            d = data[v]
            if d and base:
                w = [k for k, x in d.items() if k in base and R[x] > R[base[k]]]
                if w:
                    print(f"    {v} の悪くなった反例: {w[:8]}{' ほか' if len(w) > 8 else ''}")
print("合計      " + "".join(f" | {t[0]:3}/{t[1]:3}/{t[2]:3}" + (f" 悪{t[3]} 良{t[4]}" if v != vers[0] else "") for v, t in tot.items()))
