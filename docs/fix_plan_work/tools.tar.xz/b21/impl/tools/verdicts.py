"""impl（B2.1）: oracle の結果（results_<集>_<TAG>.json）の反例ごとの判定を、版ごとに並べる。
  python verdicts.py 集 TAG... [--diff]   （--diff なら、版で判定が違う反例だけ）"""
import json
import sys

S = "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad"
args = [a for a in sys.argv[1:] if not a.startswith("--")]
only_diff = "--diff" in sys.argv
name, tags = args[0], args[1:]
res = {t: {c["name"]: c for c in json.load(open(f"{S}/oracle/results_{name}_{t}.json"))["cases"]} for t in tags}
names = list(res[tags[0]])
for n in names:
    vs = [res[t].get(n, {}).get("verdict", "-") for t in tags]
    if only_diff and len(set(vs)) == 1:
        continue
    print(f"{n:40} " + " ".join(f"{v:9}" for v in vs))
