"""B2.1 の試作（isolate。案 A「離れた端は直さない」）の再現の例。文字はすべて架空（実際の論文の文字を書き写していない）。

oracle/run_all.py の書式（oracle/runner.py の docstring）。実行（scratchpad の oracle/ で）:
  python run_all.py <src> ../b21/isolate/cases_iso.py --name <名前>
期待は原則だけで決める（出版版 PDF の本文と同じにする。組版の文字・図や表の中の文字・ほかの段落の文字を足さない。本文の文字を
消さない。決められないものは docx のまま 13 章に出す）。0.20.0 にも 0.21.0 にも合わせない。

B2 の 4 回目の点検で残った 6 件（b2_review/workflow_final.json の remaining）のうち、すでに反例のある形は
rvB2x_principle_cases.py の v_*（b2_review/r5p/cases_v_only.py）と w_*（b2_review/r4p/cases_w_only.py）で確かめる。
ここには、まだ oracle の反例のない形を足す:
  iso_num3_*    残った 6 件の 6（nit。「113点」）: 段落の途中が表（キャプションとセル）で分断され、分断の後ろの「13点」が docx の
                「12点」の直し。docx の「1」を表のキャプションの「１」と並べ、「2」→「13」だけを直して docx にも PDF にもない
                「113点」にしないか（キャプションが全角の「表１」・半角の「表1」、出版版が「１３点」の形も）
  iso_cpo_*     残った 6 件の 5（facing_hole の頭の側。b2_review/r5reg/exp/gen_r5_cpo.py の形）: 図（キャプションは図の下）の
                前の段落の最後の文が校正で消され、図の後ろの段落の最初の行（書き出しに校正の直し）がキャプションのすぐ後ろ、
                1 ページ目の最後の受付日の行の前にある。後ろの段落の最初の行の直しを直すか（決められなければ 13 章に出す）
  iso_tabtop_*  残った 6 件の 3 の「1 行だけの表」の形（gen_r5simtop の tabbelow）: 段落の最後の文が校正で消され、次のページの
                最初に、消された文の書き出しとよく似たセル 1 つの表がある。表のセルの文字を足さないか
  iso_figtop_*  残った 6 件の 3（v_figtop）の、柱のないページの区切り・受付日の行の後ろの形
  iso_flow_*    対照: ページの区切りをまたいで続く段落（1 ページ目の最後の受付日の行・次のページの柱をはさむ）の、区切りの前・
                後ろの部分の校正の直し。本当の段落の行なので直す（案 A の守りが、ふつうのページの区切りまで「離れた端」に
                しないか）
"""
from __future__ import annotations

import sys
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
sys.path.insert(0, str(S / "n10"))

from runner import BREAK, Raw, flow, received_line  # noqa: E402
import cases_n10 as N  # noqa: E402

CASES = []


def case(name, item, paras, pages, note, truth=None, expect="exact", angle="layout"):
    CASES.append({"name": name, "angle": angle, "item": item, "paras": paras, "truth": truth or {},
                  "pages": pages, "expect": expect, "note": note})


def idx(paras, text):
    found = [i for i, (_, t) in enumerate(paras) if t == text]
    if len(found) != 1:
        raise ValueError(f"段落「{str(text)[:16]}」が {len(found)} 個")
    return found[0]


def tail_blocks():
    return [N.RH, Raw(*N.REF1_LINES), Raw(*N.REF2_LINES), BREAK, N.en_block()]


def with_head(pages, k, head="試験　五郎"):
    """k ページ目（0 から）の最初（ページ番号の行の後ろ）に柱の行を入れる。"""
    ls = pages[k].split("\n")
    pages[k] = "\n".join(ls[:1] + [head] + ls[1:])
    return pages


Z_CAP = "図１　架空の授業の流れ"
FIG_HEAD = ["導入", "↓", "課題の提示", "↓"]

# ============================================================================ iso_num3_*: 「113点」
NUM_DOCX = "架空の調査の結果を表１に示す。その結果，生徒の平均は12点であり，前回の調査より高かった。"
NUM_ROWS = [["組の名前", "一回目の得点", "二回目の得点"], ["第一の組", "31", "27"], ["第二の組", "14", "23"],
            ["第三の組", "35", "16"], ["第四の組", "19", "21"]]
for nk, cap, new in (("fw", "表１　架空の組ごとの得点", "13点"), ("hw", "表1　架空の組ごとの得点", "13点"),
                     ("fw13", "表１　架空の組ごとの得点", "１３点"), ("same", "表１　架空の組ごとの得点", "12点")):
    pub_t = NUM_DOCX.replace("12点", new)
    paras = N.article_paras(NUM_DOCX, (), [("表キャプション", cap), ("表", NUM_ROWS)])
    cut = pub_t.index("点であり") - len(new) + 1
    rows = [" ".join(r) for r in NUM_ROWS]
    pages = flow([N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2,
                  Raw(*N.body(pub_t[:cut])), Raw(cap, *rows), Raw(*N.jwrap(pub_t[cut:])), Raw(*N.body(N.P_AFTER)),
                  N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
    truth = {idx(paras, N.CTRL_DOCX): N.CTRL_PUB}
    if new != "12点":
        truth[idx(paras, NUM_DOCX)] = pub_t
    case(f"iso_num3_{nk}", "N20", paras, pages,
         f"段落の途中（「平均は」の後ろ）が表（キャプション「{cap}」とセル）で分断され、分断の後ろの「{new}であり…」が docx の"
         "「12点」の直し。docx の「1」を表のキャプションの数字と並べて残し、「2」だけを直して docx にも PDF にもない数に"
         "しない。直すか、決められなければ docx のまま 13 章に出す。",
         truth=truth, expect={"default": "exact", idx(paras, NUM_DOCX): "reported"})

# ============================================================================ iso_cpo_*: 頭の側の facing_hole
CPO_DEL = "その結果を表に示す。"
CPO_HEAD = N.P_AFTER.replace("話し合いの中で", "議論の中で")
for ak in ("date", "coldate"):
    docx_t = N.TARGET + CPO_DEL
    hl = N.body(CPO_HEAD)
    paras = N.article_paras(docx_t, (), [("画像", "授業の流れ"), ("図キャプション", Z_CAP)])
    head = [Raw(*N.body(N.TARGET)), Raw(*FIG_HEAD, "まとめ", Z_CAP), Raw(hl[0]), Raw(received_line())] + \
        ([BREAK] if ak == "date" else [])
    pages = flow([N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, *head, Raw(*hl[1:]),
                  N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
    case(f"iso_cpo_delsent_w1_{ak}", "N20", paras, pages,
         f"図（キャプションは図の下）の前の段落の最後の文「{CPO_DEL}」は出版版で消されている。図の後ろの段落の最初の行「{hl[0]}」"
         "（「話し合いの中で」→「議論の中で」の校正の直しあり）が、キャプションのすぐ後ろ、1 ページ目の最後の受付日の行の前に"
         f"あり、段落の残りは{'次のページ' if ak == 'date' else '同じページの次の段'}に続く。どちらも直すか、決められなければ"
         " docx のまま 13 章に出す（図の中の文字を足さない・本文の文字を消さない）。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_t): N.TARGET, idx(paras, N.P_AFTER): CPO_HEAD},
         expect={"default": "exact", idx(paras, docx_t): "reported", idx(paras, N.P_AFTER): "reported"})

# ============================================================================ iso_tabtop_* / iso_figtop_*: 消された最後の文と、
# 次のページの最初（受付日の行の後ろ）の、よく似た 1 行だけの表・図
TOP_DEL = "課題の提示を行った。"
for mk in ("tab", "fig"):
    for fk, fl in (("sim", "課題の把握"), ("copy", "課題の提示")):
        for bk in (("pb", "datepb", "pbhead") if mk == "tab" else ("pb", "datepb")):
            docx_t = N.TARGET + TOP_DEL
            if mk == "tab":
                mat = [("表", [[fl]]), ("表キャプション", N.TAB_CAP20)]
                mid = [fl, N.TAB_CAP20]
            else:
                mat = [("画像", fl), ("図キャプション", Z_CAP)]
                mid = [fl, Z_CAP]
            paras = N.article_paras(docx_t, (), mat)
            first = [N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*N.body(N.TARGET))]
            first += [Raw(received_line()), BREAK] if bk == "datepb" else [BREAK]
            rest = [Raw(*mid), Raw(*N.body(N.P_AFTER)), N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)),
                    *tail_blocks()]
            pages = flow(first + rest, first=25)
            if bk == "pbhead":
                pages = with_head(pages, 1)
            where = {"pb": "次のページの最初", "datepb": "1 ページ目の最後の受付日の行の後ろ（次のページの最初）",
                     "pbhead": "次のページの最初（柱の後ろ）"}[bk]
            case(f"iso_{mk}top_{fk}_{bk}", "N20", paras, pages,
                 f"docx の段落の最後の文「{TOP_DEL}」は出版版で消されている。PDF では段落の本当の最後の行がページの最後にあり、"
                 f"{where}に、{'セル 1 つの表' if mk == 'tab' else '1 行だけの小さな図'}（「{fl}」）がある。"
                 f"{'表のセル' if mk == 'tab' else '図の中'}の文字を足さない。消された文を消すか、決められなければ docx の"
                 "まま 13 章に出す。",
                 truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_t): N.TARGET},
                 expect={"default": "exact", idx(paras, docx_t): "reported"})

# ============================================================================ iso_flow_*: ふつうのページの区切り（対照）
# TARGET（184 文字。8 行）が、1 ページ目の最後の受付日の行（と次のページの柱）をはさんで、2 つのページに分かれる（2 行目か
# 6 行目の後ろ）。最初の 2 行（e0）か最後の行（e7）に校正の直しがあり、短いほうの部分に入る組と、長いほうの部分に入る組がある。
# 本当の段落の行なので直す
FLOW_EDITS = {"e0": ("黒板に掲げ", "黒板に貼り"), "e7": ("説明し合う時間を取った", "説明し合う時間を持った")}
for ek, (old, new) in FLOW_EDITS.items():
    pub_t = N.TARGET.replace(old, new)
    lines = N.body(pub_t)
    for split in (2, 6):
        for bk in ("date", "datehead", "head"):
            paras = N.article_paras(N.TARGET)
            first = [N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*lines[:split])]
            first += [Raw(received_line()), BREAK] if bk in ("date", "datehead") else [BREAK]
            rest = [Raw(*lines[split:]), Raw(*N.body(N.P_AFTER)), N.H3, Raw(*N.body(N.P_DISC)),
                    Raw(*N.body(N.P_END)), *tail_blocks()]
            pages = flow(first + rest, first=25)
            if bk in ("datehead", "head"):
                pages = with_head(pages, 1)
            case(f"iso_flow_{ek}_{split}_{bk}", "N20", paras, pages,
                 f"段落の{split} 行目の後ろでページが変わり、その間に"
                 f"{'1 ページ目の最後の受付日の行' if bk == 'date' else '受付日の行と次のページの柱' if bk == 'datehead' else '次のページの柱'}"
                 f"がある。{'最初の 2 行' if ek == 'e0' else '最後の行'}の校正の直し（「{old}」→「{new}」）は本当の段落の行の"
                 "直しなので直す（ふつうのページの区切りを、離れた端として直さないことにしない）。",
                 truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): pub_t})
