"""B2.1 の試作（isolate）の再現の例・その 2。文字はすべて架空（実際の論文の文字を書き写していない）。

oracle/run_all.py の書式（oracle/runner.py の docstring）。実行（scratchpad の oracle/ で）:
  python run_all.py <src> ../b21/isolate/cases_iso2.py --name <名前>
期待は原則だけで決める。
  iso_num3o_*   210 件の num3 の形をそのまま（段落の文字を行に分けず、表のセルを 1 つずつの行にする）。「平均は」の後ろが表で
                分断され、分断の後ろの「13点」が docx の「12点」の直し（「113点」にしない）
  iso_ins_*     段落の途中に校正で足された一文（行まるごとを含む）と、その後ろの別の校正の直し。足された文は足さなくてよい
                （13 章に出す）が、後ろの直しは本当の段落の行の直しなので直す（案 A の守りが、行まるごとの挿入の後ろを「離れた
                部分」にしないか）
  iso_mid_*     段落の途中（4 行目の後）が図・表で分断され、分断の前と後ろの両方に校正の直し。本当の段落の行なので直す（案 A は、
                短いほうの部分の直しを直さずに 13 章に出す。13.2 に回る直しの数を見るための対照）
  iso_full_*    v_figtop の形で、段落の本当の最後の行が行の幅いっぱい（段落がちょうど行の終わりで終わる）。図の中の文字を足さない
"""
from __future__ import annotations

import sys
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
sys.path.insert(0, str(S / "n10"))

from runner import BREAK, Raw, flow  # noqa: E402
import cases_n10 as N  # noqa: E402

CASES = []


def case(name, item, paras, pages, note, truth=None, expect="exact", angle="layout"):
    CASES.append({"name": name, "angle": angle, "item": item, "paras": paras, "truth": truth or {},
                  "pages": pages, "expect": expect, "note": note})


def idx(paras, text):
    found = [i for i, (_, t) in enumerate(paras) if t == text]
    if len(found) != 1:
        raise ValueError(f"段落「{str(text)[:16]}」が {len(found)} 個")
    return found[0]


def tail_blocks():
    return [N.RH, Raw(*N.REF1_LINES), Raw(*N.REF2_LINES), BREAK, N.en_block()]


def front_blocks():
    return [N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2]


Z_CAP = "図１　架空の授業の流れ"

# ============================================================================ iso_num3o_*
NUM_DOCX = "架空の調査の結果を表１に示す。その結果，生徒の平均は12点であり，前回の調査より高かった。"
NUM_ROWS = [["組の名前", "一回目の得点", "二回目の得点"], ["第一の組", "31", "27"], ["第二の組", "14", "23"],
            ["第三の組", "35", "16"], ["第四の組", "19", "21"]]
for nk, cap, new in (("fw", "表１　架空の組ごとの得点", "13点"), ("hw", "表1　架空の組ごとの得点", "13点"),
                     ("fw13", "表１　架空の組ごとの得点", "１３点"), ("same", "表１　架空の組ごとの得点", "12点")):
    pub_t = NUM_DOCX.replace("12点", new)
    paras = N.article_paras(NUM_DOCX, (), [("表キャプション", cap), ("表", NUM_ROWS)])
    cut = pub_t.index("点であり") - len(new) + 1
    cells = [c for row in NUM_ROWS for c in row]
    pages = flow([*front_blocks(), Raw(pub_t[:cut]), Raw(cap, *cells), Raw(pub_t[cut:]), Raw(*N.body(N.P_AFTER)),
                  N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
    truth = {idx(paras, N.CTRL_DOCX): N.CTRL_PUB}
    if new != "12点":
        truth[idx(paras, NUM_DOCX)] = pub_t
    case(f"iso_num3o_{nk}", "N20", paras, pages,
         f"210 件の num3 の形: 段落の途中（「平均は」の後ろ）が表（キャプション「{cap}」と 1 つずつの行のセル）で分断され、"
         f"分断の後ろの「{new}であり…」が docx の「12点」の直し。docx にも PDF にもない数（「113点」）にしない。直すか、決められ"
         "なければ docx のまま 13 章に出す。",
         truth=truth, expect={"default": "exact", idx(paras, NUM_DOCX): "reported"})

# ============================================================================ iso_ins_*: 行まるごとの挿入の後ろの直し
INS_DOCX = N.TARGET
INS_ADD = "なお，矢印の向きと長さは生徒どうしで相談して決めさせ，その理由をノートに書かせた。"
for ek, (old, new) in {"e7": ("説明し合う時間を取った", "説明し合う時間を持った"),
                       "e6": ("深さがどうなるか", "深さはどうなるか")}.items():
    pub_t = N.TARGET.replace("確かめた。", "確かめた。" + INS_ADD).replace(old, new)
    paras = N.article_paras(INS_DOCX)
    pages = flow([*front_blocks(), Raw(*N.body(pub_t)), Raw(*N.body(N.P_AFTER)), N.H3, Raw(*N.body(N.P_DISC)),
                  Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
    case(f"iso_ins_{ek}", "N20", paras, pages,
         f"段落の途中に校正で一文（{len(INS_ADD)} 文字。PDF では行まるごとを含む）が足され、その後ろでも「{old}」→「{new}」と"
         "直されている。足された一文は 20 文字以上なので足さなくてよい（13 章に出す）が、後ろの直しは本当の段落の行の直しなので"
         "直す。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, INS_DOCX): pub_t},
         expect={"default": "exact", idx(paras, INS_DOCX): "reported"})

# ============================================================================ iso_mid_*: 段落の途中の分断（対照）
MID_EDITS = [("黒板に掲げ", "黒板に貼り"), ("説明し合う時間を取った", "説明し合う時間を持った")]
for kind in ("fig", "tab"):
    pub_t = N.TARGET
    for old, new in MID_EDITS:
        pub_t = pub_t.replace(old, new)
    m_before, m_after, others, lines = N.material(kind, 60, "mid")
    paras = N.article_paras(N.TARGET, m_before, m_after)
    tl = N.body(pub_t)
    for at in (2, 6):
        pages = flow([*front_blocks(), Raw(*tl[:at]), Raw(*lines), Raw(*tl[at:]), Raw(*N.body(N.P_AFTER)), N.H3,
                      Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
        case(f"iso_mid_{kind}_{at}", "N20", paras, pages,
             f"段落の {at} 行目の後ろが{'図（約 60 文字の図の中の文字とキャプション）' if kind == 'fig' else '表（キャプションとセル）'}で"
             "分断され、最初の 2 行と最後の行の両方に校正の直しがある。本当の段落の行なので、どちらも直す（案 A は、短いほうの"
             "部分の直しを 13 章に回す）。",
             truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): pub_t},
             expect={"default": "exact", idx(paras, N.TARGET): "reported"})

# ============================================================================ iso_full_*: 本当の最後の行が行の幅いっぱい
FULL_PUB = N.TARGET.replace("最後に，教師は", "最後に，授業の終わりに教師は")
FULL_DEL = "課題の提示を行った。"
assert len(N.body(FULL_PUB)[-1]) == 24, N.body(FULL_PUB)[-1]
for fk, fl in (("sim", "課題の把握"), ("copy", "課題の提示")):
    docx_t = FULL_PUB + FULL_DEL
    paras = N.article_paras(docx_t, (), [("画像", fl), ("図キャプション", Z_CAP)])
    for bk in ("pb", "direct"):
        first = [*front_blocks(), Raw(*N.body(FULL_PUB))] + ([BREAK] if bk == "pb" else [])
        pages = flow(first + [Raw(fl, Z_CAP), Raw(*N.body(N.P_AFTER)), N.H3, Raw(*N.body(N.P_DISC)),
                              Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
        case(f"iso_full_{fk}_{bk}", "N20", paras, pages,
             f"docx の段落の最後の文「{FULL_DEL}」は出版版で消されている。段落の本当の最後の行は行の幅いっぱい（段落がちょうど行の"
             f"終わりで終わる）で、{'次のページの最初' if bk == 'pb' else 'そのすぐ後ろ'}に 1 行だけの小さな図（「{fl}」。"
             "キャプションは図の下）がある。図の中の文字を足さない。消すか、決められなければ docx のまま 13 章に出す。",
             truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_t): FULL_PUB},
             expect={"default": "exact", idx(paras, docx_t): "reported"})
