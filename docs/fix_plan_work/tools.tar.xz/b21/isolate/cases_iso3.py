"""B2.1 の試作（isolate）の再現の例・その 3。文字はすべて架空（実際の論文の文字を書き写していない）。

oracle/run_all.py の書式（oracle/runner.py の docstring）。実行（scratchpad の oracle/ で）:
  python run_all.py <src> ../b21/isolate/cases_iso3.py --name <名前>
期待は原則だけで決める。試作は、段落の終わりの行を「行の幅より短い行」で見分ける（_ends_flow）。本誌の段落の行は両端そろえで
行の幅いっぱいになるが、テスト（tests/test_pdfmatch.py）の形の多くは、ページの区切りの前の行がたまたま短い。行の幅いっぱいの
形でも守れるかを見る。
  iso_ftop_*   test_figure_at_page_top_is_not_used_as_last_line の形で、前のページの最後の行が行の幅いっぱい（段落は次の
               ページに続く）。次のページの最初に小さな図（キャプションは図の下）があり、図の中の行（「時間を見る」）が段落の
               続きの docx の文字と最初の数文字が同じ。本当の続きの行はキャプションの後ろ。図の中の文字を足さない・docx の
               文字を図の中の文字で置き換えない（del: 段落の最後の文が校正で消されている。edit: 本当の最後の行が校正で直されて
               いる）
  iso_fbot_*   test_figure_at_page_bottom_is_not_used_as_first_line の形で、図の中の行（段落の最初の docx の文字とよく似た
               行）の長さを変える（short は 7 文字、mid は 13 文字、long は 16 文字、long20 は 20 文字。行の幅は 24 文字）
"""
from __future__ import annotations

import sys
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
sys.path.insert(0, str(S / "n10"))

from runner import BREAK, Raw, flow  # noqa: E402
import cases_n10 as N  # noqa: E402

CASES = []


def case(name, item, paras, pages, note, truth=None, expect="exact", angle="layout"):
    CASES.append({"name": name, "angle": angle, "item": item, "paras": paras, "truth": truth or {},
                  "pages": pages, "expect": expect, "note": note})


def idx(paras, text):
    found = [i for i, (_, t) in enumerate(paras) if t == text]
    if len(found) != 1:
        raise ValueError(f"段落「{str(text)[:16]}」が {len(found)} 個")
    return found[0]


def tail_blocks():
    return [N.RH, Raw(*N.REF1_LINES), Raw(*N.REF2_LINES), BREAK, N.en_block()]


def front_blocks():
    return [N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2]


Z_CAP = "図１　架空の授業の流れ"
HEAD = "試験　六郎"

# ============================================================================ iso_ftop_*
X = N.TARGET.replace("生徒どうしで説明し合う時間を取った。", "生徒どうしで説明し合い，互いの考えを比べて確かめる")
LAST = "時間を取った。"
DEL = "その結果を表に示す。"
assert [len(x) for x in N.body(X)] == [24] * 8, N.body(X)
for ek in ("del", "edit"):
    docx_t = X + LAST + (DEL if ek == "del" else "")
    pub_last = LAST if ek == "del" else "時間を持った。"
    pub_t = X + pub_last
    paras = N.article_paras(docx_t, (), [("画像", "fig"), ("図キャプション", Z_CAP)])
    for fk, fig in (("short", "時間を見る"), ("long", "時間を見る活動と話し合いの流れ")):
        for sk, steps in (("1", []), ("3", ["導入", "↓"])):
            for hk in ("", "_head"):
                second = ([HEAD] if hk else []) + steps + [fig, Z_CAP, pub_last]
                pages = flow([*front_blocks(), Raw(*N.body(X)), BREAK, Raw(*second), Raw(*N.body(N.P_AFTER)), N.H3,
                              Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
                case(f"iso_ftop_{ek}_{fk}{sk}{hk}", "N20", paras, pages,
                     "前のページの最後の行が行の幅いっぱいで、段落は次のページに続く。次のページの最初"
                     f"{'（柱の後ろ）' if hk else ''}に小さな図（図の中の行「{'」「'.join(steps + [fig])}」。キャプションは図の"
                     f"下）があり、本当の続きの行「{pub_last}」はキャプションの後ろ。"
                     + (f"docx の段落の最後の文「{DEL}」は校正で消されている。" if ek == "del" else
                        "本当の最後の行は校正で「取った」→「持った」と直されている。")
                     + "図の中の文字を足さず、docx の文字を図の中の文字で置き換えない（直すか、決められなければ docx のまま 13 章に"
                       "出す）。",
                     truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_t): pub_t},
                     expect={"default": "exact", idx(paras, docx_t): "reported"})

# ============================================================================ iso_fbot_*
PUB_AFTER = N.P_AFTER.replace("話し合いの中で", "議論の中で")
assert PUB_AFTER != N.P_AFTER
for fk, fig in (("short", "話し合いの場面"), ("mid", "話し合いの中での発言の記録"), ("long", "話し合いの中で出された考えの整理"),
                ("long20", "話し合いの中で出された考えを整理した結果")):
    paras = N.article_paras(N.TARGET, (), [("図キャプション", Z_CAP), ("画像", "fig")])
    lines = N.body(PUB_AFTER)
    for hk in ("", "_head"):
        pages = flow([*front_blocks(), Raw(*N.body(N.TARGET)), Raw(Z_CAP, fig, "↓", lines[0]), BREAK,
                      Raw(*([HEAD] if hk else []), *lines[1:]), N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)),
                      *tail_blocks()], first=25)
        case(f"iso_fbot_{fk}{hk}", "N20", paras, pages,
             f"段落の最初の語句が校正で書き換えられ（「話し合いの中で」→「議論の中で」）、PDF では、ページの最後に、小さな図"
             f"（キャプションは図の上。図の中の行「{fig}」〈{len(fig)} 文字〉と「↓」）と、段落の本当の最初の行がある（段落の残りは"
             f"次のページ{'の柱の後ろ' if hk else ''}）。図の中の行を段落の最初の行と並べない（図の中の文字を足さない）。直すか、"
             "決められなければ docx のまま 13 章に出す。",
             truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.P_AFTER): PUB_AFTER},
             expect={"default": "exact", idx(paras, N.P_AFTER): "reported"})
