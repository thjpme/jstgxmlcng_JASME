"""B2.1 の試作（isolate）の再現の例・その 4（試作の弱いところを探す）。文字はすべて架空（実際の論文の文字を書き写していない）。

oracle/run_all.py の書式（oracle/runner.py の docstring）。実行（scratchpad の oracle/ で）:
  python run_all.py <src> ../b21/isolate/cases_iso4.py --name <名前>
期待は原則だけで決める。
  iso_eq_*     段落の途中に別行立ての式（PDF にだけある行。docx の式は文字でない形の代わりに、式のない docx にする）があり、
               式の前の行は短く「，」で終わる。式の前と後ろの両方に校正の直し（本当の段落の行なので直す）。式の行が和文を含む
               もの（jp）と含まないもの（en）
  iso_colon_*  段落の最後の行が文の終わりで終わらない（「…次のとおりである」）で、すぐ後ろが表のキャプション。最後の行に校正の
               直し（直すか、決められなければ docx のまま 13 章に出す）
  iso_ftopx_*  cases_iso3 の iso_ftop の形で、図の中の行が文の終わりで終わる（period）か、行の幅いっぱい（full）。図の中の文字を
               足さない
"""
from __future__ import annotations

import sys
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
sys.path.insert(0, str(S / "n10"))

from runner import BREAK, Raw, flow  # noqa: E402
import cases_n10 as N  # noqa: E402

CASES = []


def case(name, item, paras, pages, note, truth=None, expect="exact", angle="layout"):
    CASES.append({"name": name, "angle": angle, "item": item, "paras": paras, "truth": truth or {},
                  "pages": pages, "expect": expect, "note": note})


def idx(paras, text):
    found = [i for i, (_, t) in enumerate(paras) if t == text]
    if len(found) != 1:
        raise ValueError(f"段落「{str(text)[:16]}」が {len(found)} 個")
    return found[0]


def tail_blocks():
    return [N.RH, Raw(*N.REF1_LINES), Raw(*N.REF2_LINES), BREAK, N.en_block()]


def front_blocks():
    return [N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2]


Z_CAP = "図１　架空の授業の流れ"
T_CAP = "表１　架空の学級ごとの記述の数"
T_ROWS = [["学級", "一回目", "二回目"], ["Ａ組", "12", "7"], ["Ｂ組", "19", "16"]]

# ============================================================================ iso_eq_*
EQ_A = ("水を入れる時間をｘ分，水の深さをｙcmとして，表の値の組を調べると，どの組でも深さは時間の２倍になっていることが"
        "分かる。このことを式で表すと次のようになり，")
EQ_B = ("となる。生徒は，この式の２が表の横の増え方と同じであることに気付き，ほかの水そうの表についても同じように式に表して"
        "確かめていた。")
EQ_EDITS = [("値の組を調べると", "値の組を確かめると"), ("確かめていた", "確かめ合っていた")]
for ek, eq in (("en", "y = 2 x"), ("jp", "深さ ＝ ２ × 時間")):
    docx_t = EQ_A + EQ_B
    pub_a, pub_b = EQ_A.replace(*EQ_EDITS[0]), EQ_B.replace(*EQ_EDITS[1])
    paras = N.article_paras(docx_t)
    la = N.body(pub_a)
    assert len(la[-1]) < 12, la
    pages = flow([*front_blocks(), Raw(*la), Raw(eq), Raw(*N.jwrap(pub_b)), Raw(*N.body(N.P_AFTER)), N.H3,
                  Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
    case(f"iso_eq_{ek}", "N20", paras, pages,
         f"段落の途中に別行立ての式（PDF の行「{eq}」。docx には式がない形にして、PDF にだけある行とする）があり、式の前の行は"
         f"短く「，」で終わる（{len(la[-1])} 文字）。式の前（「{EQ_EDITS[0][0]}」→「{EQ_EDITS[0][1]}」）と後ろ（「{EQ_EDITS[1][0]}」→"
         f"「{EQ_EDITS[1][1]}」）の両方に校正の直しがあり、本当の段落の行なので直す。式の行は足さない。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_t): pub_a + pub_b},
         expect={"default": "exact", idx(paras, docx_t): "reported"})

# ============================================================================ iso_colon_*
COLON = ("各学級で記述の数を数え，一回目と二回目の授業で比べた。その結果は，次の表のとおりである")
for ck, (old, new) in (("mid", ("一回目と二回目", "第一回と第二回")), ("last", ("次の表の", "下の表の"))):
    paras = N.article_paras(COLON, (), [("表キャプション", T_CAP), ("表", T_ROWS)])
    pub_t = COLON.replace(old, new)
    cells = [" ".join(r) for r in T_ROWS]
    pages = flow([*front_blocks(), Raw(*N.body(pub_t)), Raw(T_CAP, *cells), Raw(*N.body(N.P_AFTER)), N.H3,
                  Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
    case(f"iso_colon_{ck}", "N20", paras, pages,
         f"段落の最後の行が文の終わりで終わらず（「…次の表のとおりである」）、すぐ後ろが表のキャプションと表。校正の直し"
         f"（「{old}」→「{new}」。{'段落の途中の行' if ck == 'mid' else '最後の行'}）を直すか、決められなければ docx のまま"
         "13 章に出す。表の文字を足さない。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, COLON): pub_t},
         expect={"default": "exact", idx(paras, COLON): "reported"})

# ============================================================================ iso_ftopx_*
X = N.TARGET.replace("生徒どうしで説明し合う時間を取った。", "生徒どうしで説明し合い，互いの考えを比べて確かめる")
LAST = "時間を取った。"
DEL = "その結果を表に示す。"
assert [len(x) for x in N.body(X)] == [24] * 8
for ek in ("del", "edit"):
    docx_t = X + LAST + (DEL if ek == "del" else "")
    pub_last = LAST if ek == "del" else "時間を持った。"
    paras = N.article_paras(docx_t, (), [("画像", "fig"), ("図キャプション", Z_CAP)])
    for fk, fig in (("period", "時間を見る。"), ("full", "時間を見る活動と話し合いの流れを表した図の例")):
        if fk == "full":
            assert len(fig) >= 22, len(fig)
        second = [fig, Z_CAP, pub_last]
        pages = flow([*front_blocks(), Raw(*N.body(X)), BREAK, Raw(*second), Raw(*N.body(N.P_AFTER)), N.H3,
                      Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
        case(f"iso_ftopx_{ek}_{fk}", "N20", paras, pages,
             f"cases_iso3 の iso_ftop の形で、次のページの最初の図の中の行が「{fig}」（{len(fig)} 文字。"
             f"{'文の終わりで終わる' if fk == 'period' else '行の幅いっぱい'}）。本当の続きの行「{pub_last}」はキャプションの後ろ。"
             + (f"docx の段落の最後の文「{DEL}」は校正で消されている。" if ek == "del" else
                "本当の最後の行は校正で「取った」→「持った」と直されている。")
             + "図の中の文字を足さず、docx の文字を図の中の文字で置き換えない。",
             truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_t): X + pub_last},
             expect={"default": "exact", idx(paras, docx_t): "reported"})
