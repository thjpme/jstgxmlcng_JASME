"""B2.1 の試作（isolate）の再現の例・その 5（stray_edge〈似ているかで消すかを決める規則〉と hole_beyond の違いを見る）。
文字はすべて架空（実際の論文の文字を書き写していない）。

oracle/run_all.py の書式（oracle/runner.py の docstring）。実行（scratchpad の oracle/ で）:
  python run_all.py <src> ../b21/isolate/cases_iso5.py --name <名前>
期待は原則だけで決める。
  iso_far_edit_*  段落の最後の行（最後の文）が、PDF では表（キャプションとセル）か、2 段組みの読み順のずれでほかの段落の後ろに
                  出て、校正で大きく書き換えられている（docx の文字と 3 分の 1 も似ていない。穴として置けない）。docx の文字を消さない
                  （直すか、決められなければ docx のまま 13 章に出す）。stray_edge（0.21.0）は似ていないので消す
  iso_far_del_*   対照: 段落の最後の文が校正で消されていて、PDF では段落のすぐ後ろに表（キャプションとセル）か、ほかの段落がある。
                  消すか、決められなければ docx のまま 13 章に出す（足さない）
"""
from __future__ import annotations

import sys
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
sys.path.insert(0, str(S / "n10"))

from runner import BREAK, Raw, flow  # noqa: E402
import cases_n10 as N  # noqa: E402

CASES = []


def case(name, item, paras, pages, note, truth=None, expect="exact", angle="layout"):
    CASES.append({"name": name, "angle": angle, "item": item, "paras": paras, "truth": truth or {},
                  "pages": pages, "expect": expect, "note": note})


def idx(paras, text):
    found = [i for i, (_, t) in enumerate(paras) if t == text]
    if len(found) != 1:
        raise ValueError(f"段落「{str(text)[:16]}」が {len(found)} 個")
    return found[0]


def tail_blocks():
    return [N.RH, Raw(*N.REF1_LINES), Raw(*N.REF2_LINES), BREAK, N.en_block()]


def front_blocks():
    return [N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2]


T_CAP = "表１　架空の学級ごとの記述の数"
T_ROWS = [["学級", "一回目", "二回目"], ["Ａ組", "12", "7"], ["Ｂ組", "19", "16"]]
OTHER = "この点は次の節で改めて詳しく述べる。"
OLD = "時間を取った。"
DEL = "以上が第三時の流れである。"
assert N.TARGET.endswith(OLD)
HEAD = N.TARGET[:-len(OLD)]
for nk, new in (("a", "話し合わせた。"), ("b", "発表させた。"), ("c", "議論が深まった。"), ("d", "議論が深まる場面もみられる。"),
                ("e", "二人組で話し合う場面も設ける。")):
    pub = HEAD + new
    for sk in ("table", "para"):
        if sk == "table":
            paras = N.article_paras(N.TARGET, (), [("表キャプション", T_CAP), ("表", T_ROWS)])
            middle = [T_CAP] + [" ".join(r) for r in T_ROWS]
        else:
            paras = N.article_paras(N.TARGET, others_after=[("本文", OTHER)])
            middle = N.body(OTHER)
        pages = flow([*front_blocks(), Raw(*N.body(HEAD)), Raw(*middle), Raw(*N.jwrap(new)), Raw(*N.body(N.P_AFTER)),
                      N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()], first=25) if sk == "table" else \
            flow([*front_blocks(), Raw(*N.body(HEAD)), Raw(*N.body(N.P_AFTER)), Raw(*N.jwrap(new)), Raw(*middle),
                  N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
        case(f"iso_far_edit_{nk}_{sk}", "N20", paras, pages,
             f"段落の最後の文の一部「{OLD}」が、PDF では{'表（キャプションとセル）' if sk == 'table' else 'すぐ後ろの段落'}の後ろに出て、"
             f"校正で「{new}」に書き換えられている（docx の文字と 3 分の 1 も似ていない）。docx の文字を消さない（直すか、決められ"
             "なければ docx のまま 13 章に出す）。表・ほかの段落の文字を足さない。",
             truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): pub},
             expect={"default": "exact", idx(paras, N.TARGET): "reported"})
for sk in ("table", "para"):
    docx_t = N.TARGET + DEL
    if sk == "table":
        paras = N.article_paras(docx_t, (), [("表キャプション", T_CAP), ("表", T_ROWS)])
        pages = flow([*front_blocks(), Raw(*N.body(N.TARGET)), Raw(T_CAP, *[" ".join(r) for r in T_ROWS]),
                      Raw(*N.body(N.P_AFTER)), N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
    else:
        paras = N.article_paras(docx_t, others_after=[("本文", OTHER)])
        pages = flow([*front_blocks(), Raw(*N.body(N.TARGET)), Raw(*N.body(N.P_AFTER)), Raw(*N.body(OTHER)), N.H3,
                      Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
    case(f"iso_far_del_{sk}", "N20", paras, pages,
         f"対照: docx の段落の最後の文「{DEL}」が校正で消されていて、PDF では段落のすぐ後ろに"
         f"{'表（キャプションとセル）' if sk == 'table' else '次の段落'}がある。消すか、決められなければ docx のまま 13 章に出す。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_t): N.TARGET},
         expect={"default": "exact", idx(paras, docx_t): "reported"})
