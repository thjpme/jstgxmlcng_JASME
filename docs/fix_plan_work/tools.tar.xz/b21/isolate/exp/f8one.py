"""isolate: fuzz8 の 1 つのケースを、指定したコードで照合し、真の文字と違う段落の、直した後の文字・13 章に出るものを出す（架空の文字の例）。
  python -I f8one.py SRC GROUP K [段落の最初の文字]"""
import json
import sys
from pathlib import Path

src, group, k = sys.argv[1], sys.argv[2], int(sys.argv[3])
head = sys.argv[4] if len(sys.argv) > 4 else ""
sys.path.insert(0, src)
from jasme_jats.config import JournalConfig  # noqa: E402
from jasme_jats.pdfdocx import _mechanical, plan_fixes  # noqa: E402
from jasme_jats.pdfmatch import compare  # noqa: E402
S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
c = json.load(open(S / "rvB8_regress" / "fuzz8" / group / "cases.json", encoding="utf-8"))[k]
_, plan = _mechanical(c["docx"], JournalConfig.load())
pc = compare(plan, c["pages"])
fixes = plan_fixes(plan, pc)
for s, p in plan.paras.items():
    t = p.plain()
    if t not in c["truth"] or (head and not t.startswith(head)):
        continue
    fx = sorted((f for f in fixes if f.src == s and not f.reason), key=lambda f: -f.start)
    new = t
    for f in fx:
        new = new[:f.start] + f.new + new[f.end:]
    if new == c["truth"][t] and not head:
        continue
    print("==", s)
    print(" docx :", t)
    print(" truth:", c["truth"][t])
    print(" fixed:", new)
    for f in fixes:
        if f.src == s:
            print("  fix", repr(f.old), "->", repr(f.new), f.kind, (f.reason or "")[:30])
    for d in pc.diffs:
        if d.src == s:
            print("  diff", repr(d.docx), repr(d.pdf), d.fixable, (d.why or "")[:30])
if "-p" in sys.argv:
    for pg in c["pages"]:
        print("-----"); print(pg)
