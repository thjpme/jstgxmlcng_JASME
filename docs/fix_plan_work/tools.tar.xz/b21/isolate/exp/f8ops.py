"""isolate: fuzz8 の 1 つのケースの、段落の照合（_align の ops）と _isolate の結果を出す（架空の文字の例）。
  python -I f8ops.py SRC GROUP K 段落の最初の文字"""
import json
import sys
from pathlib import Path

src, group, k, head = sys.argv[1], sys.argv[2], int(sys.argv[3]), sys.argv[4]
sys.path.insert(0, src)
import jasme_jats.pdfmatch as M  # noqa: E402
from jasme_jats.config import JournalConfig  # noqa: E402
from jasme_jats.pdfdocx import _mechanical  # noqa: E402
S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
c = json.load(open(S / "rvB8_regress" / "fuzz8" / group / "cases.json", encoding="utf-8"))[k]
_, plan = _mechanical(c["docx"], JournalConfig.load())
orig = M._classify


def spy(p, seq, gens, win, ops, unsure, st, owner, *a, **kw):
    if p.plain().startswith(head):
        D = "".join(ch for ch, _ in seq)
        for tag, i1, i2, j1, j2 in ops:
            print(f"  {tag:7} docx {D[i1:i2]!r:30} pdf {''.join(st.chars[win[j]] for j in range(j1, j2))!r}  lines {sorted({st.line[win[j]] for j in range(j1, j2)})}")
        print("  unsure:", {k2: v for k2, v in unsure.items() if k2 in ("head", "tail", "head_beyond", "tail_beyond", "doubt", "flow")})
        if hasattr(M, "_isolate"):
            nf = a[-1] if a and isinstance(a[-1], (set, frozenset)) else kw.get("nonflow", frozenset())
            print("  isolate:", M._isolate(p.src, seq, win, ops, st, owner, 24, unsure["doubt"], nf) if "nonflow" in M._isolate.__code__.co_varnames else M._isolate(p.src, seq, win, ops, st, owner, 24, unsure["doubt"]))
    return orig(p, seq, gens, win, ops, unsure, st, owner, *a, **kw)


M._classify = spy
M.compare(plan, c["pages"])
