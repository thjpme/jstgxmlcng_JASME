"""isolate: 本誌の出版版 PDF 7 通り（realpdf/out/docx の確かめ用 docx と PDF）で、本体から離れた部分のある段落を数える（段落 ID と数だけ）。
  python -I far_stats.py SRC"""
import sys
from pathlib import Path
sys.path.insert(0, sys.argv[1])
from jasme_jats import pdfmatch as M  # noqa: E402
from jasme_jats.config import JournalConfig  # noqa: E402
from jasme_jats.pipeline import _mechanical  # noqa: E402
I = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b21/isolate")
J = JournalConfig.load()
orig = M._isolate
hits = []


def spy(src, seq, win, ops, st, owner, width, doubt=()):
    r = orig(src, seq, win, ops, st, owner, width, doubt)
    if r[2] or r[3]:
        hits.append((src, bool(r[2]), bool(r[3]), r[0], len(seq) - r[1]))
    return r


M._isolate = spy
for d in sorted((I / "realpdf" / "out" / "docx").glob("*.docx")):
    stem = "_".join(d.stem.split("_")[:4])
    pages = M.extract_pages(Path("/home/user/jstgxmlcng_JASME/tests/private/pdf") / f"{stem}.pdf")
    _, plan, _ = _mechanical(d, J)
    hits.clear()
    pc = M.compare(plan, pages)
    far = [d2 for d2 in pc.diffs if d2.why == getattr(M, "FAR_WHY", None)]
    print(d.stem, "離れた部分のある段落:", [(s, h, t, b, e) for s, h, t, b, e in hits], " FAR の違い:", [(x.src, len(x.docx), len(x.pdf)) for x in far])
