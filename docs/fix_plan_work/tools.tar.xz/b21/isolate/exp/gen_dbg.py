"""isolate: 調べもの用の生成例（tests/test_pdfmatch.py の部品で、既存のテストの形を 1 つずつ作る）。"""


def make_cases(T):
    out = []
    blocks, middle, rest = T.split_tail_blocks("paragraph")
    for cut, tail in T.TAIL_EDITS:
        pub = T.LESSON[:-cut] + tail
        head = [*T.SMALL_FRONT, *T.body_lines(T.LESSON[:-cut]), *middle, tail]
        out.append({"name": f"stail_par_date_{cut}", "blocks": blocks, "pages": [[*head, T.R1], [*rest, *T.N10_TAIL]],
                    "want": {T.LESSON: pub}})
    return out
