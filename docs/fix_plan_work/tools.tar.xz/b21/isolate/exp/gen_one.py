"""isolate: 生成例の 1 つを、指定したコードで照合し、段落の文字・直す箇所・13 章に出るものと PDF の行を出す（架空の文字の例）。
  python -I gen_one.py SRC GENFILE 名前 [-p]"""
import importlib.util
import sys
import tempfile
from pathlib import Path

src, gen, name = sys.argv[1], sys.argv[2], sys.argv[3]
sys.path.insert(0, src)
sys.path.insert(1, "/home/user/jstgxmlcng_JASME/tests")
spec = importlib.util.spec_from_file_location("tp", "/home/user/jstgxmlcng_JASME/tests/test_pdfmatch.py")
T = importlib.util.module_from_spec(spec)
spec.loader.exec_module(T)
from jasme_jats.config import JournalConfig  # noqa: E402
from jasme_jats.pdfdocx import plan_fixes  # noqa: E402
sys.path.insert(2, str(Path(gen).resolve().parent))
spec2 = importlib.util.spec_from_file_location("gen", gen)
G = importlib.util.module_from_spec(spec2)
spec2.loader.exec_module(G)
c = next(c for c in G.make_cases(T) if c["name"] == name)
plan, src_map = T.n10_article(Path(tempfile.mkdtemp()), JournalConfig.load(), c["blocks"])
pc = T.compare(plan, T.n10_pages(*c["pages"]))
fx = plan_fixes(plan, pc)
for d, p in c["want"].items():
    s = src_map[d]
    print("==", s, "docx:", d[:50])
    print("   want:", p[:50])
    for f in fx:
        if f.src == s:
            print("   fix", repr(f.old), "->", repr(f.new), f.kind, (f.reason or "")[:30])
    for x in pc.diffs:
        if x.src == s:
            print("   diff", repr(x.docx), repr(x.pdf), x.fixable, (x.why or "")[:30])
if "-p" in sys.argv:
    for k, pg in enumerate(c["pages"]):
        print("----- page", k + 1)
        print("\n".join(pg))
