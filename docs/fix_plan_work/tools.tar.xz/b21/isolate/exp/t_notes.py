import sys, tempfile
from pathlib import Path
sys.path.insert(0, sys.argv[1]); sys.path.insert(1, "/home/user/jstgxmlcng_JASME/tests")
from conftest import NOTES
from jasme_jats import pdfmatch
from jasme_jats.config import ArticleMeta, JournalConfig
from jasme_jats.pipeline import Options, convert
pages = ["本文の大きさで書いた注番号1）と，角括弧の注番号［注2］がある文。\n"
         "箇条の番号（1）と（2）は注へのリンクにしない。2 段落からなる注3）もある。\n"
         "注\n１）本文の大きさで書かれた注番号の注である。\n［注2］角括弧で書かれた注番号の注である。\n"
         "３）2 段落からなる注の 1 段落目である。\n"]
pdfmatch.extract_pages = lambda path: pages
td = Path(tempfile.mkdtemp())
(td / "dummy.pdf").write_bytes(b"%PDF-1.4\n")
meta = ArticleMeta.from_dict({"volume": "31", "issue": "1", "fpage": "1", "lpage": "12", "pub_date": "2026-03-31",
                              "received": "2025-06-01", "accepted": "2025-11-20", "peer_review": "あり", "keywords": "a; b"})
res = convert(NOTES, meta, JournalConfig.load(), Options(out_dir=td, pdf_path=td / "dummy.pdf", route="pdf", convert_metafiles=False))
for f in res.docx_fix.skipped:
    print(f.src, repr(f.old), repr(f.new), f.kind, f.reason[:30])
for d in res.docx_fix.check.diffs if res.docx_fix.check else []:
    pass
