"""isolate: td1〜3 で、本体から離れた部分になった段落の、分かれ目の理由を出す（段落 ID・行の幅・分かれ目の種類だけ。本文の文字は出さない）。
  python -I td_far.py SRC N [段落 ID...]"""
import sys
from pathlib import Path
sys.path.insert(0, sys.argv[1])
from jasme_jats import pdfmatch as M  # noqa: E402
from jasme_jats.config import JournalConfig  # noqa: E402
from jasme_jats.pipeline import _mechanical  # noqa: E402
n = sys.argv[2]
want = set(sys.argv[3:])
d = Path(f"/home/user/jstgxmlcng_JASME/tests/private/colab/td{n}")
_, plan, _ = _mechanical(d / f"td{n}.docx", JournalConfig.load())
pages = M.extract_pages(d / f"td{n}.pdf")
orig = M._isolate


def why_break(src, ka, kb, st, owner, width):
    if kb <= ka:
        return "順の逆転"
    la, lb = st.line[ka], st.line[kb]
    if la != lb and M._ends_flow(st, la, width):
        return f"段落の終わりの行（幅 {M._line_width(st.lines[la]):.1f}/{width:.1f}）"
    for k in range(ka + 1, kb):
        o = owner.get(k)
        if o == src or st.soft[k]:
            continue
        if o is not None:
            return f"ほかの段落 {o}"
        ln = st.line[k]
        if ln in (la, lb):
            continue
        if st.date[k] >= 0 or (st.edge[k] and st.head[k]):
            continue
        if getattr(M, "ISO_TINY", False) and 0 < M._visible_count(st.lines[ln]) < M.MIN_CHARS:
            continue
        if width and M._line_width(st.lines[ln]) >= M.ISO_FULL * width:
            continue
        return f"どの段落にも当たらない行（幅 {M._line_width(st.lines[ln]):.1f}, head={st.head[k]}, lonly={st.line_only[k]}）"
    return "-"


def spy(src, seq, win, ops, st, owner, width, *rest):
    r = orig(src, seq, win, ops, st, owner, width, *rest)
    if (r[2] or r[3]) and (not want or src in want):
        pairs = [(i1 + k, win[j1 + k]) for tag, i1, i2, j1, j2 in ops if tag == "equal" for k in range(i2 - i1)]
        print(f"{src}: 本体 seq[{r[0]}:{r[1]}] / {len(seq)}  head_far={bool(r[2])} tail_far={bool(r[3])}  width={width:.1f}")
        for x, y in zip(pairs, pairs[1:]):
            if M._flow_breaks(src, x[1], y[1], st, owner, width):
                print(f"   分かれ目 seq {x[0]}->{y[0]} 行 {st.line[x[1]]}->{st.line[y[1]]}: {why_break(src, x[1], y[1], st, owner, width)}")
    return r


M._isolate = spy
pc = M.compare(plan, pages)
for dd in pc.diffs:
    if dd.why == getattr(M, "FAR_WHY", None) and (not want or dd.src in want):
        print("  FAR:", dd.src, "docx", len(dd.docx), "文字 / pdf", len(dd.pdf), "文字")
