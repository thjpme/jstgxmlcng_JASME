"""isolate: 比べのための切り替え（ISO_*）を、選んだ形（src_E）に固めた試作の最終版を I/src に書く。

  python finalize.py SRC_FROM DEST        # 例: python finalize.py ../src_E ../src

切り替えは、すべて次の形に固める: 受付日の行・ページの端の柱の候補の行は流れを切らない（ISO_ARTIFACTS=1）、目に見えて短い行で
流れが終わる（ISO_SHORT=1・ISO_SHORTANY=1）、段落の行の幅いっぱいの、どの段落にも当たらない行は流れを切らない（ISO_FULLFREE=1）、
本文の行のある部分は本体（ISO_SOLID=1）、MIN_CHARS 文字未満の行は流れを切らない（ISO_TINY=1）、段落の端の穴は hole_beyond
（ISO_STRAY=generic。stray_edge・edge_run・_edge_part は消す）。
"""
import re
import shutil
import sys
from pathlib import Path

src, dest = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
if dest.exists():
    shutil.rmtree(dest)
shutil.copytree(src, dest, ignore=shutil.ignore_patterns("__pycache__"))
pm = dest / "jasme_jats" / "pdfmatch.py"
text = pm.read_text(encoding="utf-8")


def rep(old, new):
    global text
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"{n} 回: {old[:80]!r}")
    text = text.replace(old, new)


def cut_method(name):
    """クラスの中のメソッド name を、次のメソッド（同じ字下げの def か、区切りの注釈）の前まで消す。"""
    global text
    m = re.search(rf"\n    def {name}\(.*?(?=\n    def |\n    # -{{10}})", text, re.S)
    if not m:
        raise SystemExit(f"ない: {name}")
    text = text[:m.start()] + text[m.end():]


# ---------------------------------------------------------------- 冒頭の説明
rep("""  ・PDF の中で、図・表の文字に挟まれた位置にある、分断された段落の部分（DISPLACED_WHY。図の中の原稿の写しかもしれない）。
    段落の最後（最初）の行と並べた行が、図の中の文字とキャプションの間などにあり、段落の文字とよく似た図の中の語句かもしれない
    ときも同じ（_Joint.figure_edge_lines。その行の文字と、分断する表・図の中の文字とみなした位置の文字に並べた docx の文字は、
    全角・半角・大文字・小文字・行末のダッシュの違いも直さない）
""", """  ・PDF の中で、図・表の文字に挟まれた位置にある、分断された段落の部分（DISPLACED_WHY。図の中の原稿の写しかもしれない）。
    分断する表・図の中の文字とみなした位置の文字に並べた docx の文字は、全角・半角・大文字・小文字・行末のダッシュの違いも
    直さない
  ・PDF の中で段落が分断されていて、段落の本体から離れた最初・最後の部分にかかる違い（FAR_WHY。_isolate）。照合で一致した
    文字を、本文の行の流れが切れるところ（PDF の中の順が docx と逆になる、間にほかの段落の塊の文字か、どの段落にも当たらない
    行〈図・表の中の文字・キャプションなど〉がある、前の行が段落の終わりの行〈行の幅より短く文の終わりで終わる行など〉）で
    分け、いちばん長い部分と、本文の行（段落の行の幅いっぱいの行）のある部分を本体とする。本体から離れた最初・最後の部分は、
    段落の本文の続きか、段落の文字とよく似た図の中の語句か、隣の段落の行かを PDF から決められないので、全角・半角・大文字・
    小文字・行末のダッシュの違いも含めて直さない（足さず、消さず、置き換えない）。受付日の行・ページの端の柱の候補の行
    （ページの区切りの組版の文字）、MIN_CHARS 文字未満の行、段落の行の幅いっぱいの行（校正で足された文の行かもしれない）は、
    流れを切らない。段落の最初（最後）の docx の文字がどの塊にも入らず、PDF の中でほかの段落の塊の向こうに、どの段落にも
    当たらない文字が続くときは、その文字を消さない（_Joint.hole_beyond。UNSURE_WHY）
""")

# ---------------------------------------------------------------- 理由の注釈
rep("""# ルート2 で直さない理由（PDF の中で分断された段落の部分で、前と後ろの両方が図・表の文字に挟まれたもの。図の中の原稿の写しと
# 並べたものかもしれない。段落の最後〈最初〉の行と並べた、図の中の文字とキャプションの間の行〈段落の文字とよく似た図の中の
# 語句〉と、キャプションと受付日の行の間の、隣の段落の行かもしれない行も。_Joint.figure_edge_lines）
""", """# ルート2 で直さない理由（PDF の中で分断された段落の部分で、前と後ろの両方が図・表の文字に挟まれたもの。図の中の原稿の写しと
# 並べたものかもしれない。分断する表・図の中の文字とみなした位置〈floaty〉の文字と並べた docx の文字も）
""")
rep("短い行〈段落の終わり〉の後ろの部分の違い。段落の本文の続きか、段落の文字とよく似た図の中の語句かを決められない。_Joint.isolate）",
    "短い行〈段落の終わり〉の後ろの部分の違い。段落の本文の続きか、段落の文字とよく似た図の中の語句かを決められない。_isolate）")

# ---------------------------------------------------------------- 切り替えを定数に
m = re.search(r"# isolate（B2\.1 の試作。案 A「離れた端は直さない」）の切り替え.*?ISO_TINY = [^\n]*\n", text, re.S)
assert m, "切り替えの塊がない"
text = text[:m.start()] + """# 段落の本体から離れた最初・最後の部分（_isolate）を決めるときに、段落の行の幅いっぱいとみなす割合。両端そろえの段落の行は
# 行の幅いっぱいになるので、これより短く文の終わりで終わる行（SHORT_LINE より短い行は、文の終わりでなくても）で段落の本文の
# 行の流れが終わるとみなし（_ends_flow）、これ以上の幅の、どの段落にも当たらない行は流れを切らないとする（_flow_breaks）
FULL_LINE = 0.9
""" + text[m.end():]

# ---------------------------------------------------------------- _JointResult の説明
rep("""文字とみなすもの。doubt: 図の中の文字に挟まれた、分断された部分の行と、図の中の行と偶然一致したかもしれない段落の
    最後（最初）の行の番号（DISPLACED_WHY）。edge_doubt: doubt のうち、後ろの行（_Joint.figure_edge_lines）だけ（その行と
    並べた docx の文字は、全角・半角などの違いも直さない。_classify）。head_free・tail_free: 窓の""",
    """文字とみなすもの。doubt: 図の中の文字に挟まれた、分断された部分の行の番号（図の中の原稿の写しかもしれない。
    DISPLACED_WHY）。head_beyond・tail_beyond: 段落の最初・最後の docx の文字がどの塊にも入らず、PDF の中でほかの段落の塊の
    向こうに、どの段落にも当たらない文字が続くか（_Joint.hole_beyond。その位置に同じ行の PDF の文字がなければ、消さない。
    UNSURE_WHY）。head_free・tail_free: 窓の""")

# ---------------------------------------------------------------- find_hole の説明
rep("""        まったく同じ文字のときだけ。ただし、続きが行まるごとで、すぐ後ろ（前）が docx ですぐ後ろ（前）の本文の段落の塊なら、
        穴の文字の一部が校正で直されたものでも置く（_loose_edge。表の後ろに出た最後の行「持った。」と docx の「取った。」。
        続きの最後〈最初〉の照合に使わない行だけの行を飛ばした後も。穴が docx で一文まるごとのときは置かない）。
""", """        まったく同じ文字のときだけ（置いた部分が段落の本体から離れていれば、その違いは直さない。_isolate）。
""")

# ---------------------------------------------------------------- stray_edge と、それだけが使うものを消す
for name in ("_edge_part", "edge_run", "stray_edge"):
    cut_method(name)
rep("ほかの段落の後ろ（前）にあるかもしれないか（result。消さない。0.21.0 の stray_edge に代わるもの）。",
    "ほかの段落の後ろ（前）にあるかもしれないか（result。消さない）。")
rep("""                0 if self.material_before[n] else self.figure_ctx(first[1], -1, short=True)) >= JOINT_FREE
                or (ISO_STRAY == "keep" and self.stray_edge(n, -1)))""",
    """                0 if self.material_before[n] else self.figure_ctx(first[1], -1, short=True)) >= JOINT_FREE)""")
rep("""                0 if self.material_after[n] else self.figure_ctx(last[1], 1, short=True)) >= JOINT_FREE
                or (ISO_STRAY == "keep" and self.stray_edge(n, 1)))""",
    """                0 if self.material_after[n] else self.figure_ctx(last[1], 1, short=True)) >= JOINT_FREE)""")
rep('head_beyond = ISO_STRAY != "keep" and head_hole and not head and self.hole_beyond(n, -1)',
    "head_beyond = head_hole and not head and self.hole_beyond(n, -1)")
rep('tail_beyond = ISO_STRAY != "keep" and tail_hole and not tail and self.hole_beyond(n, 1)',
    "tail_beyond = tail_hole and not tail and self.hole_beyond(n, 1)")

# ---------------------------------------------------------------- _flow_breaks・_ends_flow・_isolate・_solid
rep("""    続くのは、PDF の中の順が docx の順と同じで、ka の行が段落の終わりの行（_ends_flow）でなく、間に、ほかの段落に当たった文字も、
    どの段落にも当たらない行（図・表の中の文字・キャプションなど。ISO_ARTIFACTS なら、受付日の行と、ページの端の柱の候補の行
    〈ページの区切りの組版の文字〉は除く）もないとき（ka の行と kb の行の中の、どの段落にも当たらない文字〈校正の直し〉は
    あってもよい）。\"\"\"""",
    """    続くのは、PDF の中の順が docx の順と同じで、ka の行が段落の終わりの行（_ends_flow）でなく、間に、ほかの段落に当たった文字も、
    どの段落にも当たらない行（図・表の中の文字・キャプションなど）もないとき。ka の行と kb の行の中の、どの段落にも当たらない
    文字（校正の直し）と、間の次の行はあってもよい: 受付日の行・ページの端の柱の候補の行（ページの区切りの組版の文字）、
    MIN_CHARS 文字未満の行（図の目盛りの数字・矢印など。段落の文字の代わりにならない）、段落の行の幅 width の FULL_LINE 以上の
    行（校正で足された文の行かもしれない）。\"\"\"""")
rep("""        if ISO_ARTIFACTS and (st.date[k] >= 0 or (st.edge[k] and st.head[k])):
            continue
        if ISO_TINY and 0 < _visible_count(st.lines[ln]) < MIN_CHARS:""",
    """        if st.date[k] >= 0 or (st.edge[k] and st.head[k]):
            continue              # 受付日の行と、ページの端の柱の候補の行（ページの区切りの組版の文字）
        if 0 < _visible_count(st.lines[ln]) < MIN_CHARS:""")
rep("""        if ISO_FULLFREE and width:
            if ln not in full:
                full[ln] = _line_width(st.lines[ln]) >= ISO_FULL * width""",
    """        if width:
            if ln not in full:
                full[ln] = _line_width(st.lines[ln]) >= FULL_LINE * width""")
rep("""    短く（ISO_FULL）、文の終わりで終わる行で、段落が終わる。""",
    """    短く（FULL_LINE）、文の終わりで終わる行と、SHORT_LINE より短い行で、段落が終わる。""")
rep("""    if not ISO_SHORT or not width:
        return False""", """    if not width:
        return False""")
rep("    return (ISO_SHORTANY and w < SHORT_LINE * width) or (w < ISO_FULL * width and _ends_sentence(body))",
    "    return w < SHORT_LINE * width or (w < FULL_LINE * width and _ends_sentence(body))")
rep("""    if ISO_SOLID:
        # 本文の行（段落の行の幅いっぱいの行で、文字の半分以上がこの段落の文字と一致するもの）のある部分は、図・表などを
        # はさんでいても段落の本文の続き（本体）とみなす（図・表は本文の行の流れの外に置かれる）
        # （図の中の文字に挟まれた部分〈doubt。図の中の原稿の写しかもしれない〉は除く）
        while lo > 0 and _solid(segs[lo - 1], st, width, doubt):
            lo -= 1
        while hi + 1 < len(segs) and _solid(segs[hi + 1], st, width, doubt):
            hi += 1""", """    # 本文の行（段落の行の幅いっぱいの行で、文字の半分以上がこの段落の文字と一致するもの）のある部分は、図・表などを
    # はさんでいても段落の本文の続き（本体）とみなす（図・表は本文の行の流れの外に置かれる）
    # （図の中の文字に挟まれた部分〈doubt。図の中の原稿の写しかもしれない〉は除く）
    while lo > 0 and _solid(segs[lo - 1], st, width, doubt):
        lo -= 1
    while hi + 1 < len(segs) and _solid(segs[hi + 1], st, width, doubt):
        hi += 1""")
rep("""    一致した文字を、本文の行の流れが続かないところ（_flow_breaks）で分け、いちばん多いものを本体にする。""",
    """    一致した文字を、本文の行の流れが続かないところ（_flow_breaks）で分け、いちばん多いものと、その前後に続く、本文の行のある
    部分（_solid）を本体にする。""")
rep("""    \"\"\"一致した文字の部分 seg（(seq の位置, 列の位置) のリスト）に、本文の行（段落の行の幅 width の ISO_FULL 以上の行で、行の""",
    """    \"\"\"一致した文字の部分 seg（(seq の位置, 列の位置) のリスト）に、本文の行（段落の行の幅 width の FULL_LINE 以上の行で、行の""")
rep("        if 2 * n >= size and _line_width(st.lines[ln]) >= ISO_FULL * width:",
    "        if 2 * n >= size and _line_width(st.lines[ln]) >= FULL_LINE * width:")

# ---------------------------------------------------------------- _classify の注釈
rep("""                # 図の中の行と偶然一致したかもしれない段落の最後（最初）の行（figure_edge_lines）と、分断する表・図の中の文字と
                # みなした位置（floaty）の PDF の文字と並べた docx の文字は、全角・半角・大文字・小文字・行末のダッシュの違いも
                # 図の中の文字に合わせず、直さない違い（DISPLACED_WHY）にする（本文の最後の行「時間を２回取った。」がキャプションの
                # 後ろに出て、その前の図の中の行「時間を2回見る」と並べたとき、「２」を「2」にしない）。図の中の原稿の写しかもしれない
                # 行（recheck_runs・find_hole の doubt）は、本当に分断された段落の部分のこともあるので、今までどおり合わせる""",
    """                # 段落の本体から離れた最初・最後の部分（_isolate。FAR_WHY）と、分断する表・図の中の文字とみなした位置（floaty。
                # DISPLACED_WHY）の PDF の文字と並べた docx の文字は、全角・半角・大文字・小文字・行末のダッシュの違いも図の中の
                # 文字に合わせず、直さない違いにする（本文の最後の行「時間を２回取った。」がキャプションの後ろに出て、その前の図の
                # 中の行「時間を2回見る」と並べたとき、「２」を「2」にしない）。図の中の原稿の写しかもしれない行（recheck_runs・
                # find_hole の doubt）は、本当に分断された段落の部分のこともあるので、本体の中なら今までどおり合わせる""")
rep("""            # 段落の最初（最後）の docx の文字が PDF のどこにも見つからず、PDF ではそのすぐ前（後ろ）に、どの段落とも一致しない
            # 文字が続く（図の中の文字など）: 校正で消されたのか、別の位置にあるのか決められないので、消さない""",
    """            # 段落の最初（最後）の docx の文字が PDF のどこにも見つからず、PDF ではそのすぐ前（後ろ）か、ほかの段落の塊の向こう
            # （head_beyond・tail_beyond。同じ行に PDF の文字がないときだけ）に、どの段落とも一致しない文字が続く（図の中の文字
            # など）: 校正で消されたのか、別の位置にあるのか決められないので、消さない""")

left = sorted(set(re.findall(r"ISO_[A-Z]+|stray_edge|edge_run|_edge_part|figure_edge_lines|_loose_edge|edge_doubt|_os\b", text)))
if left:
    raise SystemExit(f"残っている: {left}")
pm.write_text(text, encoding="utf-8")

rp = dest / "jasme_jats" / "report.py"
r = rp.read_text(encoding="utf-8")
old = """from .pdfmatch import (DISPLACED_WHY, EDGE_WHY, FAR_WHY, FORMULA_MARK, HEAD_WHY, LINE_MARK, LONG_WHY, MATH_WHY, RE_PAGE_NO, UNSURE_WHY,
                       WHOLE_WHY)"""
assert r.count(old) == 1
r = r.replace(old, """from .pdfmatch import (DISPLACED_WHY, EDGE_WHY, FAR_WHY, FORMULA_MARK, HEAD_WHY, LINE_MARK, LONG_WHY, MATH_WHY, RE_PAGE_NO,
                       UNSURE_WHY, WHOLE_WHY)""")
rp.write_text(r, encoding="utf-8")
print("書いた:", dest)
