"""isolate: src_G（試作の最終版 + _figure_line）から、比べのための切り替え（G_SHORTANY。0 に固める）を除いた最終版を DEST に書く。
  python finalize2.py SRC_G DEST"""
import shutil
import sys
from pathlib import Path

src, dest = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
if dest.exists():
    shutil.rmtree(dest)
shutil.copytree(src, dest, ignore=shutil.ignore_patterns("__pycache__"))
pm = dest / "jasme_jats" / "pdfmatch.py"
text = pm.read_text(encoding="utf-8")


def rep(old, new):
    global text
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"{n} 回: {old[:80]!r}")
    text = text.replace(old, new)


rep("""FULL_LINE = 0.9
import os as _os  # noqa: E402
G_SHORTANY = _os.environ.get("G_SHORTANY", "0") == "1"   # 比べのための切り替え（src_G だけ）
""", """FULL_LINE = 0.9
""")
rep("""# 段落の本体から離れた最初・最後の部分（_isolate）を決めるときに、段落の行の幅いっぱいとみなす割合。両端そろえの段落の行は
# 行の幅いっぱいになるので、これより短く文の終わりで終わる行（SHORT_LINE より短い行は、文の終わりでなくても）で段落の本文の
# 行の流れが終わるとみなし（_ends_flow）、これ以上の幅の、どの段落にも当たらない行は流れを切らないとする（_flow_breaks）""",
    """# 段落の本体から離れた最初・最後の部分（_isolate）を決めるときに、段落の行の幅いっぱいとみなす割合。両端そろえの段落の行は
# 行の幅いっぱいになるので、これより短く文の終わりで終わる行で段落の本文の行の流れが終わるとみなし（_ends_flow）、これより
# 短く文の終わりで終わらない行は、図・表の中の行かもしれないとする（_figure_line）。これ以上の幅の、どの段落にも当たらない
# 行は流れを切らない（_flow_breaks）""")
rep("""    return (G_SHORTANY and w < SHORT_LINE * width) or (w < FULL_LINE * width and _ends_sentence(body))""",
    """    return w < FULL_LINE * width and _ends_sentence(body)""")
rep("""    短く（FULL_LINE）、文の終わりで終わる行と、SHORT_LINE より短い行で、段落が終わる。""",
    """    短く（FULL_LINE）、文の終わりで終わる行で、段落が終わる。""")
# 冒頭の説明
rep("""    文字を、本文の行の流れが切れるところ（PDF の中の順が docx と逆になる、間にほかの段落の塊の文字か、どの段落にも当たらない
    行〈図・表の中の文字・キャプションなど〉がある、前の行が段落の終わりの行〈行の幅より短く文の終わりで終わる行など〉）で
    分け、""", """    文字を、本文の行の流れが切れるところ（PDF の中の順が docx と逆になる、間にほかの段落の塊の文字か、どの段落にも当たらない
    行〈図・表の中の文字・キャプションなど〉がある、前の行が段落の終わりの行〈行の幅より短く文の終わりで終わる行〉、どちらかの
    行が図・表の中の行かもしれない行〈行の幅より短く文の終わりで終わらない行で、すぐ隣が図・表のキャプションなどの行か、どの
    段落にも当たらない和文の行のもの。_figure_line〉）で分け、""")
assert "G_SHORTANY" not in text and "_os." not in text
pm.write_text(text, encoding="utf-8")
print("書いた:", dest)
