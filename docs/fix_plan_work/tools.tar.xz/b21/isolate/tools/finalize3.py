"""isolate: src_H2 の説明を整える（試作の最終版にする前）。  python finalize3.py DIR"""
import sys
from pathlib import Path

pm = Path(sys.argv[1]) / "jasme_jats" / "pdfmatch.py"
text = pm.read_text(encoding="utf-8")


def rep(old, new):
    global text
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"{n} 回: {old[:80]!r}")
    text = text.replace(old, new)


rep("""    m = max(range(len(segs)), key=lambda x: len(segs[x]))
    lo = hi = m
""", """    m = max(range(len(segs)), key=lambda x: len(segs[x]))
""")
rep("""    一致した文字を、本文の行の流れが続かないところ（_flow_breaks。図・表の中の行かもしれない行〈_figure_line〉の前後も）で分け、いちばん多いものと、その前後に続く、本文の行のある
    部分（_solid）を本体にする。戻り値:""",
    """    一致した文字を、本文の行の流れが続かないところ（_flow_breaks。図・表の中の行かもしれない行〈_figure_line〉の前後も）で
    分け、いちばん多いものから、その前後の、本文の行のある部分（_solid）のいちばん遠いものまでを本体にする。本体の最後（最初）の
    行のすぐ向こうが図・表のキャプションなどで、その向こうに段落の最後（最初）の行らしい行があれば、その行は本体から外す
    （_edge_alternative）。戻り値:""")
rep("""    （ページの区切りの組版の文字）、MIN_CHARS 文字未満の行、段落の行の幅いっぱいの行（校正で足された文の行かもしれない）は、
    流れを切らない。""", """    （ページの区切りの組版の文字）、MIN_CHARS 文字未満の行、段落の行の幅いっぱいの行（校正で足された文の行かもしれない）は、
    流れを切らない。本文の行のある部分の間の部分（別行立ての式の前の短い行など）は本体に入れ、本体の最後（最初）の行のすぐ
    向こうが図・表のキャプションなどで、その向こうに段落の最後（最初）の行らしい、どの段落にも当たらない行（最後なら文の終わりで
    終わる行、最初なら行の幅いっぱいの行）があれば、その行は図の中の語句の行かもしれないので、本体から外す
    （_edge_alternative）。""")
pm.write_text(text, encoding="utf-8")
print("書いた:", pm)
