"""isolate: 生成例（h2.py の JSON）を、段落ごとに版で比べて数える。

  python gsum.py TAG... [--gens 名前,名前] [-v]     # 最初の TAG が比べる相手

段落の分け方は h2.py のもの: OK（出版版と同じ）/ REP（足し・消しなし、13 章に出ている = 13.2 などに回った直し）/
SILENT（足し・消しなし、13 章に出ていない）/ FAIL（足した・消した）。docx と出版版が同じで、直した後も同じ段落は数えない。
"""
import json
import sys
from collections import Counter
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
DIRS = (S / "b21" / "isolate" / "gen", S / "fixB2r4" / "gen")
GENS18 = "head tail figsim figpre pages dup figstop figwidth figwidth_head capnext capprev figw figw2 figw3 widow bfp bpage figtop"
GENS5 = "r5better r5copytop r5face r5headfig r5simtop r5tabhead r5_bl r5_cnq r5_cpo r5_fw r5_rw"
args = [a for a in sys.argv[1:] if not a.startswith("-")]
gens = (GENS18 + " " + GENS5).split()
if "--gens" in sys.argv:
    gens = sys.argv[sys.argv.index("--gens") + 1].split(",")
    args = [a for a in args if a != sys.argv[sys.argv.index("--gens") + 1]]
verbose = "-v" in sys.argv
RANK = {"OK": 0, "REP": 1, "SILENT": 2, "FAIL": 3, "ERROR": 4}


def load(gen, tag):
    for d in DIRS:
        f = d / f"fz_{gen}_{tag}.json"
        if f.exists():
            return json.loads(f.read_text(encoding="utf-8"))["cases"]
    return None


tot = {t: Counter() for t in args}
per_gen = {}
trans = {t: Counter() for t in args[1:]}
worse = {t: [] for t in args[1:]}
for g in gens:
    data = {t: load(g, t) for t in args}
    if any(v is None for v in data.values()):
        print(f"{g}: 結果がない {[t for t, v in data.items() if v is None]}")
        continue
    per_gen[g] = {t: Counter() for t in args}
    for name, c in data[args[0]].items():
        srcs = set()
        for t in args:
            srcs |= set((data[t].get(name) or {}).get("paras", {}))
        for s in srcs:
            vs = {}
            for t in args:
                ct = data[t].get(name) or {}
                if ct.get("verdict") == "ERROR":
                    vs[t] = "ERROR"
                else:
                    vs[t] = ct.get("paras", {}).get(s, {}).get("v", "OK")
            for t in args:
                tot[t][vs[t]] += 1
                per_gen[g][t][vs[t]] += 1
            for t in args[1:]:
                if vs[t] != vs[args[0]]:
                    trans[t][(vs[args[0]], vs[t])] += 1
                if RANK[vs[t]] > RANK[vs[args[0]]]:
                    worse[t].append((g, name, s, vs[args[0]], vs[t]))
print("生成例（段落ごと）: " + ", ".join(per_gen))
print(f"{'版':12} {'OK':>6} {'REP':>6} {'SILENT':>6} {'FAIL':>6} {'ERROR':>5}")
for t in args:
    c = tot[t]
    print(f"{t:12} {c['OK']:6} {c['REP']:6} {c['SILENT']:6} {c['FAIL']:6} {c['ERROR']:5}")
for t in args[1:]:
    print(f"\n{args[0]} -> {t}: " + ", ".join(f"{a}→{b} {n}" for (a, b), n in trans[t].most_common()))
    if verbose:
        for w in worse[t][:60]:
            print("  悪:", w)
if verbose:
    print("\n種類ごと:")
    for g, d in per_gen.items():
        print(f"  {g:14} " + "  ".join(f"{t}: OK{d[t]['OK']} REP{d[t]['REP']} SIL{d[t]['SILENT']} FAIL{d[t]['FAIL']}" for t in args))
