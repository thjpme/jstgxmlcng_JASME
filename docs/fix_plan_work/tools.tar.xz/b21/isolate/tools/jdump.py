"""isolate: 1 つの例の、まとめての照合（_Joint）の塊・窓と、段落ごとの照合・違いを出す（調べもの用）。

  python -I jdump.py SRC gen GENFILE 名前 [段落の文字の頭...]
  python -I jdump.py SRC oracle CASEFILE 名前 [段落の文字の頭...]

段落の文字の頭を与えると、その文字で始まる段落だけを出す（省くと、違いか 2 つ以上の塊のある段落）。
"""
import importlib.util
import sys
import tempfile
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
src, kind, cfile, name = sys.argv[1:5]
heads = sys.argv[5:]
sys.path.insert(0, src)
import jasme_jats  # noqa: E402
from jasme_jats import pdfmatch as M  # noqa: E402
from jasme_jats.config import JournalConfig  # noqa: E402
from jasme_jats.pdfdocx import plan_fixes, expected_text  # noqa: E402
from jasme_jats.pipeline import _mechanical  # noqa: E402

J = JournalConfig.load()
td = Path(tempfile.mkdtemp(prefix="jdump_"))
if kind == "gen":
    sys.path.insert(1, "/home/user/jstgxmlcng_JASME/tests")
    spec = importlib.util.spec_from_file_location("tp", "/home/user/jstgxmlcng_JASME/tests/test_pdfmatch.py")
    T = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(T)
    sys.path.insert(2, str(Path(cfile).resolve().parent))
    spec2 = importlib.util.spec_from_file_location("gen", cfile)
    G = importlib.util.module_from_spec(spec2)
    spec2.loader.exec_module(G)
    case = next(c for c in G.make_cases(T) if c["name"] == name)
    plan, _ = T.n10_article(td, J, case["blocks"])
    pages = case["raw_pages"] if "raw_pages" in case else T.n10_pages(*case["pages"])
    want = case["want"]
else:
    sys.path.insert(1, str(S / "oracle"))
    import runner  # noqa: E402
    mods = []
    spec = importlib.util.spec_from_file_location(Path(cfile).stem, cfile)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    case = next(c for c in mod.CASES if c["name"] == name)
    mf = runner._fixtures(Path(jasme_jats.__file__).resolve().parents[2])
    runner.build_docx(case, td / "case.docx", mf)
    _, plan, _ = _mechanical(td / "case.docx", J)
    pages = list(case["pages"])
    want = {}
print("code:", jasme_jats.__file__, jasme_jats.__version__)

st = M.pdf_stream(pages)
targets = {p.src for p in M.target_paragraphs(plan)}
paras, gaps, between = [], [], False
for p in plan.paras.values():
    q, g = M._para_seq(p)
    if sum(1 for c, _ in q if c != M.SKIP) >= M.MIN_CHARS:
        paras.append((p, q, g))
        gaps.append(between)
        between = False
    else:
        between = between or not p.is_blank
jt = M._Joint(plan, paras, st, gaps)
jt.first_pass()
jt.recheck_runs()
jt.fill_holes()
jt.release_islands()
jt.fill_holes()
jt.contests()
jr = jt.result()
pc = M.compare(plan, pages)
fx = plan_fixes(plan, pc)


def line_text(ln):
    return st.lines[ln]


def show_line_kind(ln):
    ks = [k for k in range(len(st.chars)) if st.line[k] == ln]
    if not ks:
        return "-"
    tags = []
    if all(st.date[k] >= 0 for k in ks):
        tags.append("date")
    if st.edge[ks[0]]:
        tags.append("edge")
    if st.top[ks[0]]:
        tags.append("top")
    if st.head[ks[0]]:
        tags.append("head")
    if st.line_only[ks[0]]:
        tags.append("lonly")
    owners = sorted({jt.own[jt.cidx[k]] for k in ks if jt.cidx[k] >= 0 and jt.own[jt.cidx[k]] >= 0})
    return ",".join(tags) + (" own=" + ",".join(paras[o][0].src for o in owners) if owners else "")


for n, (p, seq, gens) in enumerate(paras):
    text = p.plain()
    my_diffs = [d for d in pc.diffs if d.src == p.src]
    runs = M._runs(jt.kept[n])
    if heads and not any(text.startswith(h) for h in heads):
        continue
    if not heads and not my_diffs and len(runs) < 2 and p.src not in pc.width:
        continue
    print(f"\n=== {p.src} flow={jt.flow[n]} target={p.src in targets} 「{text[:30]}…{text[-12:]}」")
    for r in runs:
        i0, i1 = r[0][0], r[-1][0]
        l0, l1 = jt.line_of[r[0][1]], jt.line_of[r[-1][1]]
        print(f"  run seq[{i0}..{i1}] n={len(r)} lines {l0}..{l1}  「{''.join(seq[i][0] for i in range(i0, i1 + 1))[:40]}」")
    win = jr.windows[n]
    if win:
        lines = sorted({st.line[k] for k in win})
        print("  window lines:", lines[0], "..", lines[-1])
        for ln in lines:
            print(f"    L{ln:3d} [{show_line_kind(ln)}] {line_text(ln)[:40]}")
    u = jr.unsure[n]
    print("  unsure:", {k: v for k, v in u.items() if v and k not in ("floaty", "contested")},
          "floaty:", len(u["floaty"]))
    for d in my_diffs:
        print(f"  diff fixable={d.fixable} docx「{d.docx}」 pdf「{d.pdf[:50]}」 why={(d.why or '')[:14]}")
    if p.src in pc.width:
        print("  width:", pc.width[p.src])
    got = expected_text(text, [f for f in fx if f.src == p.src and not f.reason])
    truth = want.get(text, text)
    if got != text or truth != text:
        print(f"  fixed : {got}")
        print(f"  truth : {truth}  {'OK' if got == truth else 'NG'}")
