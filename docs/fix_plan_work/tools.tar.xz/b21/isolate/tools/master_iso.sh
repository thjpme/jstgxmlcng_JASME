#!/bin/sh
# isolate: 1 つの版（SRC・TAG）で、物差しをすべて順に実行する。  sh master_iso.sh SRC TAG [real]
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
F=$S/fixB2r4; I=$S/b21/isolate; L=$I/logs; SRC=$1; TAG=$2
echo "start $TAG $(date +%T)"
sh $F/tools/run_suites.sh $SRC $TAG quick 4 > /dev/null; echo "quick $(date +%T)"
sh $F/tools/run_oracle.sh $SRC $TAG o34 n10 n10g rv89 judge judge2; rm -rf $S/oracle/_work/f4r_*_$TAG
sh $F/tools/run_oracle.sh $SRC $TAG b2 x xm r1 y y2; rm -rf $S/oracle/_work/f4r_*_$TAG
(cd $S/oracle && python run_all.py $SRC $I/cases_iso.py $S/b2_review/r5p/cases_v_only.py $S/b2_review/r4p/cases_w_only.py --name iso_rem_$TAG > $L/rem_$TAG.log 2>&1; grep "^合計" $L/rem_$TAG.log); rm -rf $S/oracle/_work/iso_rem_$TAG
echo "oracle $(date +%T)"
sh $F/tools/run_suites.sh $SRC $TAG f4 4 > /dev/null; echo "f4 $(date +%T)"
(cd $I && PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=$SRC python $S/golden/golden.py $I/v/golden_$TAG > $L/golden_$TAG.log 2>&1); echo "golden $(date +%T)"
sh $F/tools/run_suites.sh $SRC $TAG b210 1 > /dev/null; echo "b210 $(date +%T)"
sh $F/tools/run_suites.sh $SRC $TAG f8 4 > /dev/null; echo "f8 $(date +%T)"
sh $F/gen.sh $SRC $TAG; sh $I/tools/run_gen5.sh $SRC $TAG; echo "gen $(date +%T)"
if [ "$3" = real ]; then
  (cd $I/realpdf && python -I check.py --before-src $S/n10/judge/base_src --after-src $SRC --route1 --tag _$TAG > $L/real_$TAG.log 2>&1); echo "real $(date +%T)"
  sh $I/tools/run_td.sh $SRC $TAG; echo "td $(date +%T)"
  python -I $I/tools/t_speed.py $SRC 3 > $L/speed_$TAG.json 2>&1; echo "speed $(date +%T)"
fi
echo "end $TAG $(date +%T)"
