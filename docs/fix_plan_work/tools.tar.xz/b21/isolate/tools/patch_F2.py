"""isolate: 比べのための版 F2（最終版の hole_beyond の代わりに 0.21.0 の stray_edge を使う）を作る。
  python patch_F2.py FINAL_SRC SRC_E DEST"""
import re
import shutil
import sys
from pathlib import Path

final, e_src, dest = (Path(a).resolve() for a in sys.argv[1:4])
if dest.exists():
    shutil.rmtree(dest)
shutil.copytree(final, dest, ignore=shutil.ignore_patterns("__pycache__"))
pm = dest / "jasme_jats" / "pdfmatch.py"
text = pm.read_text(encoding="utf-8")
etext = (e_src / "jasme_jats" / "pdfmatch.py").read_text(encoding="utf-8")
m = re.search(r"\n    def _edge_part\(.*?(?=\n    def fill_holes)", etext, re.S)
assert m
assert text.count("\n    def fill_holes") == 1
text = text.replace("\n    def fill_holes", m.group(0) + "\n    def fill_holes", 1)


def rep(old, new):
    global text
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"{n} 回: {old[:80]!r}")
    text = text.replace(old, new)


rep("""                0 if self.material_before[n] else self.figure_ctx(first[1], -1, short=True)) >= JOINT_FREE)""",
    """                0 if self.material_before[n] else self.figure_ctx(first[1], -1, short=True)) >= JOINT_FREE
                or self.stray_edge(n, -1))""")
rep("""                0 if self.material_after[n] else self.figure_ctx(last[1], 1, short=True)) >= JOINT_FREE)""",
    """                0 if self.material_after[n] else self.figure_ctx(last[1], 1, short=True)) >= JOINT_FREE
                or self.stray_edge(n, 1))""")
rep("head_beyond = head_hole and not head and self.hole_beyond(n, -1)", "head_beyond = False")
rep("tail_beyond = tail_hole and not tail and self.hole_beyond(n, 1)", "tail_beyond = False")
pm.write_text(text, encoding="utf-8")
print("書いた:", dest)
