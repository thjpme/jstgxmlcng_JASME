"""isolate: src_G（試作の最終版 + 図・表の中の行かもしれない、短く文の終わりで終わらない行を本文の行の流れから外す）を作る。
  python patch_G.py DIR"""
import sys
from pathlib import Path

pm = Path(sys.argv[1]) / "jasme_jats" / "pdfmatch.py"
text = pm.read_text(encoding="utf-8")


def rep(old, new):
    global text
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"{n} 回: {old[:80]!r}")
    text = text.replace(old, new)


# compare: 本文の流れでない段落の集合を _classify に渡す
rep("""    short_end = {}             # 段落 ID -> 段落の最後に一致した文字の行が目に見えて短いか（_classify）
""", """    short_end = {}             # 段落 ID -> 段落の最後に一致した文字の行が目に見えて短いか（_classify）
    # 本文の流れでない段落（図・表のキャプション・表のセル・図形の中の段落。_isolate で、図・表の中の行を見分けるのに使う）
    nonflow = {p.src for (p, _, _), u in zip(paras, jt.unsure) if not u["flow"]}
""")
rep("""        short_end[p.src] = _classify(*aligned[p.src], st, owner, owned_lines, res, dense_lines, (shorts[n], shorts[n + 1]),
                                     p.src in heads)""",
    """        short_end[p.src] = _classify(*aligned[p.src], st, owner, owned_lines, res, dense_lines, (shorts[n], shorts[n + 1]),
                                     p.src in heads, nonflow)""")
rep("""def _classify(p, seq, gens, win, ops, unsure, st: PdfStream, owner, owned_lines, res: PdfCheck, dense_lines,
              beside=((), ()), heading=False):""",
    """def _classify(p, seq, gens, win, ops, unsure, st: PdfStream, owner, owned_lines, res: PdfCheck, dense_lines,
              beside=((), ()), heading=False, nonflow=frozenset()):""")
rep("""    fb, fe, head_far, tail_far = _isolate(p.src, seq, win, ops, st, owner, 0 if heading else own_width,
                                          unsure["doubt"]) if unsure["flow"] else (0, len(seq), None, None)""",
    """    fb, fe, head_far, tail_far = _isolate(p.src, seq, win, ops, st, owner, 0 if heading else own_width,
                                          unsure["doubt"], nonflow) if unsure["flow"] else (0, len(seq), None, None)""")

# _isolate: 図・表の中の行かもしれない行の判定を _flow_breaks に渡す
rep("""def _isolate(src, seq, win, ops, st: PdfStream, owner, width, doubt=()):""",
    """def _isolate(src, seq, win, ops, st: PdfStream, owner, width, doubt=(), nonflow=frozenset()):""")
rep("""    segs = [[pairs[0]]]
    for x, y in zip(pairs, pairs[1:]):
        if _flow_breaks(src, x[1], y[1], st, owner, width):""",
    """    seen = {}

    def figure(ln):
        if ln not in seen:
            seen[ln] = _figure_line(st, ln, owner, nonflow, width)
        return seen[ln]
    segs = [[pairs[0]]]
    for x, y in zip(pairs, pairs[1:]):
        if _flow_breaks(src, x[1], y[1], st, owner, width, figure):""")
rep("""    一致した文字を、本文の行の流れが続かないところ（_flow_breaks）で分け、""",
    """    一致した文字を、本文の行の流れが続かないところ（_flow_breaks。図・表の中の行かもしれない行〈_figure_line〉の前後も）で分け、""")

# _flow_breaks
rep("""def _flow_breaks(src, ka, kb, st: PdfStream, owner, width) -> bool:""",
    """def _flow_breaks(src, ka, kb, st: PdfStream, owner, width, figure=None) -> bool:""")
rep("""    行（校正で足された文の行かもしれない）。\"\"\"
    if kb <= ka:
        return True
    la, lb = st.line[ka], st.line[kb]
    if kb == ka + 1 and la == lb:
        return False
    if la != lb and _ends_flow(st, la, width):
        return True""",
    """    行（校正で足された文の行かもしれない）。ka の行か kb の行が図・表の中の行かもしれない行（figure。_figure_line）なら、続かない。\"\"\"
    if kb <= ka:
        return True
    la, lb = st.line[ka], st.line[kb]
    if kb == ka + 1 and la == lb:
        return False
    if la != lb and (_ends_flow(st, la, width) or (figure is not None and (figure(la) or figure(lb)))):
        return True""")

# _ends_flow: 比べのための切り替え（src_G だけ）
rep("""    return w < SHORT_LINE * width or (w < FULL_LINE * width and _ends_sentence(body))""",
    """    return (G_SHORTANY and w < SHORT_LINE * width) or (w < FULL_LINE * width and _ends_sentence(body))""")
rep("""FULL_LINE = 0.9
""", """FULL_LINE = 0.9
import os as _os  # noqa: E402
G_SHORTANY = _os.environ.get("G_SHORTANY", "0") == "1"   # 比べのための切り替え（src_G だけ）
""")

# _figure_line と _line_kind（_solid の前に足す）
rep("""def _solid(seg, st: PdfStream, width, doubt=()) -> bool:""",
    '''def _line_kind(st: PdfStream, ln, owner, nonflow) -> str:
    """_figure_line で見る、PDF の行 ln の種類。"figure": 本文の流れでない段落（図・表のキャプション・表のセルなど）の文字のある
    行か、どの段落にも当たらない和文の行（図・表の中の文字）。"text": どれかの本文の流れの段落の文字のある行。"skip": 受付日の
    文字だけの行・ページの端の柱の候補の行・MIN_CHARS 文字未満の行・和文の文字のない行（数式・数字だけの行など）。"""
    ks = range(bisect.bisect_left(st.line, ln), bisect.bisect_right(st.line, ln))
    body = [k for k in ks if not st.soft[k] and st.date[k] < 0]
    if not body:
        return "skip"
    owners = {owner.get(k) for k in body} - {None}
    if owners & nonflow:
        return "figure"
    if owners:
        return "text"
    if (st.edge[body[0]] and st.head[body[0]]) or _visible_count(st.lines[ln]) < MIN_CHARS or \\
            not any(unicodedata.east_asian_width(st.chars[k]) in "FW" for k in body):
        return "skip"
    return "figure"


def _figure_line(st: PdfStream, ln, owner, nonflow, width) -> bool:
    """PDF の行 ln が、段落の本文の行でなく、図・表の中の行かもしれないか（_isolate。その行の一致は、前後の行と本文の行の流れで
    続けない）。段落の行は両端そろえで行の幅いっぱいになり、段落の最後の行は文の終わりで終わるので、行の幅 width の FULL_LINE
    より短く、文の終わりで終わらない行は本文の行らしくない（図の中の語句「時間を見る」が、段落の続きの docx の文字「時間を
    取った。」と最初の数文字が同じだと、照合はその行を段落の行と並べる）。そのような行で、すぐ前かすぐ後ろの行（_line_kind が
    "skip" の行は 5 行まで飛ばす）が、図・表のキャプションなどの行か、どの段落にも当たらない和文の行のもの。和文の文字が半分に
    満たない行（英文など）は見ない。行の幅は、受付日の文字を除いて測る。"""
    if not width:
        return False
    ks = range(bisect.bisect_left(st.line, ln), bisect.bisect_right(st.line, ln))
    body = "".join(st.chars[k] for k in ks if st.date[k] < 0 and not st.soft[k])
    if not body or sum(1 for c in body if unicodedata.east_asian_width(c) in "FWA") * 2 < len(body):
        return False
    w = _line_width(st.lines[ln]) - _line_width("".join(st.chars[k] for k in ks if st.date[k] >= 0))
    if w >= FULL_LINE * width or _ends_sentence(body):
        return False
    for step in (-1, 1):
        x = ln + step
        for _ in range(6):
            if not 0 <= x < len(st.lines):
                break
            kind = _line_kind(st, x, owner, nonflow)
            if kind == "figure":
                return True
            if kind == "text":
                break
            x += step
    return False


def _solid(seg, st: PdfStream, width, doubt=()) -> bool:''')
pm.write_text(text, encoding="utf-8")
print("書いた:", pm)
