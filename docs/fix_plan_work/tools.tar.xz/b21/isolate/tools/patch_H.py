"""isolate: src_H（最終版 G0 + 段落の端の行の向こうに、キャプションをはさんで段落の端の行らしい行があれば、端の行を本体から外す）。
  python patch_H.py DIR"""
import sys
from pathlib import Path

pm = Path(sys.argv[1]) / "jasme_jats" / "pdfmatch.py"
text = pm.read_text(encoding="utf-8")


def rep(old, new):
    global text
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"{n} 回: {old[:80]!r}")
    text = text.replace(old, new)


rep("""    while hi + 1 < len(segs) and _solid(segs[hi + 1], st, width, doubt):
        hi += 1
""", """    while hi + 1 < len(segs) and _solid(segs[hi + 1], st, width, doubt):
        hi += 1
    # 本体の最後（最初）の行のすぐ向こうが図・表のキャプションなどで、その向こうに、段落の最後（最初）の行らしい、どの段落にも
    # 当たらない行がある: 本体の最後（最初）の行は、段落の文字とよく似た図の中の語句の行で、本当の段落の行はキャプションの向こう
    # かもしれない。その行を本体から外す（_edge_alternative）
    if _edge_alternative(st, st.line[segs[hi][-1][1]], 1, owner, nonflow, src, width):
        ln = st.line[segs[hi][-1][1]]
        cut = next(x for x, (_, k) in enumerate(segs[hi]) if st.line[k] == ln)
        if cut:
            segs[hi:hi + 1] = [segs[hi][:cut], segs[hi][cut:]]
        elif hi > lo:
            hi -= 1
    if _edge_alternative(st, st.line[segs[lo][0][1]], -1, owner, nonflow, src, width):
        ln = st.line[segs[lo][0][1]]
        cut = max(x for x, (_, k) in enumerate(segs[lo]) if st.line[k] == ln) + 1
        if cut < len(segs[lo]):
            segs[lo:lo + 1] = [segs[lo][:cut], segs[lo][cut:]]
            lo += 1
            hi += 1
        elif lo < hi:
            lo += 1
""")
rep('''def _figure_line(st: PdfStream, ln, owner, nonflow, width) -> bool:''', '''def _edge_alternative(st: PdfStream, ln, step, owner, nonflow, src, width) -> bool:
    """段落 src の本体の最後（step = 1。-1 なら最初）の行 ln のすぐ後ろ（前）が、図・表のキャプションなど（本文の流れでない
    段落の文字の行。間の、_line_kind が "skip" の行は飛ばす）で、その向こうの、次（前）の本文の段落の行より手前に、段落の最後
    （最初）の行らしい、どの段落にも当たらない和文の行（最後なら文の終わりで終わる行、最初なら段落の行の幅いっぱいの行。
    受付日の文字だけの行・ページの端の柱の候補の行・MIN_CHARS 文字未満の行を除く）があるか（_isolate）。"""
    if not width:
        return False
    x, sep = ln + step, False
    for _ in range(80):
        if not 0 <= x < len(st.lines):
            return False
        ks = range(bisect.bisect_left(st.line, x), bisect.bisect_right(st.line, x))
        body = [k for k in ks if not st.soft[k] and st.date[k] < 0]
        owners = {owner.get(k) for k in body} - {None}
        if owners & nonflow:
            sep = True
        elif owners - {src}:
            return False                 # 次（前）の本文の段落の行
        elif not sep:
            if owners or _line_kind(st, x, owner, nonflow) != "skip":
                return False             # 本体の端の行のすぐ向こうが、キャプションなどでない
        elif body and not owners and not (st.edge[body[0]] and st.head[body[0]]) and \\
                _visible_count(st.lines[x]) >= MIN_CHARS:
            s = "".join(st.chars[k] for k in body)
            if sum(1 for c in s if unicodedata.east_asian_width(c) in "FWA") * 2 >= len(s) and (
                    _ends_sentence(s) if step > 0 else _line_width(st.lines[x]) >= FULL_LINE * width):
                return True
        x += step
    return False


def _figure_line(st: PdfStream, ln, owner, nonflow, width) -> bool:''')
pm.write_text(text, encoding="utf-8")
print("書いた:", pm)
