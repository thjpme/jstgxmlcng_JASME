"""isolate: pytest_iso.sh の記録と pytest の出力から、落ちたテストを「足した・消した（原則違反）」「docx のまま 13 章に出した」
「docx のまま 13 章にも出さない」「そのほか（changed_paragraphs 以外の確かめで落ちた）」に分ける。
  python ptsum.py LOG.json PYTEST.log"""
import json
import re
import sys
sys.path.insert(0, "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/oracle")
from runner import describe  # noqa: E402
rec = json.load(open(sys.argv[1], encoding="utf-8"))
failed = [ln.split()[1] for ln in open(sys.argv[2], encoding="utf-8") if ln.startswith("FAILED ")]
kinds = {}
for t in failed:
    rows = rec.get(t)
    if not rows:
        kinds[t] = "OTHER"
        continue
    k = "MISS"
    for r in rows:
        d = describe(r["docx"], r["got"], r["want"])
        if d["added"] or d["deleted"]:
            k = "VIOL"
            break
        if not r["reported"]:
            k = "SILENT" if k != "VIOL" else k
    kinds[t] = k
by = {}
for t, k in kinds.items():
    f = re.sub(r"\[.*", "", t.split("::")[-1])
    by.setdefault((k, f), []).append(t)
for (k, f), ts in sorted(by.items()):
    print(f"{k:6} {len(ts):3}  {f}")
print("合計:", {k: sum(1 for v in kinds.values() if v == k) for k in ("VIOL", "SILENT", "MISS", "OTHER")})
if "-v" in sys.argv:
    for t, k in kinds.items():
        if k in ("VIOL", "SILENT"):
            for r in rec.get(t, []):
                d = describe(r["docx"], r["got"], r["want"])
                print(f"\n[{k}] {t}\n  docx: {r['docx'][-60:]}\n  got : {r['got'][-60:]}\n  want: {r['want'][-60:]}\n  {d}")
