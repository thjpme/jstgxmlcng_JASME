#!/bin/sh
# isolate: isoFin（G0）が終わったら、H2 を最終版（I/src）にして物差しをすべて流し、続けて F2（H2 + stray_edge）も流す。
I=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b21/isolate
until grep -q "^end isoFin" $I/logs/master_isoFin.log 2>/dev/null; do sleep 20; done
rm -rf $I/src_G0fin && cp -r $I/src $I/src_G0fin
rm -rf $I/src && cp -r $I/src_H2 $I/src && rm -rf $I/src/jasme_jats/__pycache__
echo "swapped $(date +%T)" > $I/logs/queue_final.log
sh $I/tools/master_iso.sh $I/src isoH2 real > $I/logs/master_isoH2.log 2>&1
echo "H2DONE $(date +%T)" >> $I/logs/queue_final.log
sh $I/tools/master_iso.sh $I/src_F2 isoF2 real > $I/logs/master_isoF2.log 2>&1
echo "F2DONE $(date +%T)" >> $I/logs/queue_final.log
