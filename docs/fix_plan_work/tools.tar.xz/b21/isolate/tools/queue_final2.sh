#!/bin/sh
# isolate: 最終版（H3 = I/src）と F3（H3 + stray_edge）の物差しをすべて流す。
I=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b21/isolate
rm -f $I/v/q/*_isoH2.* 2>/dev/null
sh $I/tools/master_iso.sh $I/src isoH3 real > $I/logs/master_isoH3.log 2>&1
echo "H3DONE $(date +%T)" >> $I/logs/queue_final2.log
sh $I/tools/master_iso.sh $I/src_F3 isoF3 real > $I/logs/master_isoF3.log 2>&1
echo "F3DONE $(date +%T)" >> $I/logs/queue_final2.log
