#!/bin/sh
# isolate: F3 が終わったら、H6 を最終版（I/src）にして物差しをすべて流す。
I=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b21/isolate
until grep -q F3DONE $I/logs/queue_final2.log 2>/dev/null; do sleep 20; done
rm -rf $I/src_H3fin && cp -r $I/src $I/src_H3fin
rm -rf $I/src && cp -r $I/src_H6 $I/src && rm -rf $I/src/jasme_jats/__pycache__
echo "swapped $(date +%T)" > $I/logs/queue_final4.log
sh $I/tools/master_iso.sh $I/src isoH6 real > $I/logs/master_isoH6.log 2>&1
echo "H6DONE $(date +%T)" >> $I/logs/queue_final4.log
