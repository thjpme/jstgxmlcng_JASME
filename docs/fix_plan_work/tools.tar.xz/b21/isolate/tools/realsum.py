"""isolate: realpdf/check.py のログ（real_<TAG>.log）の表から、数だけを並べる（本文の文字は出さない）。
  python realsum.py TAG..."""
import re
import sys
from pathlib import Path

L = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b21/isolate/logs")
for tag in sys.argv[1:]:
    rows = [ln for ln in (L / f"real_{tag}.log").read_text(encoding="utf-8").splitlines()
            if re.match(r"\| \d\d_\d_\d\d_\d+ \|", ln)]
    print(f"== {tag}")
    for r in rows:
        c = [x.strip() for x in r.strip("|").split("|")]
        # PDF, docx, 段落, 照合, 見つからない, 直した箇所, 組版, 想定外, わざと, 照合に使わなかった（数だけ）, 最後の列
        unused = re.match(r"(\d+)", c[9]).group(1) if len(c) > 9 else "?"
        print(f"  {c[0]} {c[1]:5} 見つからない {c[4]:5} 直した {c[5]:5} 組版 {c[6]:9} 想定外 {c[7]:5} わざと [{c[8]}] 使わなかった {unused} 最後 {c[10] if len(c) > 10 else ''}")
