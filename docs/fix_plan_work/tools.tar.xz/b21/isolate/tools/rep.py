"""置き換えの補助: python rep.py FILE  （標準入力に「<<<<\n古い\n====\n新しい\n>>>>」のブロックを並べる。古い文字は 1 回だけ出ること）"""
import sys
path = sys.argv[1]
s = open(path, encoding="utf-8").read()
blocks = sys.stdin.read().split("<<<<\n")[1:]
for b in blocks:
    old, rest = b.split("\n====\n", 1)
    new = rest.rsplit("\n>>>>", 1)[0]
    n = s.count(old)
    if n != 1:
        sys.exit(f"{n} 回: {old[:80]!r}")
    s = s.replace(old, new)
open(path, "w", encoding="utf-8").write(s)
print("ok", len(blocks))
