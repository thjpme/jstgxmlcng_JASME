#!/bin/sh
# isolate: 版ごとの物差しの数を並べる。 sh report_all.sh TAG...（最初が 0.20.0、次が 0.21.0）
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
F=$S/fixB2r4; I=$S/b21/isolate
echo "== quick"; python3 $F/tools/sum_q.py "$@" 2>&1 | head -30
echo "== fuzz4"; python3 $F/tools/sum_fz.py f4 "$@" 2>&1 | head -30
echo "== fuzz8"; python3 $F/tools/sum_fz.py f8 "$@" 2>&1 | head -40
echo "== fuzz8 足した段落"; python3 -I $F/tools/added_count.py "$@"
echo "== oracle"
for set in o34 n10 n10g rv89 cj cj2 b2 x xm r1 y y2; do
  args=""; for t in "$@"; do args="$args f4r_${set}_$t"; done
  echo "-- $set"; python3 $I/tools/osum.py $args 2>&1 | sed -n '/^版/,/^$/p'
done
args=""; for t in "$@"; do args="$args iso_rem_$t"; done
echo "-- rem"; python3 $I/tools/osum.py $args 2>&1 | sed -n '/^版/,/^$/p'
echo "== gen"; python3 $I/tools/gsum.py "$@" 2>&1
echo "== b210"; for t in "$@"; do echo -n "$t: "; done; echo
