#!/bin/sh
# isolate: 5 回目の点検の生成例（b2_review/r5p/exp・r5reg/exp の gen_*.py）と fixB2r4/exp の bpage・figtop を SRC のコードで
# h2.py で動かす（並列）。  sh run_gen5.sh SRC TAG [名前...]
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
I=$S/b21/isolate
SRC=$1; TAG=$2; shift 2
W=${*:-"bpage figtop r5better r5copytop r5face r5headfig r5simtop r5tabhead r5_bl r5_cnq r5_cpo r5_fw r5_rw"}
cd /tmp
for g in $W; do
  X=""
  for d in $S/b2_review/r5p/exp $S/b2_review/r5reg/exp $S/fixB2r4/exp $I/exp; do
    if [ -f $d/gen_$g.py ]; then X=$d; break; fi
  done
  [ -z "$X" ] && { echo "no gen $g"; continue; }
  python -I $S/b2_review/r4p/h2.py $SRC $X/gen_$g.py $I/gen/fz_${g}_$TAG.json > $I/logs/gen5_${g}_$TAG.log 2>&1 &
done
wait
for g in $W; do echo "$g $TAG: $(tail -1 $I/logs/gen5_${g}_$TAG.log | sed 's/.*__init__.py //')"; done
