#!/bin/sh
# isolate: 照合の速さを、0.20.0・0.21.0・試作の順に 1 つずつ測る（ほかの処理が動いていないときに）。
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
I=$S/b21/isolate
for v in "base:$S/n10/judge/base_src" "v021:$S/b21/base021_src" "final:$I/src"; do
  n=${v%%:*}; src=${v#*:}
  python -I $I/tools/t_speed.py $src 5 > $I/logs/speed3_$n.json 2>&1
done
echo done
