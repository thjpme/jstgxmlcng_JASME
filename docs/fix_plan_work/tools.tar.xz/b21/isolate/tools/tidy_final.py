"""isolate: 試作の最終版（I/src）の説明の折り返しなどを整える（動きは変えない）。  python tidy_final.py DIR"""
import sys
from pathlib import Path

pm = Path(sys.argv[1]) / "jasme_jats" / "pdfmatch.py"
text = pm.read_text(encoding="utf-8")


def rep(old, new):
    global text
    n = text.count(old)
    if n != 1:
        raise SystemExit(f"{n} 回: {old[:80]!r}")
    text = text.replace(old, new)


rep("""        docx ですぐ後ろ（前）の本文の段落の塊のすぐ前（後ろ）に、どの段落にも当たらない文字（受付日の文字は除く。ページの端の
        行は、柱か段落の行か決められないので数える）の続きが穴の 3 分の 1 以上あり、段落の塊との間にほかの段落の塊の文字があるか、その続きが 2 行以上にわたる
        もの（docx にない表・図の文字の向こうに、段落の最後〈最初〉の行が出ているかもしれない。その続きが穴の文字かどうかは
        決めない）。""", """        docx ですぐ後ろ（前）の本文の段落の塊のすぐ前（後ろ）に、どの段落にも当たらない文字（受付日の文字は除く。ページの端の
        行は、柱か段落の行か決められないので数える）の続きが穴の 3 分の 1 以上あり、段落の塊との間にほかの段落の塊の文字が
        あるか、その続きが 2 行以上にわたるもの（docx にない表・図の文字の向こうに、段落の最後〈最初〉の行が出ているかも
        しれない。その続きが穴の文字かどうかは決めない）。""")
rep("""            if not body or any(self.cidx[k] >= 0 and self.own[self.cidx[k]] >= 0 for k in body if k < len(self.cidx)) or \\""",
    """            if not body or any(self.cidx[k] >= 0 and self.own[self.cidx[k]] >= 0 for k in body) or \\""")
rep("""    一致した文字を、本文の行の流れが続かないところ（_flow_breaks。図・表の中の行かもしれない行〈_figure_line〉の前後も）で
    分け、""", """    一致した文字を、本文の行の流れが続かないところ（_flow_breaks。図・表の中の行かもしれない行〈_figure_line〉の前後も）で
    分け、""")
pm.write_text(text, encoding="utf-8")
print("整えた:", pm)
