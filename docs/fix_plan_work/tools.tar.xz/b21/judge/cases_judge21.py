"""反例集（judge21: 単位 B2.1 の比べる担当が、3 つの試作〈isolate・ambiguity・evidence〉の弱点を探すために作ったもの）。

文字はすべて架空（実際の論文の文字を書き写していない）。部品は oracle/cases_b21.py（実装を見ない担当の反例集）のものを使う。
書式と判定は oracle/runner.py の docstring と cases_b21.py の keep・fix_or_keep。実行:
  python oracle/run_all.py <src> b21/judge/cases_judge21.py --name <名前>

組（名前は j21_<組>_<配置>_<内容>）:
  P : 図の中の行が、段落 4 の最後の行の写しにごく近く、文の終わり（「。」）で終わる形（cases_b21 の snone・srep・sins の行は
      「。」で終わらない）。配置は cases_b21 の T 組と同じ考え（1 行だけの図が次のページ・段の最初、キャプションが図の下・上、
      受付日の行・柱の後ろ）。内容は、図の中の行 a（最後の語だけが違う「…時間を取る。」）・b（docx の最後の行の「が」を除いた
      写し）・c（短い写し「説明し合う時間を取った。」）と、本当の最後の行の直し rep（「取った」→「設けた」）・none（直しなし）。
  O : docx では図（画像とキャプション）が段落 4・5・6 の後ろにあり、PDF では段落 4 の最後の行の前（段落の途中）に組まれる形
      （docx の隣の段落からは、段落の端の向こうに図があると分からない）。
  M : 図・表の中の文字が段落の端の行と似ていない、ふつうの分断（本当の最後の行・最初の行の直し）。直すのが望ましい
      （fix_or_keep の REPORTED は「13.2 に回った本当の直し」として数える）。
  I : 図の中の行が、段落の最後から 2 行目（行の幅いっぱい）の写しにごく近い形（段落の端でなく、段落の途中の行の取り違え）。
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/oracle")))
import cases_b21 as B  # noqa: E402  （runner.judge の keep・fix_or_keep の包みも入る）
from runner import BREAK, Raw  # noqa: E402

PT, QH, RN, CAP, FIGB, IMG = B.PT, B.QH, B.RN, B.CAP, B.FIGB, B.IMG
P_REP = B.P_REP
bl, art = B.bl, B.art
RECV, HEAD_LINE = B.RECV, B.HEAD_LINE
B._check(bl(PT)[-1] == "が気づいたことを説明し合う時間を取った。", "PT の最後の行")
B._check(bl(P_REP)[-1] == "が気づいたことを説明し合う時間を設けた。", "P_REP の最後の行")

CASES = []

# ---------------------------------------------------------------------------- P: 「。」で終わる、写しにごく近い図の中の行
P_FIG = {
    "a": "が気づいたことを説明し合う時間を取る。",
    "b": "気づいたことを説明し合う時間を取った。",
    "c": "説明し合う時間を取った。",
}
P_TRUTH = {"rep": P_REP, "none": None}


def p_layout(kind, p, d):
    """段落 4（行のリスト p）の最後の行のまわりの配置。d は図の中の行。戻り値: (docx の extra の図の部分, mid, 説明)。"""
    q, r = bl(QH), bl(RN)
    fig = [IMG, ("図キャプション", CAP)]
    if kind == "cb_page1":
        return fig, [Raw(*p[:-1]), BREAK, Raw(d), Raw(CAP), Raw(p[-1]), Raw(*q), Raw(*r)], \
            "次のページの最初に 1 行だけの図（その行が d）とキャプション（図の下）、その後ろに段落 4 の本当の最後の行。"
    if kind == "cb_col1":
        return fig, [Raw(*p[:-1]), Raw(d), Raw(CAP), Raw(p[-1]), Raw(*q), Raw(*r)], \
            "段の区切りの後ろに 1 行だけの図（d）とキャプション（図の下）、その後ろに段落 4 の本当の最後の行。"
    if kind == "cb_page2":
        return fig, [Raw(*p[:-1]), BREAK, Raw(FIGB[0], d), Raw(CAP), Raw(p[-1]), Raw(*q), Raw(*r)], \
            "次のページの最初に 2 行の図（最後の行が d）とキャプション、その後ろに段落 4 の本当の最後の行。"
    if kind == "ca_page":
        return fig, [Raw(*p[:-1]), BREAK, Raw(CAP), Raw(d), Raw(p[-1]), Raw(*q), Raw(*r)], \
            "次のページの最初にキャプション（図の上）と 1 行だけの図（d）、そのすぐ後ろに段落 4 の本当の最後の行。"
    if kind == "ca_col":
        return fig, [Raw(*p[:-1]), Raw(CAP), Raw(*FIGB, d), Raw(p[-1]), Raw(*q), Raw(*r)], \
            "キャプション（図の上）と図（最後の行が d）のすぐ後ろに段落 4 の本当の最後の行（ページの途中）。"
    if kind == "recv1":
        return fig, [Raw(*p[:-1]), Raw(RECV), Raw(d), Raw(CAP), Raw(p[-1]), Raw(*q), Raw(*r)], \
            "左の段の最後に投稿受付日の行、右の段の最初に 1 行だけの図（d）とキャプション、その後ろに本当の最後の行。"
    if kind == "head1":
        return fig, [Raw(*p[:-1]), BREAK, Raw(d), Raw(CAP), Raw(p[-1]), Raw(*q), Raw(*r)], \
            "次のページの最初に柱、1 行だけの図（d）とキャプション、その後ろに段落 4 の本当の最後の行。"
    raise ValueError(kind)


P_KINDS = ["cb_page1", "cb_col1", "cb_page2", "ca_page", "ca_col", "recv1", "head1"]
for kind in P_KINDS:
    for fk, d in P_FIG.items():
        for tk, tr in P_TRUTH.items():
            p = bl(tr or PT)
            fig, mid, desc = p_layout(kind, p, d)
            extra = [("本文", PT)] + fig + [("本文", QH), ("本文", RN)]
            note = (f"[{'直す' if tr else '取り違え'}] {desc} d「{d}」は docx の最後の行の写しにごく近く、「。」で終わる。"
                    + ("本当の最後の行は「取った」→「設けた」。直すか docx のまま 13 章に出す（fix_or_keep）。図の中の文字を"
                       "足す・docx の文字を消すのは FAIL。" if tr else "直しなし。段落 4 は docx のまま（exact）。"))
            CASES.append(art(f"j21_P_{kind}_{fk}_{tk}", extra, mid, {4: tr} if tr else None, None, note,
                             heads=HEAD_LINE if kind == "head1" else None))

# ---------------------------------------------------------------------------- O: docx では図が離れた位置にある
O_FIG = {"sim": "説明し合う時間を取る", "copy": "が気づいたことを説明し合う時間を取る。"}
for fk, d in O_FIG.items():
    p = bl(P_REP)
    CASES.append(art(
        f"j21_O_tail_{fk}_rep", [("本文", PT), ("本文", QH), ("本文", RN), IMG, ("図キャプション", CAP)],
        [Raw(*p[:-1]), Raw(*FIGB, d), Raw(CAP), Raw(p[-1]), Raw(*bl(QH)), Raw(*bl(RN))], {4: P_REP}, None,
        f"[直す] docx では図（画像とキャプション）が段落 6 の後ろ。PDF では段落 4 の最後の行の前に図（最後の行「{d}」）と"
        "キャプションが組まれ、段落 4 の本当の最後の行（「取った」→「設けた」）はその後ろ。直すか 13 章に出す。"))
    q = bl(B.Q_INS)
    CASES.append(art(
        f"j21_O_head_{fk}_ins", [("本文", PT), ("本文", QH), ("本文", RN), IMG, ("図キャプション", CAP)],
        [Raw(*bl(PT)), Raw(*FIGB, "班の話し合いでは" if fk == "sim" else "班の話し合いでは，ある生徒が回数を増やすと"),
         Raw(CAP), Raw(*q), Raw(*bl(RN))], {5: B.Q_INS}, None,
        "[直す] docx では図が段落 6 の後ろ。PDF では段落 5 のすぐ前に、段落 5 の書き出しとよく似た行のある図とキャプション"
        "（図の下）。段落 5 の書き出しの挿入「各」は、直すか 13 章に出す。"))
    CASES.append(art(
        f"j21_O_tail_{fk}_none", [("本文", PT), ("本文", QH), ("本文", RN), IMG, ("図キャプション", CAP)],
        [Raw(*bl(PT)[:-1]), Raw(*FIGB, d), Raw(CAP), Raw(bl(PT)[-1]), Raw(*bl(QH)), Raw(*bl(RN))], None, None,
        "[取り違え] j21_O_tail の形で直しなし。段落 4 は docx のまま。"))

# ---------------------------------------------------------------------------- M: ふつうの分断の本当の直し
FIGX = ["問い　赤い玉が出る割合を調べよう", "予想　結果　理由", "回数　10回　50回　100回"]   # 段落の文字と似ていない図
TAB = [["回数", "10回", "50回"], ["割合", "0.4", "0.5"]]
TAB_LINES = ["回数　10回　50回", "割合　0.4　0.5"]
TCAP = "表１　架空の実験の結果"
P2 = PT + "その後，各班の考えを全体で確かめた。"          # 最後の 2 行（幅いっぱいの行と短い行）
P2_REP = P2.replace("全体で確かめた", "全体で整理した")
B._check(len(bl(P2)) >= 3 and bl(P2)[:-1] == bl(P2_REP)[:-1], f"P2 {bl(P2)}")
QH_REP = QH.replace("ある生徒が", "一人の生徒が")
B._check(bl(QH_REP)[0] != bl(QH)[0], "QH_REP")
P_MID2 = PT.replace("全体で比べた", "全体で比較した")
M_CASES = [
    ("tail1_figbelow", [("本文", PT), IMG, ("図キャプション", CAP), ("本文", QH), ("本文", RN)], {4: P_REP},
     lambda: [Raw(*bl(P_REP)[:-1]), Raw(*FIGX), Raw(CAP), Raw(bl(P_REP)[-1]), Raw(*bl(QH)), Raw(*bl(RN))],
     "段落 4 の最後の 1 行（短い行）が、似ていない図とキャプション（図の下）の後ろに出る。その行の直し「取った」→「設けた」。"),
    ("tail1_figabove", [("本文", PT), IMG, ("図キャプション", CAP), ("本文", QH), ("本文", RN)], {4: P_REP},
     lambda: [Raw(*bl(P_REP)[:-1]), Raw(CAP), Raw(*FIGX), Raw(bl(P_REP)[-1]), Raw(*bl(QH)), Raw(*bl(RN))],
     "キャプションが図の上。段落 4 の最後の 1 行が図の後ろに出る。その行の直し。"),
    ("tail1_page", [("本文", PT), IMG, ("図キャプション", CAP), ("本文", QH), ("本文", RN)], {4: P_REP},
     lambda: [Raw(*bl(P_REP)[:-1]), BREAK, Raw(*FIGX), Raw(CAP), Raw(bl(P_REP)[-1]), Raw(*bl(QH)), Raw(*bl(RN))],
     "次のページの最初に似ていない図とキャプション、その後ろに段落 4 の最後の 1 行。その行の直し。"),
    ("tail1_table", [("本文", PT), ("表キャプション", TCAP), ("表", TAB), ("本文", QH), ("本文", RN)], {4: P_REP},
     lambda: [Raw(*bl(P_REP)[:-1]), Raw(TCAP, *TAB_LINES), Raw(bl(P_REP)[-1]), Raw(*bl(QH)), Raw(*bl(RN))],
     "段落 4 の最後の 1 行が、表のキャプション（表の上）と表の後ろに出る。その行の直し。"),
    ("tail2_figbelow", [("本文", P2), IMG, ("図キャプション", CAP), ("本文", QH), ("本文", RN)], {4: P2_REP},
     lambda: [Raw(*bl(P2_REP)[:-2]), Raw(*FIGX), Raw(CAP), Raw(*bl(P2_REP)[-2:]), Raw(*bl(QH)), Raw(*bl(RN))],
     "段落 4 の最後の 2 行（幅いっぱいの行と短い行）が図とキャプションの後ろに出る。短い行の直し「確かめた」→「整理した」。"),
    ("head1_figbelow", [("本文", PT), ("本文", QH), IMG, ("図キャプション", CAP), ("本文", RN)], {5: QH_REP},
     lambda: [Raw(*bl(PT)), Raw(bl(QH_REP)[0]), Raw(*FIGX), Raw(CAP), Raw(*bl(QH_REP)[1:]), Raw(*bl(RN))],
     "段落 5 の最初の 1 行だけが図の前（段の最後）に出て、2 行目からは図とキャプションの後ろ。最初の行の直し「ある」→"
     "「一人の」。"),
    ("mid_both", [("本文", PT), IMG, ("図キャプション", CAP), ("本文", QH), ("本文", RN)],
     {4: P_MID2.replace("時間を取った", "時間を設けた")},
     lambda: [Raw(*bl(P_MID2.replace("時間を取った", "時間を設けた"))[:-1]), Raw(*FIGX), Raw(CAP),
              Raw(bl(P_MID2.replace("時間を取った", "時間を設けた"))[-1]), Raw(*bl(QH)), Raw(*bl(RN))],
     "段落 4 の 1 行目の直し「比べた」→「比較した」（本体）と、図の後ろに出た最後の 1 行の直し「取った」→「設けた」。"),
]
for name, extra, truth, mid, desc in M_CASES:
    for k, v in truth.items():
        B._check(v != dict(enumerate([None] * 4 + extra)).get(k, ("", ""))[1] if False else True, "")
    CASES.append(art(f"j21_M_{name}", extra, mid(), truth, None,
                     f"[直す] {desc}図・表の中の文字は段落の文字と似ていない。直すのが望ましい（13 章に出すと「13.2 に回った"
                     "本当の直し」として数える）。図・表の文字を足す・消すのは FAIL。", angle="layout"))

# ---------------------------------------------------------------------------- I: 段落の途中の行の写しにごく近い図の中の行
PI = PT + "その時間には，各班の記録を見直して考えを確かめた。"
PI_REP = PI.replace("時間を取った", "時間を設けた")
_pi = bl(PI)
B._check(len(_pi) >= 4 and bl(PI_REP)[-1] == _pi[-1] and bl(PI_REP)[-2] != _pi[-2], f"PI {_pi} {bl(PI_REP)}")
_dcopy = _pi[-2].replace("取った。", "取る。")
B._check(_dcopy != _pi[-2], "I の図の中の行")
for tk, tr in (("rep", PI_REP), ("none", None)):
    p = bl(tr or PI)
    CASES.append(art(
        f"j21_I_inner_{tk}", [("本文", PI), IMG, ("図キャプション", CAP), ("本文", QH), ("本文", RN)],
        [Raw(*p[:-2]), Raw(_dcopy, *FIGB), Raw(CAP), Raw(*p[-2:]), Raw(*bl(QH)), Raw(*bl(RN))],
        {4: tr} if tr else None, None,
        f"[{'直す' if tr else '取り違え'}] 段落 4 の最後の 2 行が図とキャプションの後ろに出る。図の最初の行「{_dcopy}」は、docx の"
        "最後から 2 行目（幅いっぱいの行）の写しにごく近い。" + ("最後から 2 行目の直し「取った」→「設けた」。直すか 13 章に"
                                                                  "出す。" if tr else "直しなし。docx のまま。")))

_names = [c["name"] for c in CASES]
B._check(len(_names) == len(set(_names)), "名前が重なっている")

# ---------------------------------------------------------------------------- Z: 消された最後の文と、その写しにごく近い図の中の行
# （比べる担当の最終の試作 final_src の _plain_tail〈押し出された段落の続きなら直す〉の弱点を探すもの）。段落の最後の行が行の幅
# いっぱいで「。」で終わり（段落の終わりの行に見えない）、校正で消された最後の文の写しにごく近い「。」で終わる図の中の行が、
# 次の段落のすぐ前にある。
PZ = PT.replace("説明し合う時間を取った。", "全員で説明し合う時間を持たせた。")
_pz = bl(PZ)
B._check(B.wrap(_pz[-1])[0] == _pz[-1] and sum(1 if ord(c) > 0x2000 else 0.5 for c in _pz[-1]) == 24, f"PZ {_pz}")
PZ_DEL = PZ + "その時間は短かった。"
Z_FIG = {"near": "その時間は短い。", "exact": "その時間は短かった。"}
for fk, d in Z_FIG.items():
    for lk in ("imgonly", "capabove", "capbelow"):
        fig = {"imgonly": [IMG], "capabove": [("図キャプション", CAP), IMG], "capbelow": [IMG, ("図キャプション", CAP)]}[lk]
        figp = {"imgonly": [Raw(d)], "capabove": [Raw(CAP), Raw(FIGB[0], d)], "capbelow": [Raw(FIGB[0], d), Raw(CAP)]}[lk]
        CASES.append(art(
            f"j21_Z_{lk}_{fk}", [("本文", PZ_DEL)] + fig + [("本文", QH), ("本文", RN)],
            [Raw(*_pz)] + figp + [Raw(*bl(QH)), Raw(*bl(RN))], {4: PZ}, None,
            f"[取り違え] 段落 4 の最後の文「その時間は短かった。」が校正で消された。段落 4 の最後の行は行の幅いっぱいで「。」で"
            f"終わる。そのすぐ後ろの図（{lk}）の中の行「{d}」は、消された文の写しにごく近い。消された文を消して直すか、docx の"
            "まま 13 章に出す（fix_or_keep）。図の中の文字で置き換えるのは FAIL。"))
_names = [c["name"] for c in CASES]
B._check(len(_names) == len(set(_names)), "名前が重なっている")
