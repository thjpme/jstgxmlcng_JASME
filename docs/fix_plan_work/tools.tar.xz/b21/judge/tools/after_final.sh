#!/bin/sh
# judge（B2.1）: after_versions.sh が終わってから、最終の試作（final_src。final7 の内容。タグ jdF）を master_jd.sh で測り、
# 比べる担当の反例と pytest（3.13・3.10）を流す。
J=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b21/judge
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
until grep -q G1FULLDONE $J/logs/after_versions.log 2>/dev/null; do sleep 10; done
sh $J/tools/master_jd.sh $J/final_src jdF > $J/logs/master_jdF.log 2>&1
sh $J/tools/run_cj21.sh "jdF:$J/final_src" > $J/logs/run_cj21_F.log 2>&1
sh $S/fixB2r4/tools/pytest_src.sh $J/final_src python3 -q -rf > $J/logs/pt_jdF_313.log 2>&1
sh $S/fixB2r4/tools/pytest_src.sh $J/final_src $S/venv310/bin/python -q -rf > $J/logs/pt_jdF_310.log 2>&1
sh $S/fixB2r4/tools/pytest_src.sh $J/final_src python3 -q -rf -p no:randomly $S/b21/evidence/xtests/test_x_evidence.py > $J/logs/xt_jdF.log 2>&1
echo FDONE
