#!/bin/sh
# judge（B2.1）: 最終の試作（final_src。final8 の内容。字下げの区切りを「字下げのない行から字下げの行へ」に狭めたもの。タグ jdH）を
# master_jd.sh で測り、比べる担当の反例・pytest（3.13・3.10）・evidence のテストの案を流す。
J=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b21/judge
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
sh $J/tools/master_jd.sh $J/final_src jdH > $J/logs/master_jdH.log 2>&1
sh $J/tools/run_cj21.sh "jdH:$J/final_src" > $J/logs/run_cj21_H.log 2>&1
sh $S/fixB2r4/tools/pytest_src.sh $J/final_src python3 -q -rf > $J/logs/pt_jdH_313.log 2>&1
sh $S/fixB2r4/tools/pytest_src.sh $J/final_src $S/venv310/bin/python -q -rf > $J/logs/pt_jdH_310.log 2>&1
sh $S/fixB2r4/tools/pytest_src.sh $J/final_src python3 -q -rf -p no:randomly $S/b21/evidence/xtests/test_x_evidence.py > $J/logs/xt_jdH.log 2>&1
echo HDONE
