#!/bin/sh
# judge（B2.1）: run_versions.sh が終わってから、最終の試作（final_src。タグ jdfin）を master_jd.sh で測り、pytest を 2 つの版で流す。
# その後、字下げの区切りを入れる前の試作（final5_src。タグ jdg1）も同じ物差しで測る（字下げの規則の効き目を分けて見るため）。
J=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b21/judge
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
until grep -q ALLDONE $J/logs/run_versions.log 2>/dev/null; do sleep 10; done
sh $J/tools/master_jd.sh $J/final_src jdfin > $J/logs/master_jdfin.log 2>&1
sh $J/tools/run_cj21.sh "jdfin:$J/final_src" > $J/logs/run_cj21_fin.log 2>&1
sh $S/fixB2r4/tools/pytest_src.sh $J/final_src python3 -q -rf > $J/logs/pt_jdfin_313.log 2>&1
sh $S/fixB2r4/tools/pytest_src.sh $J/final_src $S/venv310/bin/python -q -rf > $J/logs/pt_jdfin_310.log 2>&1
echo FINDONE
sh $J/tools/master_jd.sh $J/final5_src jdg1 > $J/logs/master_jdg1.log 2>&1
sh $J/tools/run_cj21.sh "jdg1:$J/final5_src" > $J/logs/run_cj21_g1.log 2>&1
echo G1FULLDONE
