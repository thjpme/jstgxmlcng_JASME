#!/bin/sh
# judge（B2.1）: 5 つの版で pytest を 3.13 と 3.10 で実行する（落ちたテストの名前を logs/pt_<タグ>_<py>.txt に）。
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
J=$S/b21/judge
for x in "jd021:$J/b021_src" "jdiso:$J/isolate_src" "jdamb:$J/ambiguity_src" "jdevi:$J/evidence_src" "jd020:$J/b020_src"; do
  t=${x%%:*}; s=${x#*:}
  nice -n 10 sh $S/fixB2r4/tools/pytest_src.sh $s python3 -q -x --co -q > /dev/null 2>&1
  nice -n 10 sh $S/fixB2r4/tools/pytest_src.sh $s python3 -q -rf > $J/logs/pt_${t}_313.log 2>&1
  nice -n 10 sh $S/fixB2r4/tools/pytest_src.sh $s $S/venv310/bin/python -q -rf > $J/logs/pt_${t}_310.log 2>&1
  echo "$t $(tail -1 $J/logs/pt_${t}_313.log) | $(tail -1 $J/logs/pt_${t}_310.log)"
done
