#!/bin/sh
# judge（B2.1）: 5 つの版を順に master_jd.sh で測る。  sh run_versions.sh [TAG:SRC ...]
J=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b21/judge
V=${*:-"jd021:$J/b021_src jdiso:$J/isolate_src jdamb:$J/ambiguity_src jdevi:$J/evidence_src jd020:$J/b020_src"}
for x in $V; do
  t=${x%%:*}; s=${x#*:}
  sh $J/tools/master_jd.sh $s $t > $J/logs/master_$t.log 2>&1
  df -h / | tail -1 >> $J/logs/master_$t.log
done
echo ALLDONE
