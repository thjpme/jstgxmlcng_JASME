#!/bin/sh
# judge（B2.1）: 照合の速さ（fixB2r4/tools/t_speed.py。本誌の出版版 PDF 7 通りと小さな論文 100 本。3 回の最小）を、6 つの版（最終の試作を含む）で交互に 2 巡測る。
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
J=$S/b21/judge
for r in 1 2; do
  for x in "jd020:$J/b020_src" "jd021:$J/b021_src" "jdiso:$J/isolate_src" "jdamb:$J/ambiguity_src" "jdevi:$J/evidence_src" "jdF:$J/final_src"; do
    t=${x%%:*}; s=${x#*:}
    echo "$r $t $(uptime | sed 's/.*load average: //') $(cd /tmp && python -I $J/tools/t_speed.py $s 3)"
  done
done
