#!/bin/sh
# judge（B2.1）: 点検の生成例（r3p・r4p・r4reg・fixB2r4・r5p・r5reg の gen_*.py。29 種）を SRC のコードで h2.py で動かす（4 並列）。
#   sh gen_all.sh SRC TAG [名前 ...]   結果は b21/judge/gen/fz_<名前>_<TAG>.json、ログは b21/judge/logs/gen_<名前>_<TAG>.log
#   （b21/ambiguity/tools/gen_all.sh の出力先を judge に変えたもの）
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
A=$S/b21/review
SRC=$1; TAG=$2; shift 2
W=${*:-"head tail figsim figpre pages dup figstop figwidth figwidth_head capnext capprev figw figw2 figw3 widow bfp bpage figtop r5better r5copytop r5face r5headfig r5simtop r5tabhead r5_bl r5_cnq r5_cpo r5_fw r5_rw"}
cd /tmp
n=0
for g in $W; do
  X=""
  for d in $S/b2_review/r3p/exp $S/b2_review/r4p/exp $S/b2_review/r4reg/exp $S/fixB2r4/exp $S/b2_review/r5p/exp $S/b2_review/r5reg/exp; do
    if [ -f $d/gen_$g.py ]; then X=$d; break; fi
  done
  [ -z "$X" ] && { echo "no gen $g"; continue; }
  python -I $S/b2_review/r4p/h2.py $SRC $X/gen_$g.py $A/gen/fz_${g}_$TAG.json > $A/logs/gen_${g}_$TAG.log 2>&1 &
  n=$((n + 1)); if [ $((n % 4)) -eq 0 ]; then wait; fi
done
wait
for g in $W; do echo "$g $TAG: $(tail -n 1 $A/logs/gen_${g}_$TAG.log | sed 's/.*__init__.py //')"; done
