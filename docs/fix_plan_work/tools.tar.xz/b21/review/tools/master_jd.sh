#!/bin/sh
# impl（B2.1。judge の道具の出力先を b21/review に変えたもの）: 1 つの版（SRC・TAG）で物差しを順に実行する。  sh master_jd.sh SRC TAG [what...]
#   what を省くとすべて: quick oracle f4 golden b210 f8 real gen extra td
#   結果: quick・f4・f8・210 件は fixB2r4/v（タグ付き）、反例集のログは fixB2r4/logs、それ以外は b21/judge の下。
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
F=$S/fixB2r4; J=$S/b21/review; L=$J/logs
SRC=$1; TAG=$2; shift 2
W=${*:-"quick oracle f4 golden b210 f8 real gen extra td"}
echo "start $TAG $(date +%T)"
for w in $W; do
  case $w in
    quick) sh $F/tools/run_suites.sh $SRC $TAG quick 4 ;;
    oracle)
      sh $F/tools/run_oracle.sh $SRC $TAG o34 n10 n10g rv89 judge judge2; rm -rf $S/oracle/_work/f4r_*_$TAG
      sh $F/tools/run_oracle.sh $SRC $TAG b2 x xm r1 y y2; rm -rf $S/oracle/_work/f4r_*_$TAG ;;
    f4) sh $F/tools/run_suites.sh $SRC $TAG f4 4 ;;
    golden) (cd $J && PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=$SRC python $S/golden/golden.py $J/golden/g_$TAG > $L/golden_$TAG.log 2>&1) ;;
    b210) sh $F/tools/run_suites.sh $SRC $TAG b210 1 ;;
    f8) sh $F/tools/run_suites.sh $SRC $TAG f8 4 ;;
    real) (cd $F/realpdf && python -I check.py --before-src $S/b21/judge/b020_src --after-src $SRC --route1 --tag _$TAG > $L/real_$TAG.log 2>&1) ;;
    gen) sh $J/tools/gen_all.sh $SRC $TAG > $L/gen_$TAG.log 2>&1 ;;
    extra)
      cd $S/oracle
      python run_all.py $SRC $S/b2_review/r4p/cases_w_only.py --name jd_w_$TAG > $L/or_w_$TAG.log 2>&1 &
      python run_all.py $SRC $S/b2_review/r5p/cases_v_only.py --name jd_v_$TAG > $L/or_v_$TAG.log 2>&1 &
      python run_all.py $SRC $S/oracle/cases_b21.py --name jd_b21_$TAG > $L/or_b21_$TAG.log 2>&1 &
      python run_all.py $SRC $S/b21/isolate/cases_iso.py $S/b21/isolate/cases_iso2.py $S/b21/isolate/cases_iso3.py \
        $S/b21/isolate/cases_iso4.py $S/b21/isolate/cases_iso5.py --name jd_iso_$TAG > $L/or_iso_$TAG.log 2>&1 &
      wait
      python run_all.py $SRC $S/b21/ambiguity/cases/cases_amb.py --name jd_amb_$TAG > $L/or_amb_$TAG.log 2>&1 &
      python run_all.py $SRC $S/b21/evidence/cases_ev.py --name jd_ev_$TAG > $L/or_ev_$TAG.log 2>&1 &
      wait
      rm -rf $S/oracle/_work/jd_*_$TAG
      cd $J ;;
    td) sh $J/tools/run_td.sh $SRC $TAG > $L/td_$TAG.log 2>&1 ;;
  esac
  echo "$w $(date +%T)"
done
echo "end $TAG $(date +%T)"
