"""verify（B2.1）: 反例集 19 組の反例ごとの判定を版ごとに数え、比べる相手（最初の TAG）で FAIL でない反例が FAIL になったものを出す。
  python vcount.py TAG...   （文字は出さない）"""
import json
import sys
from collections import Counter
S = "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad"
SETS = "f4r_o34,f4r_n10,f4r_n10g,f4r_rv89,f4r_cj,f4r_cj2,f4r_b2,f4r_x,f4r_xm,f4r_r1,f4r_y,f4r_y2,jd_w,jd_v,jd_b21,jd_iso,jd_amb,jd_ev,jd_cj21".split(",")
tags = sys.argv[1:]
tot = {t: Counter() for t in tags}
newfail = {t: [] for t in tags[1:]}
trans = {t: Counter() for t in tags[1:]}
for s in SETS:
    res = {}
    for t in tags:
        res[t] = {c["name"]: c["verdict"] for c in json.load(open(f"{S}/oracle/results_{s}_{t}.json"))["cases"]}
        tot[t].update(res[t].values())
    row = [f"{s:10}"] + [f"{t}: " + "/".join(str(Counter(res[t].values())[k]) for k in ("OK", "REPORTED", "FAIL")) for t in tags]
    print("  ".join(row))
    for t in tags[1:]:
        for n, v in res[tags[0]].items():
            w = res[t].get(n, "-")
            if v != w:
                trans[t][f"{v}→{w}"] += 1
            if w == "FAIL" and v != "FAIL":
                newfail[t].append((s, n))
print("合計（OK/REPORTED/FAIL）:", " | ".join(f"{t}: {tot[t]['OK']}/{tot[t]['REPORTED']}/{tot[t]['FAIL']} (計 {sum(tot[t].values())})" for t in tags))
for t in tags[1:]:
    print(f"{tags[0]} -> {t}: {dict(trans[t])}  新しい FAIL {len(newfail[t])} {newfail[t][:10]}")
