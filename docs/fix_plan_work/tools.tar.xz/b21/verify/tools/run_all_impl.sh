#!/bin/sh
# impl（B2.1）: 1 つの版（SRC・TAG）で物差しをすべて流す（master_jd.sh・比べる担当の反例・pytest 3.13・3.10）。
#   sh run_all_impl.sh SRC TAG
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
I=$S/b21/verify; SRC=$1; TAG=$2
sh $I/tools/master_jd.sh $SRC $TAG > $I/logs/master_$TAG.log 2>&1
sh $I/tools/run_cj21.sh "$TAG:$SRC" > $I/logs/run_cj21_$TAG.log 2>&1
sh $S/fixB2r4/tools/pytest_src.sh $SRC python3 -q -rf > $I/logs/pt_${TAG}_313.log 2>&1
sh $S/fixB2r4/tools/pytest_src.sh $SRC $S/venv310/bin/python -q -rf > $I/logs/pt_${TAG}_310.log 2>&1
df -h / | tail -1 >> $I/logs/master_$TAG.log
echo ALLDONE
