#!/bin/sh
# judge（B2.1）: 比べる担当の反例 cases_judge21.py を 5 つの版で実行する（順に）。  sh run_cj21.sh [TAG:SRC ...]
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
J=$S/b21/verify
V=${*:-"jd021:$J/b021_src jdiso:$J/isolate_src jdamb:$J/ambiguity_src jdevi:$J/evidence_src jd020:$J/b020_src"}
cd $S/oracle
for x in $V; do
  t=${x%%:*}; s=${x#*:}
  python run_all.py $s $S/b21/judge/cases_judge21.py --name jd_cj21_$t > $J/logs/or_cj21_$t.log 2>&1
  rm -rf $S/oracle/_work/jd_cj21_$t
  echo "$t $(grep '^合計' $J/logs/or_cj21_$t.log)"
done
