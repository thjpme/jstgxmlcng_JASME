#!/bin/sh
# judge（B2.1）: 試作を直すときの速い確かめ。反例集の一部（n10・n10g・rv89・b2・x・y・w・v・b21・iso・amb・ev・cj21）を 4 並列で。
#   sh subset.sh SRC TAG     結果は oracle/results_<集>_<TAG>.json（集の名前は master_jd.sh と同じ: f4r_n10 など・jd_w など）
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
J=$S/b21/verify; L=$J/logs; SRC=$1; TAG=$2
cd $S/oracle
python run_all.py $SRC $S/n10/cases_n10.py --name f4r_n10_$TAG > $L/or_n10_$TAG.log 2>&1 &
python run_all.py $SRC $S/n10/cases_n10_guard.py --name f4r_n10g_$TAG > $L/or_n10g_$TAG.log 2>&1 &
python run_all.py $SRC $S/b21/judge/cases_judge21.py --name jd_cj21_$TAG > $L/or_cj21_$TAG.log 2>&1 &
python run_all.py $SRC $S/oracle/cases_b21.py --name jd_b21_$TAG > $L/or_b21_$TAG.log 2>&1 &
wait
python run_all.py $SRC $S/b2_review/r4p/cases_w_only.py --name jd_w_$TAG > $L/or_w_$TAG.log 2>&1 &
python run_all.py $SRC $S/b2_review/r5p/cases_v_only.py --name jd_v_$TAG > $L/or_v_$TAG.log 2>&1 &
python run_all.py $SRC $S/b21/isolate/cases_iso.py $S/b21/isolate/cases_iso2.py $S/b21/isolate/cases_iso3.py \
  $S/b21/isolate/cases_iso4.py $S/b21/isolate/cases_iso5.py --name jd_iso_$TAG > $L/or_iso_$TAG.log 2>&1 &
python run_all.py $SRC $S/b21/ambiguity/cases/cases_amb.py --name jd_amb_$TAG > $L/or_amb_$TAG.log 2>&1 &
wait
python run_all.py $SRC $S/b21/evidence/cases_ev.py --name jd_ev_$TAG > $L/or_ev_$TAG.log 2>&1 &
python run_all.py $SRC $S/oracle/cases_b2.py --name f4r_b2_$TAG > $L/or_b2_$TAG.log 2>&1 &
python run_all.py $SRC $S/rvB2x_principle_cases.py --name f4r_x_$TAG > $L/or_x_$TAG.log 2>&1 &
python run_all.py $SRC $S/b2_review/r2p/cases_y.py --name f4r_y_$TAG > $L/or_y_$TAG.log 2>&1 &
wait
python run_all.py $SRC $S/rvB8p/cases_rvB8p.py $S/rvB9p/cases_rvB9p_e1.py $S/rvB9p/cases_rvB9p_e2.py $S/rvB9p/cases_rvB9p_e3.py \
  $S/rvB9p/cases_rvB9p_e4.py $S/rvB9p/cases_rvB9p_e5.py $S/rvB9p/cases_rvB9p_e6.py --name f4r_rv89_$TAG > $L/or_rv89_$TAG.log 2>&1
rm -rf $S/oracle/_work/f4r_*_$TAG $S/oracle/_work/jd_*_$TAG
for x in n10 n10g cj21 b21 w v iso amb ev b2 x y rv89; do echo "$x $TAG: $(grep '^合計' $L/or_${x}_$TAG.log)"; done
