#!/bin/sh
# judge（B2.1）: master_jd.sh・run_cj21.sh の結果を、版（TAG）ごとに並べる（最初の TAG が比べる相手）。  sh summarize.sh TAG...
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
J=$S/b21/verify; F=$S/fixB2r4
echo "##### pytest"
for t in "$@"; do echo "$t: 3.13 $(tail -1 $J/logs/pt_${t}_313.log 2>/dev/null) | 3.10 $(tail -1 $J/logs/pt_${t}_310.log 2>/dev/null)"; done
echo "##### golden（n10/golden_base と manifest を比べる）"
for t in "$@"; do python3 - "$t" <<'PY'
import json, sys
from pathlib import Path
S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
t = sys.argv[1]
a = json.loads((S / "n10" / "golden_base" / "manifest.json").read_text())
p = S / "b21" / "verify" / "golden" / f"g_{t}" / "manifest.json"
p = p if p.exists() else S / "b21" / "judge" / "golden" / f"g_{t}" / "manifest.json"
b = json.loads(p.read_text()) if p.exists() else {}
diff = [k for k in set(a) | set(b) if a.get(k) != b.get(k)]
print(f"{t}: {len(b)} 件、0.20.0 と違う {len(diff)} {sorted(diff)[:5]}")
PY
done
echo "##### 本誌の出版版 PDF 7 通り"
python3 $J/tools/realcmp.py "$@"
echo "##### td1〜3（照合と直す箇所。最初の TAG と比べる）"
first=$1
for t in "$@"; do [ $t = $first ] && continue; echo "== $first -> $t"; python3 $S/b21/ambiguity/tools/tdcmp.py $J/td/cmp_$first.json $J/td/cmp_$t.json; done
for t in "$@"; do echo "$t 変換: $(grep -h -c '合格' $J/td/${t}_r2_td*.log 2>/dev/null | tr '\n' ' ')"; done
echo "##### 反例集 12 組・4 回目の反例・cases_b21・設計担当の反例・比べる担当の反例"
cd $J && python3 tools/ocmp.py --sets f4r_o34,f4r_n10,f4r_n10g,f4r_rv89,f4r_cj,f4r_cj2,f4r_b2,f4r_x,f4r_xm,f4r_r1,f4r_y,f4r_y2,jd_w,jd_v,jd_b21,jd_iso,jd_amb,jd_ev,jd_cj21 "$@"
echo "##### 生成例 29 種（段落）"
cd $J && python3 tools/sum_gen.py "$@" | tail -$(( $# + 0 ))
echo "##### quick"
cd $F/tools && python3 sum_q.py "$@" | tail -$(( $# + 1 ))
echo "##### fuzz4"
cd $J && python3 tools/fzsum2.py f4 "$@"
echo "##### fuzz8"
cd $J && python3 tools/fzsum2.py f8 "$@"
echo "##### 210 件"
args=""; for t in "$@"; do args="$args $F/v/fixB210_$t.json"; done
python3 -I $S/fixB/fixB_all.py --compare $args | tail -5
