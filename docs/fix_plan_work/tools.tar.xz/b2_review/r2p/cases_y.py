"""b2_review/r2p（単位 B2 の 1 回目の修正の後の、原則と文字の不変性〈ルート2〉の点検）の反例。文字はすべて架空。

oracle/run_all.py の書式（oracle/runner.py の docstring）。期待は原則だけで決める（0.20.0 にも B2 にも合わせない）。
  y_tailpb_*   分断の後ろが段落の最後の数文字（1 行。校正の直しあり）で、その行がページの最後にあり、次のページの最初に
               柱（著者名。8 文字未満なので、何ページにも出る行にならない）がある（_loose_edge は走査の最初の回〈t == 0〉にしか
               試さない）
  y_loose_*    段落の最後の文が校正で消され、段落のすぐ後ろの図（docx では画像。キャプションは図の上）の中の文字の最後の行が、
               消された文と半分以上同じ文字で、最後の「。」も同じ（_loose_edge が図の中の文字の行を段落の最後の行とみなす）
  y_rep1_*     校正の置き換えの PDF の文字が、行まるごと 1 行（段落の行の幅）を含み、その行が置き換えの最初か最後にある
               （_spans_whole は行の前と後ろの両方に PDF の文字が続くときだけ。行の最初・最後にそろった置き換えは、行まるごとを
               外した残りで置き換える）
"""
from __future__ import annotations

import sys
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
sys.path.insert(0, str(S / "n10"))

from runner import BREAK, DEFAULTS, Raw, flow, journal_line  # noqa: E402,F401
import cases_n10 as N  # noqa: E402

CASES = []


def case(name, item, paras, pages, note, truth=None, expect="exact", angle="layout"):
    CASES.append({"name": name, "angle": angle, "item": item, "paras": paras, "truth": truth or {},
                  "pages": pages, "expect": expect, "note": note})


def idx(paras, text):
    found = [i for i, (_, t) in enumerate(paras) if t == text]
    if len(found) != 1:
        raise ValueError(f"段落「{str(text)[:16]}」が {len(found)} 個")
    return found[0]


def tail_blocks():
    return [N.RH, Raw(*N.REF1_LINES), Raw(*N.REF2_LINES), BREAK, N.en_block()]


def with_head(pages, k, head):
    """k ページ目（0 から）のページ番号の行の次に、柱の行 head を入れる。"""
    ls = pages[k].split("\n")
    pages = list(pages)
    pages[k] = "\n".join(ls[:1] + [head] + ls[1:])
    return pages


# ============================================================================ 1. 分断の後ろの最後の行がページの最後、次のページの最初に柱
TAILFIX = [
    ("4a", 4, N.TARGET[:-4] + "持った。"),
    ("3", 3, N.TARGET[:-3] + "てた。"),
    ("6", 6, N.TARGET[:-6] + "間を取る。"),
    ("7", 7, N.TARGET[:-7] + "時間を設けた。"),
]
for tag, k, pub in TAILFIX:
    head_pdf, tail_pdf = pub[:len(N.TARGET) - k], pub[len(N.TARGET) - k:]
    assert head_pdf == N.TARGET[:-k], tag
    for kind, n in (("tab", 20), ("tab", 60), ("para", 20)):
        m_before, m_after, others, lines = N.material(kind, n, "tail")
        paras = N.article_paras(N.TARGET, m_before, m_after, others_after=others)
        blocks = [N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*N.body(head_pdf)),
                  Raw(*lines), Raw(tail_pdf), BREAK, Raw(*N.body(N.P_AFTER)), N.H3, Raw(*N.body(N.P_DISC)),
                  Raw(*N.body(N.P_END)), *tail_blocks()]
        for hk, head in (("auth", "試験　五郎"), ("none", None)):
            pages = flow(blocks, first=25)
            if head:
                pages = with_head(pages, 1, head)
            case(f"y_tailpb{tag}_{kind}{n}_{hk}", "N10", paras, pages,
                 f"段落の最後の {len(tail_pdf)} 文字（「{tail_pdf}」。docx の「{N.TARGET[-k:]}」を校正で直したもの）が、"
                 f"{N.KIND_NOTE[kind].format(side='後ろ', side2='2 つ後ろ')}（約 {N.chars(lines)} 文字）の後ろの、ページの最後の行に"
                 "ある。次のページは" + (f"柱「{head}」の行の後に" if head else "") + "次の段落から始まる。直すか、決められなければ "
                 "docx のまま 13 章に出す（docx の最後の文字を消さない。分断する文字を足さない）。",
                 truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): pub},
                 expect={"default": "exact", idx(paras, N.TARGET): "reported"})

# ============================================================================ 2. 消された最後の文と、すぐ後ろの図の中の文字の最後の行
LOOSE = [
    # 名前, docx で TARGET の後ろに付いていた文（出版版で消された）, 図の中の文字の行（最後の行が似ている）
    ("solve", "その問題を示す。", ["問題　水を入れる時間と深さの", "関係を表に表し，その決まりを", "問題を解きなさい。"]),
    ("answer", "これを図２に示す。", ["次の表を完成させ，", "これを示しなさい。"]),
    ("short", "を示した。", ["表に数を書き入れ", "を示せ。"]),
]
FIG2_CAP = "図２　架空の問題"
for tag, deleted, fig in LOOSE:
    docx_t = N.TARGET + deleted
    paras = ([("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("見出し", N.H2), ("本文", docx_t),
              ("図キャプション", FIG2_CAP), ("画像", "".join(fig)), ("本文", N.P_AFTER), ("見出し", N.H3),
              ("本文", N.P_DISC), ("本文", N.P_END), ("引用文献見出し", N.RH), ("引用文献", N.REF1), ("引用文献", N.REF2)])
    pages = N.article_pages([Raw(*N.body(N.TARGET)), Raw(FIG2_CAP, *fig)])
    case(f"y_loose_{tag}", "new", paras, pages,
         f"docx の段落の最後の文「{deleted}」は、出版版では消されている。段落のすぐ後ろに図（docx では画像で、キャプションは"
         f"図の上）があり、図の中の文字の最後の行「{fig[-1]}」が、消された文と似ている。消すか、決められなければ docx のまま"
         " 13 章に出す（図の中の文字を段落に足さない）。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_t): N.TARGET},
         expect={"default": "exact", idx(paras, docx_t): "reported"})

# ============================================================================ 3. 行まるごと 1 行を含む置き換えで、その行が置き換えの最初・最後
PRE24 = ("第三時の授業では，教師はまず前時に作った表を黒板に掲げ，水を入れる時間と水の深さの関係を振り返らせた。"
         "その後，教師の指示により，班の生徒たちは")        # 最後の行が 24 文字（行の幅いっぱい）
PRE22 = ("第三時の授業では，教師はまず前時に作った表を黒板に掲げ，水を入れる時間と水の深さの関係を振り返らせた。"
         "その後，教師の指示により，班の生徒は")            # 最後の行が 22 文字
POST = "の表にも矢印をかき，増え方がいつも同じであることを確かめた。"
NEW27 = "授業の初めに配られた架空のワークシートに印刷された二つ"          # 27 文字
NEW26 = "授業の初めに配られた架空のワークシートに印刷された二"            # 26 文字
assert len(N.body(PRE24)[-1]) == 24 and len(N.body(PRE22)[-1]) == 22 and len(NEW27) == 27 and len(NEW26) == 26
REP1 = []
# (a) 置き換えの PDF の文字が行の最初から始まる（前の行が docx の文字で行の幅いっぱいに終わる）: 行まるごと + 次の行の 3 文字
for old in ("自分たちの作った", "自分自身が書いて", "自分自身が書いて持参"):
    docx_t, pub = PRE24 + old + POST, PRE24 + NEW27 + POST
    lines = N.body(PRE24) + [NEW27[:24]] + N.jwrap(NEW27[24:] + POST)
    REP1.append((f"start{len(old)}{'x' if '身' in old else ''}", docx_t, pub, lines, old, NEW27, False))
    REP1.append((f"start{len(old)}{'x' if '身' in old else ''}_pb", docx_t, pub, lines, old, NEW27, True))
# (b) 置き換えの PDF の文字が行の最後で終わる（次の行が docx の文字から始まる）: 前の行の最後の 2 文字 + 行まるごと
for old in ("自分たちの作った", "自分自身が書いて", "自分自身が書いて持参"):
    docx_t, pub = PRE22 + old + POST, PRE22 + NEW26 + POST
    first = N.body(PRE22 + NEW26[:2])
    assert len(first[-1]) == 24
    lines = first + [NEW26[2:]] + N.jwrap(POST)
    assert len(NEW26[2:]) == 24
    REP1.append((f"end{len(old)}{'x' if '身' in old else ''}", docx_t, pub, lines, old, NEW26, False))
for tag, docx_t, pub, lines, old, new, pb in REP1:
    assert "".join(lines).lstrip("　") == pub, tag
    paras = ([("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("見出し", N.H2), ("本文", docx_t),
              ("本文", N.P_AFTER), ("見出し", N.H3), ("本文", N.P_DISC), ("本文", N.P_END), ("引用文献見出し", N.RH),
              ("引用文献", N.REF1), ("引用文献", N.REF2)])
    if pb:
        # 行まるごとの行が次のページの最初の行（ページの端の行）
        cut = len(N.body(PRE24))
        blocks = [Raw(*lines[:cut]), BREAK, Raw(*lines[cut:])]
    else:
        blocks = [Raw(*lines)]
    pages = N.article_pages(blocks)
    case(f"y_rep1_{tag}", "new", paras, pages,
         f"docx の「{old}」（{len(old)} 文字）を、出版版では「{new}」（{len(new)} 文字）に置き換えた。PDF では、その文字の"
         + ("最初の 24 文字が行まるごと（行の最初から）" if tag.startswith("start") else "最後の 24 文字が行まるごと（行の最後まで）")
         + ("。その行は次のページの最初の行" if pb else "") + "。直すか、決められなければ docx のまま 13 章に出す（行まるごとを"
         "外した残りの文字だけで直さない）。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_t): pub},
         expect={"default": "exact", idx(paras, docx_t): "reported"})

# ============================================================================ 1b. 1. の変わり型: 次のページの最初の柱の代わりに、ページの最後に投稿受付日の行（本誌の 1 ページ目）
from runner import received_line  # noqa: E402
DATE2 = ("2025年２月27日投稿受付，2025年７月30日再投稿受付，", "2025年10月10日採用決定")
for tag, k, pub in TAILFIX:
    head_pdf, tail_pdf = pub[:len(N.TARGET) - k], pub[len(N.TARGET) - k:]
    for kind, n in (("tab", 20), ("tab", 60), ("para", 20), ("para", 60), ("fig", 20), ("fig", 60)):
        m_before, m_after, others, lines = N.material(kind, n, "tail")
        paras = N.article_paras(N.TARGET, m_before, m_after, others_after=others)
        for dk, dl in (("date1", (received_line(),)), ("date2", DATE2), ("date2b", DATE2[1:])):
            blocks = [N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*N.body(head_pdf)),
                      Raw(*lines), Raw(tail_pdf), Raw(*dl), BREAK, Raw(*N.body(N.P_AFTER)), N.H3, Raw(*N.body(N.P_DISC)),
                      Raw(*N.body(N.P_END)), *tail_blocks()]
            case(f"y_taildate{tag}_{kind}{n}_{dk}", "N10", paras, flow(blocks, first=25),
                 f"段落の最後の {len(tail_pdf)} 文字（「{tail_pdf}」。docx の「{N.TARGET[-k:]}」を校正で直したもの）が、"
                 f"{N.KIND_NOTE[kind].format(side='後ろ', side2='2 つ後ろ')}（約 {N.chars(lines)} 文字）の後ろの行にあり、そのすぐ後ろ（1 ページ目の最後）に"
                 f"投稿受付日の行（{len(dl)} 行）がある。次のページは次の段落から始まる。直すか、決められなければ docx のまま 13 章に"
                 "出す（docx の最後の文字を消さない。表・受付日の文字を足さない）。",
                 truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): pub},
                 expect={"default": "exact", idx(paras, N.TARGET): "reported"})

# ============================================================================ 1c. 分断の後ろが最後の 7〜12 文字で、分断する文字が図（x_tailfix の TAILFIX_LONG は表・段落だけ）
TAILFIX_LONG2 = [
    ("7", 7, N.TARGET[:-7] + "時間を設けた。"),
    ("9", 9, N.TARGET[:-9] + "合う場を設けた。"),
    ("12", 12, N.TARGET[:-12] + "説明する時間を取った。"),
]
for tag, k, pub in TAILFIX_LONG2:
    head_pdf, tail_pdf = pub[:len(N.TARGET) - k], pub[len(N.TARGET) - k:]
    for n in (20, 60):
        m_before, m_after, others, lines = N.material("fig", n, "tail")
        paras = N.article_paras(N.TARGET, m_before, m_after, others_after=others)
        pages = N.article_pages([Raw(*N.body(head_pdf)), Raw(*lines), Raw(tail_pdf)])
        case(f"y_tailfix{tag}_fig{n}", "N10", paras, pages,
             f"PDF では段落の最後の {len(tail_pdf)} 文字（「{tail_pdf}」の 1 行。docx の「{N.TARGET[-k:]}」を校正で直したもの）の"
             f"前に、図の中の文字と図のキャプション（約 {N.chars(lines)} 文字）が入る。直すか、決められなければ docx のまま 13 章に"
             "出す（docx の最後の文字を消さない。図の中の文字を足さない）。",
             truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): pub},
             expect={"default": "exact", idx(paras, N.TARGET): "reported"})

# ============================================================================ 2b. 2. の変わり型: 段落の最初の語が校正で消され、すぐ前の図（キャプションは図の下）の中の文字の最初の行が似ている
LOOSE_HEAD = [
    # 名前, docx で P_AFTER の前に付いていた語（出版版で消された）, 図の中の文字の行（最初の行が似ている）
    ("then", "そこで，", ["そこで", "表を作る", "↓", "規則を見つける"]),
    ("first", "まず初めに，", ["まず表を作る", "↓", "規則を言葉で書く"]),
]
for tag, deleted, fig in LOOSE_HEAD:
    docx_a = deleted + N.P_AFTER
    paras = ([("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("見出し", N.H2), ("本文", N.TARGET),
              ("画像", "".join(fig)), ("図キャプション", FIG2_CAP), ("本文", docx_a), ("見出し", N.H3),
              ("本文", N.P_DISC), ("本文", N.P_END), ("引用文献見出し", N.RH), ("引用文献", N.REF1), ("引用文献", N.REF2)])
    pages = N.article_pages([Raw(*N.body(N.TARGET)), Raw(*fig, FIG2_CAP)])
    case(f"y_loosehead_{tag}", "new", paras, pages,
         f"docx の段落の最初の語「{deleted}」は、出版版では消されている。段落のすぐ前に図（docx では画像で、キャプションは"
         f"図の下）があり、図の中の文字の最初の行「{fig[0]}」が、消された語と似ている。消すか、決められなければ docx のまま"
         " 13 章に出す（図の中の文字を段落に足さない）。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_a): N.P_AFTER},
         expect={"default": "exact", idx(paras, docx_a): "reported"})

# 1b の変わり型: 受付日が分断の後ろの最後の行につながる（同じ行。本誌の 1 ページ目の形の一つ）
for tag, k, pub in TAILFIX:
    head_pdf, tail_pdf = pub[:len(N.TARGET) - k], pub[len(N.TARGET) - k:]
    for kind, n in (("tab", 20), ("para", 20), ("para", 60)):
        m_before, m_after, others, lines = N.material(kind, n, "tail")
        paras = N.article_paras(N.TARGET, m_before, m_after, others_after=others)
        blocks = [N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*N.body(head_pdf)),
                  Raw(*lines), Raw(tail_pdf + received_line()), BREAK, Raw(*N.body(N.P_AFTER)), N.H3,
                  Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()]
        case(f"y_taildatej{tag}_{kind}{n}", "N10", paras, flow(blocks, first=25),
             f"y_taildate の変わり型（受付日が、段落の最後の {len(tail_pdf)} 文字の行の後ろに同じ行でつながる）。直すか、決められ"
             "なければ docx のまま 13 章に出す（docx の最後の文字を消さない。受付日の文字を足さない）。",
             truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): pub},
             expect={"default": "exact", idx(paras, N.TARGET): "reported"})
