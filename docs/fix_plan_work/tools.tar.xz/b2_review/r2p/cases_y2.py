"""b2_review/r2p の反例（2）: 段落の最後の数文字（校正の直しあり）が、小さな図（docx では画像。キャプションは図の下）の後ろに出る形。
図の中の文字を変える（よく使う文字〈の・を・た・。・時など〉を含むもの）。文字はすべて架空。"""
from __future__ import annotations

import sys
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
sys.path.insert(0, str(S / "n10"))

from runner import BREAK, DEFAULTS, Raw, flow, journal_line  # noqa: E402,F401
import cases_n10 as N  # noqa: E402

CASES = []


def case(name, item, paras, pages, note, truth=None, expect="exact", angle="layout"):
    CASES.append({"name": name, "angle": angle, "item": item, "paras": paras, "truth": truth or {},
                  "pages": pages, "expect": expect, "note": note})


def idx(paras, text):
    found = [i for i, (_, t) in enumerate(paras) if t == text]
    if len(found) != 1:
        raise ValueError(f"段落「{str(text)[:16]}」が {len(found)} 個")
    return found[0]


TAILS = [
    ("4a", 4, N.TARGET[:-4] + "持った。"),
    ("6", 6, N.TARGET[:-6] + "間を取る。"),
    ("7", 7, N.TARGET[:-7] + "時間を設けた。"),
    ("9", 9, N.TARGET[:-9] + "合う場を設けた。"),
    ("7b", 7, N.TARGET[:-7] + "機会を取った。"),
    ("8", 8, N.TARGET[:-8] + "う時間をとった。"),
]
FIGS = {
    "a": ["導入", "↓", "前時の表を振り返る"],
    "b": ["まとめ", "↓", "分かったことを書く"],
    "c": ["課題の提示", "↓", "個人で考える時間"],
    "d": ["説明を聞く", "↓", "取り組みを話し合う"],
}
CAP = "図１　架空の授業の流れ"
for tag, k, pub in TAILS:
    head_pdf, tail_pdf = pub[:len(N.TARGET) - k], pub[len(N.TARGET) - k:]
    for fk, fig in FIGS.items():
        paras = N.article_paras(N.TARGET, (), [("画像", "".join(fig)), ("図キャプション", CAP)])
        pages = N.article_pages([Raw(*N.body(head_pdf)), Raw(*fig, CAP), Raw(tail_pdf)])
        case(f"y2_tailfig{tag}_{fk}", "N10", paras, pages,
             f"段落の最後の {len(tail_pdf)} 文字（「{tail_pdf}」。docx の「{N.TARGET[-k:]}」を校正で直したもの）が、小さな図"
             f"（図の中の文字「{'／'.join(fig)}」とキャプション）の後ろの行に出る。直すか、決められなければ docx のまま 13 章に出す"
             "（docx の最後の文字を消さない。図の中の文字を足さない）。",
             truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): pub},
             expect={"default": "exact", idx(paras, N.TARGET): "reported"})
