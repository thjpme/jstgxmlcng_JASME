"""b2r3 principle: 段落 A の最後の文字（校正の直しあり・分断あり）と同じ文が、すぐ後ろの段落 B の最初にもある形（同じ文のくり返し）。
h2.py 用。架空の文字。"""
import gen_tail as G

B_REP = "説明し合う時間を取った。その後，教師は二つの説明を並べて板書し，違いを問うた。"


def make_cases(T):
    out = []
    for ek in ("none", "e4", "e7", "e9", "punct", "delsent", "e2"):
        dt, pt = G.EDITS[ek]
        if ek == "none":
            docx, pub = T.LESSON, T.LESSON
        elif ek == "delsent":
            docx, pub = T.LESSON + "その結果を表に示す。", T.LESSON
        else:
            cut0 = len(T.LESSON) - len(dt)
            docx, pub = T.LESSON[:cut0] + dt, T.LESSON[:cut0] + pt
        lines = T.body_lines(pub)
        for bk in ("same", "bedit"):
            b_docx = B_REP
            b_pub = B_REP if bk == "same" else B_REP.replace("取った", "設けた")
            for ck in ("last1", "k7"):
                first, second = (lines[:-1], lines[-1:]) if ck == "last1" else (T.body_lines(pub[:-7]), [pub[-7:]])
                for mk in ("none", "tab", "fig"):
                    blocks = [("body", docx)]
                    if mk == "tab":
                        blocks += [("tab_cap", G.TCAP), ("table", G.CELLS)]
                        mid = [G.TCAP] + [" ".join(r) for r in G.CELLS]
                    elif mk == "fig":
                        blocks += [("image", "fig"), ("fig_cap", G.CAP)]
                        mid = G.FIGS["fig"] + [G.CAP]
                    else:
                        mid = []
                    blocks += [("body", b_docx), ("body", T.SURVEY)]
                    for ak in ("direct", "date", "pbhead"):
                        p1 = [*T.SMALL_FRONT, *first, *mid, *second]
                        rest = [*T.body_lines(b_pub), *T.body_lines(T.SURVEY), *T.N10_TAIL]
                        pages = [p1 + rest] if ak == "direct" else ([p1 + [G.DATE], rest] if ak == "date" else
                                                                     [p1, ["試験　六郎"] + rest])
                        out.append({"name": f"d_{ek}_{bk}_{ck}_{mk}_{ak}", "blocks": blocks, "pages": pages,
                                    "want": {docx: pub, b_docx: b_pub}})
    return out
