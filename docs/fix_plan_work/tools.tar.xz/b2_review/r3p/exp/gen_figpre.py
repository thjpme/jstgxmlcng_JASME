"""b2r3 principle: z_figsim_del の形で、図の中の最後の行が、段落の最後の行の最初の数文字と同じもの（2〜5 文字）と、似ていない
もの（対照）。h2.py 用。架空の文字。"""
import gen_tail as G

LASTS = {"p2": "時間", "p3": "時間を", "p4": "時間を取", "p3x": "時間を見る", "q3": "時間の表", "none": "まとめ",
         "sh3": "時を見る"}
DELS = {"del10": "その結果を表に示す。", "del6": "以上である。", "del0": ""}


def make_cases(T):
    out = []
    for dk, deleted in DELS.items():
        docx, pub = T.LESSON + deleted, T.LESSON
        for ek, (dt, pt) in (("noedit", ("", "")), ("e4", ("取った。", "持った。"))):
            pub2 = pub if ek == "noedit" else pub[:-4] + pt
            if dk == "del0" and ek == "noedit":
                continue
            for fk, last in LASTS.items():
                fig = ["導入", "↓", "課題の提示", "↓", last]
                blocks = [("body", docx), ("image", "fig"), ("fig_cap", G.CAP), ("body", T.TALK), ("body", T.SURVEY)]
                for ak in ("date", "pbhead", "direct"):
                    p1 = [*T.SMALL_FRONT, *T.body_lines(pub2[:-7]), *fig, G.CAP, pub2[-7:]]
                    rest = [*T.body_lines(T.TALK), *T.body_lines(T.SURVEY), *T.N10_TAIL]
                    pages = [p1 + rest] if ak == "direct" else ([p1 + [G.DATE], rest] if ak == "date" else
                                                                 [p1, ["試験　六郎"] + rest])
                    out.append({"name": f"p_{dk}_{ek}_{fk}_{ak}", "blocks": blocks, "pages": pages, "want": {docx: pub2}})
    return out
