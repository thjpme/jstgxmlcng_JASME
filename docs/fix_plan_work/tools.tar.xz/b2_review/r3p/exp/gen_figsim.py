"""b2r3 principle: 段落 A の最後が小さな図（図の中の文字は docx にない）の後ろに分断され、図のキャプションの前の図の中の最後の
行が、A の最後の文字とよく似ている形（h2.py 用。架空の文字）。A は LESSON（最後は「…説明し合う時間を取った。」）。"""
import gen_tail as G

FIGLAST = {
    "s3c": "時間を見る",          # A の最後と「時間を」が続いて同じ
    "s3w": "時間を書く",
    "s3n": "時刻を見る",          # 「時」「を」「る」（続かない）
    "s2": "表を見る",
    "s4": "時間を計る",
    "c6": "説明し合う時間",       # A の最後の前の部分と 7 文字続いて同じ
    "s3t": "時間を取る",          # 「時間を取」が同じ
}
EDITS = {k: G.EDITS[k] for k in ("none", "e4", "e7", "e9", "nostop", "delsent", "e2")}
CAP = "図１　架空の授業の流れ"


def make_cases(T):
    out = []
    base = T.LESSON[:-len("取った。")]
    for ek, (dt, pt) in EDITS.items():
        if ek == "none":
            docx, pub = T.LESSON, T.LESSON
        elif ek == "delsent":
            docx, pub = T.LESSON + "その結果を表に示す。", T.LESSON
        elif ek == "nostop":
            docx, pub = base[:-len("時間を")] + "時間を取る", base[:-len("時間を")] + "場を設けた。"
        else:
            cut0 = len(T.LESSON) - len(dt)
            docx, pub = T.LESSON[:cut0] + dt, T.LESSON[:cut0] + pt
        lines = T.body_lines(pub)
        for ck in ("last1", "k7"):
            first, second = (lines[:-1], lines[-1:]) if ck == "last1" else (T.body_lines(pub[:-7]), [pub[-7:]])
            for fk, last in FIGLAST.items():
                for capk in ("below", "above"):
                    fig = ["導入", "↓", "課題の提示", "↓", last]
                    if capk == "below":
                        blocks = [("body", docx), ("image", "fig"), ("fig_cap", CAP)]
                        mid = fig + [CAP]
                    else:
                        blocks = [("body", docx), ("fig_cap", CAP), ("image", "fig")]
                        mid = [CAP] + fig
                    blocks += [("body", T.TALK), ("body", T.SURVEY)]
                    for ak in ("direct", "date", "pbhead"):
                        p1 = [*T.SMALL_FRONT, *first, *mid, *second]
                        rest = [*T.body_lines(T.TALK), *T.body_lines(T.SURVEY), *T.N10_TAIL]
                        pages = [p1 + rest] if ak == "direct" else ([p1 + [G.DATE], rest] if ak == "date" else
                                                                     [p1, ["試験　六郎"] + rest])
                        out.append({"name": f"f_{ek}_{ck}_{fk}_{capk}_{ak}", "blocks": blocks, "pages": pages,
                                    "want": {docx: pub}})
    return out
