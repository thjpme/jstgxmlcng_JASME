"""b2r3 principle: 段落 A の最後の行が、小さな図（docx では画像。図の中の文字は docx にない）の後ろに出て、図の中の最後の行
（キャプションの前）が文の終わり「。」で終わり、A の最後の文字（「…時間を取った。」）とよく使う文字（を・た・。）を共有する形
（h2.py 用。架空の文字）。図の中の文字は問題文の形（本誌の論文の図によくある）。"""
import gen_tail as G

FIGLAST = {
    "q1": "表を完成させた。",            # を・た・。
    "q2": "問題を解いた。",              # を・た・。（「いた。」）
    "q3": "表を見なさい。",              # を・。
    "q4": "規則を言葉で書く。",          # を・。
    "q5": "答えを書きなさい。",          # を・。
    "q6": "式に表した。",                # た・。
}
EDITS = {k: G.EDITS[k] for k in ("none", "e4", "e7", "e9", "delsent", "addsent", "e2")}
CAP = "図１　架空の問題"


def make_cases(T):
    out = []
    for ek, (dt, pt) in EDITS.items():
        if ek == "none":
            docx, pub = T.LESSON, T.LESSON
        elif ek == "delsent":
            docx, pub = T.LESSON + "その結果を表に示す。", T.LESSON
        elif ek == "addsent":
            docx, pub = T.LESSON, T.LESSON + "以上が第三時の流れである。"
        else:
            cut0 = len(T.LESSON) - len(dt)
            docx, pub = T.LESSON[:cut0] + dt, T.LESSON[:cut0] + pt
        lines = T.body_lines(pub)
        for ck in ("last1", "k7"):
            first, second = (lines[:-1], lines[-1:]) if ck == "last1" else (T.body_lines(pub[:-7]), [pub[-7:]])
            for fk, last in FIGLAST.items():
                for capk in ("below", "above"):
                    fig = ["問題　水を入れる時間と深さ", last]
                    if capk == "below":
                        blocks = [("body", docx), ("image", "fig"), ("fig_cap", CAP)]
                        mid = fig + [CAP]
                    else:
                        blocks = [("body", docx), ("fig_cap", CAP), ("image", "fig")]
                        mid = [CAP] + fig
                    blocks += [("body", T.TALK), ("body", T.SURVEY)]
                    for ak in ("direct", "date", "pbhead"):
                        p1 = [*T.SMALL_FRONT, *first, *mid, *second]
                        rest = [*T.body_lines(T.TALK), *T.body_lines(T.SURVEY), *T.N10_TAIL]
                        pages = [p1 + rest] if ak == "direct" else ([p1 + [G.DATE], rest] if ak == "date" else
                                                                     [p1, ["試験　六郎"] + rest])
                        out.append({"name": f"q_{ek}_{ck}_{fk}_{capk}_{ak}", "blocks": blocks, "pages": pages,
                                    "want": {docx: pub}})
    return out
