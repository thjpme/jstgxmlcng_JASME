"""b2r3 principle: 段落 B の最初（校正の直し・分断・前の行）の組み合わせを生成する（h2.py 用。架空の文字）。

A は LESSON、B は TALK を変えたもの、C は SURVEY。
  edit : B の最初の直し（docx の最初 → 出版版の最初）
  cut  : PDF で B のどこが分断の前に出るか（first1: 最初の行、k7: 最初の 7 文字の行、sent: 最初の文）
  mat  : 分断する文字（tab: 表〈docx では B の前〉・fig: 図〈docx では B の前の画像とキャプション〉・figsim: 図の中の最初の行が
         B の最初とよく似ている・para: 別の段落〈docx では A の前〉）
  before: A と B の最初の行の間（direct・pbhead: ページが変わり、次のページの最初に柱・date: 受付日の行）
"""
import gen_tail as G

TALK = "話し合いの中で，ある生徒は時間が３倍になると深さも３倍になると述べ，別の生徒は理由を付け加えた。"
EDITS = {
    "none": (TALK, TALK),
    "fix": (TALK, TALK.replace("話し合いの中で", "話し合いの場面で")),
    "del": ("そこで，" + TALK, TALK),
    "add": (TALK, "まず，" + TALK),
    "rew": (TALK, TALK.replace("話し合いの中で", "議論の中で")),
    "punct": (TALK.replace("中で，", "中で、"), TALK),
    "delw": ("そこで" + TALK, TALK),
}
FIGS = {
    "fig": ["導入", "↓", "課題の提示", "↓", "まとめ"],
    "figsim": ["話し合いの場面", "↓", "課題の提示", "↓", "まとめ"],
}
CAP = "図１　架空の授業の流れ"


def make_cases(T):
    out = []
    for ek, (docx, pub) in EDITS.items():
        lines = T.body_lines(pub)
        for ck in ("first1", "k7", "sent"):
            if ck == "first1":
                first, second = lines[:1], lines[1:]
            elif ck == "k7":
                first, second = ["　" + pub[:7]], T.wrap_lines(pub[7:])
            else:
                k = pub.find("，") + 1
                first, second = T.body_lines(pub[:k]), T.wrap_lines(pub[k:])
            for mk in ("tab", "fig", "figsim", "para"):
                blocks = [("body", T.LESSON)]
                if mk == "tab":
                    blocks += [("tab_cap", G.TCAP), ("table", G.CELLS)]
                    mid = [G.TCAP] + [" ".join(r) for r in G.CELLS]
                elif mk in FIGS:
                    blocks += [("image", "fig"), ("fig_cap", CAP)]
                    mid = FIGS[mk] + [CAP]
                else:
                    blocks = [("body", G.NOTE20)] + blocks
                    mid = T.body_lines(G.NOTE20)
                blocks += [("body", docx), ("body", T.SURVEY)]
                for bk in ("direct", "pbhead", "date"):
                    head = [*T.SMALL_FRONT, *T.body_lines(T.LESSON)]
                    tail = [*first, *mid, *second, *T.body_lines(T.SURVEY), *T.N10_TAIL]
                    if bk == "direct":
                        pages = [head + tail]
                    elif bk == "pbhead":
                        pages = [head, ["試験　六郎"] + tail]
                    else:
                        pages = [head + [G.DATE], tail]
                    if mk == "para":
                        pages = [[*T.SMALL_FRONT] + p[len(T.SMALL_FRONT):] if i == 0 else p for i, p in enumerate(pages)]
                    out.append({"name": f"h_{ek}_{ck}_{mk}_{bk}", "blocks": blocks, "pages": pages,
                                "want": {docx: pub}})
    return out
