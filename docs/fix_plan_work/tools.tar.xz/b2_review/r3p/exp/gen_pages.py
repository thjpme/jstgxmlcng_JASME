"""b2r3 principle: gen_tail の反例を、ページの形を変えて作る（ページ番号なし・ページの最後にページ番号・1 ページだけ・空のページを
はさむ）。h2.py 用。架空の文字。"""
import gen_tail as G


def make_cases(T):
    out = []
    for c in G.make_cases(T):
        _, ek, ck, mk, ak = c["name"].split("_")
        if ak not in ("direct", "pb", "date") or ek in ("addsent",):
            continue
        for pk in ("nonum", "bottom", "blank", "one"):
            pages = [list(p) for p in c["pages"]]
            if pk == "one":
                pages = [[ln for p in pages for ln in p]]
                raw = ["\n".join(pages[0])]
            elif pk == "nonum":
                raw = ["\n".join(p) for p in pages]
            elif pk == "bottom":
                raw = ["\n".join([*p, f"－ {k + 1} －"]) for k, p in enumerate(pages)]
            else:
                raw = ["\n".join([f"（{k + 1}）", *p]) for k, p in enumerate(pages)]
                raw = raw[:1] + [""] + raw[1:]
            out.append({"name": f"{c['name']}_{pk}", "blocks": c["blocks"], "raw_pages": raw, "want": c["want"]})
    return out
