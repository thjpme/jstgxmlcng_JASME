"""b2r3 principle: 段落 A の最後（校正の直し・分断・後ろの行）の組み合わせを生成する（h2.py 用。架空の文字）。

A は tests/test_pdfmatch.py の LESSON、B は TALK、C は SURVEY。
  edit : A の最後の直し（docx の最後 → 出版版の最後）
  cut  : PDF で A のどこが分断の後ろに出るか（last1: 最後の行、sent: 最後の文、k7: 最後の 7 文字の行）
  mat  : 分断する文字（none・tab: 表〈docx では A の後ろ〉・fig: 図〈画像とキャプション。図の中の文字は docx にない〉・
         figsim: 図の中の文字が A の最後とよく似た文字を含む・para: 別の段落〈docx では B の後ろ〉）
  after: A の最後の行と B の間（direct・date: 受付日の行の後でページが変わる・pb: ページが変わる・pbhead: 次のページの最初に柱）
"""
EDITS = {
    "none": ("", ""),
    "e4": ("取った。", "持った。"),
    "e7": ("時間を取った。", "時間を設けた。"),
    "e9": ("合う時間を取った。", "合う場を設けた。"),
    "punct": ("取った．", "取った。"),
    "nostop": ("時間を取る", "場を設けた。"),
    "delsent": ("取った。その結果を表に示す。", "取った。"),
    "addsent": ("取った。", "取った。以上が第三時の流れである。"),
    "e2": ("った。", "った．"),
}
FIGS = {
    "fig": ["導入", "↓", "課題の提示", "↓", "まとめ"],
    "figsim": ["導入", "↓", "前時の表を振り返る", "↓", "時間を見る"],
}
CAP = "図１　架空の授業の流れ"
CELLS = [["Ａ組", "12", "7"], ["Ｂ組", "19", "16"]]
TCAP = "表１　記述の数"
NOTE20 = "この点は次の節で改めて詳しく述べる。"
DATE = "2025年８月31日投稿受付，2025年11月24日採用決定"


def make_cases(T):
    out = []
    base = T.LESSON[:-len("取った。")]          # 「…説明し合う時間を」
    for ek, (dt, pt) in EDITS.items():
        if ek == "none":
            docx, pub = T.LESSON, T.LESSON
        else:
            stem = T.LESSON[:-len("取った。")] + "取った。"
            assert stem == T.LESSON
            cut0 = len(T.LESSON) - len(dt) if T.LESSON.endswith(dt) else None
            if ek in ("delsent",):
                docx, pub = T.LESSON + "その結果を表に示す。", T.LESSON
            elif ek == "addsent":
                docx, pub = T.LESSON, T.LESSON + "以上が第三時の流れである。"
            elif ek == "nostop":
                docx, pub = base[:-len("時間を")] + "時間を取る", base[:-len("時間を")] + "場を設けた。"
            else:
                docx, pub = T.LESSON[:cut0] + dt, T.LESSON[:cut0] + pt
        lines = T.body_lines(pub)
        for ck in ("last1", "sent", "k7"):
            if ck == "last1":
                first, second = lines[:-1], lines[-1:]
            elif ck == "sent":
                k = pub.rfind("。", 0, len(pub) - 1) + 1
                first, second = T.body_lines(pub[:k]), T.wrap_lines(pub[k:])
            else:
                first, second = T.body_lines(pub[:-7]), [pub[-7:]]
            for mk in ("none", "tab", "fig", "figsim", "para"):
                blocks = [("body", docx)]
                if mk == "tab":
                    blocks += [("tab_cap", TCAP), ("table", CELLS)]
                    mid = [TCAP] + [" ".join(r) for r in CELLS]
                elif mk in FIGS:
                    blocks += [("image", "fig"), ("fig_cap", CAP)]
                    mid = FIGS[mk] + [CAP]
                elif mk == "para":
                    mid = T.body_lines(NOTE20)
                else:
                    mid = []
                blocks += [("body", T.TALK)]
                if mk == "para":
                    blocks += [("body", NOTE20)]
                blocks += [("body", T.SURVEY)]
                for ak in ("direct", "date", "pb", "pbhead"):
                    p1 = [*T.SMALL_FRONT, *first, *mid, *second]
                    rest = [*T.body_lines(T.TALK), *T.body_lines(T.SURVEY), *T.N10_TAIL]
                    if ak == "direct":
                        pages = [p1 + rest]
                    elif ak == "date":
                        pages = [p1 + [DATE], rest]
                    elif ak == "pb":
                        pages = [p1, rest]
                    else:
                        pages = [p1, ["試験　六郎"] + rest]
                    out.append({"name": f"t_{ek}_{ck}_{mk}_{ak}", "blocks": blocks, "pages": pages,
                                "want": {docx: pub}})
    return out
