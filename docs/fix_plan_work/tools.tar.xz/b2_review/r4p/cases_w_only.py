"""b2r4 principle: rvB2x_principle_cases.py の w_* だけ（4 回目の点検の反例）。"""
import importlib.util
_spec = importlib.util.spec_from_file_location("rvB2x_principle_cases", "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/rvB2x_principle_cases.py")
_m = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_m)
CASES = [c for c in _m.CASES if c["name"].startswith("w_")]
