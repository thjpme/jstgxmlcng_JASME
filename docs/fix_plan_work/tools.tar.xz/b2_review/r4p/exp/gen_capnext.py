"""b2r4 principle: 段落 A（LESSON）の最後の 1 行（last1）か最後の 7 文字（k7）が、ページ・段の区切り（受付日の行・次のページの
柱）の後ろに出て、そのすぐ後ろに表のキャプション（表は docx でも A のすぐ後ろ）か、図の上のキャプションがある形（h2.py 用。
架空の文字）。A の最後の行は本当の段落の行なので、校正の直しは直すのが望ましい（_Joint.figure_edge_lines の (A) が、図の中の
行でない行に働かないか）。after: date_pb（受付日の行でページが変わる）・pbhead（次のページの最初に柱）・date_head（両方）・
col_date（同じページの、受付日の行の後ろ。段の区切り）・pb（ページが変わるだけ。対照）。"""
import sys
sys.path.insert(0, "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b2_review/r3p/exp")
import gen_tail as G  # noqa: E402


def pairs(T):
    base = T.LESSON[:-len("取った。")]
    for ek, (dt, pt) in G.EDITS.items():
        if ek == "none":
            yield ek, T.LESSON, T.LESSON
        elif ek == "delsent":
            yield ek, T.LESSON + "その結果を表に示す。", T.LESSON
        elif ek == "addsent":
            yield ek, T.LESSON, T.LESSON + "以上が第三時の流れである。"
        elif ek == "nostop":
            yield ek, base[:-len("時間を")] + "時間を取る", base[:-len("時間を")] + "場を設けた。"
        else:
            cut0 = len(T.LESSON) - len(dt)
            yield ek, T.LESSON[:cut0] + dt, T.LESSON[:cut0] + pt


def make_cases(T):
    out = []
    for ek, docx, pub in pairs(T):
        lines = T.body_lines(pub)
        for ck in ("last1", "k7"):
            first, second = (lines[:-1], lines[-1:]) if ck == "last1" else (T.body_lines(pub[:-7]), [pub[-7:]])
            for mk in ("tab", "figabove"):
                if mk == "tab":
                    blocks = [("body", docx), ("tab_cap", G.TCAP), ("table", G.CELLS)]
                    mid = [G.TCAP] + [" ".join(r) for r in G.CELLS]
                else:
                    blocks = [("body", docx), ("fig_cap", G.CAP), ("image", "fig")]
                    mid = [G.CAP] + G.FIGS["fig"]
                blocks += [("body", T.TALK), ("body", T.SURVEY)]
                for ak in ("date_pb", "pbhead", "date_head", "col_date", "pb"):
                    p1 = [*T.SMALL_FRONT, *first]
                    rest = [*second, *mid, *T.body_lines(T.TALK), *T.body_lines(T.SURVEY), *T.N10_TAIL]
                    pages = {"date_pb": [p1 + [G.DATE], rest], "pbhead": [p1, ["試験　六郎"] + rest],
                             "date_head": [p1 + [G.DATE], ["試験　六郎"] + rest], "col_date": [p1 + [G.DATE] + rest],
                             "pb": [p1, rest]}[ak]
                    out.append({"name": f"cn_{ek}_{ck}_{mk}_{ak}", "blocks": blocks, "pages": pages, "want": {docx: pub}})
    return out
