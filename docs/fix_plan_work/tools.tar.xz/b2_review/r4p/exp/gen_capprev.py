"""b2r4 principle: 段落 B（TALK）が図のキャプション（図の下）のすぐ後ろから始まり、B の最初の行（first1）か最初の 7 文字（k7）が
ページ・段の終わりにあって、受付日の行・次のページの柱の後ろに B の残りが続く形（h2.py 用。架空の文字）。B の最初の行は本当の
段落の行なので、校正の直しは直すのが望ましい（_Joint.figure_edge_lines の (A) の頭の側が、図の中の行でない行に働かないか）。"""
import sys
sys.path.insert(0, "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b2_review/r3p/exp")
import gen_tail as G  # noqa: E402

HEAD_EDITS = {
    "none": None,
    "w1": ("話し合いの中で", "議論の中で"),
    "w2": ("話し合いの中で，", "話し合いの中では，"),
    "c1": ("話し合いの", "話合いの"),
    "del": ("そこで，", ""),
    "add": ("", "その後，"),
    "punct": ("話し合いの中で，", "話し合いの中で、"),
}


def make_cases(T):
    out = []
    for ek, e in HEAD_EDITS.items():
        if e is None:
            docx = pub = T.TALK
        elif ek == "del":
            docx, pub = e[0] + T.TALK, T.TALK
        elif ek == "add":
            docx, pub = T.TALK, e[1] + T.TALK
        else:
            docx, pub = T.TALK, T.TALK.replace(e[0], e[1], 1)
        lines = T.body_lines(pub)
        for ck in ("first1", "k7"):
            first, second = (lines[:1], lines[1:]) if ck == "first1" else (["　" + pub[:7]], T.wrap_lines(pub[7:]))
            for mk in ("figbelow", "tabcells"):
                if mk == "figbelow":
                    blocks = [("body", T.LESSON), ("image", "fig"), ("fig_cap", G.CAP)]
                    mid = G.FIGS["fig"] + [G.CAP]
                else:
                    blocks = [("body", T.LESSON), ("tab_cap", G.TCAP), ("table", G.CELLS)]
                    mid = [G.TCAP] + [" ".join(r) for r in G.CELLS]
                blocks += [("body", docx), ("body", T.SURVEY)]
                for ak in ("date_pb", "pbhead", "date_head", "col_date", "pb"):
                    p1 = [*T.SMALL_FRONT, *T.body_lines(T.LESSON), *mid, *first]
                    rest = [*second, *T.body_lines(T.SURVEY), *T.N10_TAIL]
                    pages = {"date_pb": [p1 + [G.DATE], rest], "pbhead": [p1, ["試験　六郎"] + rest],
                             "date_head": [p1 + [G.DATE], ["試験　六郎"] + rest], "col_date": [p1 + [G.DATE] + rest],
                             "pb": [p1, rest]}[ak]
                    out.append({"name": f"cp_{ek}_{ck}_{mk}_{ak}", "blocks": blocks, "pages": pages, "want": {docx: pub}})
    return out
