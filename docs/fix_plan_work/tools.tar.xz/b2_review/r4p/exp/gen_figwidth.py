"""b2r4 principle: figure_edge_lines の (A)・(B) で doubt にした行（図の中の行）と並べた docx の文字の、全角・半角・大文字・小文字・
ダッシュの違いを、図の中の文字に合わせて直さないか（h2.py 用。架空の文字）。段落 A の最後は「…説明し合う時間を Ａ 班で取った。」
（全角の Ａ）で、出版版では最後の文「その結果を表に示す。」が消されている。PDF では、段落の最後の行が小さな図（キャプションは図の
下）の後ろに出て、図の中のキャプションのすぐ前の行が、段落の最後の行とよく似ていて、英数字の全角・半角（または大文字・小文字）
だけが違う（「時間をA班で見る」）。"""
import sys
sys.path.insert(0, "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b2_review/r3p/exp")
import gen_tail as G  # noqa: E402

CAP = "図１　架空の授業の流れ"
FIG = ["導入", "↓", "課題の提示", "↓"]
VARIANTS = {
    # 名前: (docx の最後の行の部分, 本文の最後の行, 図の中の行)
    "w1": ("時間をＡ班で取った。", "時間をＡ班で取った。", "時間をA班で見る"),
    "w2": ("時間を２回取った。", "時間を２回取った。", "時間を2回見る"),
    "c1": ("時間をA班で取った。", "時間をA班で取った。", "時間をa班で見る"),
    "w3": ("時間を3回取った。", "時間を3回取った。", "時間を３回見る"),
}


def make_cases(T):
    out = []
    base = T.LESSON[:-len("時間を取った。")]
    for vk, (dtail, ptail, figline) in VARIANTS.items():
        for ek in ("delsent", "none", "e4"):
            if ek == "delsent":
                docx, pub = base + dtail + "その結果を表に示す。", base + ptail
            elif ek == "none":
                docx, pub = base + dtail, base + ptail
            else:
                docx, pub = base + dtail, base + ptail.replace("取った", "持った")
            lines = T.body_lines(pub)
            k = len(ptail)
            first, second = T.body_lines(pub[:-k]), [pub[-k:]]
            for ak in ("direct", "date", "pbhead"):
                blocks = [("body", docx), ("image", "fig"), ("fig_cap", CAP), ("body", T.TALK), ("body", T.SURVEY)]
                p1 = [*T.SMALL_FRONT, *first, *FIG, figline, CAP, *second]
                rest = [*T.body_lines(T.TALK), *T.body_lines(T.SURVEY), *T.N10_TAIL]
                pages = [p1 + rest] if ak == "direct" else ([p1 + [G.DATE], rest] if ak == "date" else
                                                             [p1, ["試験　六郎"] + rest])
                out.append({"name": f"fw_{vk}_{ek}_{ak}", "blocks": blocks, "pages": pages, "want": {docx: pub}})
    return out
