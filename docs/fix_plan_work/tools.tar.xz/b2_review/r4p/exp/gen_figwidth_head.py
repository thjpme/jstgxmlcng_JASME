"""b2r4 principle: figure_edge_lines の (B)（頭の側）で doubt にした行（図の中の最初の行）と並べた docx の文字の全角・半角を、
図の中の文字に合わせて直さないか（h2.py 用。架空の文字）。段落 B は「第２時の話し合いの中で，…」（全角の ２）で、出版版では
「第２時の議論の中で，…」。PDF では、B の最初の 9 文字の行のすぐ後ろに小さな図（docx では B のすぐ前の画像とキャプション）があり、
図の中の最初の行「第2時の話し合い」（半角の 2）が docx の B の最初の文字とよく似ている。"""
import sys
sys.path.insert(0, "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b2_review/r3p/exp")
import gen_tail as G  # noqa: E402

CAP = "図１　架空の授業の流れ"


def make_cases(T):
    out = []
    docx_b = "第２時の" + T.TALK
    for ek in ("w1", "none"):
        pub_b = docx_b.replace("話し合いの中で", "議論の中で") if ek == "w1" else docx_b
        for k in (9, 7):
            for fk, figfirst in (("half", "第2時の話し合い"), ("same", "第２時の話し合い")):
                fig = [figfirst, "↓", "課題の提示", "↓", "まとめ"]
                blocks = [("body", T.LESSON), ("image", "fig"), ("fig_cap", CAP), ("body", docx_b), ("body", T.SURVEY)]
                for ak in ("date", "pbhead"):
                    first = [*T.SMALL_FRONT, *T.body_lines(T.LESSON)]
                    rest = ["　" + pub_b[:k], *fig, CAP, *T.wrap_lines(pub_b[k:]), *T.body_lines(T.SURVEY), *T.N10_TAIL]
                    pages = [first + [G.DATE], rest] if ak == "date" else [first, ["試験　六郎"] + rest]
                    out.append({"name": f"fh_{ek}_k{k}_{fk}_{ak}", "blocks": blocks, "pages": pages, "want": {docx_b: pub_b}})
    return out
