"""b2r3 principle: 生成した反例（照合の段階だけ）を、指定した src のコードで動かし、段落ごとに判定して JSON に書く。
  python -I h2.py SRC GENFILE OUT.json [--only 名前の前置き]
GENFILE は make_cases(T) -> [{"name", "blocks", "pages", "want"}] を定義する（blocks・pages は tests/test_pdfmatch.py の
n10_article・n10_pages の引数。want: {docx の段落の文字: 出版版の文字}）。判定は oracle/runner.py の describe と同じ考え:
  OK（出版版と同じ）/ REP（足し・消しなし、13 章に出ている）/ SILENT（足し・消しなし、13 章に出ていない）/ FAIL（足した・消した）"""
import difflib
import importlib.util
import json
import sys
import tempfile
from pathlib import Path

src, gen, out = sys.argv[1], sys.argv[2], sys.argv[3]
only = sys.argv[sys.argv.index("--only") + 1] if "--only" in sys.argv else ""
sys.path.insert(0, src)
sys.path.insert(1, "/home/user/jstgxmlcng_JASME/tests")
import jasme_jats  # noqa: E402
spec = importlib.util.spec_from_file_location("tp", "/home/user/jstgxmlcng_JASME/tests/test_pdfmatch.py")
T = importlib.util.module_from_spec(spec)
spec.loader.exec_module(T)
from jasme_jats.config import JournalConfig  # noqa: E402
from jasme_jats.pdfdocx import plan_fixes  # noqa: E402
T.JOURNAL = JournalConfig.load()
sys.path.insert(2, str(Path(gen).resolve().parent))
spec2 = importlib.util.spec_from_file_location("gen", gen)
G = importlib.util.module_from_spec(spec2)
spec2.loader.exec_module(G)


def matched(a, b):
    ma, mb = set(), set()
    for i, j, n in difflib.SequenceMatcher(None, a, b, autojunk=False).get_matching_blocks():
        ma.update(range(i, i + n))
        mb.update(range(j, j + n))
    return ma, mb


def runs(pos, text):
    o, cur, last = [], "", None
    for k in sorted(pos):
        if last is not None and k != last + 1:
            o.append(cur)
            cur = ""
        cur += text[k]
        last = k
    return o + ([cur] if cur else [])


def describe(orig, fixed, truth):
    f_in_t, t_in_f = matched(fixed, truth)
    o_in_f, f_from_o = matched(orig, fixed)
    o_in_t, t_from_o = matched(orig, truth)
    extra = set(range(len(fixed))) - f_in_t
    missing = set(range(len(truth))) - t_in_f
    added = {k for k in extra if k not in f_from_o}
    deleted = {k for k in missing if k in t_from_o}
    return runs(added, fixed), runs(deleted, truth)


res = {"src": jasme_jats.__file__, "version": jasme_jats.__version__, "cases": {}}
for c in G.make_cases(T):
    if only and not c["name"].startswith(only):
        continue
    with tempfile.TemporaryDirectory() as td:
        try:
            plan, srcmap = T.n10_article(Path(td), T.JOURNAL, c["blocks"])
            pc = T.compare(plan, c["raw_pages"] if "raw_pages" in c else T.n10_pages(*c["pages"]))
            fx = plan_fixes(plan, pc)
        except Exception as e:  # noqa: BLE001
            import traceback
            res["cases"][c["name"]] = {"verdict": "ERROR", "error": traceback.format_exc()[-400:]}
            continue
    got = {s: T.expected_text(p.plain(), [f for f in fx if f.src == s and not f.reason]) for s, p in plan.paras.items()}
    paras, worst = {}, "OK"
    rank = {"OK": 0, "REP": 1, "SILENT": 2, "FAIL": 3}
    for p in plan.paras.values():
        docx = p.plain()
        truth = c["want"].get(docx, docx)
        g = got[p.src]
        if g == truth:
            if docx != truth:
                paras[p.src] = {"v": "OK"}
            continue
        added, deleted = describe(docx, g, truth)
        # 足りない・余分の文字（docx のまま残った文字・足していない文字）
        f_in_t, t_in_f = matched(g, truth)
        segs = runs(set(range(len(g))) - f_in_t, g) + runs(set(range(len(truth))) - t_in_f, truth)
        segs = [x.replace(" ", "") for x in segs if x.strip()]
        ign = [str(t).replace(" ", "").replace("\u3000", "") for s2, t in pc.ignored_lines if s2 == p.src]
        reported = any(d.src == p.src and (not d.fixable or d.why) for d in pc.diffs) or p.src in pc.unmatched or \
            any(f.src == p.src and f.reason for f in fx) or any(x in t or t in x for x in segs for t in ign if t)
        v = "FAIL" if (added or deleted) else ("REP" if reported else "SILENT")
        paras[p.src] = {"v": v, "added": added, "deleted": deleted, "fixed": g, "truth": truth, "docx": docx,
                        "diffs": [(d.docx, d.pdf, d.fixable, (d.why or "")[:10]) for d in pc.diffs if d.src == p.src]}
        if rank[v] > rank[worst]:
            worst = v
    res["cases"][c["name"]] = {"verdict": worst, "paras": paras}
Path(out).write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
cnt = {}
for v in res["cases"].values():
    cnt[v["verdict"]] = cnt.get(v["verdict"], 0) + 1
print(jasme_jats.__file__, cnt)
