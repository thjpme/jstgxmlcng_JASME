"""b2r4_regress: figure_edge_lines の (B) が、本当の段落の最後の行に当たるか（h2.py 用。架空の文字）。
段落が小さな図（図の中の文字とキャプション）で分断され、段落の最後の 1 行だけが図の後ろ（ページの最後）に出て、その行の最初の語が
校正で直されている。次のページの最初の行は柱で、柱に、直される前の docx の語の文字が含まれる。"""
CAP = "図１　架空の授業の流れ"
FIG = ["導入", "↓", "課題の提示", "↓", "まとめ"]
HEADS = {"kenkyu": "数学教育学研究　第31巻", "plain": "試験　六郎"}
BODY = ("授業の前に行った事前の調査では，表を横に見て増え方を答えられた生徒は学級の半数ほどであった。一方で，表を縦に"
        "見て二つの量の対応を答えられた生徒は一割に満たなかった。")[:71]     # 字下げを入れて 3 行ちょうど（24 文字 × 3）


def make_cases(T):
    out = []
    lines0 = T.body_lines(BODY)
    for ek, (dw, pw) in {"kenkyu": ("研究", "調査"), "kyoiku": ("教育", "指導"), "none": ("", "")}.items():
        tail = "の結果を表にまとめて，次の時間に示した。"
        docx = BODY + (dw or "調査") + tail
        pub = BODY + (pw or "調査") + tail
        lines = T.body_lines(pub)
        cut = len(lines0)       # 最後の段落の行（pw から始まる行）の前で分断する
        assert lines[cut].startswith(pw or "調査"), lines
        for hk, head in HEADS.items():
            p1 = [*T.SMALL_FRONT, *lines[:cut], *FIG, CAP, *lines[cut:]]
            p2 = [head, *T.body_lines(T.TALK), *T.N10_TAIL]
            out.append({"name": f"bfp_{ek}_{hk}", "blocks": [("body", docx), ("image", "fig"), ("fig_cap", CAP), ("body", T.TALK)],
                        "pages": [p1, p2], "want": {docx: pub}})
    return out
