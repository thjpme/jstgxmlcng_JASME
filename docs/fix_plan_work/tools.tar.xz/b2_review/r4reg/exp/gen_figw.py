"""b2r4_regress: test_figure_line_before_caption_is_not_used_as_last_line の形（消された最後の文、小さな図の後ろの本当の最後の行、
図の中のキャプションの前の行が最後の行とよく似ている）で、図の中の行と並んだ部分に全角・半角だけが違う文字がある形（h2.py 用。
架空の文字）。図の中の行（figure_edge_lines で doubt にした行）の全角・半角の違いを、本文に当てはめないか。"""
CAP = "図１　架空の授業の流れ"
STEPS = ["導入", "↓", "課題の提示", "↓"]
DATE = "2025年８月31日投稿受付，2025年11月24日採用決定"
VARS = {   # 名前: (本当の最後の行〈docx・出版版〉, 図の中のキャプションの前の行)
    "w3": ("時間を3回取った。", "時間を３回見る"),
    "w3b": ("時間を３回取った。", "時間を3回見る"),
    "wp": ("時間(5分)を取った。", "時間（5分）を見る"),
    "wpb": ("時間（5分）を取った。", "時間(5分)を見る"),
}


def make_cases(T):
    out = []
    stem = T.LESSON[:-len("時間を取った。")]
    for vk, (last, figlast) in VARS.items():
        pub = stem + last
        docx = pub + "その結果を表に示す。"
        for ak in ("date", "pbhead", "direct"):
            head = [*T.SMALL_FRONT, *T.body_lines(stem), *STEPS, figlast, CAP, last]
            rest = [*T.body_lines(T.TALK), *T.N10_TAIL]
            pages = {"date": [head + [DATE], rest], "pbhead": [head, ["試験　六郎", *rest]], "direct": [head + rest]}[ak]
            out.append({"name": f"fw_{vk}_{ak}", "blocks": [("body", docx), ("image", "fig"), ("fig_cap", CAP), ("body", T.TALK)],
                        "pages": pages, "want": {docx: pub}})
    return out
