"""b2r4_regress: test_figure_line_after_first_line_is_not_used_as_first_line の形（段落の最初の語句が校正で書き換えられ、本当の
最初の行のすぐ後ろの小さな図の中の最初の行が、docx の段落の最初の文字とよく似ている。figure_edge_lines の (B)）で、図の中の
行と並ぶ部分に全角・半角だけが違う文字がある形と、ない形（対照）。h2.py 用。架空の文字。"""
CAP = "図１　架空の授業の流れ"
STEPS = ["課題の提示", "↓", "まとめ"]
DATE = "2025年８月31日投稿受付，2025年11月24日採用決定"
VARS = {   # 名前: (docx の最初, 出版版の最初, 図の中の最初の行)
    "w1": ("第1の話し合いの中で", "第1の議論の中で", "第１の話し合いの場面"),
    "w1b": ("第１の話し合いの中で", "第１の議論の中で", "第1の話し合いの場面"),
    "same": ("第1の話し合いの中で", "第1の議論の中で", "第1の話し合いの場面"),
}


def make_cases(T):
    out = []
    rest_talk = T.TALK[len("話し合いの中で"):]
    for vk, (d0, p0, figfirst) in VARS.items():
        docx, pub = d0 + rest_talk, p0 + rest_talk
        k = pub.index("，") + 1
        for bk in ("date", "pbhead"):
            rest = ["　" + pub[:k], figfirst, *STEPS, CAP, *T.wrap_lines(pub[k:]), *T.body_lines(T.SURVEY), *T.N10_TAIL]
            first = [*T.SMALL_FRONT, *T.body_lines(T.LESSON)]
            pages = [first + [DATE], rest] if bk == "date" else [first, ["試験　六郎", *rest]]
            out.append({"name": f"fh_{vk}_{bk}", "blocks": [("body", T.LESSON), ("image", "fig"), ("fig_cap", CAP), ("body", docx),
                                                             ("body", T.SURVEY)],
                        "pages": pages, "want": {docx: pub}})
    return out
