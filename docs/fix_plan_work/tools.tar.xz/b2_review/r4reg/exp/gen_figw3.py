"""b2r4_regress: test_copy_of_deleted_sentence_in_figure_is_not_used の形（docx の段落の最後の文が校正で消され、段落のすぐ後ろの
図の中の文字にその文の写しがある。recheck_runs の doubt）で、写しと docx の文に全角・半角だけが違う文字がある形と、ない形
（対照）。h2.py 用。架空の文字。"""
CAP = "図１　架空の授業の流れ"
VARS = {
    "w": ("以上が第3時の流れである。", "以上が第３時の流れである．"),
    "wb": ("以上が第３時の流れである。", "以上が第3時の流れである．"),
    "same": ("以上が第三時の流れである。", "以上が第三時の流れである．"),
}


def make_cases(T):
    out = []
    for vk, (add, copy) in VARS.items():
        fig = ["導入", "↓", "前時の表を振り返る", "↓", "課題の提示", "↓", "水を入れる時間と深さ", copy,
               "個人で考える", "↓", "表に矢印をかき込む", "↓", "学級で話し合う", CAP]
        docx = T.LESSON + add
        out.append({"name": f"fc_{vk}", "blocks": [("body", docx), ("image", ""), ("fig_cap", CAP), ("body", T.TALK)],
                    "pages": [[*T.SMALL_FRONT, *T.body_lines(T.LESSON), *fig, *T.body_lines(T.TALK), *T.N10_TAIL]],
                    "want": {docx: T.LESSON}})
    return out
