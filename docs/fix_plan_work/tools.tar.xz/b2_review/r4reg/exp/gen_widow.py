"""b2r4_regress: 段落の最後の行だけが次のページ（受付日の行・ページ番号・柱の後ろ）に出て、そのすぐ後ろに表のキャプション・
図のキャプション（画像は文字なし）がある形（tail）と、段落の最初の行だけが前のページの最後に出て、そのすぐ前にキャプション・
表のセルがある形（head）。その行に本当の校正の直しがある。h2.py 用。架空の文字（tests/test_pdfmatch.py の LESSON・TALK・SURVEY）。"""
CAP = "図１　架空の授業の流れ"
TCAP = "表１　記述の数"
CELLS = [["Ａ組", "12", "7"], ["Ｂ組", "19", "16"]]
FIG = ["導入", "↓", "課題の提示", "↓", "まとめ"]
DATE = "2025年８月31日投稿受付，2025年11月24日採用決定"

TAIL_EDITS = {      # LESSON の最後の行（「で説明し合う時間を取った。」）の直し
    "e4": ("時間を取った。", "時間を持った。"),
    "emid": ("で説明し合う時間", "で話し合う時間"),
    "eadd": ("時間を取った。", "時間を十分に取った。"),
    "ewidth": ("時間を取った。", "時間を取った．"),
    "none": ("", ""),
}
HEAD_EDITS = {      # TALK の最初の行（「話し合いの中で，ある生徒は時間が３倍になると深」）の直し
    "h1": ("話し合いの中で", "議論の中で"),
    "h2": ("ある生徒は", "一人の生徒は"),
    "h3": ("時間が３倍", "時間が3倍"),
    "none": ("", ""),
}


def tail_cases(T):
    out = []
    for ek, (dt, pt) in TAIL_EDITS.items():
        docx = T.LESSON
        pub = T.LESSON.replace(dt, pt, 1) if dt else T.LESSON
        lines = T.body_lines(pub)
        for mk in ("tabcap", "imgcap", "figtext", "none"):
            blocks = [("body", docx)]
            if mk == "tabcap":
                blocks += [("tab_cap", TCAP), ("table", CELLS)]
                mid = [TCAP] + [" ".join(r) for r in CELLS]
            elif mk == "imgcap":
                blocks += [("image", "fig"), ("fig_cap", CAP)]
                mid = [CAP]
            elif mk == "figtext":
                blocks += [("image", "fig"), ("fig_cap", CAP)]
                mid = FIG + [CAP]
            else:
                mid = []
            blocks += [("body", T.TALK), ("body", T.SURVEY)]
            rest = [*T.body_lines(T.TALK), *T.body_lines(T.SURVEY), *T.N10_TAIL]
            for bk in ("date", "pb", "pbhead", "direct"):
                p1 = [*T.SMALL_FRONT, *lines[:-1]]
                p2 = [lines[-1], *mid, *rest]
                if bk == "date":
                    pages = [p1 + [DATE], p2]
                elif bk == "pb":
                    pages = [p1, p2]
                elif bk == "pbhead":
                    pages = [p1, ["試験　六郎"] + p2]
                else:
                    pages = [p1 + p2]
                out.append({"name": f"wt_{ek}_{mk}_{bk}", "blocks": blocks, "pages": pages, "want": {docx: pub}})
    return out


def head_cases(T):
    out = []
    for ek, (dt, pt) in HEAD_EDITS.items():
        docx = T.TALK
        pub = T.TALK.replace(dt, pt, 1) if dt else T.TALK
        lines = T.body_lines(pub)
        for mk in ("figcap", "figtext", "tab", "none"):
            blocks = [("body", T.LESSON)]
            if mk == "figcap":
                blocks += [("image", "fig"), ("fig_cap", CAP)]
                mid = [CAP]
            elif mk == "figtext":
                blocks += [("image", "fig"), ("fig_cap", CAP)]
                mid = FIG + [CAP]
            elif mk == "tab":
                blocks += [("tab_cap", TCAP), ("table", CELLS)]
                mid = [TCAP] + [" ".join(r) for r in CELLS]
            else:
                mid = []
            blocks += [("body", docx), ("body", T.SURVEY)]
            for bk in ("date", "pb", "pbhead", "direct"):
                p1 = [*T.SMALL_FRONT, *T.body_lines(T.LESSON), *mid, lines[0]]
                p2 = [*lines[1:], *T.body_lines(T.SURVEY), *T.N10_TAIL]
                if bk == "date":
                    pages = [p1 + [DATE], p2]
                elif bk == "pb":
                    pages = [p1, p2]
                elif bk == "pbhead":
                    pages = [p1, ["試験　六郎"] + p2]
                else:
                    pages = [p1 + p2]
                out.append({"name": f"wh_{ek}_{mk}_{bk}", "blocks": blocks, "pages": pages, "want": {docx: pub}})
    return out


def make_cases(T):
    return tail_cases(T) + head_cases(T)
