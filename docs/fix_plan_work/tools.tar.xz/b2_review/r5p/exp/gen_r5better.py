"""b2r5 principle: 4 回目の修正の _Joint.better_line の誤り（h2.py 用。架空の文字）。
尾の側: 段落 A（LESSON）の最後の行（本当の段落の行）が校正で大きく書き換えられ、そのすぐ後ろに図の上のキャプションがあり、その下の
図の中の行に、docx の A の最後の語句とよく似た行（図の中の手順「説明し合う時間を取る」など）がある。A の最後の行は前の行の
すぐ後ろ（間の行がない）か、1 ページ目の最後の受付日の行・次のページの柱の後ろ。
頭の側: 段落 B（TALK）の最初の行が校正で大きく書き換えられ、そのすぐ前に図のキャプション（図の下）があり、その上の図の中の行に、
docx の B の最初の語句とよく似た行がある。どちらも、本当の段落の行の直しは出版版の文字に直すのが望ましい。"""
CAP = "図１　架空の授業の流れ"
DATE = "2025年８月31日投稿受付，2025年11月24日採用決定"
TAIL = {   # docx の最後の行の文字 -> 出版版
    "t1": ("で説明し合う時間を取った。", "で議論する場を設けた。"),
    "t2": ("で説明し合う時間を取った。", "で互いに考えを述べ合った。"),
    "t3": ("で説明し合う時間を取った。", "で説明し合う場を設けた。"),
}
TFIG = {"sim": "説明し合う時間を取る", "copy": "で説明し合う時間", "far": "まとめ"}
HEAD = {
    "h1": ("話し合いの中で，ある生徒は", "議論の場で，一人の生徒が"),
    "h2": ("話し合いの中で，ある生徒は", "話し合いでは，ある生徒は"),
}
HFIG = {"sim": "話し合いの中で考える", "copy": "話し合いの中で，ある", "far": "導入"}
BREAKS = ("direct", "date_pb", "pbhead", "col_date")


def make_cases(T):
    out = []
    for ek, (d, p) in TAIL.items():
        docx, pub = T.LESSON, T.LESSON.replace(d, p)
        lines = T.body_lines(pub)
        for fk, fl in TFIG.items():
            blocks = [("body", docx), ("fig_cap", CAP), ("image", "fig"), ("body", T.TALK), ("body", T.SURVEY)]
            mid = [CAP, "導入", "↓", fl, "↓", "まとめ"]
            for bk in BREAKS:
                p1 = [*T.SMALL_FRONT, *lines[:-1]]
                rest = [lines[-1], *mid, *T.body_lines(T.TALK), *T.body_lines(T.SURVEY), *T.N10_TAIL]
                pages = {"direct": [p1 + rest], "date_pb": [p1 + [DATE], rest], "pbhead": [p1, ["試験　六郎"] + rest],
                         "col_date": [p1 + [DATE] + rest]}[bk]
                out.append({"name": f"bl_{ek}_{fk}_{bk}", "blocks": blocks, "pages": pages, "want": {docx: pub}})
    for ek, (d, p) in HEAD.items():
        docx, pub = T.TALK, T.TALK.replace(d, p, 1)
        lines = T.body_lines(pub)
        for fk, fl in HFIG.items():
            blocks = [("body", T.LESSON), ("image", "fig"), ("fig_cap", CAP), ("body", docx), ("body", T.SURVEY)]
            mid = ["導入", "↓", fl, "↓", "まとめ", CAP]
            for bk in BREAKS:
                p1 = [*T.SMALL_FRONT, *T.body_lines(T.LESSON), *mid, lines[0]]
                rest = [*lines[1:], *T.body_lines(T.SURVEY), *T.N10_TAIL]
                pages = {"direct": [p1 + rest], "date_pb": [p1 + [DATE], rest], "pbhead": [p1, ["試験　六郎"] + rest],
                         "col_date": [p1 + [DATE] + rest]}[bk]
                out.append({"name": f"bh_{ek}_{fk}_{bk}", "blocks": blocks, "pages": pages, "want": {docx: pub}})
    return out
