"""b2r5 principle: 段落 A（LESSON）の最後の文が校正で消され、PDF では A の本当の最後の行がページ（段）の最後にあり、次のページの
最初（柱の後ろ）か受付日の行の後ろに、小さな図（1〜2 行。キャプションは図の下）がある。図の中の行が、消された文の一部と同じ
文字（写し）を含む。まとめての照合はその行を A の最後の行と並べうるが、間は柱・受付日の行だけ（ページの最初の端の行）なので、
4 回目の修正の _Joint.figure_edge_lines の (A) は facing_hole か better_line のときだけ働く（h2.py 用。架空の文字）。
期待: A は消された文を消す（出版版の文字）か、決められなければ docx のまま 13 章に出す（docx にも PDF にもない文字にしない）。"""
CAP = "図１　架空の授業の流れ"
DATE = "2025年８月31日投稿受付，2025年11月24日採用決定"
# 消された文と、図の中の行（写し・よく似た行）
DELS = {
    "mid": ("次に，課題の提示を行った。", ["課題の提示"]),
    "head": ("課題の提示を行った。", ["課題の提示"]),
    "head2": ("課題の提示を行った。", ["導入", "課題の提示"]),
    "tail": ("その後，表にまとめた。", ["表にまとめた"]),
    "far": ("その結果を表に示す。", ["まとめ"]),
}
BREAKS = ("pb", "pbhead", "datepb", "datehead", "col")


def pages_for(p1, p2, bk):
    return {"pb": [p1, p2], "pbhead": [p1, ["試験　六郎", *p2]], "datepb": [p1 + [DATE], p2],
            "datehead": [p1 + [DATE], ["試験　六郎", *p2]], "col": [p1 + [DATE] + p2]}[bk]


def make_cases(T):
    out = []
    for dk, (dele, fig) in DELS.items():
        docx, pub = T.LESSON + dele, T.LESSON
        for mk in ("figbelow", "tabbelow"):
            if mk == "figbelow":
                blocks = [("body", docx), ("image", "fig"), ("fig_cap", CAP), ("body", T.TALK), ("body", T.SURVEY)]
                mid = [*fig, CAP]
            else:          # 図ではなく、表のセルの行（docx の表のセルの文字は 4 文字未満なので照合しない）
                blocks = [("body", docx), ("table", [[x] for x in fig]), ("tab_cap", "表１　記述の数"), ("body", T.TALK),
                          ("body", T.SURVEY)]
                mid = [*fig, "表１　記述の数"]
            for bk in BREAKS:
                p1 = [*T.SMALL_FRONT, *T.body_lines(pub)]
                p2 = [*mid, *T.body_lines(T.TALK), *T.body_lines(T.SURVEY), *T.N10_TAIL]
                out.append({"name": f"ct_{dk}_{mk}_{bk}", "blocks": blocks, "pages": pages_for(p1, p2, bk),
                            "want": {docx: pub}})
    return out
