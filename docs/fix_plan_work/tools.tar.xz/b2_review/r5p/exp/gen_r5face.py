"""b2r5 principle: 4 回目の修正の _Joint.facing_hole の誤り（h2.py 用。架空の文字）。
段落 A（LESSON）の最後の 1 行（本当の段落の行。校正の直しあり）が、1 ページ目の最後の投稿受付日の行の後ろ（次のページの最初・
同じページの次の段の最初・次のページの柱の後ろ）に出て、そのすぐ後ろに表のキャプション（表は docx でも A のすぐ後ろ）か図の上の
キャプションがある（w_capnext の形）。そのうえで、表・図の後ろの段落 B（TALK）の書き出しが校正で直されている（B の最初の docx の
文字が塊に入らない）。A の最後の行の直しも、B の書き出しの直しも、出版版の文字に直すのが望ましい。"""
TCAP = "表１　記述の数"
CELLS = [["Ａ組", "12", "7"], ["Ｂ組", "19", "16"]]
CAP = "図１　架空の授業の流れ"
FIG = ["導入", "↓", "課題の提示", "↓", "まとめ"]
DATE = "2025年８月31日投稿受付，2025年11月24日採用決定"
A_EDITS = {"e4": ("時間を取った", "時間を持った"), "none": None}
B_EDITS = {"none": None, "w1": ("話し合いの中で", "議論の中で"), "c1": ("話し合いの", "話合いの"),
           "add": ("", "その後，"), "del": ("そこで，", "")}
BREAKS = ("date_pb", "pbhead", "date_head", "col_date")


def make_cases(T):
    out = []
    for ak, ae in A_EDITS.items():
        a_docx = T.LESSON
        a_pub = T.LESSON if ae is None else T.LESSON.replace(*ae)
        for bk_, be in B_EDITS.items():
            if be is None:
                b_docx = b_pub = T.TALK
            elif be[0] == "":
                b_docx, b_pub = T.TALK, be[1] + T.TALK
            elif be[1] == "":
                b_docx, b_pub = be[0] + T.TALK, T.TALK
            else:
                b_docx, b_pub = T.TALK, T.TALK.replace(*be, 1)
            for mk in ("tab", "figabove"):
                if mk == "tab":
                    blocks = [("body", a_docx), ("tab_cap", TCAP), ("table", CELLS)]
                    mid = [TCAP] + [" ".join(r) for r in CELLS]
                else:
                    blocks = [("body", a_docx), ("fig_cap", CAP), ("image", "fig")]
                    mid = [CAP] + FIG
                blocks += [("body", b_docx), ("body", T.SURVEY)]
                lines = T.body_lines(a_pub)
                for bk in BREAKS:
                    p1 = [*T.SMALL_FRONT, *lines[:-1]]
                    rest = [lines[-1], *mid, *T.body_lines(b_pub), *T.body_lines(T.SURVEY), *T.N10_TAIL]
                    pages = {"date_pb": [p1 + [DATE], rest], "pbhead": [p1, ["試験　六郎"] + rest],
                             "date_head": [p1 + [DATE], ["試験　六郎"] + rest], "col_date": [p1 + [DATE] + rest]}[bk]
                    out.append({"name": f"fc_{ak}_{bk_}_{mk}_{bk}", "blocks": blocks, "pages": pages,
                                "want": {a_docx: a_pub, b_docx: b_pub}})
    return out
