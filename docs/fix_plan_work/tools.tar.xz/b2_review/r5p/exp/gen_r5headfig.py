"""b2r5 principle: 段落 B（TALK）のすぐ前に図（docx では画像。キャプションは図の下）があり、PDF では図の中の文字・キャプション・B の
順に並ぶ（ふつうの組み方）。図の中のある行が、B の docx の書き出しとよく似ているか同じ（図の中の手順「話し合いの中で考える」・
写し「話し合いの中で，ある」）。B の書き出しが校正で直されている。図の中の文字を B に足さないか、B の文字を図の中の行と並べて
残さないか（h2.py 用。架空の文字）。期待: B は出版版の文字に直すか、決められなければ docx のまま 13 章に出す。"""
CAP = "図１　架空の授業の流れ"
CAP_LONG = "図１　第三時の授業の流れと話し合いの場面"
DATE = "2025年８月31日投稿受付，2025年11月24日採用決定"
EDITS = {
    "none": None,
    "w1": ("話し合いの中で", "議論の中で"),
    "w2": ("話し合いの中で，", "話し合いでは，"),
    "c1": ("話し合いの", "話合いの"),
    "heavy": ("話し合いの中で，ある生徒は", "議論の場で，一人の生徒が"),
    "add": ("", "その後，"),
    "del": ("そこで，", ""),
}
FIGLINES = {
    "step": ["導入", "↓", "話し合いの中で考える", "↓", "まとめ"],      # よく似た手順の行（間に短い行）
    "step2": ["導入", "話し合いの中で考える", "まとめ"],               # 短い行は端だけ
    "copy": ["導入", "↓", "話し合いの中で，ある", "↓", "まとめ"],      # 写し
    "copylong": ["導入", "↓", "話し合いの中で，ある生徒は", "↓", "まとめ"],
    "far": ["導入", "↓", "課題の提示", "↓", "まとめ"],                  # 対照
}
BREAKS = ("direct", "pb", "pbhead", "date")


def make_cases(T):
    out = []
    for ek, e in EDITS.items():
        if e is None:
            docx = pub = T.TALK
        elif e[0] == "":
            docx, pub = T.TALK, e[1] + T.TALK
        elif e[1] == "":
            docx, pub = e[0] + T.TALK, T.TALK
        else:
            docx, pub = T.TALK, T.TALK.replace(*e, 1)
        for fk, fl in FIGLINES.items():
            for ck, cap in (("cap", CAP), ("caplong", CAP_LONG)):
                if ck == "caplong" and fk not in ("copy", "step"):
                    continue
                blocks = [("body", T.LESSON), ("image", "fig"), ("fig_cap", cap), ("body", docx), ("body", T.SURVEY)]
                for bk in BREAKS:
                    a = [*T.SMALL_FRONT, *T.body_lines(T.LESSON)]
                    b = [*fl, cap, *T.body_lines(pub), *T.body_lines(T.SURVEY), *T.N10_TAIL]
                    pages = {"direct": [a + b], "pb": [a, b], "pbhead": [a, ["試験　六郎", *b]], "date": [a + [DATE], b]}[bk]
                    out.append({"name": f"hf_{ek}_{fk}_{ck}_{bk}", "blocks": blocks, "pages": pages, "want": {docx: pub}})
    return out
