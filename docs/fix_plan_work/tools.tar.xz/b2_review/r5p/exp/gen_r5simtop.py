"""b2r5 principle: gen_r5copytop の形で、次のページの最初（柱の後ろ）か受付日の行の後ろの小さな図（1〜2 行。キャプションは図の
下）の中の行が、校正で消された A の最後の文の書き出しとよく似ているが同じではない（「課題の提示を行った。」と図の中の「課題の
把握」）。図の中の文字（「把握」）を足さないか（h2.py 用。架空の文字）。"""
CAP = "図１　架空の授業の流れ"
TCAP = "表１　記述の数"
DATE = "2025年８月31日投稿受付，2025年11月24日採用決定"
DELS = {
    "s1": ("課題の提示を行った。", ["課題の把握"]),
    "s2": ("課題の提示を行った。", ["導入", "課題の把握"]),
    "s3": ("課題の提示を行った。", ["課題の把握と見通し"]),
    "s4": ("次に，課題の提示を行った。", ["課題の把握"]),
    "s5": ("その後，表にまとめた。", ["表にまとめる"]),
    "s6": ("その後，表にまとめた。", ["表に書く"]),
    "s7": ("その結果を表に示す。", ["その結果の表"]),
}
BREAKS = ("pb", "pbhead", "datepb", "datehead", "col")


def pages_for(p1, p2, bk):
    return {"pb": [p1, p2], "pbhead": [p1, ["試験　六郎", *p2]], "datepb": [p1 + [DATE], p2],
            "datehead": [p1 + [DATE], ["試験　六郎", *p2]], "col": [p1 + [DATE] + p2]}[bk]


def make_cases(T):
    out = []
    for dk, (dele, fig) in DELS.items():
        docx, pub = T.LESSON + dele, T.LESSON
        for mk in ("figbelow", "tabbelow"):
            if mk == "figbelow":
                blocks = [("body", docx), ("image", "fig"), ("fig_cap", CAP), ("body", T.TALK), ("body", T.SURVEY)]
                mid = [*fig, CAP]
            else:
                blocks = [("body", docx), ("table", [[x] for x in fig]), ("tab_cap", TCAP), ("body", T.TALK),
                          ("body", T.SURVEY)]
                mid = [*fig, TCAP]
            for bk in BREAKS:
                p1 = [*T.SMALL_FRONT, *T.body_lines(pub)]
                p2 = [*mid, *T.body_lines(T.TALK), *T.body_lines(T.SURVEY), *T.N10_TAIL]
                out.append({"name": f"st_{dk}_{mk}_{bk}", "blocks": blocks, "pages": pages_for(p1, p2, bk),
                            "want": {docx: pub}})
    return out
