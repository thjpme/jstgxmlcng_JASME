"""b2r5 principle: 段落 A（LESSON）の最後の文が校正で消され、PDF では A のすぐ後ろ（同じページ・次のページの最初・柱の後ろ・
受付日の行の後ろ）に表（docx でも A のすぐ後ろ。キャプションは表の下か上）があり、表の最初の行（見出しのセル）が、消された文の
書き出しと同じ文字で始まる（「記述の数を表に示す。」と見出しの行「記述の数　人数」）。表のセルの文字を A に足さないか（h2.py 用。
架空の文字）。期待: A は消された文を消すか、決められなければ docx のまま 13 章に出す。表のセルの段落（4 文字以上）は変えない。"""
TCAP = "表１　記述の数"
DATE = "2025年８月31日投稿受付，2025年11月24日採用決定"
# 消された文と、表の行（セル）
VARS = {
    "hdr": ("記述の数を表に示す。", [["記述の数", "人数"], ["Ａ組", "12"], ["Ｂ組", "19"]]),
    "hdr2": ("記述の数を表に示す。", [["記述の種類", "人数"], ["Ａ組", "12"], ["Ｂ組", "19"]]),
    "row": ("課題の提示を行った。", [["課題の把握", "12"], ["まとめ", "19"]]),
    "row1": ("課題の提示を行った。", [["課題の把握"]]),
    "long": ("その結果を表に示す。", [["その結果の分類", "人数"], ["Ａ組", "12"]]),
}
BREAKS = ("direct", "pb", "pbhead", "datepb", "datehead", "col")


def pages_for(p1, p2, bk):
    return {"direct": [p1 + p2], "pb": [p1, p2], "pbhead": [p1, ["試験　六郎", *p2]], "datepb": [p1 + [DATE], p2],
            "datehead": [p1 + [DATE], ["試験　六郎", *p2]], "col": [p1 + [DATE] + p2]}[bk]


def make_cases(T):
    out = []
    for vk, (dele, rows) in VARS.items():
        docx, pub = T.LESSON + dele, T.LESSON
        for ck in ("capbelow", "capabove"):
            if ck == "capbelow":
                blocks = [("body", docx), ("table", rows), ("tab_cap", TCAP), ("body", T.TALK), ("body", T.SURVEY)]
                mid = [" ".join(r) for r in rows] + [TCAP]
            else:
                blocks = [("body", docx), ("tab_cap", TCAP), ("table", rows), ("body", T.TALK), ("body", T.SURVEY)]
                mid = [TCAP] + [" ".join(r) for r in rows]
            for bk in BREAKS:
                p1 = [*T.SMALL_FRONT, *T.body_lines(pub)]
                p2 = [*mid, *T.body_lines(T.TALK), *T.body_lines(T.SURVEY), *T.N10_TAIL]
                out.append({"name": f"th_{vk}_{ck}_{bk}", "blocks": blocks, "pages": pages_for(p1, p2, bk),
                            "want": {docx: pub}})
    return out
