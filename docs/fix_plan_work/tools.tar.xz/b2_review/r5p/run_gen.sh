#!/bin/sh
# b2_review/r5p（5 回目の原則の点検。4 回目の修正の後）: 生成例を SRC のコードで h2.py で動かす（順に）。
#   sh run_gen.sh SRC TAG gen...   gen は名前（r3p・r4p・r4reg・fixB2r4/exp・r5p/exp の gen_<名前>.py）
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
R=$S/b2_review/r5p
SRC=$1; TAG=$2; shift 2
cd /tmp
for g in "$@"; do
  X=""
  for d in $R/exp $S/fixB2r4/exp $S/b2_review/r4reg/exp $S/b2_review/r4p/exp $S/b2_review/r3p/exp; do
    if [ -f $d/gen_$g.py ]; then X=$d; break; fi
  done
  [ -z "$X" ] && { echo "no gen $g"; continue; }
  python -I $S/b2_review/r4p/h2.py $SRC $X/gen_$g.py $R/exp/fz_${g}_$TAG.json > $R/logs/gen_${g}_$TAG.log 2>&1
  echo "$g $TAG: $(tail -1 $R/logs/gen_${g}_$TAG.log | sed 's/.*__init__.py //')"
done
