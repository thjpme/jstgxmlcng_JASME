"""b2r5_regress: 段落 A（LESSON）の最後の行が、前の行のすぐ後ろ（ページ・段の区切りなし）にあり、そのすぐ後ろに図の上の
キャプション（図の中の文字はキャプションの後ろ）がある形（h2.py 用。架空の文字）。A の最後の行は本当の段落の行。4 回目の修正で
入った (A) の「間に行がない」形（better_line）が、キャプションの後ろの図の中の行が A の最後の docx の文字とよく似ているときに、
本当の最後の行を図の中の行とみなして、その行の校正の直しを直さなくならないかを見る（3 回目の修正の前と 4 回目の点検の版は、
間に行がない形を (A) にしなかった）。
  edit: A の最後の直し。cut: A の最後の行の長さ（ふつう・7 文字・3 文字）。fig: 図の中の行（A の最後の文と似た語句・消された
  最後の文の写し・関係のない語句）。after: キャプションの前（なし・受付日の行の後ろ・次のページの柱の後ろ）。"""
import sys
sys.path.insert(0, "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b2_review/r3p/exp")
sys.path.insert(0, "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b2_review/r4p/exp")
import gen_tail as G  # noqa: E402
import gen_capnext as CN  # noqa: E402

FIGL = {
    "sim": ["導入", "↓", "生徒どうしで説明し合う時間", "↓", "まとめ"],
    "res": ["導入", "↓", "結果を表にまとめる", "↓", "まとめ"],
    "unrel": ["導入", "↓", "課題の提示", "↓", "まとめ"],
}


def make_cases(T):
    out = []
    for ek, docx, pub in CN.pairs(T):
        if ek in ("addsent", "nostop"):
            continue
        for ck in ("last1", "k7", "k3"):
            if ck == "last1":
                lines = T.body_lines(pub)
            else:
                n = int(ck[1:])
                lines = [*T.body_lines(pub[:-n]), pub[-n:]]
            for fk, figl in FIGL.items():
                blocks = [("body", docx), ("fig_cap", G.CAP), ("image", "fig"), ("body", T.TALK), ("body", T.SURVEY)]
                tail = [G.CAP, *figl, *T.body_lines(T.TALK), *T.body_lines(T.SURVEY), *T.N10_TAIL]
                for ak in ("direct", "date_pb", "pbhead"):
                    head = [*T.SMALL_FRONT, *lines]
                    pages = {"direct": [head + tail], "date_pb": [head + [G.DATE], tail],
                             "pbhead": [head, ["試験　六郎"] + tail]}[ak]
                    out.append({"name": f"bl_{ek}_{ck}_{fk}_{ak}", "blocks": blocks, "pages": pages, "want": {docx: pub}})
    return out
