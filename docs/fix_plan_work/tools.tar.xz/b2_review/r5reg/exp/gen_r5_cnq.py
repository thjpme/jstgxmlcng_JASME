"""b2r5_regress: r4p/exp/gen_capnext.py の形（段落 A〈LESSON〉の最後の 1 行か最後の 7 文字が、受付日の行・次のページの柱の後ろに
出て、すぐ後ろに表のキャプションか図の上のキャプションがある）で、さらに、表・図の後ろの段落 B（TALK）の書き出しも校正で直されて
いる形（h2.py 用。架空の文字）。B の最初の docx の文字がどの塊にも入らないと、_Joint.facing_hole が真になり、A の最後の行（本当の
段落の行）を (A) で直さなくなるか（4 回目の修正の facing_hole の手がかりが、隣の段落の書き出しの直しで働かないか）を見る。"""
import sys
sys.path.insert(0, "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b2_review/r3p/exp")
sys.path.insert(0, "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b2_review/r4p/exp")
import gen_tail as G  # noqa: E402
import gen_capnext as CN  # noqa: E402

B_EDITS = {
    "bnone": None,
    "bw1": ("話し合いの中で", "議論の中で"),
    "bdel": ("そこで，", ""),
    "badd": ("", "その後，"),
}


def b_pair(T, ek):
    e = B_EDITS[ek]
    if e is None:
        return T.TALK, T.TALK
    if ek == "bdel":
        return e[0] + T.TALK, T.TALK
    if ek == "badd":
        return T.TALK, e[1] + T.TALK
    return T.TALK, T.TALK.replace(e[0], e[1], 1)


def make_cases(T):
    out = []
    for ek, docx, pub in CN.pairs(T):
        if ek == "none":
            continue
        lines = T.body_lines(pub)
        for ck in ("last1", "k7"):
            first, second = (lines[:-1], lines[-1:]) if ck == "last1" else (T.body_lines(pub[:-7]), [pub[-7:]])
            for mk in ("tab", "figabove"):
                for bk in B_EDITS:
                    b_docx, b_pub = b_pair(T, bk)
                    if mk == "tab":
                        blocks = [("body", docx), ("tab_cap", G.TCAP), ("table", G.CELLS)]
                        mid = [G.TCAP] + [" ".join(r) for r in G.CELLS]
                    else:
                        blocks = [("body", docx), ("fig_cap", G.CAP), ("image", "fig")]
                        mid = [G.CAP] + G.FIGS["fig"]
                    blocks += [("body", b_docx), ("body", T.SURVEY)]
                    for ak in ("date_pb", "pbhead", "date_head", "col_date"):
                        p1 = [*T.SMALL_FRONT, *first]
                        rest = [*second, *mid, *T.body_lines(b_pub), *T.body_lines(T.SURVEY), *T.N10_TAIL]
                        pages = {"date_pb": [p1 + [G.DATE], rest], "pbhead": [p1, ["試験　六郎"] + rest],
                                 "date_head": [p1 + [G.DATE], ["試験　六郎"] + rest], "col_date": [p1 + [G.DATE] + rest]}[ak]
                        out.append({"name": f"cnq_{ek}_{ck}_{mk}_{bk}_{ak}", "blocks": blocks, "pages": pages,
                                    "want": {docx: pub, b_docx: b_pub}})
    return out
