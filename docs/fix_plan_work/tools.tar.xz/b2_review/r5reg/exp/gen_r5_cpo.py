"""b2r5_regress: r4p/exp/gen_capprev.py の形（段落 B〈TALK〉が図のキャプション〈図の下〉か表のすぐ後ろから始まり、B の最初の行か
最初の 7 文字がページ・段の終わりにあって、受付日の行・次のページの柱の後ろに B の残りが続く）で、さらに、図・表の前の段落 A
（LESSON）の最後も校正で直されている形（h2.py 用。架空の文字）。A の最後の docx の文字がどの塊にも入らない（消された最後の文
など）と、_Joint.facing_hole が真になり、B の最初の行（本当の段落の行）を (A) で直さなくなるかを見る。"""
import sys
sys.path.insert(0, "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b2_review/r3p/exp")
sys.path.insert(0, "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b2_review/r4p/exp")
import gen_tail as G  # noqa: E402
import gen_capnext as CN  # noqa: E402
import gen_capprev as CP  # noqa: E402


def make_cases(T):
    out = []
    a_pairs = {ek: (d, p) for ek, d, p in CN.pairs(T) if ek in ("none", "e4", "e7", "delsent", "addsent", "nostop")}
    for bk, e in CP.HEAD_EDITS.items():
        if e is None:
            docx = pub = T.TALK
        elif bk == "del":
            docx, pub = e[0] + T.TALK, T.TALK
        elif bk == "add":
            docx, pub = T.TALK, e[1] + T.TALK
        else:
            docx, pub = T.TALK, T.TALK.replace(e[0], e[1], 1)
        if bk == "none":
            continue
        lines = T.body_lines(pub)
        for ak_, (a_docx, a_pub) in a_pairs.items():
            for ck in ("first1", "k7"):
                first, second = (lines[:1], lines[1:]) if ck == "first1" else (["　" + pub[:7]], T.wrap_lines(pub[7:]))
                for mk in ("figbelow", "tabcells"):
                    if mk == "figbelow":
                        blocks = [("body", a_docx), ("image", "fig"), ("fig_cap", G.CAP)]
                        mid = G.FIGS["fig"] + [G.CAP]
                    else:
                        blocks = [("body", a_docx), ("tab_cap", G.TCAP), ("table", G.CELLS)]
                        mid = [G.TCAP] + [" ".join(r) for r in G.CELLS]
                    blocks += [("body", docx), ("body", T.SURVEY)]
                    for ak in ("date_pb", "pbhead", "date_head", "col_date"):
                        p1 = [*T.SMALL_FRONT, *T.body_lines(a_pub), *mid, *first]
                        rest = [*second, *T.body_lines(T.SURVEY), *T.N10_TAIL]
                        pages = {"date_pb": [p1 + [G.DATE], rest], "pbhead": [p1, ["試験　六郎"] + rest],
                                 "date_head": [p1 + [G.DATE], ["試験　六郎"] + rest], "col_date": [p1 + [G.DATE] + rest]}[ak]
                        out.append({"name": f"cpo_{bk}_{ak_}_{ck}_{mk}_{ak}", "blocks": blocks, "pages": pages,
                                    "want": {docx: pub, a_docx: a_pub}})
    return out
