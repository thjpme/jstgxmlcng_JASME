"""b2r5_regress: tests/test_pdfmatch.py の test_figure_line_before_caption_does_not_change_width・
test_figure_line_after_first_line_does_not_change_width の形（h2.py・e2e 用。架空の文字）。"""


def make_cases(T):
    out = []
    for kname, last, fig in (("zen", "時間を２回取った。", "時間を2回見る"), ("han", "時間を3回取った。", "時間を３回見る")):
        pub = T.LESSON[:-len("時間を取った。")] + last
        docx = pub + "その結果を表に示す。"
        head = [*T.SMALL_FRONT, *T.body_lines(pub[:-len(last)]), *T.SMALL_FIG_STEPS, fig, T.SMALL_FIG_CAP, last]
        out.append({"name": f"fw_{kname}_date", "blocks": [("body", docx), ("image", "fig"), ("fig_cap", T.SMALL_FIG_CAP),
                                                           ("body", T.TALK)],
                    "pages": [[*head, T.R1], [*T.body_lines(T.TALK), *T.N10_TAIL]], "want": {docx: pub}})
    for kname, dh, ph, ff in (("split", "第２時の話し合いの中で", "第２時の議論の中で", "第2時の話し合い"),):
        docx = dh + T.TALK[len("話し合いの中で"):]
        pub = ph + docx[len(dh):]
        rest = ["　" + ph, ff, *T.SMALL_FIG_STEPS[1:], "まとめ", T.SMALL_FIG_CAP, *T.wrap_lines(pub[len(ph):]),
                *T.body_lines(T.SURVEY), *T.N10_TAIL]
        first = [*T.SMALL_FRONT, *T.body_lines(T.LESSON)]
        out.append({"name": f"fwh_{kname}_date", "blocks": [("body", T.LESSON), ("image", "fig"), ("fig_cap", T.SMALL_FIG_CAP),
                                                            ("body", docx), ("body", T.SURVEY)],
                    "pages": [[*first, T.R1], rest], "want": {docx: pub}})
    return out
