"""b2r5_regress: 段落 A（LESSON）の最後から 2 行目が校正でまるごと書き換えられ（どの段落の文字ともほとんど並ばない行になる）、
A の最後の行（本当の段落の行。校正の直しがあることもある）のすぐ後ろに、表のキャプションか図の上のキャプションがある形（h2.py 用。
架空の文字）。_Joint.figure_edge_lines の (A) は、A の最後の行と内側の塊の行の間が、どの段落にも当たらない行（図の中の文字と
みなす）だけなら、最後の行を図の中の行とみなすので、書き換えられた本文の行を図の中の文字と取り違えて、A の最後の行の直しを
直さなくならないかを見る。"""
import sys
sys.path.insert(0, "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/b2_review/r3p/exp")
import gen_tail as G  # noqa: E402

# LESSON_TAIL の前半（最後から 2 行目に当たる部分）の書き換え
REWRITES = {
    "rw1": ("最後に，教師は時間が３倍になると深さがどうなるかを問い，", "終盤では，授業者が水位の変わり方を予想させ，"),
    "rw2": ("最後に，教師は時間が３倍になると深さがどうなるかを問い，", "まとめの場面で再び予想を立てさせ，"),
}
LAST = {"none": ("", ""), "e4": ("取った。", "持った。"), "delsent": ("取った。その結果を表に示す。", "取った。")}


def make_cases(T):
    out = []
    for rk, (old, new) in REWRITES.items():
        for lk, (dt, pt) in LAST.items():
            docx = T.LESSON if lk != "delsent" else T.LESSON + "その結果を表に示す。"
            pub = T.LESSON.replace(old, new)
            if lk == "e4":
                docx_l, pub = docx, pub[:-len(dt)] + pt
            docx_l = docx
            lines = T.body_lines(pub)
            for mk in ("tab", "figabove", "figbelow_next"):
                if mk == "tab":
                    blocks = [("body", docx_l), ("tab_cap", G.TCAP), ("table", G.CELLS)]
                    mid = [G.TCAP] + [" ".join(r) for r in G.CELLS]
                elif mk == "figabove":
                    blocks = [("body", docx_l), ("fig_cap", G.CAP), ("image", "fig")]
                    mid = [G.CAP] + G.FIGS["fig"]
                else:          # 対照: 図はキャプションの上（A の最後の行のすぐ後ろは図の中の文字）
                    blocks = [("body", docx_l), ("image", "fig"), ("fig_cap", G.CAP)]
                    mid = G.FIGS["fig"] + [G.CAP]
                blocks += [("body", T.TALK), ("body", T.SURVEY)]
                for ak in ("direct", "pb"):
                    if ak == "direct":
                        pages = [[*T.SMALL_FRONT, *lines, *mid, *T.body_lines(T.TALK), *T.body_lines(T.SURVEY), *T.N10_TAIL]]
                    else:
                        pages = [[*T.SMALL_FRONT, *lines], [*mid, *T.body_lines(T.TALK), *T.body_lines(T.SURVEY), *T.N10_TAIL]]
                    out.append({"name": f"rw_{rk}_{lk}_{mk}_{ak}", "blocks": blocks, "pages": pages, "want": {docx_l: pub}})
    return out
