"""fixB: 点検の実験（rvB2 の CASES と rvB_regress_exp の EXPS。どれも架空の文字）を、1 つのコード（src）でまとめて実行する。

  python -I fixB_all.py SRC 出力.json
  python -I fixB_all.py --compare A.json B.json [C.json]   # 直す箇所（text）が違うものだけを出す
"""
import json
import subprocess
import sys
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
RV = S / "rvB2"
MODS = ["win1", "win2", "win3", "win4", "num1", "num2", "num3", "pbottom", "labels", "date", "fig", "layout", "window"]


def run(src, out):
    res = {}
    for m in MODS:
        p = subprocess.run([sys.executable, "-I", str(RV / "rvB2_run.py"), "--src", src, "--cases", str(RV / f"rvB2_cases_{m}.py")],
                           capture_output=True, text=True)
        if p.returncode:
            print(m, p.stderr[-2000:])
            raise SystemExit(1)
        for k, v in json.loads(p.stdout).items():
            res[f"{m}/{k}"] = v
    sys.path.insert(0, str(S))
    import rvB_regress_exp as rx
    p = subprocess.run([sys.executable, "-I", str(S / "rvB_regress_exp.py"), "--worker", src, *rx.EXPS], capture_output=True, text=True)
    if p.returncode:
        print("regress", p.stderr[-2000:])
        raise SystemExit(1)
    for k, v in json.loads(p.stdout).items():
        res[f"regress/{k}"] = v
    Path(out).write_text(json.dumps(res, ensure_ascii=False, indent=0), encoding="utf-8")
    print(len(res), "cases ->", out)


def compare(paths):
    data = [json.loads(Path(p).read_text(encoding="utf-8")) for p in paths]
    names = [Path(p).stem for p in paths]
    keys = list(data[0])
    nd = 0
    for k in keys:
        fx = [json.dumps(d.get(k, {}).get("fixes"), ensure_ascii=False) for d in data]
        um = [json.dumps(d.get(k, {}).get("unmatched"), ensure_ascii=False) for d in data]
        if len(set(fx)) > 1 or len(set(um)) > 1:
            nd += 1
            print(f"## {k}")
            for n, d in zip(names, data):
                r = d.get(k, {})
                ign = r.get("ignored") or []
                print(f"  [{n}] fixes={r.get('fixes')} unmatched={r.get('unmatched')} ignored={len(ign)} {ign[:3]}")
    print(f"{nd} / {len(keys)} cases differ")


if __name__ == "__main__":
    if sys.argv[1] == "--compare":
        compare(sys.argv[2:])
    else:
        run(sys.argv[1], sys.argv[2])
