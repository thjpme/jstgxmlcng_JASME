"""fixB2r1: 同じ行に 2 つの段落が並ぶ境目（追い込みの見出し・つながった段落）の直し。文字はすべて架空。
点検の x_runin_*・x_contest_* と同じ形で、PDF に次の段落を 2 回入れない（N.article_pages は after を足すので使わない）。"""
from __future__ import annotations

import sys
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
sys.path.insert(0, str(S / "n10"))
sys.path.insert(0, str(S / "oracle"))

from runner import BREAK, Raw, flow  # noqa: E402
import cases_n10 as N  # noqa: E402

CASES = []


def case(name, paras, pages, note, truth, expect):
    CASES.append({"name": name, "angle": "layout", "item": "new", "paras": paras, "truth": truth,
                  "pages": pages, "expect": expect, "note": note})


def idx(paras, text):
    found = [i for i, (_, t) in enumerate(paras) if t == text]
    assert len(found) == 1, text
    return found[0]


def pages_of(blocks):
    return flow([N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, *blocks, N.H3,
                 Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), N.RH, Raw(*N.REF1_LINES), Raw(*N.REF2_LINES), BREAK,
                 N.en_block()], first=25)


def base_paras(x, y=N.P_AFTER, ystyle="本文", xstyle="本文"):
    return [("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("見出し", N.H2), ("本文", N.TARGET),
            (xstyle, x), (ystyle, y), ("見出し", N.H3), ("本文", N.P_DISC), ("本文", N.P_END), ("引用文献見出し", N.RH),
            ("引用文献", N.REF1), ("引用文献", N.REF2)]


T0 = None
# 1. 追い込みの見出し（docx では別の段落「（１）架空の目的」。PDF では次の段落の最初の行の頭に全角の空白をはさんで入る）
RH = "（１）架空の目的"
B_EDIT = N.P_AFTER.replace("話し合いの中で", "話し合いでは")
for tag, h_pub, p_pub in (("none", RH, N.P_AFTER), ("head", "（１）架空の目標", N.P_AFTER), ("body", RH, B_EDIT),
                          ("both", "（１）架空の目標", B_EDIT), ("head2", "（１）架空のねらい", N.P_AFTER),
                          ("headadd", "（１）架空の目的と方法", N.P_AFTER), ("headdel", "（１）架空の", N.P_AFTER)):
    paras = [("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("見出し", N.H2), ("本文", N.TARGET),
             ("見出し2", RH), ("本文", N.P_AFTER), ("見出し", N.H3), ("本文", N.P_DISC), ("本文", N.P_END),
             ("引用文献見出し", N.RH), ("引用文献", N.REF1), ("引用文献", N.REF2)]
    pages = pages_of([Raw(*N.body(N.TARGET)), Raw(*N.jwrap(h_pub + "　" + p_pub))])
    truth = {idx(paras, N.CTRL_DOCX): N.CTRL_PUB}
    exp = {"default": "exact"}
    if h_pub != RH:
        truth[idx(paras, RH)] = h_pub
        exp[idx(paras, RH)] = "reported"
    if p_pub != N.P_AFTER:
        truth[idx(paras, N.P_AFTER)] = p_pub
        exp[idx(paras, N.P_AFTER)] = "reported"
    case(f"r1_runin_{tag}", paras, pages,
         "追い込みの見出し（docx では別の段落）が、PDF では次の段落の最初の行の頭に全角の空白をはさんで入る（次の段落は 1 回"
         f"だけ）。{tag}。直すか、決められなければ 13 章に出す（見出しの文字を本文に、本文の文字を見出しに足さない）。",
         truth, exp)

# 2. docx の段落 X と次の段落 Y が、PDF では 1 つにつながる（X の最後と Y の最初が同じ行）
X_DOCX = N.T_HEAD[:-5] + "確かめる"            # docx は「…確かめる」で終わる
Y_HEAD_E = N.P_AFTER.replace("話し合いの中で", "議論の中で")
Y_ADD = "そこで，" + N.P_AFTER
for tag, x_pub, y_pub in (("fix", N.T_HEAD, N.P_AFTER), ("same", X_DOCX, N.P_AFTER), ("period", X_DOCX + "。", N.P_AFTER),
                          ("te", X_DOCX[:-1] + "て", N.P_AFTER), ("yhead", X_DOCX, Y_HEAD_E),
                          ("yadd", N.T_HEAD, Y_ADD), ("xadd", N.T_HEAD + "以上である。", N.P_AFTER),
                          ("fix_yhead", N.T_HEAD, Y_HEAD_E)):
    x_docx = X_DOCX if tag not in ("yadd", "xadd") else N.T_HEAD
    paras = base_paras(x_docx)
    pages = pages_of([Raw(*N.body(N.TARGET)), Raw(*N.body(x_pub + y_pub))])
    truth = {idx(paras, N.CTRL_DOCX): N.CTRL_PUB}
    exp = {"default": "exact"}
    if x_pub != x_docx:
        truth[idx(paras, x_docx)] = x_pub
        exp[idx(paras, x_docx)] = "reported"
    if y_pub != N.P_AFTER:
        truth[idx(paras, N.P_AFTER)] = y_pub
        exp[idx(paras, N.P_AFTER)] = "reported"
    case(f"r1_join_{tag}", paras, pages,
         f"docx の段落 X と Y が、PDF では 1 つの段落につながる（X の最後と Y の最初が同じ行。Y は 1 回だけ）。{tag}。直すか、"
         "決められなければ 13 章に出す（Y に X の文字を、X に Y の文字を足さない）。", truth, exp)
