"""fixB2r1: 同じ行に 2 つの段落が並ぶ境目の、決められない形・空白の形（_contests の (1)〜(3) と、決められないとき）。
文字はすべて架空。oracle/run_all.py の書式。"""
from __future__ import annotations

import sys
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
sys.path.insert(0, str(S / "n10"))
sys.path.insert(0, str(S / "oracle"))

from runner import BREAK, Raw, flow  # noqa: E402
import cases_n10 as N  # noqa: E402

CASES = []


def case(name, paras, pages, note, truth, expect):
    CASES.append({"name": name, "angle": "layout", "item": "new", "paras": paras, "truth": truth,
                  "pages": pages, "expect": expect, "note": note})


def idx(paras, text):
    found = [i for i, (_, t) in enumerate(paras) if t == text]
    assert len(found) == 1, text
    return found[0]


def pages_of(blocks):
    return flow([N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, *blocks, N.H3,
                 Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), N.RH, Raw(*N.REF1_LINES), Raw(*N.REF2_LINES), BREAK,
                 N.en_block()], first=25)


def paras_of(x, xstyle="本文"):
    return [("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("見出し", N.H2), ("本文", N.TARGET),
            (xstyle, x), ("本文", N.P_AFTER), ("見出し", N.H3), ("本文", N.P_DISC), ("本文", N.P_END),
            ("引用文献見出し", N.RH), ("引用文献", N.REF1), ("引用文献", N.REF2)]


X_DOCX = N.T_HEAD[:-5] + "確かめる"
Y_EDIT = N.P_AFTER.replace("話し合いの中で", "議論の中で")
RH = "（１）架空の目的"
# (x_pdf, y_pdf, sep, x_docx, xstyle, tag): PDF の行は x_pdf + sep + y_pdf
FORMS = [
    # 決められない: A の最後（「る」）と B の書き出し（「話し合い」）の両方が直され、間の「て議論」に文の終わりも全角の空白もない
    (X_DOCX[:-1] + "て", Y_EDIT, "", X_DOCX, "本文", "te_yedit"),
    # 決められない: 見出しの後ろに足された「と方法」と本文の間に空白がない（どちらの段落にも docx の直された文字がない）
    ("（１）架空の目的と方法", N.P_AFTER, "", RH, "見出し2", "headadd_nospace"),
    # 追い込みの見出しと本文の間が半角の空白（両端そろえの空白と区別できない）。A の最後の直し「的」→「標」は (3) で A のもの
    ("（１）架空の目標", N.P_AFTER, " ", RH, "見出し2", "head_halfspace"),
    # 両端そろえの空白（句読点の後の半角の空白）がある、つながった段落。B の書き出しに足された「そこで，」
    (N.T_HEAD, "そこで， " + N.P_AFTER, " ", N.T_HEAD, "本文", "yadd_spaces"),
    # 両端そろえの空白があり、A の最後の「る」→「た。」
    (N.T_HEAD, N.P_AFTER, " ", X_DOCX, "本文", "fix_spaces"),
]
for x_pdf, y_pdf, sep, x_docx, xstyle, tag in FORMS:
    paras = paras_of(x_docx, xstyle)
    line_text = x_pdf + sep + y_pdf
    pages = pages_of([Raw(*N.body(N.TARGET)), Raw(*(N.jwrap(line_text) if xstyle != "本文" else N.body(line_text)))])
    truth = {idx(paras, N.CTRL_DOCX): N.CTRL_PUB}
    exp = {"default": "exact"}
    if x_pdf != x_docx:
        truth[idx(paras, x_docx)] = x_pdf
        exp[idx(paras, x_docx)] = "reported"
    y_truth = y_pdf.replace("， ", "，")
    if y_truth != N.P_AFTER:
        truth[idx(paras, N.P_AFTER)] = y_truth
        exp[idx(paras, N.P_AFTER)] = "reported"
    case(f"r1c_{tag}", paras, pages,
         f"同じ行に A の最後と B の最初が並ぶ（{tag}）。直すか、決められなければ両方とも docx のまま 13 章に出す（A を途中まで"
         "直したり、B の頭に A の文字を足したりしない）。", truth, exp)
