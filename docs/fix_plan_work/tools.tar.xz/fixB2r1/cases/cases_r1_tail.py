"""fixB2r1: 段落の最後（最初）の短い部分の校正の直し（分断あり・なし）。文字はすべて架空。
oracle/run_all.py の書式。"""
from __future__ import annotations

import sys
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
sys.path.insert(0, str(S / "n10"))
sys.path.insert(0, str(S / "oracle"))

from runner import BREAK, Raw, flow  # noqa: E402
import cases_n10 as N  # noqa: E402

CASES = []


def case(name, paras, pages, note, truth, expect):
    CASES.append({"name": name, "angle": "layout", "item": "N10", "paras": paras, "truth": truth,
                  "pages": pages, "expect": expect, "note": note})


def idx(paras, text):
    found = [i for i, (_, t) in enumerate(paras) if t == text]
    assert len(found) == 1, text
    return found[0]


# 分断なし: 段落の最後の行（数文字）が校正で直された
TAILS = [("4a", 4, N.TARGET[:-4] + "持った。"), ("4b", 4, N.TARGET[:-4] + "取れた。"), ("3", 3, N.TARGET[:-3] + "てた。"),
         ("6", 6, N.TARGET[:-6] + "間を取る。"), ("7", 7, N.TARGET[:-7] + "時間を設けた。"),
         ("9", 9, N.TARGET[:-9] + "合う場を設けた。"), ("2", 2, N.TARGET[:-2] + "る。"),
         ("rew", 7, N.TARGET[:-7] + "場を設けて話し合わせた。"), ("del", 4, N.TARGET[:-4] + "取")]
for tag, k, pub in TAILS:
    head_pdf, tail_pdf = pub[:len(N.TARGET) - k], pub[len(N.TARGET) - k:]
    paras = N.article_paras(N.TARGET)
    pages = N.article_pages([Raw(*N.body(head_pdf)), Raw(tail_pdf)])
    case(f"r1_tail{tag}_nosplit", paras, pages,
         f"分断なし。段落の最後の行「{tail_pdf}」（docx の「{N.TARGET[-k:]}」を校正で直したもの）。直すか、13 章に出す。",
         {idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): pub},
         {"default": "exact", idx(paras, N.TARGET): "reported"})
    # 同じ形で、最後の行の前でページが変わる
    blocks = [N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*N.body(head_pdf)), BREAK,
              Raw(tail_pdf), Raw(*N.body(N.P_AFTER)), N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), N.RH,
              Raw(*N.REF1_LINES), Raw(*N.REF2_LINES), BREAK, N.en_block()]
    case(f"r1_tail{tag}_pb", paras, flow(blocks, first=25),
         f"段落の最後の行「{tail_pdf}」の前でページが変わる（次のページの最初の行）。直すか、13 章に出す。",
         {idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): pub},
         {"default": "exact", idx(paras, N.TARGET): "reported"})
