"""fixB2r4: figure_edge_lines の (B) で、L のすぐ外の行が受付日の行・ページの端の行（柱など）のとき（h2.py 用。架空の文字）。
頭の側: 段落 B（TALK）の最初の k 文字の行がページ（段）の最後にあり、次のページの最初（柱の後ろ）か受付日の行の後ろに小さな図
（docx では B のすぐ前の画像とキャプション。キャプションは図の下）があり、図の中の最初の行が B の最初の文字とよく似ている。
尾の側: 段落 A（LESSON）の最後の文が校正で消され、A の後ろに図（キャプションは図の上）があり、図の中の最後の行が A の最後の行と
よく似ていて、図の後ろでページ（段）が変わり、次のページの最初（柱の後ろ）に本当の最後の行がある。"""
CAP = "図１　架空の授業の流れ"
DATE = "2025年８月31日投稿受付，2025年11月24日採用決定"
HEAD_EDITS = {"w1": ("話し合いの中で", "議論の中で"), "w2": ("話し合いの", "話合いの"), "none": ("", "")}
FIGS_H = {"sim": "話し合いの場面", "far": "導入"}
BETWEEN = ("none", "head", "date", "datehead", "col")


def pages_for(p1_tail, p2, bk, T):
    """p1_tail: 1 ページ目の最後の行まで、p2: 2 ページ目の行（柱なし）。"""
    if bk == "none":
        return [p1_tail, p2]
    if bk == "head":
        return [p1_tail, ["試験　六郎", *p2]]
    if bk == "date":
        return [p1_tail + [DATE], p2]
    if bk == "datehead":
        return [p1_tail + [DATE], ["試験　六郎", *p2]]
    return [p1_tail + [DATE] + p2]          # 同じページの次の段（受付日の行は段の最後）


def make_cases(T):
    out = []
    for ek, (a, b) in HEAD_EDITS.items():
        docx = T.TALK
        pub = T.TALK.replace(a, b, 1) if a else T.TALK
        for k in (7, pub.index("，") + 1):
            for fk, figfirst in FIGS_H.items():
                fig = [figfirst, "↓", "課題の提示", "↓", "まとめ"]
                blocks = [("body", T.LESSON), ("image", "fig"), ("fig_cap", CAP), ("body", docx), ("body", T.SURVEY)]
                for bk in BETWEEN:
                    p1 = [*T.SMALL_FRONT, *T.body_lines(T.LESSON), "　" + pub[:k]]
                    p2 = [*fig, CAP, *T.wrap_lines(pub[k:]), *T.body_lines(T.SURVEY), *T.N10_TAIL]
                    out.append({"name": f"bh_{ek}_k{k}_{fk}_{bk}", "blocks": blocks, "pages": pages_for(p1, p2, bk, T),
                                "want": {docx: pub}})
    # 尾の側
    for dk in ("del", "none", "e4"):
        if dk == "del":
            docx, pub = T.LESSON + "その結果を表に示す。", T.LESSON
        elif dk == "none":
            docx, pub = T.LESSON, T.LESSON
        else:
            docx, pub = T.LESSON, T.LESSON.replace("時間を取った", "時間を持った")
        lines = T.body_lines(pub)
        for fk, figlast in (("sim", "時間を見る"), ("far", "まとめ")):
            fig = ["導入", "↓", "課題の提示", "↓", figlast]
            blocks = [("body", docx), ("fig_cap", CAP), ("image", "fig"), ("body", T.TALK), ("body", T.SURVEY)]
            for bk in BETWEEN:
                p1 = [*T.SMALL_FRONT, *lines[:-1], CAP, *fig]
                p2 = [lines[-1], *T.body_lines(T.TALK), *T.body_lines(T.SURVEY), *T.N10_TAIL]
                out.append({"name": f"bt_{dk}_{fk}_{bk}", "blocks": blocks, "pages": pages_for(p1, p2, bk, T),
                            "want": {docx: pub}})
    return out
