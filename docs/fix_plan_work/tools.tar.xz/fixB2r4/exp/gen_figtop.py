"""fixB2r4: 小さな図が次のページ（段）の最初にあり、段落の最後（最初）の行が図のキャプションの後ろ（前）に出る形（h2.py 用。架空の
文字）。図の中の文字の行がページの端の行になり、柱と見分けられない。図の中のキャプションのすぐ前の行は、段落の最後の行とよく似て
いる（sim）か、似ていない（far）。尾の側は段落 A（LESSON）の最後、頭の側は段落 B（TALK）の最初。"""
CAP = "図１　架空の授業の流れ"
DATE = "2025年８月31日投稿受付，2025年11月24日採用決定"
TAIL_EDITS = {"none": None, "delsent": "その結果を表に示す。", "e4": ("取った", "持った"), "heavy": ("時間を取った。", "場を設けて話し合わせた。")}
HEAD_EDITS = {"none": None, "w1": ("話し合いの中で", "議論の中で")}
BREAKS = ("pb", "pbhead", "datepb", "datehead", "col")


def pages_for(p1, p2, bk):
    if bk == "pb":
        return [p1, p2]
    if bk == "pbhead":
        return [p1, ["試験　六郎", *p2]]
    if bk == "datepb":
        return [p1 + [DATE], p2]
    if bk == "datehead":
        return [p1 + [DATE], ["試験　六郎", *p2]]
    return [p1 + [DATE] + p2]


def make_cases(T):
    out = []
    for ek, e in TAIL_EDITS.items():
        if e is None:
            docx = pub = T.LESSON
        elif isinstance(e, str):
            docx, pub = T.LESSON + e, T.LESSON
        else:
            docx, pub = T.LESSON, T.LESSON.replace(e[0], e[1])
        last = pub[len(T.LESSON) - 7:] if ek != "heavy" else pub[-len(e[1]):]
        body = pub[:len(pub) - len(last)]
        for fk, figlast in (("sim", "時間を見る"), ("far", "まとめ")):
            for nf in (1, 2, 3):
                fig = (["導入", "↓"][:nf - 1]) + [figlast]
                blocks = [("body", docx), ("image", "fig"), ("fig_cap", CAP), ("body", T.TALK), ("body", T.SURVEY)]
                for bk in BREAKS:
                    p1 = [*T.SMALL_FRONT, *T.body_lines(body)]
                    p2 = [*fig, CAP, *T.wrap_lines(last), *T.body_lines(T.TALK), *T.body_lines(T.SURVEY), *T.N10_TAIL]
                    out.append({"name": f"ft_{ek}_{fk}{nf}_{bk}", "blocks": blocks, "pages": pages_for(p1, p2, bk),
                                "want": {docx: pub}})
    for ek, e in HEAD_EDITS.items():
        docx = T.TALK
        pub = T.TALK if e is None else T.TALK.replace(e[0], e[1])
        for fk, figfirst in (("sim", "話し合いの場面"), ("far", "導入")):
            for nf in (1, 2, 3):
                fig = [figfirst] + ["↓", "まとめ"][:nf - 1]
                blocks = [("body", T.LESSON), ("fig_cap", CAP), ("image", "fig"), ("body", docx), ("body", T.SURVEY)]
                for bk in BREAKS:
                    lines = T.body_lines(pub)
                    p1 = [*T.SMALL_FRONT, *T.body_lines(T.LESSON), CAP, *fig, lines[0]]
                    p2 = [*lines[1:], *T.body_lines(T.SURVEY), *T.N10_TAIL]
                    out.append({"name": f"fh_{ek}_{fk}{nf}_{bk}", "blocks": blocks, "pages": pages_for(p1, p2, bk),
                                "want": {docx: pub}})
    return out
