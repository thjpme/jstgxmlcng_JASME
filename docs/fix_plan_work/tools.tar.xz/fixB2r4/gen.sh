#!/bin/sh
# fixB2r4: 点検の生成例（r3p・r4p・r4reg の gen_*.py）を SRC のコードで実行する（並列）。 sh gen.sh SRC TAG [gen ...]
# gen の名前: r3p の head tail figsim figpre pages dup figstop、r4p の figwidth figwidth_head capnext capprev、
#            r4reg の figw figw2 figw3 widow bfp
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
F=$S/fixB2r4
SRC=$1; TAG=$2; shift 2
W=${*:-"head tail figsim figpre pages dup figstop figwidth figwidth_head capnext capprev figw figw2 figw3 widow bfp"}
cd /tmp
for g in $W; do
  case $g in
    head|tail|figsim|figpre|pages|dup|figstop) X=$S/b2_review/r3p/exp ;;
    figwidth|figwidth_head|capnext|capprev) X=$S/b2_review/r4p/exp ;;
    *) X=$S/b2_review/r4reg/exp ;;
  esac
  python -I $S/b2_review/r4p/h2.py $SRC $X/gen_$g.py $F/gen/fz_${g}_$TAG.json > $F/logs/gen_${g}_$TAG.log 2>&1 &
done
wait
for g in $W; do echo "$g $TAG: $(tail -1 $F/logs/gen_${g}_$TAG.log | sed 's/.*__init__.py //')"; done
