#!/bin/sh
# fixB2r4: 作業ツリーの src を写す。 sh snap.sh 名前
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
F=$S/fixB2r4
rm -rf $F/$1_src && mkdir -p $F/$1_src && cp -r /home/user/jstgxmlcng_JASME/src/jasme_jats $F/$1_src/ && rm -rf $F/$1_src/jasme_jats/__pycache__
echo $F/$1_src
