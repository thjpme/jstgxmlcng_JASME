"""fixB2r2: fuzz8 で、docx にも PDF にもない文字を足した段落（judge8 の added に空白でない文字があるもの）を数える。
  python -I added_count.py TAG..."""
import json
import sys
from collections import Counter
from pathlib import Path
S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
V = S / "fixB2r4" / "v" / "f8"
sys.path.insert(0, str(S / "oracle"))
sys.path.insert(0, str(S / "rvB8_regress" / "fuzz8"))
import judge8  # noqa: E402
groups = [(d / "cases.json", d.name) for d in sorted((S / "rvB8_regress" / "fuzz8").glob("*_3[0-9][0-9]")) if (d / "cases.json").exists()]
for tag in sys.argv[1:]:
    n = Counter()
    for cp, g in groups:
        r = json.load(open(V / f"{g}_{tag}.json", encoding="utf-8"))
        cases = json.load(open(cp, encoding="utf-8"))
        for k, c in enumerate(cases):
            for doc, p in c["truth"].items():
                x = r["cases"][k]["paras"].get(doc)
                if x is None:
                    continue
                v, _, ds = judge8.verdict(doc, p, x)
                if v == "VIOLATION" and any(a.strip() for a in ds["added"]):
                    n["added"] += 1
    print(tag, dict(n))
