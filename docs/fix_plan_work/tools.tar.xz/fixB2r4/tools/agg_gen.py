"""fixB2r4: 生成例（h2.py の JSON）を、0.20.0（base）・点検した版（prev）・指定した版でまとめて数える。
  python agg_gen.py TAG [gen ...]"""
import json
import sys
from collections import Counter
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
DIRS = (S / "fixB2r4" / "gen", S / "b2_review" / "r4p" / "exp", S / "b2_review" / "r4reg" / "exp", S / "b2_review" / "r3p" / "exp")
GENS = "head tail figsim figpre pages dup figstop figwidth figwidth_head capnext capprev figw figw2 figw3 widow bfp bpage figtop".split()
RANK = {"OK": 0, "REP": 1, "SILENT": 2, "FAIL": 3, "ERROR": 4}


def load(gen, tag):
    for d in DIRS:
        f = d / f"fz_{gen}_{tag}.json"
        if f.exists():
            return json.loads(f.read_text(encoding="utf-8"))["cases"]
    return None


tag = sys.argv[1]
gens = sys.argv[2:] or GENS
tot = Counter()
for g in gens:
    base, cur = load(g, "base"), load(g, tag)
    prev = load(g, "prev") if g in ("bpage", "figtop") else load(g, "cur")
    worse = [n for n in cur if n in prev and RANK[cur[n]["verdict"]] > RANK[prev[n]["verdict"]]]
    better = [n for n in cur if n in prev and RANK[cur[n]["verdict"]] < RANK[prev[n]["verdict"]]]
    fb, fp, fc = (sum(1 for v in x.values() if v["verdict"] == "FAIL") for x in (base, prev, cur))
    new_vs_base = [n for n in cur if cur[n]["verdict"] == "FAIL" and base.get(n, {}).get("verdict") != "FAIL"]
    print(f"{g:14} {len(cur):5} 件  prev→{tag}: 悪 {len(worse)}・良 {len(better)}  FAIL base {fb}・prev {fp}・{tag} {fc}"
          f"  base で FAIL でないのに FAIL {len(new_vs_base)}  {dict(Counter(v['verdict'] for v in cur.values()))}")
    tot.update({"n": len(cur), "worse": len(worse), "better": len(better), "fb": fb, "fp": fp, "fc": fc, "new": len(new_vs_base)})
print("合計", dict(tot))
