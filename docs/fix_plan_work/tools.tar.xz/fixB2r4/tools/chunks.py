"""verify_colab: 直した docx の照合する段落の文字を 8 文字ずつに切り、PDF（空白・改行を除いた文字）にあるかを数える。
使い方: PYTHONPATH=<src> python chunks.py <tdN> <直した docx>"""
import sys, re
from jasme_jats.config import JournalConfig
from jasme_jats.pdfdocx import _mechanical
from jasme_jats.pdfmatch import extract_pages, target_paragraphs
td, path = sys.argv[1], sys.argv[2]
J = JournalConfig.load()
texts, plan = _mechanical(path, J)
tg = [p.src for p in target_paragraphs(plan)]
pages = extract_pages(f"/home/user/jstgxmlcng_JASME/tests/private/colab/{td}/{td}.pdf")
ws = re.compile(r"[\s　￾￯￼]")
flat = ws.sub("", "".join(pages))
K = 8
bad = 0
for s in tg:
    t = ws.sub("", texts.get(s, ""))
    miss = []
    for i in range(0, max(1, len(t) - K + 1), 4):
        c = t[i:i + K]
        if len(c) >= 4 and c not in flat:
            miss.append(c)
    if miss:
        bad += 1
        print(s, len(miss), " | ".join(miss[:6]))
print("paragraphs with missing chunks:", bad, "of", len(tg))
