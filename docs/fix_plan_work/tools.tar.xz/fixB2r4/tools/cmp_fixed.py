"""verify_colab: 元の docx・0.20.0 の直した docx・作業ツリーの直した docx の段落の文字を比べる。
使い方: PYTHONPATH=<src> python cmp_fixed.py <tdN> [--all]
"""
import sys, difflib, unicodedata
from pathlib import Path
from jasme_jats.config import JournalConfig
from jasme_jats.pdfdocx import _mechanical
from jasme_jats.pdfmatch import is_width_pair, extract_pages, fold
S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
td = sys.argv[1]
J = JournalConfig.load()
orig = _mechanical(f"/home/user/jstgxmlcng_JASME/tests/private/colab/{td}/{td}.docx", J)[0]
base = _mechanical(S / f"colab_v20/run/base/{td}/31_1_PDFに合わせた原稿.docx", J)[0]
new = _mechanical(S / f"fix_verify/colab/route_pdf/{td}/31_1_PDFに合わせた原稿.docx", J)[0]
pages = extract_pages(f"/home/user/jstgxmlcng_JASME/tests/private/colab/{td}/{td}.pdf")
flat = "".join(pages).replace("\n", "⏎")

def ops(a, b):
    out = []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if tag == "equal":
            continue
        x, y = a[i1:i2], b[j1:j2]
        if len(x) == len(y) and all(is_width_pair(p, q) or fold(p) == fold(q) for p, q in zip(x, y)):
            continue
        if not x.strip() and not y.strip():
            continue
        out.append((i1, i2, x, y, a[max(0, i1-12):i1], a[i2:i2+12]))
    return out

def pdfctx(before, after):
    for anchor in (before[-6:], after[:6]):
        k = flat.find(anchor) if len(anchor) >= 4 else -1
        if k >= 0:
            return flat[max(0, k-30):k+50]
    return "?"

keys = sorted(set(orig) | set(base) | set(new), key=lambda s: (len(s), s))
for s in keys:
    o, b, n = orig.get(s, ""), base.get(s, ""), new.get(s, "")
    on = ops(o, n)
    if b != n or (on and "--all" in sys.argv):
        print(f"== {s}  base==new: {b == n}  text-ops orig->new: {len(on)}")
        for i1, i2, x, y, pre, post in on:
            print(f"   new: [{pre}]〔{x!r}→{y!r}〕[{post}]")
        if b != n:
            for i1, i2, x, y, pre, post in ops(b, n):
                print(f"   base->new: [{pre}]〔{x!r}→{y!r}〕[{post}]")
            for i1, i2, x, y, pre, post in ops(o, b):
                print(f"   base: [{pre}]〔{x!r}→{y!r}〕[{post}]")
