"""fixB2r4: 生成例（h2.py の JSON）を版ごとに比べる。 python cmp_gen.py gen 版:ファイル ... [-v]
ファイルは fixB2r4/gen/fz_<gen>_<版>.json か、b2_review の r4p/exp・r4reg/exp・r3p/exp の fz_<gen>_<版>.json を探す。"""
import json
import sys
from collections import Counter
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
gen = sys.argv[1]
tags = [a for a in sys.argv[2:] if not a.startswith("-")]
verbose = "-v" in sys.argv
data = {}
for t in tags:
    for d in (S / "fixB2r4" / "gen", S / "b2_review" / "r4p" / "exp", S / "b2_review" / "r4reg" / "exp",
              S / "b2_review" / "r3p" / "exp", S / "fixB2r3" / "gen"):
        f = d / f"fz_{gen}_{t}.json"
        if f.exists():
            data[t] = json.loads(f.read_text(encoding="utf-8"))["cases"]
            break
    else:
        print("ない:", t)
for t, c in data.items():
    print(f"{gen} {t}: {dict(Counter(v['verdict'] for v in c.values()))}")
rank = {"OK": 0, "REP": 1, "SILENT": 2, "FAIL": 3, "ERROR": 4}
ts = list(data)
for a, b in zip(ts, ts[1:]):
    worse = [n for n in data[a] if n in data[b] and rank[data[b][n]["verdict"]] > rank[data[a][n]["verdict"]]]
    better = [n for n in data[a] if n in data[b] and rank[data[b][n]["verdict"]] < rank[data[a][n]["verdict"]]]
    print(f"  {a} -> {b}: 悪くなった {len(worse)}・よくなった {len(better)}")
    for n in worse if verbose else worse[:12]:
        print(f"    悪: {n} {data[a][n]['verdict']} -> {data[b][n]['verdict']}")
