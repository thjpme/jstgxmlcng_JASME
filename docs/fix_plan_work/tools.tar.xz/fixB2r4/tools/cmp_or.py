"""fixB2r4: oracle の結果を、版ごとに反例ごとに比べる。 python cmp_or.py 前の名前の形 後の名前の形 [which...]
   名前の形は oracle/results_<形>.json の <形> で、{w} が反例集の名前（o34・n10…）になる。例: r3_{w}_cur f3_{w}_v1"""
import json
import sys
from pathlib import Path
O = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/oracle")
A, B = sys.argv[1], sys.argv[2]
W = sys.argv[3:] or ["o34", "n10", "n10g", "rv89", "cj", "cj2", "b2", "x", "xm", "r1", "y", "y2"]
R = {"OK": 0, "REPORTED": 1, "FAIL": 2}
for w in W:
    fa, fb = O / f"results_{A.format(w=w)}.json", O / f"results_{B.format(w=w)}.json"
    if not fa.exists() or not fb.exists():
        print(w, "結果がない", fa.exists(), fb.exists())
        continue
    a = {c["name"]: c["verdict"] for c in json.load(open(fa))["cases"]}
    b = {c["name"]: c["verdict"] for c in json.load(open(fb))["cases"]}
    worse = [(n, a.get(n), b[n]) for n in b if n in a and R.get(b[n], 3) > R.get(a[n], 3)]
    better = [(n, a.get(n), b[n]) for n in b if n in a and R.get(b[n], 3) < R.get(a[n], 3)]
    new = [n for n in b if n not in a]
    cnt = {v: sum(1 for x in b.values() if x == v) for v in R}
    print(f"{w}: {cnt}  悪くなった {len(worse)} {worse[:6]}  よくなった {len(better)} {better[:8]}  新しい {len(new)}")
