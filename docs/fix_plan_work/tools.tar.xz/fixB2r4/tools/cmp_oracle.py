"""fixB2r1: 反例集の結果（oracle/results_<名前>.json）を反例ごとに比べる。
  python cmp_oracle.py A_NAME B_NAME [...]   # 例: b2v_n10_F3 r1_n10_v2"""
import json, sys
from pathlib import Path
O = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/oracle")
names = sys.argv[1:]
res = [{c["name"]: c for c in json.load(open(O / f"results_{n}.json", encoding="utf-8"))["cases"]} for n in names]
keys = list(res[-1])
diff = 0
for k in keys:
    vs = [r.get(k, {}).get("verdict", "-") for r in res]
    if len(set(vs)) > 1:
        diff += 1
        print(f"{k:40} " + " -> ".join(vs))
        for r, n in zip(res, names):
            c = r.get(k)
            if not c:
                continue
            bad = [p for p in c["paras"] if p["verdict"] != "OK"]
            for p in bad:
                print(f"    [{n}] {p['label']}({p['src']}) {p['verdict']}: {p['reason'][:200]}")
print("違う反例:", diff, "/", len(keys))
