"""fixB2r4: 本誌の PDF の結果（realpdf/check.py の results_after_*.json・jobs_results_route1_*.json）を 2 つの版で比べる。
   python cmp_real.py A.json B.json"""
import json
import sys
a, b = (json.load(open(x)) for x in sys.argv[1:3])
ja, jb = a.get("jobs", a), b.get("jobs", b)
diff = 0
for k in sorted(set(ja) | set(jb)):
    x, y = ja.get(k), jb.get(k)
    if isinstance(x, dict):
        x = {kk: vv for kk, vv in x.items() if kk not in ("file", "version", "seconds", "out", "path")}
    if isinstance(y, dict):
        y = {kk: vv for kk, vv in y.items() if kk not in ("file", "version", "seconds", "out", "path")}
    if x != y:
        diff += 1
        keys = sorted(set(x or {}) | set(y or {}))
        print(k, "違う項目:", [kk for kk in keys if (x or {}).get(kk) != (y or {}).get(kk)])
print("違う組:", diff, "/", len(set(ja) | set(jb)))
