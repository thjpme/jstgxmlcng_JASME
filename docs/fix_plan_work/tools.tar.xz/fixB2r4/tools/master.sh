#!/bin/sh
# judge: 4 つの版（base・R・G・J）で、点検の例・反例集・golden を順に実行する。
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
J=$S/n10/judge; L=$J/logs
echo "start $(date +%T)"
sh $J/tools/run_suites.sh $J/base_src base quick 4; echo "quick base $(date +%T)"
for x in R G J; do sh $J/tools/run_suites.sh $J/${x}_src $x quick 4; echo "quick $x $(date +%T)"; done
for x in base R G J; do d=$J/${x}_src; [ $x = base ] && d=$J/base_src; sh $J/tools/run_oracle.sh $d $x o34 n10 n10g rv89; echo "oracle $x $(date +%T)"; done
for x in base R G J; do d=$J/${x}_src; [ $x = base ] && d=$J/base_src; sh $J/tools/run_suites.sh $d $x f4 4; echo "f4 $x $(date +%T)"; done
for x in base R G J; do d=$J/${x}_src; [ $x = base ] && d=$J/base_src; (cd $J && PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=$d python $S/golden/golden.py $J/v/golden_$x > $L/golden_$x.log 2>&1) & done; wait; echo "golden $(date +%T)"
for x in base R G J; do d=$J/${x}_src; [ $x = base ] && d=$J/base_src; sh $J/tools/run_suites.sh $d $x b210 1 & done; wait; echo "b210 $(date +%T)"
for x in base R G J; do d=$J/${x}_src; [ $x = base ] && d=$J/base_src; sh $J/tools/run_suites.sh $d $x f8 4; echo "f8 $x $(date +%T)"; done
echo "end $(date +%T)"
