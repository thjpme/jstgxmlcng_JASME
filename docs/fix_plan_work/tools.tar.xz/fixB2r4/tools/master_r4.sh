#!/bin/sh
# fixB2r4: 1 つの版（SRC・TAG）で、物差しを順に実行する。  sh master_r3.sh SRC TAG
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
J=$S/fixB2r4; L=$J/logs; SRC=$1; TAG=$2
echo "start $TAG $(date +%T)"
sh $J/tools/run_suites.sh $SRC $TAG quick 4; echo "quick $(date +%T)"
sh $J/tools/run_oracle.sh $SRC $TAG o34 n10 n10g rv89 judge judge2; rm -rf $S/oracle/_work/f4r_*_$TAG; sh $J/tools/run_oracle.sh $SRC $TAG b2 x xm r1 y y2; rm -rf $S/oracle/_work/f4r_*_$TAG; echo "oracle $(date +%T)"
sh $J/tools/run_suites.sh $SRC $TAG f4 4; echo "f4 $(date +%T)"
(cd $J && PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=$SRC python $S/golden/golden.py $J/v/golden_$TAG > $L/golden_$TAG.log 2>&1); echo "golden $(date +%T)"
sh $J/tools/run_suites.sh $SRC $TAG b210 1; echo "b210 $(date +%T)"
sh $J/tools/run_suites.sh $SRC $TAG f8 4; echo "f8 $(date +%T)"
(cd $J/realpdf && python -I check.py --before-src $J/base_src --after-src $SRC --route1 --tag _$TAG > $L/real_$TAG.log 2>&1); echo "real $(date +%T)"
echo "end $TAG $(date +%T)"
