"""verify_colab: PDF（pypdfium2 の文字）を探す。使い方: python pgrep.py <tdN> <文字列> [前 後]"""
import sys
from jasme_jats.pdfmatch import extract_pages
td, q = sys.argv[1], sys.argv[2]
b = int(sys.argv[3]) if len(sys.argv) > 3 else 40
a = int(sys.argv[4]) if len(sys.argv) > 4 else 60
pages = extract_pages(f"/home/user/jstgxmlcng_JASME/tests/private/colab/{td}/{td}.pdf")
for pn, pg in enumerate(pages):
    k = pg.find(q)
    while k >= 0:
        print(f"p{pn+1}@{k}: {pg[max(0,k-b):k+len(q)+a]!r}")
        k = pg.find(q, k + 1)
