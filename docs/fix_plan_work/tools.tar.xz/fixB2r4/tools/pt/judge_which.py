"""pytest のプラグイン: 読んだ jasme_jats の場所を出す（-p judge_which）。"""
def pytest_sessionstart(session):
    import jasme_jats
    print("\nWHICH", jasme_jats.__file__, jasme_jats.__version__)
