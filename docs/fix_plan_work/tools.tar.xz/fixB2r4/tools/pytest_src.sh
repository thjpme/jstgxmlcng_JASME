#!/bin/sh
# judge: 本体の tests を、指定した src のコードで実行する。  sh pytest_src.sh <src> <python> [pytest の引数...]
# pyproject の pythonpath（src, tests）は PYTHONPATH より前に入るので、-o pythonpath で上書きする（WHICH の行で確かめる）。
SRC=$(cd "$1" && pwd); PY=$2; shift 2
H=$(cd "$(dirname "$0")" && pwd)
cd /home/user/jstgxmlcng_JASME && PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$H/pt:$SRC" \
  $PY -m pytest -p no:cacheprovider -p judge_which -o pythonpath="$SRC /home/user/jstgxmlcng_JASME/tests" "$@"
