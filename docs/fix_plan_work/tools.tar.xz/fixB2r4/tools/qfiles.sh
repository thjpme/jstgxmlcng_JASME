# judge: quick（rvB2p/quick.py の形）の反例のファイルの一覧
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
QFILES="$S/rvB2p/cases_bound.py $S/rvB2p/cases_cont.py $S/rvB2p/cases_dashtable.py $S/rvB2p/cases_edge2.py $S/rvB2p/cases_len20.py \
$S/rvB2p/cases_refend.py $S/rvB2p/cases_refs2.py $S/rvB2p/cases_rep.py $S/rvB2p/cases_rep2.py $S/rvB2p/cases_split.py \
$S/fixB3/cases_b3_edge.py $S/rvB8p/cases_h1.py $S/rvB8p/cases_h1b.py $S/rvB8p/cases_h2.py $S/rvB8p/cases_h2b.py $S/rvB8p/cases_h3.py \
$S/rvB8p/cases_h4.py $S/rvB9p/cases_e1.py $S/rvB9p/cases_e5.py $S/rvB9p/cases_e6.py $S/rvB9_regress/cases_t1.py \
$S/rvB9_regress/cases_t2.py $S/rvB9_regress/cases_t3.py $S/rvB9_regress/cases_t4.py $S/rvB9_regress/cases_t5.py \
$S/n10/joint/cases_island.py $S/rvB2p/fz11.json $S/rvB2p/fz21.json $S/rvB2p/fz22.json $S/rvB2p/fz23.json \
$S/rvB2p/fz101.json $S/rvB2p/fz102.json $S/rvB2p/fz103.json $S/rvB2p/fz104.json $S/rvB9p/bound1.json $S/rvB9p/bound2.json"
