"""rvB2p（単位 B の原則の点検）: 架空の文字の小さな論文で、照合（compare）と直す箇所（plan_fixes）だけを動かす速い実験。

  python -I quick.py run SRC CASEFILE OUT.json      # SRC の jasme_jats で CASEFILE の CASES を実行して JSON に書く
  python -I quick.py cmp CASEFILE A.json B.json      # 2 つの結果を、truth に照らして並べる（足した・消した文字）

CASEFILE は CASES = {名前: dict(body=[(スタイル, 文字) | ("table", 行のリスト)], refs=[...], pages=[...], truth={文字: 出版版の文字})}
を定義する。truth に書かない段落は docx のまま（変わってはいけない）。docx は make_fixtures.make_article で作る（scratchpad だけ）。
"""
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ORACLE = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/oracle")


def load(casefile):
    if str(casefile).endswith(".json"):
        return json.loads(Path(casefile).read_text(encoding="utf-8"))
    spec = importlib.util.spec_from_file_location("cases", casefile)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.CASES


def run(src, casefile, out):
    sys.path.insert(0, src)
    sys.path.insert(1, "/home/user/jstgxmlcng_JASME/tests")
    import make_fixtures as mf
    import jasme_jats
    from jasme_jats.config import JournalConfig
    from jasme_jats.pipeline import _mechanical
    from jasme_jats import pdfmatch
    from jasme_jats.pdfdocx import plan_fixes, expected_text
    j = JournalConfig.load()
    cases = load(casefile)
    res = {"version": jasme_jats.__version__, "file": jasme_jats.__file__, "cases": {}}
    ddir = HERE / "docx"
    ddir.mkdir(exist_ok=True)
    plans = {}
    for name, c in cases.items():
        spec = json.dumps([c.get("body", []), c.get("refs", [])], ensure_ascii=False)
        h = hashlib.sha1(spec.encode()).hexdigest()[:12]
        path = ddir / f"{h}.docx"
        if not path.exists():
            def body(b, parts=c.get("body", [])):
                out_ = [mf.para(mf.S["sec1"], "１．はじめに")]
                for kind, x in parts:
                    if kind == "table":
                        out_.append(mf.table([[mf.cell(t) for t in row] for row in x]))
                    else:
                        out_.append(mf.para(mf.S[kind], x))
                return out_
            refs = c.get("refs", [])
            mf.make_article(path, c.get("title", "照合の原則の検証用文書"), body,
                            refs=(lambda b, refs=refs: [mf.para(mf.S["ref"], r) for r in refs]) if refs else None)
        if h not in plans:
            plans[h] = _mechanical(path, j)[1]
        plan = plans[h]
        pc = pdfmatch.compare(plan, c["pages"])
        fixes = plan_fixes(plan, pc)
        paras = {}
        for p in plan.paras.values():
            t = p.plain()
            mine = [f for f in fixes if f.src == p.src and not f.reason]
            paras[p.src] = {"orig": t, "fixed": expected_text(t, mine)}
        res["cases"][name] = {
            "ok": pc.ok,
            "unmatched": pc.unmatched,
            "diffs": [(d.src, d.docx, d.pdf, d.fixable, getattr(d, "why", "")[:8]) for d in pc.diffs],
            "fixes": [(f.src, f.kind, f.old, f.new, f.reason[:14]) for f in fixes],
            "ignored": getattr(pc, "ignored_lines", None),
            "paras": paras,
        }
    Path(out).write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")


def cmp(casefile, *paths):
    sys.path.insert(0, str(ORACLE))
    from runner import describe
    cases = load(casefile)
    data = [json.loads(Path(p).read_text(encoding="utf-8")) for p in paths]
    for name, c in cases.items():
        truth = c.get("truth", {})
        print(f"## {name}")
        for d in data:
            r = d["cases"].get(name)
            if r is None:
                print(f"  [{d['version']}] (なし)")
                continue
            bad = []
            for src, x in r["paras"].items():
                want = truth.get(x["orig"], x["orig"])
                if x["fixed"] != want:
                    ds = describe(x["orig"], x["fixed"], want)
                    tag = []
                    if ds["added"]:
                        tag.append("足した" + "・".join(f"「{s}」" for s in ds["added"]))
                    if ds["deleted"]:
                        tag.append("消した" + "・".join(f"「{s}」" for s in ds["deleted"]))
                    if ds["left"] or ds["not_added"]:
                        tag.append("直していない" + "・".join(f"「{s}」" for s in ds["left"] + ds["not_added"]))
                    bad.append(f"{src}: {' / '.join(tag)}  [{x['orig'][:30]}…→{x['fixed'][:60]}]")
            verdict = "VIOLATION" if any("足した" in b or "消した" in b for b in bad) else ("MISS" if bad else "OK")
            print(f"  [{d['version']}] {verdict}  unmatched={r['unmatched']} ignored={len(r['ignored'] or [])}")
            for b in bad:
                print(f"      {b}")
            txt = [f for f in r["fixes"] if f[1] == "text"]
            if txt:
                print(f"      fixes(text)={txt}")


if __name__ == "__main__":
    if sys.argv[1] == "run":
        run(sys.argv[2], sys.argv[3], sys.argv[4])
    else:
        cmp(sys.argv[2], *sys.argv[3:])
