"""b2_review regress: ルート1 とルート2 のレポートの 13 章を、段落 ID の集合で突き合わせる（文字は出さない）。
  python r12.py DIR_ROUTE1 DIR_ROUTE2"""
import re, sys
from pathlib import Path
def sec(path):
    txt = Path(path, "31_1_変換レポート.md").read_text(encoding="utf-8")
    i, j = txt.find("## 13."), txt.find("\n## 14.")
    out = {}
    for s in re.split(r"\n(?=### 13\.)", txt[i:j])[1:]:
        head = s.split("\n", 1)[0][4:8]
        rows = [l.split("|")[1].strip() for l in s.split("\n") if re.match(r"^\| d\d+ ", l)]
        out[head] = rows
    return out
a, b = sec(sys.argv[1]), sec(sys.argv[2])
r1_text, r1_width, r1_unm, r1_ign = set(a.get("13.1", [])), set(a.get("13.2", [])), set(a.get("13.3", [])), set(a.get("13.4", []))
r2_fix, r2_skip, r2_rest, r2_unm, r2_ign = set(b.get("13.1", [])), set(b.get("13.2", [])), set(b.get("13.4", [])), set(b.get("13.5", [])), set(b.get("13.6", []))
print("route1 13.1 文字の違いの段落", len(r1_text), "/ route2 13.1∪13.2", len(r2_fix | r2_skip))
print("  route1 にだけある（ルート2 で直さず 13.2 にも出ない）:", sorted(r1_text - r2_fix - r2_skip))
print("  route2 13.2 にあり route1 13.1 にない:", sorted(r2_skip - r1_text))
print("  route1 13.2（全角・半角）にだけあり route2 13.1 にない:", sorted(r1_width - r2_fix - r2_skip))
print("  見つからない段落 r1/r2 同じ:", r1_unm == r2_unm, sorted(r1_unm ^ r2_unm))
print("  照合に使わなかった文字の段落 r1/r2 同じ:", r1_ign == r2_ign, sorted(r1_ign ^ r2_ign))
print("  route2 13.4（直した後も残る違い）:", sorted(r2_rest), " うち 13.2 にない:", sorted(r2_rest - r2_skip))
