#!/bin/sh
# judge: 本誌の出版版 PDF（tests/private/pdf）で、base を変更前、R・G・J を変更後としてルート2（とルート1）を確かめる（順に実行）。
J=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/n10/judge
cd $J/realpdf
for x in R G J; do
  python -I check.py --before-src $J/base_src --after-src $J/${x}_src --route1 --tag _$x > $J/logs/real_$x.log 2>&1
  echo "real $x $(date +%T)"
done
