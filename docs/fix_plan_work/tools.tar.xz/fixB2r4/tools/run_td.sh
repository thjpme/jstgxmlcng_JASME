#!/bin/sh
# b2r3_regress: td1〜3 をルート2 とルート1 で変換する。 sh run_td.sh SRC TAG
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
F=$S/fixB2r4; SRC=$1; TAG=$2
for n in 1 2 3; do
  D=/home/user/jstgxmlcng_JASME/tests/private/colab/td$n
  (cd /tmp && PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=$SRC python -m jasme_jats $D/td$n.docx --meta /home/user/jstgxmlcng_JASME/examples/meta_example.toml \
     --pdf $D/td$n.pdf --route pdf --ai manual --out $F/td/${TAG}_r2/td$n > $F/td/${TAG}_r2_td$n.log 2>&1) &
  (cd /tmp && PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=$SRC python -m jasme_jats $D/td$n.docx --meta /home/user/jstgxmlcng_JASME/examples/meta_example.toml \
     --pdf $D/td$n.pdf --route docx --ai manual --out $F/td/${TAG}_r1/td$n > $F/td/${TAG}_r1_td$n.log 2>&1) &
done
wait
(cd /tmp && PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=$SRC python $F/tools/td_cmp_compare.py $F/td/cmp_$TAG.json)
echo "done $TAG"
