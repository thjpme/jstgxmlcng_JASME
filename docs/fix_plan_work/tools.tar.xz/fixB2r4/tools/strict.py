"""fixB2r1: 反例集の結果（oracle/results_*.json）で、直した後の段落の文字が、元の docx の文字とも truth（出版版）とも違う
段落（途中まで直した・別の文字にした）を数える。runner の判定（OK/REPORTED/FAIL）とは別の、厳しい見方。

  python strict.py results_a.json [results_b.json ...] [-v]
-v: その段落の元の文字・直した文字・truth も出す（架空の文字だけ）。
"""
import json
import sys


def main():
    files = [x for x in sys.argv[1:] if not x.startswith("-")]
    verbose = "-v" in sys.argv
    for f in files:
        data = json.load(open(f))
        rows = data if isinstance(data, list) else data.get("results", data.get("cases", []))
        bad = []
        for c in rows:
            for p in c.get("paras", []):
                o, fx = p.get("original"), p.get("fixed")
                t = p.get("truth") if p.get("truth") is not None else o
                if fx is None or fx == o or fx == t:
                    continue
                bad.append((c["name"], p.get("label"), p.get("src"), o, fx, t, c.get("verdict")))
        print(f"== {f}: 途中の文字の段落 {len(bad)}（反例 {len({b[0] for b in bad})}）")
        for name, label, src, o, fx, t, v in bad:
            print(f"  {v:8s} {name} {label}({src})")
            if verbose:
                print(f"     docx : {o}\n     fixed: {fx}\n     truth: {t}")


if __name__ == "__main__":
    main()
