"""fixB2r4: 反例集の結果（oracle/results_<名前>.json）から、名前が PREFIX で始まる反例だけを数え、版ごとに比べる。
  python sub_or.py PREFIX 名前...      # 最初の名前が比べる相手"""
import json
import sys
from collections import Counter
from pathlib import Path

O = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/oracle")
RANK = {"OK": 0, "REPORTED": 1, "FAIL": 2}
pre, names = sys.argv[1], sys.argv[2:]
data = {}
for n in names:
    cs = json.loads((O / f"results_{n}.json").read_text(encoding="utf-8"))["cases"]
    data[n] = {c["name"]: c["verdict"] for c in cs if c["name"].startswith(pre)}
for n in names:
    print(n, len(data[n]), dict(Counter(data[n].values())))
a = names[0]
for b in names[1:]:
    worse = [k for k in data[a] if k in data[b] and RANK.get(data[b][k], 3) > RANK.get(data[a][k], 3)]
    better = [k for k in data[a] if k in data[b] and RANK.get(data[b][k], 3) < RANK.get(data[a][k], 3)]
    print(f"{a} -> {b}: 悪くなった {len(worse)} {worse[:8]}・よくなった {len(better)}")
