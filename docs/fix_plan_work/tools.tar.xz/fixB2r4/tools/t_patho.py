"""judge: 照合の速さの悪い形（同じ文がくり返す長い論文。アンカーが少ない）。  python -I t_patho.py SRC"""
import sys
import time
from pathlib import Path
src = sys.argv[1]
sys.path.insert(0, src)
sys.path.insert(1, "/home/user/jstgxmlcng_JASME/tests")
import make_fixtures as mf  # noqa: E402
from jasme_jats.config import JournalConfig  # noqa: E402
from jasme_jats.pdfdocx import _mechanical  # noqa: E402
from jasme_jats.pdfmatch import compare  # noqa: E402
T = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/n10/judge/tmp")
S1 = "授業は全部で五回行い，各回の記録を観点ごとに分類した。"
S2 = "分類の結果は表に示すとおりであり，対応の見方が増えた。"
paras = [((S1 + S2) * 3 if k % 2 else (S2 + S1) * 3).replace("五回", "五回" + "一二三四五六七八九"[k % 9], 1).replace("表に", "表" + "甲乙丙丁戊己庚辛壬"[k // 9 % 9] + "に", 1) for k in range(80)]
path = T / "patho2.docx"
if not path.exists():
    mf.make_article(path, "照合の速さの検証用文書", lambda b: [mf.para(mf.S["sec1"], "１．はじめに")] + [mf.para(mf.S["body"], t) for t in paras])
_, plan = _mechanical(path, JournalConfig.load())
lines = []
for t in paras:
    t = "　" + t
    lines += [t[i:i + 24] for i in range(0, len(t), 24)]
pages = []
for i in range(0, len(lines), 45):
    pages.append("\n".join([f"（{i // 45 + 1}）"] + lines[i:i + 45]))
t0 = time.perf_counter()
pc = compare(plan, pages)
print(f"{time.perf_counter() - t0:.2f}s", "unmatched", len(pc.unmatched), "diffs", len(pc.diffs))
