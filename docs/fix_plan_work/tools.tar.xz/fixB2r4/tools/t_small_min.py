"""b2r3_regress: 小さな論文 100 本（fuzz8 の m_mix_311 の最初の 100 本）の照合の時間の、N 回の最小。  python -I t_small_min.py SRC [N]"""
import json
import sys
import time
from pathlib import Path
src = sys.argv[1]
N = int(sys.argv[2]) if len(sys.argv) > 2 else 5
sys.path.insert(0, src)
from jasme_jats.config import JournalConfig  # noqa: E402
from jasme_jats.pdfdocx import _mechanical  # noqa: E402
from jasme_jats.pdfmatch import compare  # noqa: E402
S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
jn = JournalConfig.load()
small = json.load(open(S / "rvB8_regress" / "fuzz8" / "m_mix_311" / "cases.json", encoding="utf-8"))[:100]
plans = [(_mechanical(c["docx"], jn)[1], c["pages"]) for c in small]
best = None
for _ in range(N):
    t0 = time.perf_counter()
    for plan, pages in plans:
        compare(plan, pages)
    t = time.perf_counter() - t0
    best = t if best is None else min(best, t)
print(round(best, 3))
