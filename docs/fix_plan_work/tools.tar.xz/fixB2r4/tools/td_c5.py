"""b2_review regress: tdN で、1 つの違い（TextDiff）の直す箇所が、すべて直るか、すべて直らないか（C5b）と、
直さない箇所がすべて理由付きか（13.2 に出るか）を確かめる（件数だけ出す）。  python -I td_c5.py SRC tdN"""
import sys
src, td = sys.argv[1], sys.argv[2]
sys.path.insert(0, src)
import difflib
import jasme_jats.pdfmatch as pm
from jasme_jats.config import JournalConfig
from jasme_jats.pdfdocx import _mechanical, plan_fixes
from jasme_jats.builder import word_note_marks
base = f"/home/user/jstgxmlcng_JASME/tests/private/colab/{td}/{td}"
j = JournalConfig.load(None)
_, plan = _mechanical(base + ".docx", j)
marks = {wid: m for wid, (_, m) in word_note_marks(plan, j).items()}
res = pm.compare(plan, pm.extract_pages(base + ".pdf"), marks)
fx = plan_fixes(plan, res)
mixed = 0
for d in res.diffs:
    if not d.fixable:
        continue
    mine = [f for f in fx if f.src == d.src and f.kind == "text" and d.start <= f.start and f.end <= max(d.end, d.start)]
    st = {bool(f.reason) for f in mine}
    if len(st) > 1:
        mixed += 1
print(td, "diffs", len(res.diffs), "why", sum(1 for d in res.diffs if d.why), "fixes", len(fx), "skipped", sum(1 for f in fx if f.reason),
      "mixed", mixed, "whys", sorted({d.why[:10] for d in res.diffs if d.why}))
