"""td1〜3 の照合（compare）と直す箇所（plan_fixes）を、指定した src で出す（作業用。結果は scratchpad の JSON だけ）。
PYTHONPATH=<src> python td_cmp_compare.py <出力 JSON>"""
import json, sys
from pathlib import Path
import jasme_jats
from jasme_jats import pdfmatch, pdfdocx
from jasme_jats.config import JournalConfig
from jasme_jats.pipeline import _mechanical
out = {}
for n in (1, 2, 3):
    d = Path(f"/home/user/jstgxmlcng_JASME/tests/private/colab/td{n}")
    doc, plan, _ = _mechanical(d / f"td{n}.docx", JournalConfig.load())
    pages = pdfmatch.extract_pages(d / f"td{n}.pdf")
    pc = pdfmatch.compare(plan, pages)
    fixes = pdfdocx.plan_fixes(plan, pc)
    out[f"td{n}"] = {"diffs": [(x.src, x.docx, x.pdf, x.start, x.end, x.fixable, x.why[:10]) for x in pc.diffs],
                     "fixes": [(f.src, f.start, f.end, f.new, f.kind, f.reason[:10]) for f in fixes],
                     "ignored": pc.ignored_lines}
Path(sys.argv[1]).write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
print(jasme_jats.__file__)
