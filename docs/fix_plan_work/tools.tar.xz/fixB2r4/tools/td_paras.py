"""b2_review regress: Colab の tdN の、元の docx・0.20.0 の直した docx・作業ツリーの直した docx の段落の文字を比べる
（端末にだけ出す。実際の論文の文字なのでファイルに書き写さない）。
  PYTHONPATH=<src> python td_paras.py tdN DIR_BASE DIR_NEW"""
import difflib, sys
from pathlib import Path
from jasme_jats.config import JournalConfig
from jasme_jats.pdfdocx import _mechanical
from jasme_jats.pdfmatch import is_width_pair, fold
td, db, dn = sys.argv[1:4]
J = JournalConfig.load()
orig = _mechanical(f"/home/user/jstgxmlcng_JASME/tests/private/colab/{td}/{td}.docx", J)[0]
base = _mechanical(Path(db) / "31_1_PDFに合わせた原稿.docx", J)[0]
new = _mechanical(Path(dn) / "31_1_PDFに合わせた原稿.docx", J)[0]
def ops(a, b):
    out = []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if tag != "equal":
            out.append((a[i1:i2], b[j1:j2], a[max(0, i1 - 10):i1], a[i2:i2 + 10]))
    return out
keys = sorted(set(orig) | set(base) | set(new), key=lambda s: (len(s), s))
n = 0
for s in keys:
    o, b, w = orig.get(s), base.get(s), new.get(s)
    if b != w:
        n += 1
        print(f"== {s}: orig→base {len(ops(o or '', b or ''))} ops, orig→new {len(ops(o or '', w or ''))} ops")
        for x, y, pre, post in ops(b or "", w or ""):
            print(f"   base→new: [{pre}]〔{x!r} → {y!r}〕[{post}]")
print("段落が違う:", n, "/", len(keys))
