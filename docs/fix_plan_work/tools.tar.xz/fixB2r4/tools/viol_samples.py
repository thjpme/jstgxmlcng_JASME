"""judge: fuzz8 の C の VIOLATION のうち、文字を消したものの例と、消した文字の長さ・群の分布。"""
import json
import sys
from collections import Counter
from pathlib import Path
S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
V = S / "n10" / "judge" / "v" / "f8"
sys.path.insert(0, str(S / "oracle"))
sys.path.insert(0, str(S / "rvB8_regress" / "fuzz8"))
import judge8  # noqa: E402
tag = sys.argv[1]
N = int(sys.argv[2]) if len(sys.argv) > 2 else 6
groups = [(d / "cases.json", d.name) for d in sorted((S / "rvB8_regress" / "fuzz8").glob("*_3[0-9][0-9]")) if (d / "cases.json").exists()]
lens, grp, shown, base_same = Counter(), Counter(), 0, Counter()
for cp, g in groups:
    r = json.load(open(V / f"{g}_{tag}.json", encoding="utf-8"))
    rb = json.load(open(V / f"{g}_base.json", encoding="utf-8"))
    cases = json.load(open(cp, encoding="utf-8"))
    for k, c in enumerate(cases):
        for doc, p in c["truth"].items():
            x = r["cases"][k]["paras"].get(doc)
            if x is None:
                continue
            v, _, ds = judge8.verdict(doc, p, x)
            if v != "VIOLATION":
                continue
            add = [a for a in ds["added"] if a.strip()]
            dele = [a for a in ds["deleted"] if a.strip()]
            if add or not dele:
                continue
            lens[min(sum(len(d) for d in dele), 10)] += 1
            grp[g.split("_3")[0]] += 1
            xb = rb["cases"][k]["paras"].get(doc)
            base_same[xb["fixed"] == x["fixed"]] += 1
            if shown < N:
                shown += 1
                print(f"## {g} case{k} {x['src']} 消した {dele}")
                print("  docx :", doc[:120])
                print("  truth:", p[:120])
                print("  fixed:", x["fixed"][:120])
print("消した文字の長さ（10 以上はまとめる）:", dict(sorted(lens.items())))
print("群:", dict(grp))
print("base と同じ直した後の文字か:", dict(base_same))
