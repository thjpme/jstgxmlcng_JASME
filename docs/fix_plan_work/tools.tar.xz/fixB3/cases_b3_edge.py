"""fixB3: 段落の先頭・末尾の違いで、同じ行に PDF の文字がなく、隣の行が照合に使わない行のとき（架空の文字）。
rvB8p/q.py の形（python -I q.py run SRC この.py OUT.json）。"""
FRONT = ["照合の原則の検証用文書", "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
BODY = "本文の段落の途中に，表の数字だけの行が入る場合を確かめる。"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
Y_END = "架空二郎（2021）．「架空の比の研究」．『架空教育研究』，第12巻，2018"
P_END = "架空三郎（2017）．「架空の図の研究」．『架空数学研究』，第30号，p.16"
PP_END = "架空太郎（2019）．「架空の題目」．『架空学会誌』，第29号，pp.11-16"
REF2 = "見本三郎（2019）．「見本の題目」．『見本誌』，第3巻，pp.5-8．"
CASES = {}


def page(*lines, no=1):
    return "\n".join([f"（{no}）", *lines])


# 1. 段落の最後の年・ページ（数字だけの行）が出版版で直されている／同じ
for name, ref, pub, k in [("year_end_fixed", Y_END, Y_END.replace("2018", "2019"), -4),
                          ("year_end_same", Y_END, Y_END, -4),
                          ("p_end_fixed", P_END, P_END.replace("p.16", "p.17"), -2),
                          ("p_end_same", P_END, P_END, -2)]:
    CASES[name] = dict(body=[("body", BODY)], refs=[REF2, ref],
                       pages=[page(*FRONT, BODY, "引用および参考文献", REF, REF2, pub[:k], pub[k:], *EN)],
                       truth={ref: pub} if ref != pub else {})
    # 次のページの最初の行
    CASES[name + "_pagetop"] = dict(body=[("body", BODY)], refs=[REF2, ref],
                                    pages=[page(*FRONT, BODY, "引用および参考文献", REF, REF2, pub[:k]),
                                           page(pub[k:], *EN, no=2)],
                                    truth={ref: pub} if ref != pub else {})
# 2. 「pp.11-」の行と次のページの「16」の間に、前のページの最後の行の柱（何ページにも出る行でないもの）がある
for name, num in [("pp_bottom_head_same", "16"), ("pp_bottom_head_fixed", "17")]:
    pub = PP_END[:-2] + num
    CASES[name] = dict(body=[("body", BODY)], refs=[REF2, PP_END],
                       pages=[page(*FRONT, BODY, "引用および参考文献", REF, REF2, PP_END[:-2], "架空の柱の行"),
                              page(num, *EN, "架空の柱の行", no=2)],
                       truth={PP_END: pub} if num != "16" else {})
# 3. 別の行の見出しの番号が出版版で直されている（「（1）」→「（2）」）／同じ
H = "（1）架空の授業の分析の方法と記録の観点"
B2 = "次に，記録した発言を三つの観点から分類し，それぞれの件数を述べる。"
for name, num in [("heading_number_fixed", "（2）"), ("heading_number_same", "（1）")]:
    CASES[name] = dict(body=[("body", BODY), ("sec2", H), ("body", B2)], refs=[],
                       pages=[page(*FRONT, BODY, num, H[3:], B2, "引用および参考文献", REF, *EN)],
                       truth={H: num + H[3:]} if num != "（1）" else {})
# 4. 校正で段落の最後が消された（次の行がほかの段落／ページの最初の柱）。前者は今までどおり消す
B3 = "本稿では，架空の授業の記録を観点ごとに整理し，その特徴を三つに分けて考察した。以上"
P3 = "本稿では，架空の授業の記録を観点ごとに整理し，その特徴を三つに分けて考察した。"
B4 = "次の段落は表の後ろに続く本文の段落であり，照合の確かめに使う。"
CASES["tail_deleted_next_para"] = dict(body=[("body", B3), ("body", B4)], refs=[],
                                       pages=[page(*FRONT, P3, B4, "引用および参考文献", REF, *EN)], truth={B3: P3})
CASES["tail_deleted_page_top_head"] = dict(body=[("body", B3), ("body", B4)], refs=[],
                                           pages=[page(*FRONT, P3), page("試験六郎", B4, "引用および参考文献", REF, *EN, no=2)],
                                           truth={B3: P3})
# 5. 段落の最初が校正で直された（前の行がページの最初の柱）。同じ行に PDF の文字があるので、今までどおり直す
B5 = "本稿は架空の授業を対象とする。授業は五回行い，記録の方法は次の節で述べる。"
P5 = B5.replace("本稿は", "本論文は")
CASES["head_replaced_after_head"] = dict(body=[("body", BODY), ("body", B5)], refs=[],
                                         pages=[page(*FRONT, BODY), page("試験六郎", P5, "引用および参考文献", REF, *EN, no=2)],
                                         truth={B5: P5})
# 6. 段落の最初が校正で消された（前の行がページの最初の柱）
B6 = "なお，本稿は架空の授業を対象とする。授業は五回行い，記録の方法は次の節で述べる。"
P6 = B6[3:]
CASES["head_deleted_after_head"] = dict(body=[("body", BODY), ("body", B6)], refs=[],
                                        pages=[page(*FRONT, BODY), page("試験六郎", P6, "引用および参考文献", REF, *EN, no=2)],
                                        truth={B6: P6})
# 7. 次の文献の年の数字と並べられる形（N10 の仲間。段落の後ろの数字が、窓の中の次の段落の数字と一致する）
for name, ref, pub, k in [("year_end_fixed_next_ref", Y_END, Y_END.replace("2018", "2019"), -4),
                          ("p_end_fixed_next_ref", P_END, P_END.replace("p.16", "p.17"), -2)]:
    CASES[name] = dict(body=[("body", BODY)], refs=[ref, REF2],
                       pages=[page(*FRONT, BODY, "引用および参考文献", REF, pub[:k], pub[k:], REF2, *EN)],
                       truth={ref: pub})
