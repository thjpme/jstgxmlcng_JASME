# N10 とその仲間（ルート2）の直し方の設計 ― 3 案の比べと、組み合わせ C

対象は 0.20.0（コミット 6ab1769）の `src/jasme_jats/pdfmatch.py`（と `pdfdocx.py` の `plan_fixes`）。直すのは、依頼の 1〜4
（1: 分断された段落の後ろ・前が照合の窓の外に出る N10 と仲間、2: 行末のハイフンをまたぐ 2 つの直し、3: 段落の最初・最後の黙った
違い、4: en dash〈利用者の判断待ち〉）。文字はすべて架空。実際の論文の結果は段落 ID と件数だけで書く。

この文書の数は、すべて judge（比べる担当）が、同じ道具・同じ条件で測り直したもの（設計担当の報告の数は使っていない）。

## 1. 結論

**joint（まとめての照合）を土台にし、その分類の段階に、guard と reanchor の考えを取り入れた守り（C1〜C5）を重ねる「組み合わせ C」に
する。** 試作は `n10/judge/C_src`（joint の `src` に守りを足したもの）。

- 照合（窓の決め方）は joint のもの: 全段落を docx の順につないだ列と PDF の列を、どちらにも 1 回だけ出る 8 文字のアンカーの
  最長増加列で単調に対応させ、アンカーの間を difflib で埋める（`_backbone`）。段落ごとの窓は「段落に割り当てた塊のある行」から
  作る列の位置のリストで、ほかの段落の塊の文字を含まない（`_window_lines`）。分断された段落の後ろ・前は、窓の外に出ず、
  分断された部分として照合され、そこにある校正の直しも直る。
- 守り（分類の段階。照合の結果を「足さない・消さない」側に倒す）:
  - **C1**（新規）段落の最初・最後の、同じ行の PDF にだけある文字は、一致した文字との間（または PDF にだけある文字どうしの間）に
    英文の単語の間でない空白があれば足さない（EDGE_WHY）。本文の横の図の中の文字が同じ行につながったものを足さないため。
    英文の段落の端に足すときは、単語の間の空白も足す。
  - **C2**（guard の規則）置き換えの PDF の側が docx の側より 20 文字以上長ければ直さない（LONG_WHY）。
  - **C3**（reanchor の WHOLE_WHY の考え）段落の途中の違いの PDF の側にある、どの段落にも当たらない行まるごとは、足さず、
    置き換えにも使わない（13.6 に出す。docx の文字だけが残る置き換えは WHOLE_WHY）。
  - **C4**（reanchor の `_drop_dates` の考え）受付日の文字列の一部だけと並んだ一致は外して照合し直す。
  - **C5**（新規）まとめた直しの範囲の全角・半角の直しはまとめた直しに含め、`plan_fixes` は 1 つの違いを分けた直す箇所を
    まとめて直すか、まとめて直さない。
- en dash は、joint と同じく `ENDASH`（"pdf" が案 (b)、"docx" が案 (a)）で切り替える。8 章。

理由（数は 3 章）: C は、原則を破る形（足す・消す）が 5 案の中でもっとも少なく（fuzz8 で docx にも PDF にもない文字を足した段落
0.20.0 3,728 → C 190。reanchor 305・guard 2,867・joint 2,711）、本当の校正の直しの取りこぼしも少なく（N10 146 件で FAIL 0・
OK 132。guard は FAIL 28）、本誌の出版版 PDF 7 通りで想定外の直し・誤報が 0、照合は 0.20.0 の 13 分の 1 の時間（18.5 秒 → 1.4 秒）、
既存のテストは 308 件のうち 307 件がそのまま通る（1 件は理由を付けて書き換える。7.3）。

## 2. 物差しと測り方

測った版: base（0.20.0）、R（reanchor `n10/reanchor/src_final`）、G（guard `n10/guard/src`。v14）、J（joint `n10/joint/src`。v28）、
C（組み合わせ `n10/judge/C_src`）。どれも `n10/judge/<版>_src` に写してから測った（測っている間に元のフォルダが変わらないように）。

| 物差し | 道具（scratchpad） | 測り方 |
|---|---|---|
| pytest | `n10/judge/tools/pytest_src.sh` | 本体の tests を、`-o pythonpath=<src> tests` で上書きして実行（`judge_which` で読んだコードを確かめた）。3.13 と 3.10 |
| 設計担当のテスト | `n10/judge/xtests/test_x_*.py` | R 16・G 24（+書き換え 2）・J 43・judge 16 を、5 つの版すべてで実行 |
| golden | `golden/golden.py` | `n10/golden_base`（0.20.0）と manifest を比べる（19 件） |
| 本誌の出版版 PDF | `n10/judge/realpdf/check.py`（realpdf_B/check.py に `--after-src` を足したもの） | `--before-src` に 0.20.0、`--route1`。5 本・7 通り |
| 反例集（oracle） | `oracle/run_all.py` | 34 件・N10 146 件（cases_n10）・guard の N10 139 件・rv89 28 件（rvB8p + rvB9p e1〜e6）・judge 39 件（cases_judge）・judge2 10 件（cases_judge2） |
| 点検の例（quick） | `n10/judge/tools/run_suites.sh` + `sum_q.py` | rvB2p・fixB3・rvB8p・rvB9p・rvB9_regress・joint の cases_island と、乱数の例（fz11〜104、bound1・2）。36 ファイル・126,057 段落 |
| 乱数の例 | 同上（`run8_all.py` + `sum_fz.py`） | rvB4_regress の fuzz4（2,400 本・20,413 段落）と rvB8_regress の fuzz8（24,300 本・221,544 段落） |
| 210 件 | `fixB/fixB_all.py --compare` | 0.20.0 と直す箇所が違うものを数える |
| 速さ | `n10/judge/tools/t_speed.py` | 7 通りの実 PDF の compare の合計（3 回の最小）と、fuzz8 の 100 本。2 回ずつ |

測り方で気づいたこと（報告の数と違う理由）:

- **reanchor の報告の「pytest 308 件通る」は、0.20.0 のコードを測っていた。** `cd /tmp && PYTHONPATH=<src> python -m pytest
  …/tests` は、pyproject の `pythonpath = ["src", "tests"]` が PYTHONPATH より前に入るので、本体の `src`（0.20.0）を読む
  （judge_which で確かめた）。R を正しく読むと、既存のテストが 3 件落ちる（3.1）。
- 乱数の例で、guard・reanchor は直す箇所のうち text だけを当てはめていた（`run8.py`）。ここでは、ルート2 と同じく全角・半角・空白を
  含むすべてを当てはめた（`run8_all.py`。joint と同じ）。版どうしの比べ方は同じなので、どちらでも順位は変わらないが、数は報告と違う。
- 点検の例（quick）の docx は内容のハッシュで共有の置き場に作るので、初回だけ順に作った（並列で作ると壊れた docx を読むことがある。
  1 件そうなったので作り直した）。

## 3. 測った数

### 3.1 テスト・golden・速さ

| | base | R | G | J | C |
|---|---|---|---|---|---|
| 既存のテスト 308 件（3.13・3.10 とも同じ） | 308 通る | 305（3 落ちる） | 306（2 落ちる。期待を書き換えたもの） | 308 | 307（1 落ちる。7.3 で書き換え） |
| R のテスト 16 件 | 4 | **16** | 6 | 8 | 10 |
| G のテスト 24 件 | 1 | 5 | **24** | 10 | 10 |
| J のテスト 43 件 | 13 | 30 | 21 | **43** | **43** |
| judge のテスト 16 件（`xtests/test_x_judge.py`） | 3 | 8 | 6 | 3 | **16** |
| golden 19 件（XML・AI 依頼文・レポート） | — | 同じ | 同じ | 同じ | 同じ |
| 実 PDF 7 通りの照合の合計（2 回） | 18.45・18.64 秒 | 19.32・18.92 | 18.57・18.82 | 1.36・1.47 | 1.39・1.37 |
| 小さな論文 100 本（2 回） | 1.07・0.91 秒 | 1.45・1.39 | 1.19・1.35 | 1.05・1.03 | 1.02・1.08 |
| fuzz8 の照合の時間の合計 | 432 秒 | 563 | 543 | 467 | 444 |
| pdfmatch.py の行数 | 890 | 1,922 | 1,233 | 1,891 | 1,985 |

R が落とす既存のテスト: `test_wrong_pdf_changes_nothing`（別の記事の PDF で、段落の一部を PDF 全体から探し直して違いを作る）、
`test_long_pdf_only_text_on_other_paragraph_line_is_not_reported`、`test_added_sentence_in_page_edge_line_is_only_reported`。
他の版のテストが落ちるのは、多くが定数・属性の名前の違い（`DISPLACED_WHY`・`SOFT_DASH_FIX`・`splits` など）と、「直す」か
「13 章に出す」かの期待の違い（G のテストは、J・C が直す形を DISPLACED_WHY で出すことを期待する）。振る舞いで比べるのは 3.3・3.4。

### 3.2 本誌の出版版 PDF（5 本・7 通り）

どの版も、組版の文字による挿入・削除 0→0、XML に入った受付日・ページ番号 0→0、不変性・最終・DTD・J-STAGE は 7 通りとも合格、
ルート1 の照合に使わなかった文字はルート2 と同じ。違うところ:

| | base | R | G | J・C |
|---|---|---|---|---|
| 見つからない段落（24 巻 25・29 巻 79） | 1・1 | 0・0 | 1・1 | 0・0 |
| わざと入れた違い以外の直し（29 巻 79・30 巻 59 table・text） | 2・4・4（d17・d42 の想定外の削除） | 0・0・0 | 0・0・0 | 0・0・0 |
| わざと入れた違い E1（29 巻 79） | 誤 | 直 | 直さない | 直 |
| 13.2 の直さない違い（わざと入れたもの以外） | 29 巻 79 で 1 | 29 巻 79 で 1（d35。EDGE_WHY） | 3（d17、d42 が 2 通り。どれも本文は docx と同じ誤報） | 0 |
| 13.6 の行数（24 巻 25・25 巻 77・27 巻 47 table・text・29 巻 79・30 巻 59 table・text） | — | 15・1・14・3・2・2・2 | 15・1・14・3・5・5・2 | 15・1・12・3・73・7・2 |

J・C は、29 巻 79 ページで 13.6 が 73 行になる（分断された段落の窓の中の図の中の文字 60 行など）。誤りではないが一覧が長くなる（9 章）。

### 3.3 反例集（oracle）

OK / REPORTED / FAIL の件数。

| | base | R | G | J | C |
|---|---|---|---|---|---|
| 原則の 34 件 | 34/0/0 | 34/0/0 | 34/0/0 | 34/0/0 | 34/0/0 |
| N10（cases_n10）146 件 | 73/12/61 | 128/18/0 | 94/24/28 | 132/14/0 | 132/14/0 |
| guard の N10 139 件 | 72/17/50 | 136/2/1 | 102/37/0 | 137/2/0 | 137/2/0 |
| rv89 28 件 | 1/16/11 | 7/18/3 | 1/24/3 | 7/18/3 | 7/18/3 |
| judge 39 件（cases_judge） | 25/1/13 | 26/5/8 | 26/7/6 | 26/3/10 | **34/4/1** |
| judge2 10 件（cases_judge2） | 4/0/6 | 6/2/2 | 4/2/4 | 3/2/5 | **8/1/1** |

- G の N10 の FAIL 28 件は、どれも「直していない」（分断された部分の校正の直し 21 件、校正で消された段落の最後の短い文 4 件、
  段落の最後の「。」、段落の最後の行の一文〈13 章にも出ない〉、図の中の写しの近くの直し）。足す・消すはないが、決められる直しを
  取りこぼす。
- R の guard の N10 の FAIL 1 件（n10g_table20_head_none）は、表のセルの文字「る量を別々に見」を足す（0.20.0 と同じ形）。
- rv89 の FAIL 3 件（rvB8p の slide_short_line・slide_page_top・digit_line_prev_fixed）は 0.20.0 から同じ（9 章）。
- C の judge の FAIL 1 件（jg_copy_fig20_del）と judge2 の FAIL 1 件（jg2_whole_fullline）は 3.5 と 9 章。

### 3.4 点検の例

| | base | R | G | J | C |
|---|---|---|---|---|---|
| quick 126,057 段落（OK / MISS 13 章 / MISS 黙って / VIOLATION） | 125,186 / 524 / 176 / 171 | 125,445 / 514 / 62 / 36 | 125,192 / 792 / 36 / 37 | 125,472 / 510 / 34 / 41 | **125,483** / 510 / 34 / **30** |
| quick: base より悪い（うち VIOLATION）／よい | — | 28（2）／344 | 2（0）／274 | 4（1）／352 | 7（1）／368 |
| fuzz4 20,413 段落（OK / MISS / VIOLATION、13 章に出ない OK でない段落） | 20,297 / 100 / 16、18 | 20,306 / 105 / 2、2 | 20,295 / 109 / 9、8 | 20,310 / 99 / 4、3 | **20,313 / 99 / 1、1** |
| fuzz4: base より悪い | — | 8 | 2 | 3 | 3 |
| fuzz8 221,544 段落（OK / MISS / VIOLATION） | 201,432 / 14,291 / 5,821 | 211,282 / 7,873 / 2,389 | 201,314 / 15,393 / 4,837 | 209,247 / 7,611 / 4,686 | **211,480** / 7,837 / **2,227** |
| fuzz8: 13 章に出ない OK でない段落 | 10,262 | 569 | 2,859 | 2,603 | **469** |
| fuzz8: base より悪い（うち VIOLATION）／よい | — | 43（8）／10,208 | 135（1）／985 | 31（12）／7,889 | 24（3）／**10,427** |
| fuzz8: docx にも PDF にもない文字を足した段落 | 3,728 | 305 | 2,867 | 2,711 | **190** |
| 210 件: base と直す箇所が違う | — | 14 | 26 | 24（すべてよくなった） | 24（J と同じ） |

- fuzz8 の VIOLATION のうち「文字を消した」1,700〜1,840 段落は、どの版にもほぼ同じ数ある。C では 1,804 のうち 1,735 が 0.20.0 と同じ
  直した後の文字で、ほとんどは、校正で足された 20 文字以上の文を足さない（LONG_WHY で 13 章に出す）ときに、判定の道具が docx の「。」を
  足された文の「。」と並べて「消した」と数えるもの（判定の道具の見かけ）。足した段落の数のほうが、版の違いをよく表す。
- J が base より悪い 31 段落のうち VIOLATION 12 は、隣り合う段落に同じ文がくり返す f11_39 の形と、受付日の文字との偶然の一致で年を
  壊す形（「20223」など）。C ではあとの形が C4 で直り、悪い段落は 24（VIOLATION 3）。
- 210 件で J・C が直す箇所の違う 24 件は、win3 6 件（段落の最後を消していた → 消さない）、num1 12 件（キャプションを足していた →
  足さずに「2→3」だけ直す）、num2 4 件（正しく直す）、そのほか 2 件。G は num1 の半角 6 件で正しい「12→13」も直さなくなる。

### 3.5 judge の反例（cases_judge・cases_judge2）でわかったこと

| 形 | base | R | G | J | C |
|---|---|---|---|---|---|
| jg_join_*（段落の最初・最後の行に、図の中の文字が同じ行としてつながる。8 件） | OK 8 | FAIL 6 | OK 8 | FAIL 7 | OK 8 |
| jg_edge_*（校正で段落の端に足された「。」・語。4 件） | FAIL 4 | OK 1・REP 3 | REP 4 | OK 3・REP 1 | OK 3・REP 1 |
| jg_tail2_*（分断の後ろが最後の 2 文字だけ。4 件） | FAIL 3 | OK 4 | FAIL 3（「た。」を消す） | OK 4 | OK 4 |
| jg_copy_fig*_del（消された最後の文の写しが、すぐ後ろの小さな図の中にある。2 件） | FAIL 2 | FAIL 2 | FAIL 2 | FAIL 2 | FAIL 1・REP 1 |
| jg_hy_zenkaku（docx「pp.45－58」、PDF「pp.46-」「59」） | FAIL | OK | FAIL（「pp.46-5-58」） | FAIL（同じ） | OK |
| jg2_numhead（docx にない見出しの番号「（２）」が PDF にある） | OK | FAIL（足す） | OK | FAIL（足す） | OK |
| jg2_whole_caption*（段落の途中にキャプションの行まるごと。2 件） | FAIL 2 | OK 2 | FAIL 2 | FAIL 2 | OK 2 |
| jg2_date_between_digits（「pp.21-」と「36．」の間に受付日の行） | FAIL（「3」を足す） | OK | FAIL | REP | OK |
| jg2_en_start（英文要旨の最初に校正で足された「Briefly,」） | FAIL | REP | REP | FAIL（空白が抜ける） | OK |

このほか、設計担当のテストの形を 5 つの版で動かした結果（`n10/judge/dbg/rtests.py`・`gtests.py`）:

- 受付日の行をはさむ引用文献の数字（「pp.6-」受付日「14．」）: base・G は「114」にする。R・C は直す。J は直さない（13 章）。
- 段落の行の間の、図の中の文字の行（14 文字）と次の行の「。」: base は「0）」を残して壊す、J は図の文字を足す。R・C は年だけ直す。
- 段落の最後の「29．」の次の行が「30．」＋受付日: base・J は「30．29．」にする。R・G は docx のまま 13 章、C は「30」に直す。
- 置き換えの位置の図の中の写し（30 文字）: base・J は写しで置き換える。G は直さない（LONG_WHY）、R・C は「志向→指向」だけ直す。
- 段落の最後の 8 文字が、ほかの段落と引用文献の後ろに出る: base・R はほかの段落の「付録」を足す。G は直さない、J・C は正しく直す。
- 表のセル「量を別々に見る」の「る」: base・R はセルの文字を足す。G・J・C は足さない。

## 4. 各案の弱点（反証）

### 4.1 reanchor（R）

- 0.20.0 の窓で照合した後に、段落の残りを PDF 全体から探し直す（`_find_part`・`_reanchor_end`）。別の記事の PDF でも段落の一部を
  見つけて違いを作る（既存のテスト `test_wrong_pdf_changes_nothing` が落ちる。直さないので docx は変わらない）。離れた位置の
  ほかの段落の文字を使う例もある（「付録」を足す、表のセルの文字を足す）。
- 段落の端の、同じ行の PDF にだけある文字を足す経路で、図の中の文字・見出しの番号を足す（jg_join 6 件・jg2_numhead）。
- 照合の後に、端の取り直し（`_trim_edges`・`_refit_edges`・`_reanchor_trimmed`・`_realign_masked`・`_reseat_edges`・`_drop_scatter`・
  `_drop_dates`）を何段も重ね、閾値が多い（SOLID=6・JUMP=30・REANCHOR_MIN=5・候補 12+4 か所・1.5n+12 など）。1,922 行。
- 小さな論文で 1.4 倍ほど遅い（実 PDF では同じ）。
- よいところ（C に取り入れた）: 段落の途中の行まるごとを足さない（WHOLE_WHY）、受付日の文字との偶然の一致を外す（`_drop_dates`）。

### 4.2 guard（G）

- 照合はそのままで、段落の文字とみなす塊を決め直し、外れた部分を直さない違い（DISPLACED_WHY）にする。安全側だが、分断された部分の
  本当の校正の直しを取りこぼす（N10 の FAIL 28、実 PDF の E1、210 件の num1 の半角 6 件）。
- 実 PDF で、本文は docx と同じなのに DISPLACED_WHY の誤報が 3 件（d17・d42）。13.2 の見比べが増える。
- 最後の 1〜2 文字は離れた位置を探さない（`_found_apart` は 3 文字以上）ので、0.20.0 と同じく消す（jg_tail2 3 件）。
- 段落の途中のキャプションの行まるごと（jg2_whole_caption）、受付日の行をはさむ数字（jg2_date_between_digits）は 0.20.0 と同じ誤り。
- よいところ（C に取り入れた）: 置き換えの PDF の側が 20 文字以上長いものを直さない規則。段落の端の PDF にだけある文字を黙って
  捨てずに EDGE_WHY で出す考え（joint にもある）。

### 4.3 joint（J）

- 照合はもっともよい（N10・guard の N10 の FAIL 0、210 件はすべてよくなる、実 PDF で誤報 0、照合が 13 倍速い）。
- 弱いのは分類の段階で、新しい経路と 0.20.0 から残る経路で文字を足す:
  - 段落の端の、同じ行の PDF にだけある文字を足す新しい経路で、図の中の文字・見出しの番号を足す（jg_join 7 件・jg2_numhead）。
  - 段落の途中の、どの段落にも当たらない 20 文字未満の行まるごとを足す（0.20.0 からの限界。fuzz8 の足した段落の大部分〈キャプションの
    行〉。jg2_whole_caption）。
  - 置き換えの位置の図の中の写しで置き換える（0.20.0 と同じ）。
  - 受付日の文字との偶然の一致で数字を壊す（「30．29．」「20223」。0.20.0 と同じ）。
  - 全角のハイフンをはさむ 2 つの直しで「pp.46-5-58」（0.20.0 は「pp.46 5-58」。`plan_fixes` が 1 つの違いの一部だけを当てはめる）。
  - 英文の段落の最初に足す語の後ろの空白が抜ける（jg2_en_start）。
  - 隣り合う段落に同じ文がくり返す形（f11_39）で、ほかの段落の文字を足す。
- C は、これらのうち f11_39 以外を守り C1〜C5 で止める（f11_39 は 9 章）。

## 5. 選んだ設計と理由、捨てた案と理由

**選ぶ: C（joint の照合 + 守り C1〜C5）。**

- 原則を最もよく守る: 足す・消す（VIOLATION）が quick 30（base 171・R 36・G 37・J 41）、fuzz4 1（base 16）、fuzz8 2,227（base 5,821・
  R 2,389・G 4,837・J 4,686）で、docx にも PDF にもない文字を足した段落は fuzz8 で 190（base 3,728・R 305・G 2,867・J 2,711）。
  黙って残る違い（13 章に出ない OK でない段落）も、quick 34・fuzz4 1・fuzz8 469 でもっとも少ない。
- 本当の校正の直しを取りこぼさない: N10 で OK 132・FAIL 0（G は FAIL 28）、分断の境目で校正で足された文字（editb・editb2 の 7 件）も
  すべて直す（R は 4 件、G は 7 件を 13 章に出すだけ）、
  fuzz8 の OK 211,480（もっとも多い）、210 件は J と同じくすべてよくなる。実 PDF の E1 も直る。
- 速さ: 実 PDF の照合は 0.20.0 の 18.5 秒から 1.4 秒。小さな論文でも 0.20.0 と同じ。
- 既存のテストは 307 件がそのまま通り、書き換える 1 件は原則に沿う（7.3）。golden は変わらない。

**捨てる: R 単独**（既存のテスト 3 件が落ちる。PDF 全体から探し直す経路と端の取り直しの段が多く、別の記事・離れた位置の文字と
並べる。足す経路が残る〈jg_join・jg2_numhead・「付録」〉。小さな論文で遅い）。**G 単独**（決められる直しを取りこぼす〈N10 FAIL 28〉、
実 PDF で誤報 3、0.20.0 から残る足す形〈キャプションの行・受付日の数字〉を止めない）。**J 単独**（4.3 の足す経路が残る。fuzz8 で
足した段落 2,711）。R と G のよい規則は C3・C4・C2 として C に入れた。

## 6. 関数ごとの変更点と入れる順

試作のコードはそのまま写せる: `n10/judge/C_src/jasme_jats/pdfmatch.py`・`pdfdocx.py`。0.20.0 との差分は
`n10/judge/C_vs_base_pdfmatch.patch`・`C_vs_base_pdfdocx.patch`、joint からの差分（守りだけ）は
`n10/judge/C_guards_vs_J_pdfmatch.patch`・`C_guards_vs_J_pdfdocx.patch`。`report.py` は 6.4 を足す（試作では変えていない）。

### 6.1 手順 1: まとめての照合（joint の `pdfmatch.py` をそのまま入れる）

`compare(plan, pages, fn_marks=None)`:
- 段落の列 `paras` を作るときに、`gaps`（その段落の直前に、照合しない docx の段落〈4 文字未満・画像だけなど〉があるか）も作る。
- 0.20.0 の手順 1・2（全体の `difflib`・`_window`・`_align(seq, st, (lo, hi))`）を、`jt = _joint(plan, paras, st, gaps)` と、段落ごとの
  `_align(seq, st, jt.windows[k])` に置き換える。`aligned[src] = (p, seq, gens, win, ops, jt.unsure[k])`、`owner` は `win[x]` で数える。
- `dense_lines`（どれかの段落の文字が ISLAND 文字より多く当たったか、行の文字の半分以上が当たった行。受付日の文字は数えない）を
  作り、`_classify` に渡す。
- 手順 4（新）: docx で隣り合う 2 つの段落の窓の間の、どの段落にも当たらない行（3 行・60 文字以下）を、前の段落の
  `ignored_lines` に記録する（校正で足された一文かもしれないので 13.6 に出す）。
- `_window` は使わなくなるので消す。

新しい定数・理由（joint のもの）: `JOINT_K=8`・`JOINT_SOLID=8`・`JOINT_GAP=20`・`JOINT_FREE=20`・`LINE_BONUS=1.5`・`JOINT_EDGE=5`・
`SENTENCE_END`・`ISLAND=2`・`ISLAND_REST=20`・`ISLAND_ROUNDS=10`・`SHORT_LINE=0.6`・`DASHES`・`ENDASH`・`DASH_WHY`・`DISPLACED_WHY`・
`EDGE_WHY`・`UNSURE_WHY`。

新しい関数・クラス（joint のもの。役割だけ書く。中身は試作のとおり）:
- `_JointResult`（段落ごとの窓〈列の位置のリスト〉と印 `unsure`: head・tail・flow・floaty・doubt・head_free・tail_free）。
- `_backbone(D, P)`: どちらにも 1 回だけ出る `JOINT_K` 文字のアンカーの最長増加列と、その間の difflib。`_runs`・`_match`・
  `_edge_block`・`_flow_paragraphs`。
- `_Joint`: `first_pass`（単調な対応から段落の塊。`trim` で端の疎らな行を外す）、`recheck_runs`（離れた塊を主な塊の隣に移すか、
  図の中の写しかもしれない塊に doubt の印）、`fill_holes`・`find_hole`（塊に入らなかった部分を、隣の塊のすぐ隣 → 段落の後ろ〈前〉の
  どの段落にも当たらない文字の続き → アンカー、の順に探す。最大 6 回）、`release_islands`・`line_islands`（ほかの段落の塊に挟まれた
  1〜2 文字の塊、1 行の中だけの 2 文字以下の一致を外す）、`contests`（`_contests`: 同じ行の 2 段落の境目を LCS と行の境目の点で
  決め直す）、`result`（`_window_lines` で窓を作り、段落の最初・最後の docx の文字の位置を決められないか〈UNSURE〉を決める）。
- `_joint`・`_unique_piece`・`_lcs_prefix`・`_contests`・`_side_line`・`_window_lines`。

変える関数（joint のもの）:
- `_hyphen_key`: `DASHES` も「-」にする。
- `_align(seq, st, win)`: 窓を列の位置のリストで受け取る。`_line_islands` の行を外して照合し直す（最大 `ISLAND_ROUNDS` 回）。
  新しい `_line_islands`。
- `_slide_inserts`・`_whole_lines`: `lo + j` を `win[j]` にする（行の境目・行全体の判定を窓の位置で行う。続いた行は列の上でも
  続いているものだけ）。
- `_ignored_rows(st, win, …)`: 同じく `win`。
- `_classify(p, seq, gens, win, ops, unsure, st, owner, owned_lines, res, dense_lines)`: 窓の位置は `win[j]`。主な変更は
  ①段落の最初・最後の一致が 1 行の中だけの 2 文字以下（weak）なら、その外側の違いを EDGE_WHY にし、その一致の全角・半角も直さない、
  ②`head_short`・`tail_short`（`SHORT_LINE`）、③`floaty`（分断する表・図の中の文字とみなす位置）は照合に使わず 13.6 に記録、
  ④本文の流れの段落では段落の前後の PDF にだけある文字（同じ行のもの）も扱う（`cut_prev`・`cut_next`。続きの行があれば EDGE_WHY、
  段落の最後が文の終わりの記号で終われば直す）、⑤段落の最初・最後の docx の文字の位置を決められなければ UNSURE_WHY（消さない）、
  ⑥`loose` は `dense_lines` で見る、⑦doubt の行の違いは DISPLACED_WHY、⑧en dash（`forced`・`ENDASH`。8 章）。
- `_report_regions(…, forced, res, near=12, width=None)`: 近い違いをまとめるとき、PDF の文字を「違う部分ごとの PDF の文字」と
  「その間の一致した部分の docx の文字（全角・半角だけが違う文字は PDF の文字）」で作る（依頼 2。行末のハイフンを落とさない）。
  まとめた違いが PDF にだけある文字で始まるときは、まとめた範囲の最初の docx の文字の前に足す（0.20.0 と同じ位置）。

### 6.2 手順 2: 守り C1〜C5（judge。`C_guards_vs_J_*.patch`）

- **C4 `_date_islands(ops, w, st, win)`**（新）: 一致した塊の中の受付日の文字（`st.date >= 0`）のうち、その受付日の文字列の一部だけと
  並んだもの（その受付日の文字数より少ない）の窓の位置。`_align` の照合し直しの集合に足す
  （`isl = _line_islands(...) | _date_islands(...)`）。docx に受付日の文字列がそのままある段落は、文字列全体と並ぶので外さない。
- **C3 `_whole_free_lines(js, win, st, owner, mine)`**（新）と `_classify`: 段落の途中の違い（`0 < i1 and i2 < len(seq)`）の、
  照合に使う PDF の文字 `js` に、窓の中の文字がすべて `js` にあり、どれもどの段落にも当たらない行があれば、その行を `js` から外し、
  `_ignore` で 13.6 に記録し、`stray` に入れる。外した後に `js` が空なら、docx の側に文字があるときだけ `WHOLE_WHY`（新しい理由）の
  直さない違いにし、ないとき（PDF にだけある文字）は何も足さない。置く場所は、`js` を作った直後、`if not docx_side:` の前。
- **C2**（`_classify`、docx の側に文字がある分岐。`HEAD_WHY` の判定の後）: `len(js) - （docx の側の SKIP でない文字の数） >= 20` なら
  `LONG_WHY` の直さない違い。
- **C1**（`_classify`、段落の最初・最後の分岐。`cont` の判定の後）: `tag == "insert"` で `cont` でないとき、最後なら
  `[win[last_eq]] + js の位置`、最初なら `js の位置 + [win[first_eq]]` の隣り合う 2 文字のどこかで、後ろの文字に `space_before` があり、
  2 文字がともに英文の文字（`_latin`）でなければ `cont = True`（EDGE_WHY）。
- **C1b**（`_report_regions`、まとめない 1 つの insert で、段落の最初か最後のもの）: 段落の一致した文字との間が英文の単語の間の
  空白（`_pdf_space`）なら、足す文字の後ろ（最初）・前（最後）に空白を足す。
- **C5a**（`_report_regions`）: 直せるまとめた違い（`len(group) > 1`）を出した後、その docx の範囲 `[a, b)` の中の `width` の項目を消す
  （PDF の文字はまとめた違いの文字に入っている）。
- **C5b**（`pdfdocx.plan_fixes`）: 1 つの違い（TextDiff）を文字ごとに分けた直す箇所に、違いの番号を付ける。重なりで直さない箇所が
  1 つでもある違いは、その違いの直す箇所をすべて「ほかの直す箇所と重なる」にし、決まるまで重なりの判定をくり返す。

### 6.3 手順 3: en dash の切り替え（8 章）

`ENDASH` を `compare(…, endash=ENDASH)` の引数にして `_classify` まで渡す（モジュールの変数を書き換えずに済むように）。利用者が
どちらかに決めたら定数で固定する。両方を選べるようにするなら `Options.endash`（"pdf"・"docx"）→ `pipeline` の `check_pdf` と
`pdfdocx.make_fixed_docx` → `check_pdf(…, endash=)` → `compare`、CLI の `--endash`、Colab の手順 2 の選択（`tools/make_notebook.py`）。

### 6.4 手順 4: レポート（`report.py`）

`WHY_MARKS` に `DISPLACED_WHY`・`EDGE_WHY`・`UNSURE_WHY`・`WHOLE_WHY`・`DASH_WHY` の添え書きを足す（足さないと、ルート1 の 13.1 と
Colab の枠に「（直せない違い）」と出て、13.2 の PDF の欄が 30 文字で切れる）。13 章の節は増やさない（13.6 はそのまま使う）。

### 6.5 手順 5: 文書・版

`docs/DESIGN.md` 4.4（照合の手順をまとめての照合に書き換え、守りと新しい理由、限界）、`docs/DEVELOPMENT.md` の「残っている課題」
（N10 と行末のハイフンの 2 行を消し、9 章の限界を書く）、`docs/FIX_PLAN.md`、pdfmatch.py の冒頭の説明。ルート2 の XML とレポートの
形が変わるので 0.21.0。ノートブックは `Options` を変えたときだけ作り直す。

入れる順: (1) 7 章のテストを先に入れて 0.20.0 で落ちることを確かめる → (2) 6.1（joint）を入れ、既存のテストと J のテストが通ること、
golden が変わらないことを確かめる → (3) 6.2 の守りを C4・C3・C2・C1（C1b）・C5 の順に 1 つずつ入れ、そのたびに judge のテストと
quick・N10 を回す → (4) 6.3 → (5) 6.4・6.5 → (6) 7.4 の物差しをすべて回す。

## 7. テストの計画と合格の条件

### 7.1 足すテスト（`tests/test_pdfmatch.py`。文字はすべて架空）

- joint のテスト 43 件（`n10/joint/tests_new/test_joint_n10.py`。0.20.0 で 30 件落ちる）: 分断（表・図・ほかの段落・読み順の逆転・
  引用文献の後ろ）、表の行の数字、柱と同じ文字、段落の端の穴、同じ文、表の後ろの最後の語の直し、ページの最初の年の行、行末の
  ハイフンをまたぐ 2 つの直し（依頼 2）、段落の最初・最後の直し（依頼 3）、en dash（依頼 4）。
- judge のテスト 16 件（`n10/judge/xtests/test_x_judge.py`。7.3 の書き換えた既存のテスト 1 件を含む。0.20.0 で 13 件、joint で 13 件
  落ちる）: C1（図の中の文字が端の行につながる 2 件・「。」の後ろの図の文字・見出しの番号・英文の端の語 2 件と対照の「。」）、
  C3（キャプションの行 2 件と対照の組み直し）、C2、C4（行の途中で受付日につながった年・受付日の行をはさむ数字）、C5（全角の
  ハイフン・`plan_fixes` の一括）。
- reanchor・guard のテストのうち、C で通る形を足す（名前・理由を C のものにする）: R の `test_tail_after_table_is_matched_as_part`・
  `test_head_before_figure_is_matched_as_part`・`test_middle_split_by_other_paragraph`・`test_short_tail_after_table_is_not_deleted`・
  `test_received_date_between_digits_is_not_matched`・`test_unowned_line_inside_paragraph_is_not_inserted`、G の
  `test_tail_after_other_paragraphs_is_not_deleted`・`test_hyphen_between_two_fixes_is_kept`・`test_hyphenation_between_two_fixes_has_no_space`・
  `test_short_match_moved_next_to_previous_block`・`test_real_corrections_next_to_split_are_fixed`。
- en dash: 案 (a)・(b) の両方（`monkeypatch` か `endash` 引数）。行末が U+FFFE のときは両方とも docx のまま。
- 反例集（`n10/cases_n10.py`・`cases_n10_guard.py`・`cases_judge.py`・`cases_judge2.py`）は、本体には入れず scratchpad の oracle で
  回す回帰の物差しにする（実行に時間がかかり、判定の道具も scratchpad にある）。テストに移すのは上の形。

### 7.2 消す・変えないテスト

既存のテストは、7.3 の 1 件を除き変えない（C で 307 件がそのまま通る）。

### 7.3 書き換えるテスト（理由つき）

`test_added_sentence_in_page_edge_line_is_only_reported` の前半（ページの途中の行にまるごと入った 12 文字の一文を足す）を、
「足さずに照合に使わなかった文字として記録する（`("d12", added) in pc.ignored_lines`、違い・直す箇所なし）」にする。理由: 段落の途中の
本文の行は両端そろえで行の幅いっぱいになり、校正で足された文は前後の行の組み直しになる（行の途中から始まる）ので、段落の途中に
行まるごと PDF にだけある短い文字は、docx にない図・表の中の文字（キャプション・軸の名前）と区別できない（C3）。足すと図表の文字が
本文に入る（fuzz8 で足した段落の大部分がこの形）。後半（ページの端の行）は変えない。書き換えた版は
`n10/judge/xtests/test_x_judge.py` の最後にある。

### 7.4 物差しでの合格の条件（C の試作の数。これより悪くしない）

- pytest: すべて通る（3.13・3.10）。足したテストのうち 0.20.0 で落ちるものが 40 件以上。
- golden: 19 件とも XML・AI 依頼文・レポートが 0.20.0 と同じ。
- 本誌の出版版 PDF 7 通り: 組版の文字による挿入・削除 0、XML の受付日・ページ番号 0、不変性など合格 7/7、見つからない段落 0
  （24 巻 25・29 巻 79）、わざと入れた違い以外の直し 0、E1 直、わざと入れた違い以外の 13.2 の直さない違い 0、ルート1 とルート2 の
  照合に使わなかった文字が同じ。
- 反例集: 34 件すべて OK、N10 146 件の FAIL 0（OK 132 以上）、guard の N10 の FAIL 0、rv89 の FAIL は既知の 3 件だけ、judge 39 件の
  FAIL 1 以下（jg_copy_fig20_del）、judge2 10 件の FAIL 1 以下（jg2_whole_fullline）。
- quick: VIOLATION 30 以下、MISS（黙って）34 以下、0.20.0 より悪い段落 7 以下（うち VIOLATION 1。f11_39）。
- fuzz4: VIOLATION 1 以下、13 章に出ない OK でない段落 1 以下。fuzz8: OK 211,480 以上、VIOLATION 2,227 以下、足した段落 190 以下、
  13 章に出ない OK でない段落 469 以下、0.20.0 より悪い段落 24 以下（うち VIOLATION 3）。
- 210 件: C と同じ（0.20.0 と違うのは 24 件で、すべてよくなる）。
- 速さ: 実 PDF 7 通りの照合の合計 3 秒以下（0.20.0 は 18.5 秒）、小さな論文 100 本は 0.20.0 の 1.2 倍以下。

## 8. 依頼 4（en dash）の (a)・(b)

どちらも、docx の「–」を消さない（0.20.0 は消していた）。PDF の行末が U+FFFE（何の字形か分からない）なら、どちらも docx のまま
で違いにしない。照合では、docx のダッシュ（`DASHES`）を `_hyphen_key` でハイフンと同じ文字とみなす（違う文字とみなすと、行末の
ハイフンを無視するので「–」が消える）。

- **案 (b) PDF に合わせて「-」に直す**（`ENDASH = "pdf"`。joint・C の既定）: `_classify` で、docx のダッシュと PDF の英数字の後の行末の
  「-」「‐」が並んだら、`forced[j] = "-"` にして直せる違いにする。ルート2 は「–」→「-」を変更履歴で直し（13.1）、XML も「-」。
  ルート1 は 13.1 に直せる違いとして出る。影響: 段落の途中の「–」と PDF の「-」は 0.20.0 からふつうの違いとして「-」に直しているので、
  行末の位置でも同じになる（同じ論文の中で、行の途中は直し行末は直さない、ということがない）。
- **案 (a) docx のまま 13 章に出す**（`ENDASH = "docx"`）: 同じ位置を `DASH_WHY` の直さない違いにする。ルート2 は 13.2（直さなかった
  箇所）に出て、XML は「–」のまま（PDF と 1 文字違う。利用者が見比べて直す）。ルート1 は 13.1 に添え書きつきで出る。
- 影響の大きさ: 本誌の出版版 PDF 5 本で、英数字の後の行末の「-」は 7 か所（どれも「数字-」改行「数字」のページの範囲）、U+FFFE は
  19 か所、PDF の中の「–」は 1 か所。docx にその位置の「–」があるときだけ違いが変わるので、論文 1 本で多くて数か所。
- `DASHES` の範囲: joint・C は「–—―−‒」（en dash・em dash・水平線・マイナス・数字幅のダッシュ）、guard・reanchor は「–」だけ。依頼は
  en dash なので、本体では「–」だけから始め、ほかは利用者の判断を待つことを勧める（em dash を「-」に直すかは別の判断）。
- judge の勧め: (b)。PDF の文字は pdfium が U+002D と読んだもので字形が決まっており、行の途中との一貫性もある。

## 9. 残る限界

1. 消された最後の文の写しが、段落のすぐ後ろの小さな図（20 文字ほど）の中にある形では、写しと並べて「．」に直す（jg_copy_fig20_del。
   どの版も同じ。60 文字の図なら C は 13 章に出す）。
2. 隣り合う段落に同じ文がくり返し、その近くに校正の直しがある形で、ほかの段落の文字を足す（quick の f11_39 の 1 段落。joint から）。
3. rvB8p の 3 件（短い行・ページの最初の行に行の境目でそろえた挿入、前の行の続きの数字の直し）は 0.20.0 と同じ。
4. 段落の途中に行まるごと入った校正の一文は足さない（13.6 に出す。C3）。組み直しで行の途中から始まる本当の挿入は直す。quick で
   3 段落（人工的に行を分けた例）が OK → 13 章になる。
5. 段落の端の、同じ行の PDF にだけある文字は、空白をはさまずにつながった図の中の文字なら足しうる（C1 は空白を手がかりにする）。
   続きの行がありうる・1〜2 文字の偶然の一致のときは EDGE_WHY で 13 章に出る（直らない）。
6. 校正で足された 20 文字以上の文は足さない（LONG_WHY で 13 章）。0.20.0 と同じ。
7. 英文・和文がまじる位置で、足す文字を空白の前に置くか後ろに置くか（fuzz8 で 233 段落）、足す文字のすぐ隣の全角・半角の句読点
   （135 段落）は 0.20.0 からの限界（足す位置は `plan_fixes` の「直前の docx の文字の後ろ」）。
8. 13.6 が長くなる（29 巻 79 ページで 73 行。分断された段落の窓の中の図の中の文字）。害はないが、段落ごとに行数と最初・最後の行に
   まとめる表示（数字だけの行と同じ）にすると読みやすい（report.py。任意）。
9. 定数（JOINT_K・JOINT_GAP・JOINT_FREE・ISLAND・SHORT_LINE・20 文字など）は架空の例と本誌の 5 本で決めた。出版社の別の組版ソフトの
   PDF（取り出しの順・空白の入り方が違うもの）では、試験運用で確かめる。同じ文の繰り返しが多い論文はアンカーが少なく、difflib で
   埋める範囲が広くなる（0.20.0 と同じ程度の時間になる）。
10. 判定の道具の見かけ: fuzz8 の「文字を消した」の大部分と jg2_whole_fullline は、足さなかった長い文を判定の道具が「消した」・
    「13 章に出ていない」と数えるもので、ツールは 13 章（LONG_WHY・13.6）に出している。

## 10. 付録: ファイル

- 試作: `n10/judge/C_src`（組み合わせ C）。比べた版の写し: `n10/judge/base_src`・`R_src`・`G_src`・`J_src`。
- 差分: `n10/judge/C_vs_base_pdfmatch.patch`・`C_vs_base_pdfdocx.patch`・`C_guards_vs_J_pdfmatch.patch`・`C_guards_vs_J_pdfdocx.patch`。
- テストの案: `n10/judge/xtests/test_x_judge.py`（judge の 16 件と書き換えた既存のテスト）、`test_x_joint.py`・`test_x_reanchor.py`・
  `test_x_guard.py`（設計担当のものの写し）。
- 反例: `n10/cases_judge.py`（39 件）・`n10/cases_judge2.py`（10 件）。
- 物差しの道具: `n10/judge/tools/`（`master_one.sh`・`run_suites.sh`・`run_oracle.sh`・`sum_q.py`・`sum_fz.py`・`cmp_fz.py`・
  `viol_kinds.py`・`t_speed.py`・`pytest_src.sh`）、`n10/judge/realpdf/check.py`、`n10/judge/dbg/`。結果: `n10/judge/v/`・`logs/`、
  `oracle/results_judge_*.json`、`n10/judge/realpdf/out/summary_*.txt`（実際の論文の文字を含むので、外に出さない）。
