"""N10 の 3 案（reanchor・guard・joint）を比べる担当（judge）の反例。文字はすべて架空（実際の論文の文字を書き写していない）。

oracle/run_all.py の書式（oracle/runner.py の docstring）。実行（scratchpad の oracle/ で）:
  python run_all.py <src> ../n10/cases_judge.py --name <名前>
期待は原則だけで決める（出版版 PDF の本文と同じにする。表・図の中の文字・ほかの段落の文字を足さない。本文の文字を消さない。
決められないものは 13 章に出す）。どの版の結果にも合わせない。

各案の新しい経路を突く形:
  jg_join_*     段落の最初・最後の行に、同じ行として図の中の文字（docx にない）がつながる（段落の端の、同じ行の PDF にだけある
                文字を足す経路〈joint・reanchor〉）。校正で足された「。」の対照も入れる
  jg_dup_*      段落の最後の文と同じ文が、すぐ後ろの段落の途中にもあり、最後の文が表で分断される（同じ文の取り合い）
  jg_far_*      分断された最後の文と同じ文が、離れたほかの段落にもある（PDF 全体から探し直す経路〈reanchor〉）
  jg_wrong_pdf  別の記事の PDF（段落はどれも見つからないはず。PDF 全体から探し直す経路が、別の記事の文字と並べないか）
  jg_rev_*      段落の後半が前半より前に出る（読み順の逆転）
  jg_digits_*   表で分断された最後の文の数字が出版版で直され、表のセルに同じ数字がある
  jg_long_*     分断された最後の文に、校正で 20 文字以上の文が足された
  jg_note_*     段落がページの区切りで続き、前のページの最後に注の段落（docx では注の節）が入る
  jg_tail2_*    分断の後ろが最後の 2 文字だけ
  jg_copy_*     最後の文の写し（句点が「．」）が、すぐ後ろの小さな図（20・60 文字）の中にある
  jg_hy_*       行末のハイフンをまたぐ 2 つの直しの仲間（en dash・全角のハイフン）
  jg_edge_*     段落の最初・最後の校正の直しの仲間（すぐ隣の行が図の中の文字・表のキャプション）
"""
from __future__ import annotations

import unicodedata

from runner import BREAK, DEFAULTS, Raw, flow, journal_line  # noqa: F401

KINSOKU = "，。、．）」』！？"


def _w(c: str) -> float:
    return 1.0 if unicodedata.east_asian_width(c) in ("F", "W", "A") else 0.5


def jwrap(text: str, width: float = 24) -> list:
    lines, cur, n = [], "", 0.0
    for c in text:
        if cur and n + _w(c) > width and c not in KINSOKU:
            lines.append(cur)
            cur, n = "", 0.0
        cur += c
        n += _w(c)
    if cur:
        lines.append(cur)
    return lines


def body(text: str, indent=True) -> list:
    return jwrap(("　" if indent else "") + text)


def _check(cond, msg):
    if not cond:
        raise ValueError("反例の組み立ての誤り: " + msg)


def front() -> Raw:
    return Raw(journal_line(fp=41, lp=52), DEFAULTS["題目"], DEFAULTS["副題"], "架空大学　試験　五郎")


def en_block() -> Raw:
    return Raw(DEFAULTS["英文題目"], DEFAULTS["英文副題"], "Goro SHIKEN", "Fictional University", "Abstract",
               DEFAULTS["英文要旨"])


CASES = []


def case(name, item, paras, pages, note, truth=None, expect="exact"):
    CASES.append({"name": name, "angle": "layout", "item": item, "paras": paras, "truth": truth or {},
                  "pages": pages, "expect": expect, "note": note})


def idx(paras, text):
    found = [i for i, (_, t) in enumerate(paras) if t == text]
    _check(len(found) == 1, f"段落「{str(text)[:16]}」が {len(found)} 個")
    return found[0]


# ============================================================================ 架空の論文
H1, H2, H3, RH = "１．はじめに", "２．授業の様子", "３．考察", "引用および参考文献"
INTRO = ("本稿の目的は，架空の小学校で行った割合の授業において，児童が基準量と比較量の関係をどのように説明したかを，"
         "授業の記録から明らかにすることである。")
CTRL = "記録の対象は，第５学年の二つの学級で4回行った授業である。授業者は架空の教諭二名である。"
CTRL_PUB = CTRL.replace("4回", "４回")
A_HEAD = ("第二時の授業では，教師はまず前時に使った帯図を黒板に示し，基準にする量と比べる量の関係を確かめさせた。"
          "続いて，帯図の下に数直線をかき，二つの量の割合を数直線の上に書き入れる活動を示した。")
A_TAIL = "最後に，教師は基準にする量が変わると割合がどうなるかを問い，児童どうしで考えを伝え合う時間を設けた。"
A = A_HEAD + A_TAIL
B = ("話し合いでは，ある児童は基準にする量が二倍になると割合は半分になると述べ，別の児童は帯図の長さを比べて"
     "その理由を説明した。教師は二人の説明を並べて板書した。")
DISC = ("このような説明が生まれた理由として，帯図と数直線を並べてかく活動によって，二つの量の関係に児童の目が向いたことが"
        "考えられる。ただし，割合を式で表すことに困難を感じる児童も多かった。")
END = "今後は，ほかの学年でも同じような説明が見られるかを確かめていきたい。"
R1 = "架空一子（2018）．「割合の学習における帯図の役割」．『架空算数教育研究』，第21号，pp.31-38"
R1_LINES = ["架空一子（2018）．「割合の学習における帯図の", "役割」．『架空算数教育研究』，第21号，pp.31-38"]
_check("".join(R1_LINES) == R1, "R1")

TAB_CAP = "表２　架空の学級ごとの説明の数"


def table(total):
    rows = [["学級", "前半", "後半"]]
    n, k = len(TAB_CAP) + 6, 0
    while n < total:
        row = ["ＡＢＣＤＥＦＧＨ"[k % 8] + "組", str(11 + (k * 5) % 19), str(7 + (k * 3) % 13)]
        rows.append(row)
        n += sum(len(c) for c in row)
        k += 1
    return rows


def table_lines(rows):
    return [TAB_CAP] + [" ".join(r) for r in rows]


FIG_CAP = "図２　架空の帯図と数直線"
FIG_WORDS = ["基準にする量", "比べる量", "割合", "帯図", "数直線", "０", "１", "２倍", "半分", "もとにする大きさ",
             "比べられる大きさ", "目盛り", "全体", "部分"]


def figure(total):
    out, n, k = [], len(FIG_CAP), 0
    while n < total:
        w = FIG_WORDS[k % len(FIG_WORDS)] + ("" if k < len(FIG_WORDS) else "（" + "一二三四"[k // len(FIG_WORDS) % 4] + "）")
        out.append(w)
        n += len(w)
        k += 1
    return out + [FIG_CAP]


def paras_of(target, before=(), after=(), extra_after=(), b_text=B, end=END):
    return ([("見出し", H1), ("本文", INTRO), ("本文", CTRL), ("見出し", H2), *before, ("本文", target), *after,
             ("本文", b_text), *extra_after, ("見出し", H3), ("本文", DISC), ("本文", end), ("引用文献見出し", RH),
             ("引用文献", R1)])


def pages_of(target_blocks, b_lines=None, extra_blocks=(), end=END):
    return flow([front(), H1, Raw(*body(INTRO)), Raw(*body(CTRL_PUB)), H2, *target_blocks,
                 Raw(*(b_lines or body(B))), *extra_blocks, H3, Raw(*body(DISC)), Raw(*body(end)), RH,
                 Raw(*R1_LINES), BREAK, en_block()], first=41)


T0 = {2: CTRL_PUB}       # 確かめ用の直し（「4回」→「４回」）。どの反例にもある（段落の番号は paras_of で 2）

# ============================================================================ 1. 段落の端の行に、図の中の文字が同じ行としてつながる
FIG_SIDE = ["深さ（cm）", "時間（分）", "１０", "２０", "３０", "図３　架空の変化のグラフ"]
for label, where in (("時間（分）", "end"), ("点Ｐの位置", "end"), ("点Ｐの位置", "start"), ("目盛り", "start")):
    lines = body(A)
    if where == "end":
        lines = lines[:-1] + [lines[-1] + "　" + label]
    else:
        lines = [label + "　" + lines[0]] + lines[1:]
    for nxt in ("para", "fig"):
        paras = paras_of(A, after=[("画像", "グラフ"), ("図キャプション", "図３　架空の変化のグラフ")] if nxt == "fig" else ())
        blocks = [Raw(*lines)] + ([Raw(*FIG_SIDE)] if nxt == "fig" else [])
        if where == "start" and nxt == "fig":
            paras = paras_of(A, before=[("画像", "グラフ"), ("図キャプション", "図３　架空の変化のグラフ")])
            blocks = [Raw(*FIG_SIDE), Raw(*lines)]
        name = f"jg_join_{where}_{'label' if label == '時間（分）' else 'p' if label.startswith('点') else 'tick'}_{nxt}"
        case(name, "edge", paras, pages_of(blocks),
             f"段落の{'最後' if where == 'end' else '最初'}の行に、docx にない図の中の文字「{label}」が同じ行としてつながる"
             f"（図が本文の横に置かれた形）。{'段落の後ろ' if where == 'end' else '段落の前'}は"
             f"{'次の段落' if nxt == 'para' else '図の中の文字の行'}。図の中の文字は足さない（docx のまま）。",
             truth=dict(T0))
# 対照: 校正で足された「。」（同じ行）。足すか、決められなければ 13 章に出す
A_NOP = A[:-1]
for nxt in ("para", "fig"):
    paras = paras_of(A_NOP, after=[("画像", "グラフ"), ("図キャプション", "図３　架空の変化のグラフ")] if nxt == "fig" else ())
    blocks = [Raw(*body(A))] + ([Raw(*FIG_SIDE)] if nxt == "fig" else [])
    case(f"jg_edge_period_{nxt}", "edge", paras, pages_of(blocks),
         f"docx の段落の最後の「。」が、PDF の同じ行にはある（校正で足された）。段落の後ろは{'次の段落' if nxt == 'para' else '図の中の文字の行'}。"
         "「。」を足すか、決められなければ 13 章に出す。",
         truth={**T0, idx(paras, A_NOP): A}, expect={"default": "exact", idx(paras, A_NOP): "reported"})
# 校正で足された語（同じ行、文の終わりの記号で終わらない）で、段落の後ろが図の中の文字の行
A_ADD = A[:-1] + "ことにした"
paras = paras_of(A[:-1], after=[("画像", "グラフ"), ("図キャプション", "図３　架空の変化のグラフ")])
case("jg_edge_words_fig", "edge", paras, pages_of([Raw(*body(A_ADD)), Raw(*FIG_SIDE)]),
     "docx の段落の最後（「設けた」の後ろ）に、PDF では校正で足された「ことにした」が同じ行に続き、段落の後ろは図の中の文字の行。"
     "足すか、決められなければ 13 章に出す（図の中の文字は足さない）。",
     truth={**T0, idx(paras, A[:-1]): A_ADD}, expect={"default": "exact", idx(paras, A[:-1]): "reported"})
# 段落の最初に校正で足された「まず，」で、段落の前の行が表のキャプション（docx の段落）と表のセル
rows = table(60)
paras = paras_of(A, before=[("表キャプション", TAB_CAP), ("表", rows)])
case("jg_edge_start_after_table", "edge", paras, pages_of([Raw(*table_lines(rows)), Raw(*body("まず，" + A))]),
     "段落の最初に校正で足された「まず，」があり、段落の前は表（docx の表）。足すか、決められなければ 13 章に出す（表の文字は足さない）。",
     truth={**T0, idx(paras, A): "まず，" + A}, expect={"default": "exact", idx(paras, A): "reported"})

# ============================================================================ 2. 同じ文がすぐ後ろの段落の途中にもある
B_DUP = ("話し合いでは，ある児童は基準にする量が二倍になると割合は半分になると述べた。" + A_TAIL
         + "教師は二人の説明を並べて板書した。")
for n in (60, 200):
    rows = table(n)
    paras = paras_of(A, after=[("表キャプション", TAB_CAP), ("表", rows)], b_text=B_DUP)
    blocks = [Raw(*body(A_HEAD)), Raw(*table_lines(rows)), Raw(*jwrap(A_TAIL))]
    case(f"jg_dup_next_tab{n}", "N10", paras, pages_of(blocks, b_lines=body(B_DUP)),
         f"段落の最後の文（{len(A_TAIL)} 文字）が約 {n} 文字の表の後ろに出る。同じ文が、すぐ後ろの段落の途中にもある。どちらの"
         "段落も変えない（同じ文を取り合って消したり、ほかの段落の文字を足したりしない）。",
         truth=dict(T0))
    A_TAIL_E = A_TAIL.replace("伝え合う", "説明し合う")
    paras = paras_of(A.replace(A_TAIL, A_TAIL), after=[("表キャプション", TAB_CAP), ("表", rows)], b_text=B_DUP)
    blocks = [Raw(*body(A_HEAD)), Raw(*table_lines(rows)), Raw(*jwrap(A_TAIL_E))]
    case(f"jg_dup_next_tab{n}_edit", "N10", paras, pages_of(blocks, b_lines=body(B_DUP)),
         f"jg_dup_next_tab{n} で、表の後ろの最後の文だけが校正で直されている（「伝え合う」→「説明し合う」）。すぐ後ろの段落の同じ文は"
         "直されていない。最後の文を直すか、決められなければ 13 章に出す。すぐ後ろの段落は変えない。",
         truth={**T0, idx(paras, A): A_HEAD + A_TAIL_E}, expect={"default": "exact", idx(paras, A): "reported"})

# ============================================================================ 3. 分断された最後の文と同じ文が、離れたほかの段落にもある
END_COPY = "まとめると，" + A_TAIL
for n in (200, 600):
    rows = table(n)
    paras = paras_of(A, after=[("表キャプション", TAB_CAP), ("表", rows)], end=END_COPY)
    blocks = [Raw(*body(A_HEAD)), Raw(*table_lines(rows)), Raw(*jwrap(A_TAIL))]
    case(f"jg_far_copy_tab{n}", "N10", paras, pages_of(blocks, end=END_COPY),
         f"段落の最後の文が約 {n} 文字の表の後ろに出る。同じ文が、離れた段落（考察の後ろ）にもある。どの段落も変えない。",
         truth=dict(T0))
    A_TAIL_E = A_TAIL.replace("児童どうし", "学級全体")
    blocks = [Raw(*body(A_HEAD)), Raw(*table_lines(rows)), Raw(*jwrap(A_TAIL_E))]
    case(f"jg_far_copy_tab{n}_edit", "N10", paras, pages_of(blocks, end=END_COPY),
         f"jg_far_copy_tab{n} で、表の後ろの最後の文だけが校正で直されている（「児童どうし」→「学級全体」）。離れた段落の同じ文は"
         "直されていない。最後の文を直すか、決められなければ 13 章に出す。離れた段落は変えない。",
         truth={**T0, idx(paras, A): A_HEAD + A_TAIL_E}, expect={"default": "exact", idx(paras, A): "reported"})

# ============================================================================ 4. 別の記事の PDF
OTHER_TITLE = "架空の図形の学習における証明の読み方"
OTHER_PARAS = ["本稿の目的は，架空の中学校で行った図形の証明の授業において，生徒が証明をどのように読んだかを明らかに"
               "することである。授業は二つの学級で行った。",
               "証明の読み方を調べるために，生徒に証明の各行の理由を書かせる課題を作った。課題は三問からなり，どの問題も"
               "教科書の例題をもとにしている。",
               "その結果，理由を書けた生徒は学級の半数ほどであり，最後に，教師は生徒どうしで考えを伝え合う時間を設けた"
               "学級のほうが多かった。",
               "今後は，証明を書く活動との関係を確かめていきたい。"]
paras = paras_of(A)
pages = flow([Raw(journal_line(fp=53, lp=64), OTHER_TITLE, "―架空の副題―", "架空大学　見本　七郎"), H1,
              *[Raw(*body(t)) for t in OTHER_PARAS[:2]], "２．結果", Raw(*body(OTHER_PARAS[2])), "３．おわりに",
              Raw(*body(OTHER_PARAS[3])), RH, Raw("見本八郎（2016）．「架空の証明の研究」．『見本誌』，第7巻，pp.1-9"),
              BREAK, Raw("A Fictional Study of Reading Proofs", "Shichiro MIHON", "Abstract",
                         "This is another fictional abstract.")], first=53)
case("jg_wrong_pdf", "N10", paras, pages,
     "別の記事の PDF（見出しと、いくつかの言い回しだけが同じ）。段落はどれも PDF に見つからないはずで、どの段落も変えない"
     "（別の記事の文字と並べて直さない）。",
     truth={})

# ============================================================================ 5. 読み順の逆転（段落の後半が前半より前に出る）
for gap in ("none", "para"):
    paras = paras_of(A)
    if gap == "none":
        blocks = [Raw(*jwrap(A_TAIL)), Raw(*body(A_HEAD))]
    else:
        blocks = [Raw(*jwrap(A_TAIL)), Raw(*body(B)), Raw(*body(A_HEAD))]
    case(f"jg_rev_{gap}", "N10", paras,
         pages_of(blocks, b_lines=[] if gap == "para" else None) if gap == "none" else
         flow([front(), H1, Raw(*body(INTRO)), Raw(*body(CTRL_PUB)), H2, *blocks, H3, Raw(*body(DISC)), Raw(*body(END)),
               RH, Raw(*R1_LINES), BREAK, en_block()], first=41),
         "PDF では段落の最後の文が段落の前半より前に出る（読み順の逆転"
         + ("" if gap == "none" else "。間に次の段落") + "）。どの段落も変えない。",
         truth=dict(T0))

# ============================================================================ 6. 表で分断された最後の文の数字が直され、表のセルに同じ数字がある
A_NUM = A_HEAD + "最後に，教師は基準にする量が12mのときの割合を問い，児童どうしで考えを伝え合う時間を設けた。"
A_NUM_PUB = A_NUM.replace("12m", "13m")
rows = [["学級", "前半", "後半"], ["Ａ組", "12", "13"], ["Ｂ組", "13", "12"], ["Ｃ組", "11", "12"]]
paras = paras_of(A_NUM, after=[("表キャプション", TAB_CAP), ("表", rows)])
tail_pub = A_NUM_PUB[len(A_HEAD):]
case("jg_digits_tab", "N10", paras, pages_of([Raw(*body(A_HEAD)), Raw(*table_lines(rows)), Raw(*jwrap(tail_pub))]),
     "段落の最後の文が表の後ろに出て、その文の「12m」が出版版で「13m」に直されている。表のセルに「12」「13」がある。"
     "「13m」に直すか、決められなければ 13 章に出す（表のセルの数字を足したり、docx の数字を消したりしない）。",
     truth={**T0, idx(paras, A_NUM): A_NUM_PUB}, expect={"default": "exact", idx(paras, A_NUM): "reported"})

# ============================================================================ 7. 分断された最後の文に、校正で 20 文字以上の文が足された
LONG_ADD = "なお，この活動は前時の振り返りとも結び付けて行った。"
for n in (60, 200):
    rows = table(n)
    paras = paras_of(A, after=[("表キャプション", TAB_CAP), ("表", rows)])
    tail_pub = A_TAIL + LONG_ADD
    case(f"jg_long_add_tab{n}", "N10", paras,
         pages_of([Raw(*body(A_HEAD)), Raw(*table_lines(rows)), Raw(*jwrap(tail_pub))]),
         f"段落の最後の文が約 {n} 文字の表の後ろに出て、その後ろに校正で足された一文（{len(LONG_ADD)} 文字）が続く。足すか、"
         "決められなければ 13 章に出す（表の文字は足さない）。",
         truth={**T0, idx(paras, A): A + LONG_ADD}, expect={"default": "exact", idx(paras, A): "reported"})

# ============================================================================ 8. ページの最後の注の段落で分断される
NOTE_H = "注"
NOTE = "1）帯図は，二つの量の大きさを一本の帯の長さで表した図である。ここでは架空の教科書の書き方にならった。"
cut = len(A_HEAD) + 10
for edit in ("none", "tail"):
    a_pub = A if edit == "none" else A.replace("考えを伝え合う", "考えを話し合う")
    paras = ([("見出し", H1), ("本文", INTRO), ("本文", CTRL), ("見出し", H2), ("本文", A), ("本文", B), ("見出し", H3),
              ("本文", DISC), ("本文", END), ("注見出し", NOTE_H), ("注", NOTE), ("引用文献見出し", RH), ("引用文献", R1)])
    lines = body(a_pub)
    k = len(body(a_pub[:cut]))
    pages = flow([front(), H1, Raw(*body(INTRO)), Raw(*body(CTRL_PUB)), H2, Raw(*lines[:k]), Raw(*jwrap(NOTE)), BREAK,
                  Raw(*lines[k:]), Raw(*body(B)), H3, Raw(*body(DISC)), Raw(*body(END)), NOTE_H, RH, Raw(*R1_LINES),
                  BREAK, en_block()], first=41)
    truth = dict(T0)
    exp = "exact"
    if edit == "tail":
        truth[idx(paras, A)] = a_pub
        exp = {"default": "exact", idx(paras, A): "reported"}
    case(f"jg_note_split_{edit}", "N10", paras, pages,
         "段落がページの区切りで次のページに続き、前のページの最後に注の文（docx では引用文献の前の注の節の段落）が入る。"
         + ("どの段落も変えない。" if edit == "none" else "次のページの部分に校正の直し（「伝え合う」→「話し合う」）がある。直すか、"
            "決められなければ 13 章に出す。注の文字は足さない。"),
         truth=truth, expect=exp)

# ============================================================================ 9. 分断の後ろが最後の 2 文字だけ
for kind in ("tab", "fig"):
    for n in (60, 200):
        lines = body(A)
        last = lines[-1]
        lines = lines[:-1] + [last[:-2]]
        mat_docx = [("表キャプション", TAB_CAP), ("表", table(n))] if kind == "tab" else \
            [("画像", "帯図"), ("図キャプション", FIG_CAP)]
        mat_pdf = table_lines(table(n)) if kind == "tab" else figure(n)
        paras = paras_of(A, after=mat_docx)
        case(f"jg_tail2_{kind}{n}", "N10", paras, pages_of([Raw(*lines), Raw(*mat_pdf), Raw(last[-2:])]),
             f"段落の最後の 2 文字（「{last[-2:]}」の 1 行）の前に、約 {n} 文字の{'表' if kind == 'tab' else '図の中の文字'}が入る。"
             "何も変えない（最後の 2 文字を消さない）。",
             truth=dict(T0))

# ============================================================================ 10. 最後の文の写しが、すぐ後ろの小さな図の中にある
COPY = A_TAIL.replace("。", "．")
for n in (20, 60):
    paras = paras_of(A, after=[("画像", "帯図"), ("図キャプション", FIG_CAP)])
    fig = figure(n)
    case(f"jg_copy_fig{n}", "N10", paras,
         pages_of([Raw(*body(A_HEAD)), Raw(*fig[:1]), Raw(*jwrap(COPY)), Raw(*fig[1:]), Raw(*jwrap(A_TAIL))]),
         f"段落の最後の文が約 {n} 文字の図の後ろに出て、図の中（段落のすぐ後ろ）に最後の文の写し（句点が「．」）がある。"
         "どの段落も変えない（写しの「．」で直さない）。",
         truth=dict(T0))
    # 最後の文が校正で消され、写しだけが図の中にある
    paras = paras_of(A, after=[("画像", "帯図"), ("図キャプション", FIG_CAP)])
    case(f"jg_copy_fig{n}_del", "N10", paras,
         pages_of([Raw(*body(A_HEAD)), Raw(*fig[:1]), Raw(*jwrap(COPY)), Raw(*fig[1:])]),
         f"段落の最後の文が校正で消され、すぐ後ろの小さな図（約 {n} 文字）の中に、その文の写し（句点が「．」）だけがある。"
         "最後の文を消すか、決められなければ docx のまま 13 章に出す（写しの「．」で直さない）。",
         truth={**T0, idx(paras, A): A_HEAD}, expect={"default": "exact", idx(paras, A): "reported"})

# ============================================================================ 11. 行末のハイフンをまたぐ 2 つの直しの仲間
for name, docx_ref, l1, l2, pub in [
        ("endash", "架空三子（2020）．「架空の比の研究」．『架空学会誌』，第9巻，pp.45–58．",
         "架空三子（2020）．「架空の比の研究」．『架空学会誌』，第9巻，pp.46-", "59．",
         "架空三子（2020）．「架空の比の研究」．『架空学会誌』，第9巻，pp.46-59．"),
        ("zenkaku", "架空三子（2020）．「架空の比の研究」．『架空学会誌』，第9巻，pp.45－58．",
         "架空三子（2020）．「架空の比の研究」．『架空学会誌』，第9巻，pp.46-", "59．",
         "架空三子（2020）．「架空の比の研究」．『架空学会誌』，第9巻，pp.46-59．"),
        ("one_fix", "架空三子（2020）．「架空の比の研究」．『架空学会誌』，第9巻，pp.45-58．",
         "架空三子（2020）．「架空の比の研究」．『架空学会誌』，第9巻，pp.45-", "59．",
         "架空三子（2020）．「架空の比の研究」．『架空学会誌』，第9巻，pp.45-59．")]:
    paras = [("見出し", H1), ("本文", INTRO), ("本文", CTRL), ("引用文献見出し", RH), ("引用文献", R1), ("引用文献", docx_ref)]
    pages = flow([front(), H1, Raw(*body(INTRO)), Raw(*body(CTRL_PUB)), RH, Raw(*R1_LINES), Raw(l1, l2), BREAK,
                  en_block()], first=41)
    case(f"jg_hy_{name}", "hyphen", paras, pages,
         "引用文献のページの範囲が、PDF では行末の「-」の改行の後に続き、数字が出版版で直されている。ハイフン（ダッシュ）を消したり"
         "空白を入れたりしない。en dash は案 (a)（docx のまま 13 章）でも案 (b)（「-」に直す）でもよい。",
         truth={2: CTRL_PUB, idx(paras, docx_ref): pub},
         expect={"default": "exact", idx(paras, docx_ref): "reported" if name == "endash" else "exact"})

_names = [c["name"] for c in CASES]
_check(len(_names) == len(set(_names)), "反例の名前が重なる")
