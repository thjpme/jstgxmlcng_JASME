"""judge の組み合わせ C の守り（C1〜C5）を突く反例。文字はすべて架空。oracle/run_all.py の書式。

  python run_all.py <src> ../n10/cases_judge2.py --name <名前>

  jg2_en_*      英文要旨の最後・最初に、校正で足された文（英文の単語の間の空白の後ろ）。C1（和文の行の中の空白）で止めない
  jg2_numhead   見出しの前に、PDF にだけある番号「（１）」と空白（docx の見出しに番号がない）。足さないか 13 章に出す
  jg2_whole_*   段落の途中の、どの段落にも当たらない行まるごと（C3）。図のキャプションの行は足さない。校正の直しが行の
                途中から始まる形（組み直しで行の途中から始まる）は今までどおり直す
  jg2_date_*    受付日の文字との偶然の一致（C4）。docx に受付日の文字列がそのままある段落は、そのまま照合する
  jg2_width_*   まとめた直しと全角・半角の直しが重なる形（C5）
"""
from __future__ import annotations

import unicodedata

from runner import BREAK, DEFAULTS, Raw, flow, journal_line, received_line  # noqa: F401

KINSOKU = "，。、．）」』！？"


def _w(c):
    return 1.0 if unicodedata.east_asian_width(c) in ("F", "W", "A") else 0.5


def jwrap(text, width=24):
    lines, cur, n = [], "", 0.0
    for c in text:
        if cur and n + _w(c) > width and c not in KINSOKU:
            lines.append(cur)
            cur, n = "", 0.0
        cur += c
        n += _w(c)
    if cur:
        lines.append(cur)
    return lines


def body(text, indent=True):
    return jwrap(("　" if indent else "") + text)


def front():
    return Raw(journal_line(fp=41, lp=52), DEFAULTS["題目"], DEFAULTS["副題"], "架空大学　試験　五郎")


CASES = []


def case(name, item, paras, pages, note, truth=None, expect="exact"):
    CASES.append({"name": name, "angle": "layout", "item": item, "paras": paras, "truth": truth or {},
                  "pages": pages, "expect": expect, "note": note})


def idx(paras, text):
    found = [i for i, (_, t) in enumerate(paras) if t == text]
    assert len(found) == 1, text
    return found[0]


H1, H2, RH = "１．はじめに", "２．方法", "引用および参考文献"
INTRO = "本稿の目的は，架空の小学校で行った割合の授業において，児童の説明の特徴を明らかにすることである。"
CTRL = "記録の対象は，第５学年の二つの学級で4回行った授業である。"
CTRL_PUB = CTRL.replace("4回", "４回")
A = ("第二時の授業では，教師はまず前時に使った帯図を黒板に示し，基準にする量と比べる量の関係を確かめさせた。"
     "続いて，帯図の下に数直線をかき，二つの量の割合を数直線の上に書き入れる活動を示した。最後に，教師は基準にする量が"
     "変わると割合がどうなるかを問い，児童どうしで考えを伝え合う時間を設けた。")
B = "話し合いでは，ある児童は基準にする量が二倍になると割合は半分になると述べた。"
R1 = "架空一子（2018）．「割合の学習における帯図の役割」．『架空算数教育研究』，第21号，pp.31-38"
R1_LINES = ["架空一子（2018）．「割合の学習における帯図の", "役割」．『架空算数教育研究』，第21号，pp.31-38"]
EN_ABS = "This fictional study examines how pupils explained ratios in two classes. The lessons were recorded and analysed."


def base_paras(target, extra=(), abstract=EN_ABS, heading=H2):
    return ([("見出し", H1), ("本文", INTRO), ("本文", CTRL), ("見出し", heading), ("本文", target), *extra, ("本文", B),
             ("引用文献見出し", RH), ("引用文献", R1), ("英文要旨", abstract)])


def base_pages(target_lines, abstract_lines=None, heading_line=H2, extra=()):
    return flow([front(), H1, Raw(*body(INTRO)), Raw(*body(CTRL_PUB)), heading_line, Raw(*target_lines), *extra,
                 Raw(*body(B)), RH, Raw(*R1_LINES), BREAK,
                 Raw(DEFAULTS["英文題目"], DEFAULTS["英文副題"], "Goro SHIKEN", "Fictional University", "Abstract",
                     *(abstract_lines or [EN_ABS]))], first=41)


T0 = {2: CTRL_PUB}

# ---------------------------------------------------------------- C1: 英文の段落の端（単語の間の空白の後ろ）
EN_ADD = " The results were compared."
paras = base_paras(A)
case("jg2_en_end", "edge", paras, base_pages(body(A), abstract_lines=[EN_ABS[:60], EN_ABS[60:] + EN_ADD]),
     "英文要旨の最後の行に、校正で足された文「The results were compared.」が単語の間の空白の後ろに続く（同じ行）。足すか、"
     "決められなければ 13 章に出す。",
     truth={**T0, idx(paras, EN_ABS): EN_ABS + EN_ADD}, expect={"default": "exact", idx(paras, EN_ABS): "reported"})
EN_PRE = "Briefly, "
case("jg2_en_start", "edge", paras, base_pages(body(A), abstract_lines=[EN_PRE + EN_ABS[:50], EN_ABS[50:]]),
     "英文要旨の最初の行の書き出しに、校正で足された「Briefly,」がある。足すか、決められなければ 13 章に出す。",
     truth={**T0, idx(paras, EN_ABS): EN_PRE + EN_ABS}, expect={"default": "exact", idx(paras, EN_ABS): "reported"})
# 見出しの前の、PDF にだけある番号（docx の見出しに番号がない）
paras = base_paras(A, heading="研究の方法")
case("jg2_numhead", "edge", paras, base_pages(body(A), heading_line="（２）　研究の方法"),
     "docx の見出し「研究の方法」の前に、PDF では番号「（２）」と空白がある（組版で付いた番号かもしれない）。docx のまま。",
     truth=dict(T0))

# ---------------------------------------------------------------- C3: 段落の途中の行まるごと
lines = body(A)
for cap in ("図２　架空の配置", "表２　架空の得点の一覧"):
    paras = base_paras(A)
    case(f"jg2_whole_caption{len(cap)}", "N10", paras, base_pages(lines[:3] + [cap] + lines[3:]),
         f"段落の途中（3 行目の後ろ）に、docx にない図・表のキャプションの行「{cap}」がまるごと入る。足さない。",
         truth=dict(T0))
# 校正で足された語句が、組み直しで行の途中から始まる（今までどおり直す）
A_INS = A.replace("続いて，", "続いて，教師は", 1)
paras = base_paras(A)
case("jg2_whole_reflow", "N10", paras, base_pages(body(A_INS)),
     "校正で「教師は」が足され、PDF では段落の行が組み直されている（足された語は行の途中）。足す。",
     truth={**T0, idx(paras, A): A_INS})
# 校正で足された語句が、たまたま 1 行まるごとになった（行の幅いっぱいの 24 文字。20 文字以上なので足さないで 13 章）
FULL = "この活動は前時の振り返りと結び付けて行った。"
assert len(FULL) <= 24
k = len(A_INS) - 0
paras = base_paras(A)
cut = A.index("続いて，")
case("jg2_whole_fullline", "N10", paras, base_pages(body(A[:cut]) + [FULL] + jwrap(A[cut:])),
     f"校正で足された一文（{len(FULL)} 文字）が、段落の途中の行にまるごと入っている。足すか、決められなければ 13 章に出す。",
     truth={**T0, idx(paras, A): A[:cut] + FULL + A[cut:]}, expect={"default": "exact", idx(paras, A): "reported"})

# ---------------------------------------------------------------- C4: 受付日
DATE = received_line()
BODY_DATE = "本稿は，" + DATE + "の記録をもとに書き直したものである。"
paras = base_paras(BODY_DATE)
case("jg2_date_in_docx", "artifact", paras, base_pages(body(BODY_DATE)),
     "docx の本文に、受付日と同じ形の文字列がそのままある（架空の書き方）。docx のまま（受付日の文字として外さない）。",
     truth=dict(T0))
REF2 = "架空二子（2019）．「架空の割合の研究」．『架空学会誌』，第8巻，pp.21-35．"
REF2_PUB = REF2.replace("35．", "36．")
paras = [("見出し", H1), ("本文", INTRO), ("本文", CTRL), ("引用文献見出し", RH), ("引用文献", R1), ("引用文献", REF2),
         ("英文要旨", EN_ABS)]
pages = flow([front(), H1, Raw(*body(INTRO)), Raw(*body(CTRL_PUB)), RH, Raw(*R1_LINES),
              Raw("架空二子（2019）．「架空の割合の研究」．『架空学", "会誌』，第8巻，pp.21-", DATE, "36．"), BREAK,
              Raw(DEFAULTS["英文題目"], DEFAULTS["英文副題"], "Goro SHIKEN", "Fictional University", "Abstract", EN_ABS)],
             first=41)
case("jg2_date_between_digits", "N10", paras, pages,
     "引用文献の「pp.21-」の改行の後に受付日の行が入り、その後ろに出版版で直された「36．」がある。受付日の数字と並べて"
     "「35」を壊さない。直すか、決められなければ 13 章に出す。",
     truth={**T0, idx(paras, REF2): REF2_PUB}, expect={"default": "exact", idx(paras, REF2): "reported"})

# ---------------------------------------------------------------- C5: まとめた直しと全角・半角
P_W = "この結果は，架空の調査(試験，2019)と同じ傾向を示している。"
P_W_PUB = "この結果は，架空の調査（試験，2020）と同じ傾向を示している。"
paras = base_paras(P_W)
case("jg2_width_merge", "hyphen", paras, base_pages(body(P_W_PUB)),
     "かっこの全角・半角の直しと、すぐ隣の年の直し（「2019」→「2020」）が近くにある。両方を直す（一部だけを当てはめて、"
     "docx にも PDF にもない文字にしない）。",
     truth={**T0, idx(paras, P_W): P_W_PUB})
