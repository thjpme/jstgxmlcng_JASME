"""N10 の反例集: PDF の中で段落が表・図の中の文字・別の段落（2 段組みの読み順のずれ）に分断され、段落の後ろ・前・途中が
照合の窓（段落の長さ + 60 文字ほど）の外に出る形と、その仲間（行末のハイフンをまたぐ 2 つの直し、段落の最初・最後の黙った
違い、en dash）。文字はすべて架空（実際の論文の文字を書き写していない）。

oracle/run_all.py の書式（oracle/runner.py の docstring）。実行（scratchpad の oracle/ で）:
  python run_all.py <src> ../n10/cases_n10.py --name <名前>
期待は原則だけで決める（出版版 PDF の本文と同じにする。表・図の中の文字・ほかの段落の文字を足さない。本文の文字を消さない。
決められないものは 13 章に出す）。0.20.0 の結果には合わせない。

反例の名前: n10_<位置>_<分断する文字><長さ>[_<変わり型>]
  位置        tail（段落の後ろ〈最後の文。2 行〉が分断の後ろ）/ tail1（段落の最後の行〈17 文字〉だけが分断の後ろ）/
              head（段落の最初の行が分断の前）/ mid（段落の途中〈4 行目の後〉）
  分断する文字 tab（表のキャプションと表の行。docx では段落の後ろ〈head は前〉の Word の表）/
              fig（図の中の文字と図のキャプション。docx では画像なので、図の中の文字は docx のどの段落にもない）/
              para（別の段落。docx では 2 つ後ろ〈head は前〉の本文の段落。読み順のずれ）
  長さ        分断する文字のおよその文字数（20・60・200・600）
  変わり型    edit（分断された側の部分に校正の直し）/ editb（分断の境目に校正で足された文字）/
              sim（分断された部分とよく似た文がほかの段落にある）/ dup（よく似た文が図の中の文字にある。どの段落にも当たらない）/
              del（分断の後ろにあるはずの文が校正で消された）/ deldup（消された文の写しが図の中の文字にある）/
              short（分断された部分が 4 文字だけ）/ pb（分断がページの区切りにかかる）
仲間の形:
  hy_*    行末のハイフンをまたぐ 2 つの直し（docx「pp.45-58」、PDF「pp.46-」の改行の後の「59」）
  edge_*  段落の最初・最後の PDF にだけある文字（校正で足された「。」・語・一文）と、校正で消された段落の最後の文字が次の段落の
          書き出しにもある形、段落の最後の数字が次の文献の「（2019）」と偶然一致する形
  dash_*  docx の en dash「–」と、PDF の英数字の後の行末の「-」（利用者の判断待ち。案 (a) docx のまま〈13 章に出す〉・
          案 (b) PDF に合わせて「-」に直す。どちらでも通るように expect は reported にしてある）
  dupnext_* 段落の書き出しの写しが、段落のすぐ前の図の中の文字にある形（段落の最初の部分がそちらと並べられる。29 巻 79 ページの形）
"""
from __future__ import annotations

import unicodedata

from runner import BREAK, DEFAULTS, Raw, flow, journal_line  # noqa: F401

# ============================================================================ 補助
KINSOKU = "，。、．）」』！？"     # 行頭に来ない文字（前の行にぶら下げる）


def _w(c: str) -> float:
    return 1.0 if unicodedata.east_asian_width(c) in ("F", "W", "A") else 0.5


def jwrap(text: str, width: float = 24) -> list:
    """和文の行分け（1 行 24 文字。行頭の句読点は前の行にぶら下げる）。"""
    lines, cur, n = [], "", 0.0
    for c in text:
        if cur and n + _w(c) > width and c not in KINSOKU:
            lines.append(cur)
            cur, n = "", 0.0
        cur += c
        n += _w(c)
    if cur:
        lines.append(cur)
    return lines


def body(text: str, indent=True) -> list:
    """本文の段落の PDF の行（最初の行は全角の空白で字下げ）。"""
    return jwrap(("　" if indent else "") + text)


def chars(lines) -> int:
    return sum(1 for ln in lines for c in ln if not c.isspace())


def front() -> Raw:
    return Raw(journal_line(fp=25, lp=36), DEFAULTS["題目"], DEFAULTS["副題"], "架空大学　試験　五郎")


def en_block() -> Raw:
    return Raw(DEFAULTS["英文題目"], DEFAULTS["英文副題"], "Goro SHIKEN", "Fictional University", "Abstract",
               DEFAULTS["英文要旨"])


def _check(cond, msg):
    if not cond:
        raise ValueError("反例の組み立ての誤り: " + msg)


# ============================================================================ 架空の論文の段落
H1 = "１．はじめに"
H2 = "２．授業の記録"
H3 = "３．考察"
RH = "引用および参考文献"
P_INTRO = ("本研究の目的は，架空の中学校で行った比例の授業において，生徒が二つの量の関係をどのように捉えたかを，"
           "ノートの記述と授業中の発話から明らかにすることである。")
CTRL_DOCX = "分析の対象は，第１学年の一つの学級で3回行った授業の記録である。授業者は架空の教諭である。"
CTRL_PUB = CTRL_DOCX.replace("3回", "３回")
# 分断される段落（184 文字。最後の文〈TAIL〉は 2 行）
T_HEAD = ("第三時の授業では，教師はまず前時に作った表を黒板に掲げ，水を入れる時間と水の深さの関係を振り返らせた。"
          "続いて，表の隣り合う値の間に矢印をかき，深さがどれだけ増えたかを矢印の上に書き込む活動を示した。"
          "生徒は自分のノートの表にも矢印をかき，増え方がいつも同じであることを確かめた。")
T_TAIL = "最後に，教師は時間が３倍になると深さがどうなるかを問い，生徒どうしで説明し合う時間を取った。"
TARGET = T_HEAD + T_TAIL
P_AFTER = ("話し合いの中で，ある生徒は時間が３倍になると深さも３倍になると述べ，別の生徒は１分ごとに同じだけ増えるから"
           "だと理由を付け加えた。教師はこの二つの説明を並べて板書した。")
P_DISC = ("このような変容が起きた理由として，矢印で表す活動によって，表の横の関係に生徒の目が向いたことが考えられる。"
          "ただし，規則を言葉で述べられても，それを式に表すことに困難を感じる生徒も多かった。")
P_END = "今後は，ほかの学年や単元でも同じような変容が見られるかを確かめていきたい。"
REF1 = "架空一郎（2019）．「比例の学習における関係の見方」．『架空数学教育研究』，第29号，pp.11-16"
REF2 = "仮名花子（2021）．「表と式を結ぶ授業の工夫」．『架空の算数と数学』，第12巻，pp.45-58"
REF1_LINES = ["架空一郎（2019）．「比例の学習における関係の", "見方」．『架空数学教育研究』，第29号，pp.11-16"]
REF2_LINES = ["仮名花子（2021）．「表と式を結ぶ授業の工夫」．", "『架空の算数と数学』，第12巻，pp.45-58"]
_check("".join(REF1_LINES) == REF1 and "".join(REF2_LINES) == REF2, "引用文献の行")

# 別の段落（分断する文字 para）。docx では TARGET の 2 つ後ろ（head は前）にある本文の段落
OTHER = {
    20: ["この点は次の節で改めて詳しく述べる。"],
    60: ["なお，授業の記録は二人の観察者が別々に取り，授業の後に照らし合わせて食い違いを確かめた。"
         "記録の方法は前時と同じである。"],
    200: ["授業の前に行った事前の調査では，表を横に見て増え方を答えられた生徒は学級の半数ほどであった。"
          "一方で，表を縦に見て二つの量の対応を答えられた生徒は一割に満たなかった。このことから，学級の多くの生徒は，"
          "表を見るときに一方の量の変化だけに目を向けていたと考えられる。事前の調査の問題は，教科書の練習問題を"
          "もとに架空の数値に置き換えて作ったものである。"],
    600: ["授業の前に行った事前の調査では，表を横に見て増え方を答えられた生徒は学級の半数ほどであった。"
          "一方で，表を縦に見て二つの量の対応を答えられた生徒は一割に満たなかった。このことから，学級の多くの生徒は，"
          "表を見るときに一方の量の変化だけに目を向けていたと考えられる。事前の調査の問題は，教科書の練習問題を"
          "もとに架空の数値に置き換えて作ったものである。",
          "事前の調査の結果を受けて，授業者は単元の計画を見直した。当初の計画では，第二時に式の表し方を扱う予定で"
          "あったが，表の見方を広げる活動に時間を充てることにした。具体的には，表の数の間に矢印をかき込む活動と，"
          "表を縦に見て対応の規則を言葉で表す活動を加えた。これらの活動は，架空の先行研究の授業例を参考にして"
          "作ったものである。",
          "また，単元の終わりに行った事後の調査では，表を縦に見て対応を答えられた生徒が学級の七割を超えた。自由記述"
          "には，矢印をかくと増え方が見えるようになった，横に見るだけでなく縦に見てもよいことに気付いた，といった"
          "内容が多く見られた。こうした記述からは，生徒が活動の意味を自分なりに捉えていたことがうかがえる。"],
}

# 表（分断する文字 tab）: キャプションと表の行（1 行にセルを空白で区切る）。長さごとに行を足す
TAB_CAP = "表１　架空の学級ごとの記述の数"
TAB_CAP20 = "表１　記述の数"
_GROUPS = "ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺ"


def table_rows(total: int):
    """セルの文字数の合計がおよそ total になる表（キャプションを含む）。戻り値: (キャプション, docx の表の行)。"""
    cap = TAB_CAP20 if total <= 20 else TAB_CAP
    rows = [["学級", "一回目", "二回目"]] if total > 20 else []
    n = len(cap) + sum(len(c) for r in rows for c in r)
    k = 0
    while n < total:
        row = [_GROUPS[k % len(_GROUPS)] + "組", str(10 + (k * 7) % 23), str(5 + (k * 11) % 17)]
        rows.append(row)
        n += sum(len(c) for c in row)
        k += 1
    return cap, rows


def table_lines(cap, rows) -> list:
    return [cap] + [" ".join(r) for r in rows]


# 図（分断する文字 fig）: 図の中の文字（docx では画像）と図のキャプション
FIG_CAP = "図１　架空の授業の流れ"
FIG_WORDS = ["導入", "前時の表を振り返る", "課題の提示", "水を入れる時間と深さ", "個人で考える", "表に矢印をかき込む",
             "増え方を書く", "学級で話し合う", "増え方に注目する説明", "何倍かに注目する説明", "二つの説明を比べる",
             "まとめ", "分かったことを書く", "振り返りを書く", "教師の発問", "生徒の説明", "板書の記録", "ノートの記述",
             "記述の分類", "値・変化・対応", "矢印の活動", "縦に見る活動", "対応の規則", "隠れた数を求める"]


def figure_lines(total: int) -> list:
    """図の中の文字の行（およそ total 文字。キャプションを含む）。語句と矢印「↓」の行を交互に並べる。"""
    out, n, k = [], len(FIG_CAP), 0
    while n < total:
        w = FIG_WORDS[k % len(FIG_WORDS)]
        if k >= len(FIG_WORDS):
            w = w + "（" + "一二三四五"[k // len(FIG_WORDS) % 5] + "）"
        out.append(w)
        n += len(w)
        if n < total:
            out.append("↓")
            n += 1
        k += 1
    return out + [FIG_CAP]


# ============================================================================ 反例の組み立て
CASES = []


def case(name, item, paras, pages, note, truth=None, expect="exact"):
    CASES.append({"name": name, "angle": "layout", "item": item, "paras": paras, "truth": truth or {},
                  "pages": pages, "expect": expect, "note": note})


def idx(paras, text):
    found = [i for i, (_, t) in enumerate(paras) if t == text]
    _check(len(found) == 1, f"段落「{str(text)[:16]}」が {len(found)} 個")
    return found[0]


def article_paras(target_docx, material_before=(), material_after=(), others_after=(), others_before=(),
                  after=P_AFTER):
    """docx の段落の並び。material_*: 表・図の段落（TARGET のすぐ前・すぐ後ろ）。others_*: 別の段落（2 つ後ろ・前）。"""
    return ([("見出し", H1), ("本文", P_INTRO), ("本文", CTRL_DOCX), ("見出し", H2), *others_before,
             *material_before, ("本文", target_docx), *material_after, ("本文", after), *others_after,
             ("見出し", H3), ("本文", P_DISC), ("本文", P_END), ("引用文献見出し", RH),
             ("引用文献", REF1), ("引用文献", REF2)])


def article_pages(target_blocks, after=P_AFTER, others_pdf=(), page_break_after_target_head=False):
    """PDF の各ページの文字。target_blocks は TARGET の位置に入るブロック（分断を含む）。"""
    blocks = [front(), H1, Raw(*body(P_INTRO)), Raw(*body(CTRL_PUB)), H2, *target_blocks, Raw(*body(after)),
              *others_pdf, H3, Raw(*body(P_DISC)), Raw(*body(P_END)), RH, Raw(*REF1_LINES), Raw(*REF2_LINES),
              BREAK, en_block()]
    return flow(blocks, first=25)


def material(kind, n, position):
    """分断する文字: (docx の段落〈TARGET の前に置くもの〉, docx の段落〈後ろ〉, docx の段落〈2 つ後ろ・前の別の段落〉,
    PDF の行)。"""
    if kind == "tab":
        cap, rows = table_rows(n)
        docx = [("表キャプション", cap), ("表", rows)]
        lines = table_lines(cap, rows)
        return (docx, [], [], lines) if position == "head" else ([], docx, [], lines)
    if kind == "fig":
        lines = figure_lines(n)
        docx = [("画像", "授業の流れ"), ("図キャプション", FIG_CAP)]
        return (docx, [], [], lines) if position == "head" else ([], docx, [], lines)
    if kind == "para":
        paras = [("本文", t) for t in OTHER[n]]
        lines = [ln for t in OTHER[n] for ln in body(t)]
        return ([], [], paras, lines)
    raise ValueError(kind)


def split_target(position, pdf_target=TARGET):
    """TARGET の PDF の行を、分断の前と後ろに分ける。"""
    if position == "tail":     # 最後の文（2 行）が分断の後ろ（T_HEAD の後ろで分ける。校正で足された文字は後ろの部分に入る）
        cut = len(T_HEAD) if pdf_target.startswith(T_HEAD) else pdf_target.index("最後に")
        return body(pdf_target[:cut]), jwrap(pdf_target[cut:])
    lines = body(pdf_target)
    if position == "tail1":    # 最後の行（17 文字。段落の 1 割ほど）だけが分断の後ろ
        return lines[:-1], lines[-1:]
    if position == "head":     # 最初の行だけが分断の前
        return lines[:1], lines[1:]
    if position == "mid":      # 4 行目の後
        return lines[:4], lines[4:]
    raise ValueError(position)


KIND_NOTE = {"tab": "表のキャプションと表の行（docx では段落の{side}の Word の表）",
             "fig": "図の中の文字と図のキャプション（docx では段落の{side}の画像とキャプション。図の中の文字は docx にない）",
             "para": "別の段落（docx では{side2}の本文の段落。2 段組みの読み順のずれ）"}
POS_NOTE = {"tail": "段落の最後の文（2 行）の前", "tail1": "段落の最後の行（17 文字）の前", "head": "段落の最初の行の後",
            "mid": "段落の 4 行目の後"}


def build(position, kind, n, target_docx=TARGET, target_pdf=TARGET, extra_pdf=None, after=P_AFTER,
          after_pdf=None, others_extra=()):
    m_before, m_after, others, lines = material(kind, n, position)
    if extra_pdf is not None:
        lines = extra_pdf(lines)
    others_before = others if position == "head" else []
    others_after = list(others) + list(others_extra) if position != "head" else list(others_extra)
    paras = article_paras(target_docx, m_before, m_after, others_after=others_after, others_before=others_before,
                          after=after)
    first, second = split_target(position, target_pdf)
    # 別の段落は PDF では TARGET の中に入るので、本来の位置には置かない
    pages = article_pages([Raw(*first), Raw(*lines), Raw(*second)], after=after_pdf or after,
                          others_pdf=[Raw(*body(t)) for _, t in others_extra])
    side = "前" if position == "head" else "後ろ"
    side2 = "1 つ前" if position == "head" else "2 つ後ろ"
    what = KIND_NOTE[kind].format(side=side, side2=side2)
    return paras, pages, f"PDF では{POS_NOTE[position]}に、{what}が約 {chars(lines)} 文字入る。"


# ---------------------------------------------------------------- 1. 位置 × 分断する文字 × 長さ（違いは確かめ用の 1 つだけ）
for position in ("tail", "tail1", "head", "mid"):
    for kind in ("tab", "fig", "para"):
        for n in (20, 60, 200, 600):
            paras, pages, note = build(position, kind, n)
            case(f"n10_{position}_{kind}{n}", "N10", paras, pages,
                 note + "どの段落も docx と PDF の本文は同じ（確かめ用の「3回」→「３回」だけ）。段落の文字を消したり、"
                        "分断する文字に置き換えたり、分断する文字を足したりしない。",
                 truth={idx(paras, CTRL_DOCX): CTRL_PUB})

# ---------------------------------------------------------------- 2. 分断された側の部分に校正の直し（edit）
EDIT = {   # 位置: (docx の TARGET, PDF の TARGET。直しは分断の後ろ〈head は前〉の部分にある)
    "tail": (TARGET.replace("時間を取った", "時間を設けた"), TARGET),
    "tail1": (TARGET.replace("時間を取った", "時間を設けた"), TARGET),
    "head": (TARGET.replace("教師はまず", "教師は初めに"), TARGET),
    "mid": (TARGET.replace("自分のノート", "各自のノート"), TARGET),
}
for position, (docx_t, pdf_t) in EDIT.items():
    for kind in ("tab", "fig", "para"):
        for n in (60, 200, 600):
            paras, pages, note = build(position, kind, n, target_docx=docx_t, target_pdf=pdf_t)
            case(f"n10_{position}_{kind}{n}_edit", "N10", paras, pages,
                 note + "分断された側の部分に、校正の直し（docx と PDF で語が違う）がある。直しは PDF に合わせ、"
                        "ほかは変えない。",
                 truth={idx(paras, CTRL_DOCX): CTRL_PUB, idx(paras, docx_t): pdf_t})

# ---------------------------------------------------------------- 3. 分断の境目に校正で足された文字（editb）
EDITB_PDF = T_HEAD + "さらに，" + T_TAIL
for kind in ("tab", "fig", "para"):
    for n in (60, 200):
        paras, pages, note = build("tail", kind, n, target_pdf=EDITB_PDF)
        case(f"n10_tail_{kind}{n}_editb", "N10", paras, pages,
             note + "分断の後ろの部分の書き出しに、校正で足された「さらに，」がある（分断の境目）。足すか、決められなければ "
                    "13 章に出す（分断する文字は足さない）。",
             truth={idx(paras, CTRL_DOCX): CTRL_PUB, idx(paras, TARGET): EDITB_PDF},
             expect={"default": "exact", idx(paras, TARGET): "reported"})

# 分断の前の部分の最後（分断のすぐ前の行の終わり）に、校正で足された文字がある
EDITB2_PDF = T_HEAD[:-1] + "と言える。" + T_TAIL
for kind in ("tab", "fig", "para"):
    for n in (60, 200):
        paras, pages, note = build("tail", kind, n, target_pdf=EDITB2_PDF)
        case(f"n10_tail_{kind}{n}_editb2", "N10", paras, pages,
             note + "分断の前の部分の最後（「確かめた。」の後ろ）に、校正で足された「と言える。」がある（分断の境目の"
                    "前の側）。足すか、決められなければ 13 章に出す（分断する文字は足さない）。",
             truth={idx(paras, CTRL_DOCX): CTRL_PUB, idx(paras, TARGET): EDITB2_PDF},
             expect={"default": "exact", idx(paras, TARGET): "reported"})

# ---------------------------------------------------------------- 4. よく似た文がほかの段落にある（sim）
SIM_AFTER = P_AFTER + "最後に，教師は時間が３倍になると深さがどうなるかを問い，生徒どうしで説明し合う時間を取った。"
_check(SIM_AFTER.endswith(T_TAIL), "SIM_AFTER")
for kind in ("tab", "fig", "para"):
    for n in (60, 200, 600):
        paras, pages, note = build("tail", kind, n, after=SIM_AFTER)
        case(f"n10_tail_{kind}{n}_sim", "N10", paras, pages,
             note + "すぐ後ろの段落の最後の文が、分断された最後の文とまったく同じ。どの段落も変えない（後ろの段落の文と"
                    "並べて消したり、その段落の文字を足したりしない）。",
             truth={idx(paras, CTRL_DOCX): CTRL_PUB})

# ---------------------------------------------------------------- 5. よく似た文が図の中の文字にある（dup）
DUP_TAIL = T_TAIL.replace("。", "．")       # 投稿時の原稿の写しが図の中に入っている形（句点だけ違う）


def _with_dup(lines):
    return lines[:len(lines) // 2] + jwrap(DUP_TAIL) + lines[len(lines) // 2:]


for n in (200, 600):
    paras, pages, note = build("tail", "fig", n, extra_pdf=_with_dup)
    case(f"n10_tail_fig{n}_dup", "N10", paras, pages,
         note + "図の中の文字に、分断された最後の文の写し（句点が「．」）がある（どの段落にも当たらない）。どの段落も"
                "変えない（写しと並べて句点を直したり、図の中の文字を足したりしない）。",
         truth={idx(paras, CTRL_DOCX): CTRL_PUB})

# ---------------------------------------------------------------- 6. 分断の後ろにあるはずの文が校正で消された（del・deldup）
# del・deldup: 最後の文（45 文字。段落の 24%）が消された形。段落の 85% 以上が一致しないので「PDF に見つからない段落」（13.5）に
# なってもよい（reported）。del1・deldup1: 段落の最後に足した短い文（13 文字。段落の 7%）が消された形（exact。消す）
D_ADD = "以上が第三時の流れである。"
TARGET_D = TARGET + D_ADD
DUP_ADD = D_ADD.replace("。", "．")
for kind in ("tab", "fig", "para"):
    for n in (60, 200):
        m_before, m_after, others, lines = material(kind, n, "tail")
        paras = article_paras(TARGET, m_before, m_after, others_after=others)
        pages = article_pages([Raw(*body(T_HEAD)), Raw(*lines)])
        case(f"n10_tail_{kind}{n}_del", "N10", paras, pages,
             f"PDF では段落の最後の文が校正で消されていて、段落の後ろに{KIND_NOTE[kind].format(side='後ろ', side2='2 つ後ろ')}"
             f"が約 {chars(lines)} 文字続く。段落の最後の文を消す（PDF のどこにもない）か、決められなければ 13 章に出す"
             "（段落の 24% なので、PDF に見つからない段落になってもよい）。分断する文字を足さない。",
             truth={idx(paras, CTRL_DOCX): CTRL_PUB, idx(paras, TARGET): T_HEAD},
             expect={"default": "exact", idx(paras, TARGET): "reported"})
        paras = article_paras(TARGET_D, m_before, m_after, others_after=others)
        pages = article_pages([Raw(*body(TARGET)), Raw(*lines)])
        case(f"n10_tail_{kind}{n}_del1", "N10", paras, pages,
             f"docx の段落の最後の短い文「{D_ADD}」が PDF にない（校正で消された）。段落の後ろに"
             f"{KIND_NOTE[kind].format(side='後ろ', side2='2 つ後ろ')}が約 {chars(lines)} 文字続く。その文を消す"
             "（PDF のどこにもない）。分断する文字を足さない。図の中の文字の最初の行が短い行（照合に使わない行）のときは、"
             "その行が出版版で直された段落の最後の文字かもしれないので、消さずに 13 章に出してもよい（fig は reported）。",
             truth={idx(paras, CTRL_DOCX): CTRL_PUB, idx(paras, TARGET_D): TARGET},
             expect={"default": "exact", idx(paras, TARGET_D): "reported" if kind == "fig" else "exact"})
for n in (200,):
    m_before, m_after, others, lines = material("fig", n, "tail")
    paras = article_paras(TARGET, m_before, m_after)
    pages = article_pages([Raw(*body(T_HEAD)), Raw(*_with_dup(lines))])
    case(f"n10_tail_fig{n}_deldup", "N10", paras, pages,
         "PDF では段落の最後の文が校正で消されていて、段落の後ろの図の中の文字に、その文の写し（句点が「．」）がある"
         "（投稿時の原稿の写しが図に入っている形）。消すか、決められなければ docx のまま 13 章に出す。図の中の文字は足さない。",
         truth={idx(paras, CTRL_DOCX): CTRL_PUB, idx(paras, TARGET): T_HEAD},
         expect={"default": "exact", idx(paras, TARGET): "reported"})
    paras = article_paras(TARGET_D, m_before, m_after)
    half = len(lines) // 2
    pages = article_pages([Raw(*body(TARGET)), Raw(*(lines[:half] + [DUP_ADD] + lines[half:]))])
    case(f"n10_tail_fig{n}_deldup1", "N10", paras, pages,
         f"docx の段落の最後の短い文「{D_ADD}」が PDF の本文にない（校正で消された）が、段落の後ろの図の中の文字に、その文の"
         "写し（句点が「．」）がある。消すか、決められなければ docx のまま 13 章に出す。図の中の文字は足さない。",
         truth={idx(paras, CTRL_DOCX): CTRL_PUB, idx(paras, TARGET_D): TARGET},
         expect={"default": "exact", idx(paras, TARGET_D): "reported"})

# ---------------------------------------------------------------- 7. 分断された部分が 4 文字だけ（short）
SHORT_CUT = len(TARGET) - 4                # 「取った。」
for kind in ("tab", "fig", "para"):
    for n in (60, 200):
        m_before, m_after, others, lines = material(kind, n, "tail")
        paras = article_paras(TARGET, m_before, m_after, others_after=others)
        pages = article_pages([Raw(*body(TARGET[:SHORT_CUT])), Raw(*lines), Raw(TARGET[SHORT_CUT:])])
        case(f"n10_tail_{kind}{n}_short", "N10", paras, pages,
             f"PDF では段落の最後の 4 文字（「{TARGET[SHORT_CUT:]}」の 1 行）の前に、"
             f"{KIND_NOTE[kind].format(side='後ろ', side2='2 つ後ろ')}が約 {chars(lines)} 文字入る。何も変えない"
             "（最後の 4 文字を消さない）。",
             truth={idx(paras, CTRL_DOCX): CTRL_PUB})

# ---------------------------------------------------------------- 8. 分断がページの区切りにかかる（pb）
for kind in ("tab", "fig"):
    for n in (200, 600):
        m_before, m_after, others, lines = material(kind, n, "tail")
        paras = article_paras(TARGET, m_before, m_after)
        first, second = split_target("tail")
        blocks = [front(), H1, Raw(*body(P_INTRO)), Raw(*body(CTRL_PUB)), H2, Raw(*first), BREAK, Raw(*lines),
                  Raw(*second), Raw(*body(P_AFTER)), H3, Raw(*body(P_DISC)), Raw(*body(P_END)), RH, Raw(*REF1_LINES),
                  Raw(*REF2_LINES), BREAK, en_block()]
        case(f"n10_tail_{kind}{n}_pb", "N10", paras, flow(blocks, first=25),
             f"段落の最後の文の前でページが変わり、次のページの最初（ページ番号の次）に"
             f"{KIND_NOTE[kind].format(side='後ろ', side2='2 つ後ろ')}が約 {chars(lines)} 文字あって、その後に最後の文が"
             "続く。何も変えない。",
             truth={idx(paras, CTRL_DOCX): CTRL_PUB})

# ============================================================================ 仲間の形
# ---------------------------------------------------------------- 行末のハイフンをまたぐ 2 つの直し（hy）
HY_DOCX = "架空太郎（2019）．「架空の題目」．『架空学会誌』，第29号，pp.45-58．"
HY_PUB = "架空太郎（2019）．「架空の題目」．『架空学会誌』，第29号，pp.46-59．"
for name, l1, l2, pub in [("both", "架空太郎（2019）．「架空の題目」．『架空学会誌』，第29号，pp.46-", "59．", HY_PUB),
                          ("fffe", "架空太郎（2019）．「架空の題目」．『架空学会誌』，第29号，pp.46￾", "59．", HY_PUB),
                          ("before", "架空太郎（2019）．「架空の題目」．『架空学会誌』，第29号，pp.46-", "58．",
                           HY_DOCX.replace("45", "46")),
                          ("after", "架空太郎（2019）．「架空の題目」．『架空学会誌』，第29号，pp.45-", "59．",
                           HY_DOCX.replace("58", "59"))]:
    paras = [("見出し", H1), ("本文", P_INTRO), ("本文", CTRL_DOCX), ("引用文献見出し", RH), ("引用文献", REF1),
             ("引用文献", HY_DOCX)]
    pages = flow([front(), H1, Raw(*body(P_INTRO)), Raw(*body(CTRL_PUB)), RH, Raw(*REF1_LINES), Raw(l1, l2), BREAK,
                  en_block()], first=25)
    case(f"hy_{name}", "hyphen", paras, pages,
         "引用文献の「pp.45-58」が、PDF では「pp.46-」（行末のハイフン）の改行の後の「59」。直しが 2 つ（12 文字以内）なら"
         "まとめた違いになる。ハイフンを消したり空白を入れたりせず、数字だけを直す。",
         truth={idx(paras, CTRL_DOCX): CTRL_PUB, idx(paras, HY_DOCX): pub})

# ---------------------------------------------------------------- 段落の最初・最後の PDF にだけある文字（edge）
E_BODY = "本稿では，架空の授業の記録を観点ごとに整理し，その特徴を三つに分けて考察した"      # 「。」がない
E_NEXT = "次の節では，それぞれの特徴について，具体的な発話の例を挙げて詳しく述べる。"


def edge_article(docx_body, pdf_body_lines, next_docx=E_NEXT, next_pdf_lines=None):
    paras = [("見出し", H1), ("本文", P_INTRO), ("本文", CTRL_DOCX), ("見出し", H2), ("本文", docx_body),
             ("本文", next_docx), ("見出し", H3), ("本文", P_DISC), ("引用文献見出し", RH), ("引用文献", REF1)]
    pages = flow([front(), H1, Raw(*body(P_INTRO)), Raw(*body(CTRL_PUB)), H2, Raw(*pdf_body_lines),
                  Raw(*(next_pdf_lines or body(next_docx))), H3, Raw(*body(P_DISC)), RH, Raw(*REF1_LINES), BREAK,
                  en_block()], first=25)
    return paras, pages


_paras, _pages = edge_article(E_BODY, body(E_BODY + "。"))
case("edge_end_period", "edge", _paras, _pages,
     "docx の段落の最後に「。」がなく、PDF の段落の最後の行にはある（校正で足された）。「。」を足す。",
     truth={idx(_paras, CTRL_DOCX): CTRL_PUB, idx(_paras, E_BODY): E_BODY + "。"})
E_ADD = "。以上を踏まえる"
_paras, _pages = edge_article(E_BODY, body(E_BODY + E_ADD + "。"))
case("edge_end_words", "edge", _paras, _pages,
     "PDF の段落の最後の行に、校正で足された短い文字「。以上を踏まえる。」が docx の最後の文字の後ろに続く（同じ行）。"
     "足すか、決められなければ 13 章に出す。",
     truth={idx(_paras, CTRL_DOCX): CTRL_PUB, idx(_paras, E_BODY): E_BODY + E_ADD + "。"},
     expect={"default": "exact", idx(_paras, E_BODY): "reported"})
E_LONG = "。なお，授業の記録は二人の観察者が別々に取り，授業の後で照らし合わせた"
_paras, _pages = edge_article(E_BODY, body(E_BODY + E_LONG + "。"))
case("edge_end_sentence", "edge", _paras, _pages,
     "PDF の段落の最後に、校正で足された一文（約 35 文字、2 行にわたる）が続く。足すか、決められなければ 13 章に出す"
     "（黙って落とさない）。",
     truth={idx(_paras, CTRL_DOCX): CTRL_PUB, idx(_paras, E_BODY): E_BODY + E_LONG + "。"},
     expect={"default": "exact", idx(_paras, E_BODY): "reported"})
E_LINE = "なお，授業の記録は別に保存した。"
_paras, _pages = edge_article(E_BODY + "。", body(E_BODY + "。") + [E_LINE])
case("edge_end_line", "edge", _paras, _pages,
     "PDF の段落の最後の行の次の行に、校正で足された一文（「。」で終わる 16 文字）がまるごと入っている（docx にない）。"
     "足すか、決められなければ 13 章に出す（黙って落とさない）。",
     truth={idx(_paras, CTRL_DOCX): CTRL_PUB, idx(_paras, E_BODY + "。"): E_BODY + "。" + E_LINE},
     expect={"default": "exact", idx(_paras, E_BODY + "。"): "reported"})
E_START = "本稿では，架空の授業の記録を観点ごとに整理し，その特徴を三つに分けて考察した。"
_paras, _pages = edge_article(E_START, body("まず，" + E_START))
case("edge_start_words", "edge", _paras, _pages,
     "PDF の段落の最初の行の書き出しに、校正で足された「まず，」がある（docx にない）。足すか、決められなければ 13 章に出す。",
     truth={idx(_paras, CTRL_DOCX): CTRL_PUB, idx(_paras, E_START): "まず，" + E_START},
     expect={"default": "exact", idx(_paras, E_START): "reported"})
# 校正で消された段落の最後の文字が、次の段落の書き出しにもある
E_DEL_DOCX = "本稿では，架空の授業の記録を観点ごとに整理し，その特徴を三つに分けて考察した。以上"
E_DEL_PUB = "本稿では，架空の授業の記録を観点ごとに整理し，その特徴を三つに分けて考察した。"
E_DEL_NEXT = "以上のことから，次の節では，それぞれの特徴について，具体的な発話の例を挙げて詳しく述べる。"
_paras, _pages = edge_article(E_DEL_DOCX, body(E_DEL_PUB), next_docx=E_DEL_NEXT)
case("edge_del_next_start", "edge", _paras, _pages,
     "docx の段落の最後の「以上」が出版版で消されていて、次の段落が「以上のことから」で始まる。段落の最後の「以上」を消す"
     "（次の段落の書き出しと並べて残さない）。決められなければ 13 章に出す。",
     truth={idx(_paras, CTRL_DOCX): CTRL_PUB, idx(_paras, E_DEL_DOCX): E_DEL_PUB},
     expect={"default": "exact", idx(_paras, E_DEL_DOCX): "reported"})
_paras, _pages = edge_article(E_DEL_DOCX.replace("以上", "以上の"), body(E_DEL_PUB), next_docx=E_DEL_NEXT)
case("edge_del3_next_start", "edge", _paras, _pages,
     "docx の段落の最後の「以上の」が出版版で消されていて、次の段落が「以上のことから」で始まる。段落の最後の「以上の」を消す。"
     "決められなければ 13 章に出す。",
     truth={idx(_paras, CTRL_DOCX): CTRL_PUB, idx(_paras, E_DEL_DOCX.replace("以上", "以上の")): E_DEL_PUB},
     expect={"default": "exact", idx(_paras, E_DEL_DOCX.replace("以上", "以上の")): "reported"})
# 段落の最後の数字が、次の文献の「（2019）」と偶然一致する（行全体でしか一致させない行の年が出版版で直されている）
YEAR_DOCX = "架空二郎（2021）．「架空の比の研究」．『架空教育研究』，第12巻，2018"
YEAR_PUB = YEAR_DOCX[:-4] + "2019"
YEAR_NEXT = "見本三郎（2019）．「見本の題目」．『見本誌』，第3巻，pp.5-8．"
PAGE_DOCX = "架空三郎（2017）．「架空の図の研究」．『架空数学研究』，第30号，p.16"
PAGE_PUB = PAGE_DOCX[:-2] + "17"
PAGE_NEXT = "見本四郎（2016）．「見本の図の題目」．『見本誌』，第4巻，pp.1-9．"
for name, ref, pub, lines, nxt in [
        ("year", YEAR_DOCX, YEAR_PUB, ["架空二郎（2021）．「架空の比の研究」．『架空", "教育研究』，第12巻，", "2019"], YEAR_NEXT),
        ("page", PAGE_DOCX, PAGE_PUB, ["架空三郎（2017）．「架空の図の研究」．『架空", "数学研究』，第30号，p.", "17"], PAGE_NEXT)]:
    paras = [("見出し", H1), ("本文", P_INTRO), ("本文", CTRL_DOCX), ("引用文献見出し", RH), ("引用文献", REF1),
             ("引用文献", ref), ("引用文献", nxt)]
    pages = flow([front(), H1, Raw(*body(P_INTRO)), Raw(*body(CTRL_PUB)), RH, Raw(*REF1_LINES), Raw(*lines),
                  Raw(*jwrap(nxt)), BREAK, en_block()], first=25)
    case(f"edge_{name}_next_ref", "N10", paras, pages,
         "引用文献の最後の数字だけの行が出版版で直されていて（行全体でしか一致させない行）、次の文献の書き出しの年に docx の"
         "数字と同じ数字がある。直すか、決められなければ 13 章に出す（次の文献の数字と並べて黙って残したり、一部を消したり"
         "しない）。",
         truth={idx(paras, CTRL_DOCX): CTRL_PUB, idx(paras, ref): pub},
         expect={"default": "exact", idx(paras, ref): "reported"})

# ---------------------------------------------------------------- en dash（dash）
DASH_BODY = "架空の研究では pp.11–16 の範囲を参照した。"
DASH_PUB = DASH_BODY.replace("–", "-")
paras = [("見出し", H1), ("本文", P_INTRO), ("本文", CTRL_DOCX), ("本文", DASH_BODY), ("引用文献見出し", RH),
         ("引用文献", REF1)]
pages = flow([front(), H1, Raw(*body(P_INTRO)), Raw(*body(CTRL_PUB)), Raw("　架空の研究では pp.11-", "16 の範囲を参照した。"),
              RH, Raw(*REF1_LINES), BREAK, en_block()], first=25)
case("dash_endash_eol", "endash", paras, pages,
     "docx の en dash「–」と同じ位置に、PDF では英数字の後の行末の「-」がある。案 (b) なら「-」に直す（OK）、案 (a) なら"
     "docx のまま 13 章に出す（REPORTED）。消してはいけない。",
     truth={idx(paras, CTRL_DOCX): CTRL_PUB, idx(paras, DASH_BODY): DASH_PUB},
     expect={"default": "exact", idx(paras, DASH_BODY): "reported"})

# ---------------------------------------------------------------- 段落の書き出しの写しが、すぐ前の図の中の文字にある（dupnext）
NX_PUB = "そこで本研究では，表を縦に見る活動を取り入れた授業を計画し，その効果を二つの学級で確かめることとした。"
NX_DOCX = NX_PUB.replace("表を縦に見る", "表を縦に読む")
NX_COPY = ["授業の計画（原稿の写し）", "そこで本研究では，表を縦に", "見る活動を取り入れた授業を", "計画する"]
paras = [("見出し", H1), ("本文", P_INTRO), ("本文", CTRL_DOCX), ("見出し", H2), ("本文", T_HEAD), ("画像", "原稿"),
         ("本文", NX_DOCX), ("図キャプション", "図１　架空の授業の計画"), ("本文", P_AFTER), ("引用文献見出し", RH),
         ("引用文献", REF1)]
pages = flow([front(), H1, Raw(*body(P_INTRO)), Raw(*body(CTRL_PUB)), H2, Raw(*body(T_HEAD)), Raw(*NX_COPY),
              Raw(*body(NX_PUB)), Raw("図１　架空の授業の計画"), Raw(*body(P_AFTER)), RH, Raw(*REF1_LINES), BREAK,
              en_block()], first=25)
case("dupnext_head_copy", "N10", paras, pages,
     "段落の書き出し（「そこで本研究では，表を縦に」）の写しが、段落のすぐ前の図の中の文字にあり、docx の段落はその直後に"
     "校正の直し（「縦に読む」→ PDF「縦に見る」）がある。直しは本来の位置で直し、図の中の文字を足さない。",
     truth={idx(paras, CTRL_DOCX): CTRL_PUB, idx(paras, NX_DOCX): NX_PUB})

_names = [c["name"] for c in CASES]
_check(len(_names) == len(set(_names)), "反例の名前が重なる")
