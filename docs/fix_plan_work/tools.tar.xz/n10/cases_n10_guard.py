"""N10 とその仲間の反例（guard の担当が作ったもの。文字はすべて架空）。oracle/runner.py の書式。

  python oracle/run_all.py <src> n10/cases_n10_guard.py --name <名前>

段落の後ろ・前・途中が、PDF の中で表・図の中の文字・別の段落（2 段組みの読み順のずれ）で分断される形を、分断の長さ
（20・60・200・600 文字ほど）と、分断された部分の大きさ（最後の 8 文字・最後の行・最後の 2 行・段落の前半など）で組み合わせる。
校正の直しがない形（docx のまま残ればよい）、分断された部分に直しがある形（直せなければ 13 章に出ればよい）、分断の手前に
直しがある形（直すはず）、よく似た文字列が近くにある形も入れる。あわせて、行末のハイフンをまたぐ 2 つの直し（対象 2）、
段落の最初・最後の黙った違い（対象 3）、en dash（対象 4。truth は案 (b)〈PDF の「-」に合わせる〉のもの）。

expect の考え方（原則だけから決める）:
  - 分断された部分に違いがない段落は exact（docx のまま残れば OK）。
  - 分断された部分に違いがある段落は reported（PDF に合わせて直せれば OK、直せなければ docx のまま 13 章に出ればよい）。
  - 段落の最後・最初の、PDF にだけある文字（校正で足された文字）も reported。
  - 分断の手前の直しのある段落も reported（直せれば OK。版どうしの OK → REPORTED の数を、守りで直さなくなった校正として数える）。
  - ハイフン・en dash は exact。
"""
from runner import BREAK, DEFAULTS, Join, Raw, flow, journal_line, wrap, zen  # noqa: F401

H1 = "１．はじめに"
H2 = "２．研究の方法"
RH = "引用および参考文献"
PA = ("本研究の目的は，架空の中学校で行った比の授業において，生徒が二つの量の関係をどのように捉えたかを，"
      "発話の記録と記述の分析によって明らかにすることである。")
# 分断される段落（24 文字の行で 4 行ほど。最後の行は「増えていったことがうかがえる。」の前後）
PB = ("授業は全部で五回行い，各回の記録を第２節で述べる枠組みで分類した。分類の結果は表１に示すとおりであり，"
      "回を追うごとに対応の見方が増えていったことがうかがえる。")
PB_LONG = PB + ("さらに，第三回以降では，二つの量の変化を対応させて説明する生徒が増え，記述の中にも表や式を用いた説明が"
                "多く見られるようになった。")
PC = "次に，生徒の記述を観点ごとに整理し，その特徴を三つの段階に分けて述べる。第一の段階は量を別々に見る段階である。"
PD = "第二の段階は一方の量の変化に着目する段階であり，第三の段階は二つの量の変化を対応させる段階である。"
PE = "以下では，それぞれの段階に当たる発話の例を示し，段階の間の移り変わりを授業の展開に沿って述べる。"
PF = "なお，発話の分類は二人の研究者が別々に行い，一致しなかったものは協議して決めた。"
R1 = "架空一郎（2019）．「架空の数の研究」．『架空数学研究』，第29号，pp.11-16．"
R2 = "架空二郎（2021）．「架空の比の研究」．『架空教育研究』，第12巻，pp.45-58．"
R3 = "架空三郎（2017）．「架空の図の研究」．『架空数学研究』，第30号，pp.1-16．"
R4 = "架空四郎（2020）．「架空の表の研究」．『架空学会誌』，第8巻，pp.21-36．"
FIG_CAP = "図１　架空の授業における発話の数の変化"
TAB_CAP = "表１　架空の観点ごとの発話の数"

# 図の中の文字（docx では図は画像なので docx にない。4 文字以上の行）
FIG_POOL = ["架空の点Ａの位置", "横の軸は時間の長さ", "縦の軸は量の大きさ", "生徒の発話の数", "第一の段階の発話",
            "第二の段階の発話", "第三の段階の発話", "授業の前半の記録", "授業の後半の記録", "記述の分類の結果",
            "対応の見方の数", "量を別々に見る見方", "架空の曲線の名前", "変化の割合の目安", "架空の目盛りの説明"]


def fig_lines(n):
    """図の中の文字の行（合わせて n 文字ほど）。"""
    out, total, k = [], 0, 0
    while total < n:
        s = FIG_POOL[k % len(FIG_POOL)] + ("" if k < len(FIG_POOL) else zen(k // len(FIG_POOL)))
        out.append(s)
        total += len(s)
        k += 1
    return out


def table_rows(n):
    """Word の表の行（セルの文字が合わせて n 文字ほど）。見出しの行と、観点の名前と数字のセルの行。"""
    rows = [["観点", "第１回", "第２回", "第３回"]]
    names = ["量を別々に見る", "一方の量に着目する", "対応させて見る", "式で表す", "表で表す", "言葉で説明する",
             "図で説明する", "変化の割合を見る"]
    total, k = sum(len(c) for c in rows[0]), 0
    while total < n:
        name = names[k % len(names)] + ("" if k < len(names) else zen(k // len(names)))
        row = [name, str(3 + k % 7), str(5 + k % 4), str(2 + k % 9)]
        rows.append(row)
        total += sum(len(c) for c in row)
        k += 1
    return rows


def cell_lines(rows):
    return [c for row in rows for c in row]


OTHER_PARAS = [PC, PD, PE, PF]


def other_text(n):
    """別の段落（docx では分断される段落の後ろにある段落）を、合わせて n 文字ほど。"""
    out, total = [], 0
    for p in OTHER_PARAS:
        if total >= n:
            break
        out.append(p)
        total += len(p)
    return out


def split_tail(text, kind):
    """段落の文字を、分断の前と後ろに分ける。kind: tail8（最後の 8 文字）/ line（最後の行）/ lines2（最後の 2 行）/
    half（後ろの半分）/ head（最初の行だけ前）。"""
    ls = wrap(text)
    if kind == "tail8":
        return text[:-8], text[-8:]
    if kind == "line":
        return "".join(ls[:-1]), ls[-1]
    if kind == "lines2":
        return "".join(ls[:-2]), "".join(ls[-2:])
    if kind == "half":
        k = len(text) // 2
        return text[:k], text[k:]
    if kind == "head":
        return ls[0], "".join(ls[1:])
    raise ValueError(kind)


def front():
    return Raw(journal_line(fp=25, lp=36), DEFAULTS["題目"], DEFAULTS["副題"], "試験　五郎")


CASES = []


def add(name, note, paras, truth, blocks, expect="exact", angle="layout", item="N10"):
    CASES.append({"name": name, "angle": angle, "item": item, "paras": paras, "truth": truth,
                  "pages": flow(blocks, first=25), "expect": expect, "note": note})


# ---------------------------------------------------------------------------- 段落の後ろ（前）が分断される形
# docx: 見出し・PA・PB（分断される段落）・[図 / 表]・PC・PD・PE・PF・引用文献
# PDF : 見出し・PA・PB の前の部分・[分断する文字]・PB の後ろの部分・（残りの段落）
# 直し: none（なし）/ tail（分断された部分に直し: 「うかがえる」→「うかがえた」など）/ main（分断の手前に直し: 「五回」→「５回」）
EDITS = {
    "none": lambda s: s,
    "tail": lambda s: s.replace("うかがえる。", "うかがえた。").replace("ようになった。", "ようになっていった。"),
    "main": lambda s: s.replace("全部で五回", "全部で５回"),
}


def body_paras(pb, inter_kind, n):
    """docx の段落の並び（分断する文字の種類に合わせて図・表を入れる）と、分断される段落の番号。"""
    paras = [("見出し", H1), ("本文", PA), ("本文", pb)]
    if inter_kind == "fig":
        paras += [("画像", "架空の図"), ("図キャプション", FIG_CAP)]
    elif inter_kind == "table":
        paras += [("表キャプション", TAB_CAP), ("表", table_rows(n))]
    paras += [("本文", PC), ("本文", PD), ("本文", PE), ("本文", PF), ("引用文献見出し", RH), ("引用文献", R1),
              ("引用文献", R2)]
    return paras, 2


def interruption(inter_kind, n):
    """PDF の中で段落を分断する行と、その後ろに残る段落（docx の順で、分断の後ろに出すもの）。"""
    if inter_kind == "fig":
        return [*fig_lines(n), FIG_CAP], OTHER_PARAS
    if inter_kind == "table":
        return [TAB_CAP, *cell_lines(table_rows(n))], OTHER_PARAS
    if inter_kind == "para":
        ps = other_text(n)
        return [ln for p in ps for ln in wrap(p)], OTHER_PARAS[len(ps):]
    raise ValueError(inter_kind)


for inter_kind in ("fig", "table", "para"):
    for n in (20, 60, 200, 600):
        if inter_kind == "para" and n == 600:
            continue                       # 別の段落は 4 段落（300 文字ほど）まで
        for part in ("tail8", "line", "lines2", "head", "half"):
            for edit in ("none", "tail", "main"):
                if part in ("head", "half") and edit == "tail":
                    edit_fn = lambda s: s.replace("授業は全部", "授業は合わせて")   # noqa: E731  分断された前の部分の直し
                else:
                    edit_fn = EDITS[edit]
                if edit != "none" and n not in (60, 600) and not (inter_kind == "para" and n == 200):
                    continue               # 直しのある形は 60・600（別の段落は 60・200）文字の分断だけ
                pb = PB_LONG if part in ("lines2", "half") else PB
                paras, idx = body_paras(pb, inter_kind, n)
                pub = edit_fn(pb)
                before, after = split_tail(pub, part)
                inter, rest = interruption(inter_kind, n)
                if part == "head":
                    # 段落の最初の行が、分断する文字の前（ページの最後など）にあり、残りが後ろにある
                    blocks = [front(), H1, PA, Raw(*wrap(before)), Raw(*inter), Raw(*wrap(after)), *rest]
                else:
                    blocks = [front(), H1, PA, Raw(*wrap(before)), Raw(*inter), Raw(*wrap(after)), *rest]
                blocks += [RH, R1, R2]
                truth = {idx: pub} if pub != pb else {}
                # 直しのある段落は reported（直せれば OK。分断が長いと段落が見つからない段落になることもある）。
                # 直しを守りで直さなくなったか（OK → REPORTED）は、版どうしの判定の違いで数える
                expect = {"default": "exact", idx: "reported"} if edit != "none" else "exact"
                add(f"n10g_{inter_kind}{n}_{part}_{edit}",
                    f"段落 2 の{ {'tail8': '最後の 8 文字', 'line': '最後の行', 'lines2': '最後の 2 行', 'head': '最初の行の後ろ', 'half': '後ろの半分'}[part]}"
                    f"が、{ {'fig': '図の中の文字', 'table': '表のセル', 'para': '別の段落'}[inter_kind]}（{n} 文字ほど）で分断される。"
                    f"直し: { {'none': 'なし', 'tail': '分断された部分', 'main': '分断の手前'}[edit]}。",
                    paras, truth, blocks, expect=expect)


# ---------------------------------------------------------------------------- 引用文献の後ろが、ほかの文献の後ろに出る（2 段組みの読み順）
for edit in ("none", "pages"):
    r1 = R1 if edit == "none" else R1.replace("pp.11-16", "pp.11-17")
    paras = [("見出し", H1), ("本文", PA), ("本文", PB), ("引用文献見出し", RH), ("引用文献", R1), ("引用文献", R2),
             ("引用文献", R3), ("引用文献", R4)]
    blocks = [front(), H1, PA, PB, RH, Raw(r1[:-8]), Raw(*wrap(R2)), Raw(*wrap(R3)), Raw(r1[-8:]), Raw(*wrap(R4))]
    add(f"n10g_ref_tail_{edit}", "引用文献 R1 の最後の 8 文字が、R2・R3（R3 も「16．」で終わる）の後ろに出る。"
        + ("直しなし。" if edit == "none" else "R1 の終わりのページが出版版で「17」に直っている。"),
        paras, {4: r1} if r1 != R1 else {}, blocks,
        expect={"default": "exact", 4: "reported"} if edit != "none" else "exact")

# 段落の最後の文字・数字が、窓の中の次の文献の文字と偶然一致する（docx「…第12巻，2018」→ PDF の行「2019」、次の文献「（2019）」）
YEAR_REF = "架空五郎（2021）．「架空の量の研究」．『架空教育研究』，第12巻，2018"
NEXT_REF = "架空六郎（2019）．「架空の割合の研究」．『架空数学研究』，第31号，pp.5-9．"
paras = [("見出し", H1), ("本文", PA), ("引用文献見出し", RH), ("引用文献", R1), ("引用文献", YEAR_REF), ("引用文献", NEXT_REF)]
add("n10g_year_next_ref", "引用文献の最後の年が出版版で「2019」に直り、次の文献に「（2019）」がある。docx の「2018」を消したり"
    "黙って残したりせず、直すか 13 章に出す。",
    paras, {4: YEAR_REF[:-4] + "2019"},
    [front(), H1, PA, RH, R1, Raw("架空五郎（2021）．「架空の量の研究」．『架空教育研究』，第12巻，", "2019"), NEXT_REF],
    expect={"default": "exact", 4: "reported"}, item="N10")

# ---------------------------------------------------------------------------- よく似た文字列が近くにある形
SIM_A = "架空省（2018a）．『架空学校学習指導要領（令和元年告示）解説　架空算数編』．架空文教出版．"
SIM_B = "架空省（2018b）．『架空学校学習指導要領（令和元年告示）解説　架空総則編』．架空館出版社．"
for edit in ("none", "tail"):
    a = SIM_A if edit == "none" else SIM_A.replace("架空文教出版", "架空文教出版社")
    paras = [("見出し", H1), ("本文", PA), ("引用文献見出し", RH), ("引用文献", R1), ("引用文献", SIM_A), ("引用文献", SIM_B),
             ("引用文献", R2)]
    blocks = [front(), H1, PA, RH, R1, Raw(a[:20]), Raw(*wrap(SIM_B)), Raw(*wrap(R2)), Raw(a[20:])]
    add(f"n10g_similar_refs_{edit}", "よく似た文献 A・B の A の後ろの部分が、B と次の文献の後ろに出る。"
        + ("直しなし。" if edit == "none" else "A の出版社名が出版版で直っている。"),
        paras, {4: a} if a != SIM_A else {}, blocks, expect={"default": "exact", 4: "reported"} if edit != "none" else "exact")

# 次の段落が、分断された段落の最後と同じ文字で終わる（「…ことがうかがえる。」）
PC_SAME = "次に，生徒の記述を観点ごとに整理すると，第三回以降で対応の見方が増えていったことがうかがえる。"
for edit in ("none", "tail"):
    pub = EDITS[edit](PB)
    before, after = split_tail(pub, "line")
    paras = [("見出し", H1), ("本文", PA), ("本文", PB), ("本文", PC_SAME), ("本文", PD), ("本文", PE),
             ("引用文献見出し", RH), ("引用文献", R1)]
    blocks = [front(), H1, PA, Raw(*wrap(before)), Raw(*wrap(PC_SAME)), Raw(*wrap(PD)), Raw(*wrap(PE)), Raw(after), RH, R1]
    add(f"n10g_same_ending_{edit}", "分断された段落の最後の行が、同じ文字で終わる次の段落などの後ろに出る。"
        + ("直しなし。" if edit == "none" else "分断された部分に直し。"),
        paras, {2: pub} if pub != PB else {}, blocks,
        expect={"default": "exact", 2: "reported"} if edit != "none" else "exact")

# ---------------------------------------------------------------------------- 本当の校正（守りで直さなくならないか）
# 段落の最後の文字が消されている（次の段落の行が続く。次の段落の書き出しとは違う文字）
P_DEL = "本稿では，架空の授業の記録を観点ごとに整理し，その特徴を三つに分けて考察した。以上"
add("n10g_real_end_delete", "段落の最後の「以上」が出版版で消されている（すぐ後ろは次の段落）。今までどおり消す（exact）。",
    [("見出し", H1), ("本文", PA), ("本文", P_DEL), ("本文", PC), ("引用文献見出し", RH), ("引用文献", R1)],
    {2: P_DEL[:-2]}, [front(), H1, PA, P_DEL[:-2], PC, RH, R1], item="new", angle="edit")
# 段落の最後の文字が消されていて、その文字が次の段落の書き出しにもある（対象 3）
P_DEL2 = "本稿では，架空の授業の記録を観点ごとに整理し，その特徴を三つに分けて考察した。そ"
PC_SO = "その結果，第三回以降で対応の見方が増えていったことが分かった。"
add("n10g_end_delete_same_as_next", "段落の最後の「そ」が出版版で消されていて、次の段落が「その結果」で始まる（対象 3）。"
    "消すか、13 章に出す。",
    [("見出し", H1), ("本文", PA), ("本文", P_DEL2), ("本文", PC_SO), ("引用文献見出し", RH), ("引用文献", R1)],
    {2: P_DEL2[:-1]}, [front(), H1, PA, P_DEL2[:-1], PC_SO, RH, R1],
    expect={"default": "exact", 2: "reported"}, item="new", angle="edit")
# 段落の最後に「。」が足されている（同じ行。対象 3）
P_NOEND = "本稿では，架空の授業の記録を観点ごとに整理し，その特徴を三つに分けて考察した"
add("n10g_end_period_added", "段落の最後の「。」が出版版で足されている（同じ行）。足すか、13 章に出す（対象 3）。",
    [("見出し", H1), ("本文", PA), ("本文", P_NOEND), ("本文", PC), ("引用文献見出し", RH), ("引用文献", R1)],
    {2: P_NOEND + "。"}, [front(), H1, PA, P_NOEND + "。", PC, RH, R1],
    expect={"default": "exact", 2: "reported"}, item="new", angle="edit")
# 段落の最後に一文が足されている（同じ行から次の行へ。対象 3）
ADDED = "なお，記録は二人で取った。"
add("n10g_end_sentence_added", "段落の最後に一文が出版版で足されている（同じ行から続く）。足すか、13 章に出す（対象 3）。",
    [("見出し", H1), ("本文", PA), ("本文", P_DEL[:-2]), ("本文", PC), ("引用文献見出し", RH), ("引用文献", R1)],
    {2: P_DEL[:-2] + ADDED}, [front(), H1, PA, P_DEL[:-2] + ADDED, PC, RH, R1],
    expect={"default": "exact", 2: "reported"}, item="new", angle="edit")
# 段落の最初に文字が足されている（同じ行。対象 3）
add("n10g_start_added", "段落の最初に「まず，」が出版版で足されている（同じ行）。足すか、13 章に出す（対象 3）。",
    [("見出し", H1), ("本文", PA), ("本文", PC), ("引用文献見出し", RH), ("引用文献", R1)],
    {2: "まず，" + PC}, [front(), H1, PA, "まず，" + PC, RH, R1],
    expect={"default": "exact", 2: "reported"}, item="new", angle="edit")
# 段落の途中の直しが、ほかの段落（図のキャプション）で分断された位置にある
P_SPLIT = "授業の記録は，二人の研究者が別々に分類し，一致しなかったものは協議して決めた。その結果，一致率は八割を超えた。"
P_SPLIT_PUB = P_SPLIT.replace("協議して決めた", "協議のうえ決めた")
cut = P_SPLIT_PUB.index("のうえ")
add("n10g_fix_at_caption_split", "段落の途中が図のキャプション（docx の段落）で分断され、その位置に直しがある。"
    "直すか、13 章に出す。",
    [("見出し", H1), ("本文", PA), ("本文", P_SPLIT), ("画像", "架空の図"), ("図キャプション", FIG_CAP), ("本文", PC),
     ("引用文献見出し", RH), ("引用文献", R1)],
    {2: P_SPLIT_PUB}, [front(), H1, PA, Raw(*wrap(P_SPLIT_PUB[:cut])), Raw(FIG_CAP), Raw(*wrap(P_SPLIT_PUB[cut:])), PC, RH, R1],
    expect={"default": "exact", 2: "reported"}, item="new", angle="edit")

# ---------------------------------------------------------------------------- 行末のハイフンをまたぐ 2 つの直し（対象 2）
REF_HY = "架空太郎（2019）．「架空の題目」．『架空学会誌』，第29号，pp.45-58．"
for name, l1, l2, pub in [
        ("both", "架空太郎（2019）．「架空の題目」．『架空学会誌』，第29号，pp.46-", "59．", REF_HY.replace("45-58", "46-59")),
        ("fffe", "架空太郎（2019）．「架空の題目」．『架空学会誌』，第29号，pp.46￾", "59．", REF_HY.replace("45-58", "46-59")),
        ("before", "架空太郎（2019）．「架空の題目」．『架空学会誌』，第29号，pp.46-", "58．", REF_HY.replace("45-58", "46-58")),
        ("after", "架空太郎（2019）．「架空の題目」．『架空学会誌』，第29号，pp.45-", "59．", REF_HY.replace("45-58", "45-59"))]:
    add(f"n10g_hyphen_two_fixes_{name}", "引用文献のページの範囲の「-」が行末にあり、その前後の数字が出版版で直っている（対象 2）。"
        "docx の「-」を消さない。",
        [("見出し", H1), ("本文", PA), ("引用文献見出し", RH), ("引用文献", R1), ("引用文献", REF_HY)],
        {4: pub}, [front(), H1, PA, RH, R1, Raw(l1, l2)], item="new", angle="edit")
# 英文の行末のハイフネーションの近くの 2 つの直し（docx にハイフンがない）
EN_REF = "Shiken, T. (2019). Fictional explanation of ratio. Fictional Journal of Mathematics, 12, 45-58."
add("n10g_hyphenation_two_fixes", "英文の引用文献で、行末のハイフネーション（docx にハイフンがない）の前後に直しがある（対象 2 の仲間）。"
    "語の間に空白を足さない。",
    [("見出し", H1), ("本文", PA), ("引用文献見出し", RH), ("引用文献", R1), ("引用文献", EN_REF)],
    {4: EN_REF.replace("explanation", "explanations").replace("Fictional explanation", "Fictitious explanation")},
    [front(), H1, PA, RH, R1, Raw("Shiken, T. (2019). Fictitious expla-", "nations of ratio. Fictional Journal of",
                                  "Mathematics, 12, 45-58.")], item="new", angle="edit")

# ---------------------------------------------------------------------------- en dash（対象 4。truth は案 (b)）
for name, body, lines, pub in [
        ("endash_line_end", "架空の研究では pp.11–16 の範囲を参照した。", ["架空の研究では pp.11-", "16 の範囲を参照した。"],
         "架空の研究では pp.11-16 の範囲を参照した。"),
        ("endash_same", "架空の研究では pp.11–16 の範囲を参照した。", ["架空の研究では pp.11–", "16 の範囲を参照した。"], None),
        ("endash_fffe", "架空の研究では pp.11–16 の範囲を参照した。", ["架空の研究では pp.11￾", "16 の範囲を参照した。"], None),
        ("hyphen_line_end", "架空の研究では pp.11-16 の範囲を参照した。", ["架空の研究では pp.11-", "16 の範囲を参照した。"], None)]:
    add(f"n10g_{name}", "docx のダッシュと、PDF の英数字の後の行末の「-」（対象 4）。en dash は案 (b) なら PDF の「-」に直す。"
        "U+FFFE（何の文字か分からない）なら docx のまま。",
        [("見出し", H1), ("本文", body), ("引用文献見出し", RH), ("引用文献", R1)],
        {1: pub} if pub else {}, [front(), H1, Raw(*lines), RH, R1], item="new", angle="edit")

# ---------------------------------------------------------------------------- DESIGN 4.4 の限界に挙げた、N10 の仲間の形
# 終わりのページが出版版で直された引用文献が続き、その後ろに同じ「61．」で終わる文献がある
RA = "架空七郎（2016）．「架空の量の研究」．『架空学会誌』，第20号，pp.28-56．"
RB = "架空八郎（2017）．「架空の比の研究」．『架空学会誌』，第21号，pp.36-61．"
RC = "架空九郎（2018）．「架空の数の研究」．『架空学会誌』，第22号，pp.10-61．"
paras = [("見出し", H1), ("本文", PA), ("引用文献見出し", RH), ("引用文献", RA), ("引用文献", RB), ("引用文献", RC)]
add("n10g_refs_end_pages_corrected", "終わりのページが出版版で直された引用文献が 2 つ続き（「56」→「57」、「61」→「62」）、その後ろに"
    "同じ「61．」で終わる文献がある（DESIGN 4.4 の限界の形）。直すか、13 章に出す。",
    paras, {3: RA.replace("56", "57"), 4: RB.replace("36-61", "36-62")},
    [front(), H1, PA, RH, Raw(RA[:-3], "57．"), Raw(RB[:-3], "62．"), Raw(*wrap(RC))],
    expect={"default": "exact", 3: "reported", 4: "reported"}, item="N10")
# 段落の最後の行が「）。」だけ（前の行の最後で出版版の直し）
P_PAREN = "授業の記録は，二人の研究者が別々に分類した（試験，2021"
add("n10g_last_line_paren", "段落の最後の行が「）。」だけで、その前の行の年が出版版で「2022」に直っている。直すか、13 章に出す。",
    [("見出し", H1), ("本文", PA), ("本文", P_PAREN + "）。"), ("本文", PC), ("引用文献見出し", RH), ("引用文献", R1)],
    {2: P_PAREN.replace("2021", "2022") + "）。"},
    [front(), H1, PA, Raw(P_PAREN.replace("2021", "2022")), Raw("）。"), PC, RH, R1],
    expect={"default": "exact", 2: "reported"}, item="N10")
