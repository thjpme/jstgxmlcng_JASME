"""joint: 段落の途中の、PDF の 1 行の中だけの 1〜2 文字の偶然の一致（表のキャプションの「表１」の「１」と docx の「12点」の
「1」など）を確かめる例（rvB2p の quick.py の形。架空の文字）。

段落 P1 の「12点」の前に、PDF では表・図の文字（docx にないキャプションとセル、docx の表）が入り、出版版で「13点」に直された
もの（と直されていないもの）。比べるため、段落の途中の行がまるごと校正で書き換えられたもの、行の最初の「。」の後ろに
校正で文が足されたものも入れる（これらは偶然の一致ではない）。
"""
FR = ["（1）", "照合の原則の検証用文書", "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
P1 = "架空の調査の結果を表１に示す。その結果，生徒の平均は12点であり，前回の調査より高かった。"
P2 = "次の段落は表の後ろに続く本文の段落であり，照合の確かめに使う。"
CAP = "表１　架空の得点"
ROWS = [["組", "男子", "女子"], ["1組", "31", "27"], ["2組", "14", "23"]]
KROWS = [["区分", "上位", "下位"], ["一組", "多い", "少ない"]]
CASES = {}
cut = P1.index("12点")
for pub in ("13点", "12点", "１３点"):
    p1 = P1.replace("12点", pub)
    truth = {P1: p1} if p1 != P1 else {}
    tag = {"13点": "13", "12点": "same", "１３点": "w13"}[pub]

    def page(mid, p1=p1):
        return ["\n".join([*FR, "　" + p1[:cut], *mid, p1[cut:], "　" + P2, "引用および参考文献", REF, *EN])]
    # docx にない表（キャプションと数字のセル）
    CASES[f"nocap_cells_{tag}"] = dict(body=[("body", P1), ("body", P2)], refs=[REF],
                                       pages=page([CAP, "31", "27", "14", "23"]), truth=truth)
    # docx にない図のキャプションだけ（照合に使わない文字が近くにない）
    CASES[f"nocap_fig_{tag}"] = dict(body=[("body", P1), ("body", P2)], refs=[REF],
                                     pages=page(["図１　架空の図"]), truth=truth)
    # docx にない表（キャプションと漢字のセル）
    CASES[f"nocap_kanji_{tag}"] = dict(body=[("body", P1), ("body", P2)], refs=[REF],
                                       pages=page([CAP, *[c for r in KROWS for c in r]]), truth=truth)
    # docx の表（キャプションの段落と Word の表。docx では段落の後ろ）
    CASES[f"tab_{tag}"] = dict(body=[("body", P1), ("tab_cap", CAP), ("table", ROWS), ("body", P2)], refs=[REF],
                               pages=page([CAP, *[c for r in ROWS for c in r]]), truth=truth)
    CASES[f"tabk_{tag}"] = dict(body=[("body", P1), ("tab_cap", CAP), ("table", KROWS), ("body", P2)], refs=[REF],
                                pages=page([CAP, *[c for r in KROWS for c in r]]), truth=truth)

# 段落の途中の行が、校正でまるごと書き換えられた（docx と 1〜2 文字だけ偶然同じ）
P4A, P4B, P4C = "架空の文の一行目はこのまま残る文である。", "二行目の文字は校正で別の文に書き換える。", "三行目もこのまま残る文である。"
P4 = P4A + P4B + P4C
for k, new in enumerate(("書き換えた後の新しい説明を置いた。", "ここは新しく置いた説明で，元と違う。")):
    CASES[f"rewrite_{k}"] = dict(body=[("body", P4), ("body", P2)], refs=[REF],
                                 pages=["\n".join([*FR, "　" + P4A, new, P4C, "　" + P2, "引用および参考文献", REF, *EN])],
                                 truth={P4: P4A + new + P4C})

# 行の最初の「。」の後ろに、校正で文が足された（足した文はその行の残りを占める）
P3A, P3B = "最初の文では架空の調査の目的を述べる", "次の文では架空の調査の方法を述べる。"
P3 = P3A + "。" + P3B
for k, ins in enumerate(("足した短い一文。", "校正の段階で足された長めの説明の一文がここに入る。")):
    CASES[f"addline_{k}"] = dict(body=[("body", P3), ("body", P2)], refs=[REF],
                                 pages=["\n".join([*FR, "　" + P3A, "。" + ins, P3B, "　" + P2, "引用および参考文献", REF, *EN])],
                                 truth={P3: P3A + "。" + ins + P3B})
