"""judge: fuzz8 で、版 A と版 B の判定が違う段落を数え、例を出す。  python cmp_fz.py f8 A B [VA VB] [N]"""
import json
import sys
from collections import Counter
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
V = S / "n10" / "judge" / "v"
sys.path.insert(0, str(S / "oracle"))
sys.path.insert(0, str(S / "rvB8_regress" / "fuzz8"))
import judge8  # noqa: E402
what, A, B = sys.argv[1:4]
va_want = sys.argv[4] if len(sys.argv) > 4 else "VIOLATION"
vb_want = sys.argv[5] if len(sys.argv) > 5 else "OK"
N = int(sys.argv[6]) if len(sys.argv) > 6 else 8
if what == "f4":
    groups = [(S / "rvB4_regress" / "fuzz" / c / "cases.json", c) for c in
              ("c1", "c8", "c9", "c10", "dense31", "dense32", "h39", "h60")]
    sub = V / "f4"
else:
    groups = [(d / "cases.json", d.name) for d in sorted((S / "rvB8_regress" / "fuzz8").glob("*_3[0-9][0-9]"))
              if (d / "cases.json").exists()]
    sub = V / "f8"
per_group = Counter()
kinds = Counter()
shown = 0
for cp, g in groups:
    ra = json.load(open(sub / f"{g}_{A}.json", encoding="utf-8"))
    rb = json.load(open(sub / f"{g}_{B}.json", encoding="utf-8"))
    cases = json.load(open(cp, encoding="utf-8"))
    for k, c in enumerate(cases):
        for doc, p in c["truth"].items():
            xa, xb = ra["cases"][k]["paras"].get(doc), rb["cases"][k]["paras"].get(doc)
            if xa is None or xb is None:
                continue
            a, _, da = judge8.verdict(doc, p, xa)
            b, _, db = judge8.verdict(doc, p, xb)
            if a == va_want and b == vb_want:
                per_group[g.split("_3")[0]] += 1
                ds = da if va_want != "OK" else db
                if ds:
                    kinds[("足" if ds["added"] else "") + ("消" if ds["deleted"] else "")] += 1
                if shown < N:
                    shown += 1
                    print(f"## {g} case{k} {xa['src']}")
                    print("  docx :", doc[:110])
                    print("  truth:", p[:110])
                    print(f"  {A:5}:", xa["fixed"][:110], "| added", (da or {}).get("added"), "deleted", (da or {}).get("deleted"))
                    print(f"  {B:5}:", xb["fixed"][:110], "| added", (db or {}).get("added"), "deleted", (db or {}).get("deleted"))
print("群ごと:", dict(per_group))
print("種類:", dict(kinds))
