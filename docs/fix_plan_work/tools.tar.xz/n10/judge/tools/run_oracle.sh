#!/bin/sh
# judge: oracle の形の反例集（34 件・N10・guard の N10・rv89・judge の反例）を SRC のコードで実行する。  sh run_oracle.sh SRC TAG [which...]
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
J=$S/n10/judge; L=$J/logs
SRC=$1; TAG=$2; shift 2; W=${*:-"o34 n10 n10g rv89"}
cd $S/oracle
for w in $W; do
  case $w in
    o34) python run_all.py $SRC $S/oracle/cases_seed.py $S/oracle/cases_artifact.py $S/rvB2_principle_cases.py --name judge_o34_$TAG > $L/o34_$TAG.log 2>&1 & ;;
    n10) python run_all.py $SRC $S/n10/cases_n10.py --name judge_n10_$TAG > $L/n10_$TAG.log 2>&1 & ;;
    n10g) python run_all.py $SRC $S/n10/cases_n10_guard.py --name judge_n10g_$TAG > $L/n10g_$TAG.log 2>&1 & ;;
    rv89) python run_all.py $SRC $S/rvB8p/cases_rvB8p.py $S/rvB9p/cases_rvB9p_e1.py $S/rvB9p/cases_rvB9p_e2.py $S/rvB9p/cases_rvB9p_e3.py $S/rvB9p/cases_rvB9p_e4.py $S/rvB9p/cases_rvB9p_e5.py $S/rvB9p/cases_rvB9p_e6.py --name judge_rv89_$TAG > $L/rv89_$TAG.log 2>&1 & ;;
    judge) python run_all.py $SRC $J/../cases_judge.py --name judge_cj_$TAG > $L/cj_$TAG.log 2>&1 & ;;
  esac
done
wait
for w in $W; do f=$L/${w}_$TAG.log; [ $w = judge ] && f=$L/cj_$TAG.log; echo "$w $TAG: $(grep '^合計' $f)"; done
