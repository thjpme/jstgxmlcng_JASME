#!/bin/sh
# judge: 点検の担当の例を SRC のコードで実行する。結果は n10/judge/v/ の下だけに書く。
#   sh run_suites.sh SRC TAG [quick|f4|f8|b210|all] [並列の数]
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
J=$S/n10/judge; V=$J/v; mkdir -p $V/q $V/f4 $V/f8
SRC=$1; TAG=$2; WHAT=${3:-all}; P=${4:-4}
. $J/tools/qfiles.sh
if [ $WHAT = quick ] || [ $WHAT = all ]; then
  n=0
  for f in $QFILES; do
    b=$(basename $(dirname $f))_$(basename $f); b=${b%.*}
    python -I $J/tools/quick.py run $SRC $f $V/q/${b}_$TAG.json > $V/q/${b}_$TAG.log 2>&1 &
    n=$((n + 1)); if [ $((n % P)) -eq 0 ]; then wait; fi
  done
  wait
fi
if [ $WHAT = f4 ] || [ $WHAT = all ]; then
  n=0
  for c in c1 c8 c9 c10 dense31 dense32 h39 h60; do
    python -I $J/tools/run8_all.py $SRC $S/rvB4_regress/fuzz/$c/cases.json $V/f4/${c}_$TAG.json > $V/f4/${c}_$TAG.log 2>&1 &
    n=$((n + 1)); if [ $((n % P)) -eq 0 ]; then wait; fi
  done
  wait
fi
if [ $WHAT = f8 ] || [ $WHAT = all ]; then
  n=0
  for d in $S/rvB8_regress/fuzz8/*_3[0-9][0-9]; do
    [ -f $d/cases.json ] || continue
    g=$(basename $d)
    python -I $J/tools/run8_all.py $SRC $d/cases.json $V/f8/${g}_$TAG.json > $V/f8/${g}_$TAG.log 2>&1 &
    n=$((n + 1)); if [ $((n % P)) -eq 0 ]; then wait; fi
  done
  wait
fi
if [ $WHAT = b210 ] || [ $WHAT = all ]; then
  python -I $S/fixB/fixB_all.py $SRC $V/fixB210_$TAG.json > $V/fixB210_$TAG.log 2>&1
fi
echo "done $TAG $WHAT"
