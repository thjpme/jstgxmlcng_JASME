"""judge: 乱数の例（rvB4_regress の fuzz4、rvB8_regress の fuzz8）の結果を、版ごとに数え、base と比べる。

  python sum_fz.py f4|f8 TAG... [-v]      # 最初の TAG が比べる相手（base）
判定は rvB8_regress/fuzz8/judge8.py（OK / MISS / VIOLATION）。13 章に出るか（直さなかった箇所・直せない違い・見つからない段落）も数える。
"""
import json
import os
import sys
from collections import Counter
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
V = S / "n10" / "judge" / "v"
sys.path.insert(0, str(S / "oracle"))
sys.path.insert(0, str(S / "rvB8_regress" / "fuzz8"))
import judge8  # noqa: E402

R = {"OK": 0, "MISS": 1, "VIOLATION": 2}
what = sys.argv[1]
tags = [a for a in sys.argv[2:] if not a.startswith("-")]
verbose = "-v" in sys.argv
if what == "f4":
    groups = [(S / "rvB4_regress" / "fuzz" / c / "cases.json", c) for c in
              ("c1", "c8", "c9", "c10", "dense31", "dense32", "h39", "h60")]
    sub = V / "f4"
else:
    groups = [(d / "cases.json", d.name) for d in sorted((S / "rvB8_regress" / "fuzz8").glob("*_3[0-9][0-9]"))
              if (d / "cases.json").exists()]
    sub = V / "f8"
tot = {t: Counter() for t in tags}
silent = Counter()
secs = Counter()
trans = {t: Counter() for t in tags[1:]}
worse = {t: [] for t in tags[1:]}
better = Counter()
n_cases = 0
for cases_path, g in groups:
    res = {}
    for t in tags:
        f = sub / f"{g}_{t}.json"
        res[t] = json.load(open(f, encoding="utf-8")) if f.exists() else None
    if any(r is None for r in res.values()):
        print("結果がない:", g, [t for t, r in res.items() if r is None])
        continue
    cases = json.load(open(cases_path, encoding="utf-8"))
    n_cases += len(cases)
    for t in tags:
        secs[t] += res[t].get("seconds", 0)
    for k, c in enumerate(cases):
        for doc, p in c["truth"].items():
            if any(doc not in res[t]["cases"][k]["paras"] for t in tags):
                continue
            v = {}
            for t in tags:
                x = res[t]["cases"][k]["paras"][doc]
                vv, _, _ = judge8.verdict(doc, p, x)
                rep = bool(x["skipped"] or x["whys"] or x["unmatched"])
                v[t] = (vv, rep)
                tot[t][vv] += 1
                silent[t] += vv != "OK" and not rep
            a = v[tags[0]]
            for t in tags[1:]:
                b = v[t]
                ka = a[0] if a[0] == "OK" else f"{a[0]}({'13章' if a[1] else '黙って'})"
                kb = b[0] if b[0] == "OK" else f"{b[0]}({'13章' if b[1] else '黙って'})"
                if ka != kb:
                    trans[t][(ka, kb)] += 1
                if R[b[0]] > R[a[0]] or (b[0] == a[0] != "OK" and a[1] and not b[1]):
                    worse[t].append((g, k, doc[:60], p[:60], ka, kb, res[t]["cases"][k]["paras"][doc].get("fixed", "")[:70]))
                elif R[b[0]] < R[a[0]]:
                    better[t] += 1
print(f"=== {what}: 論文 {n_cases} 本")
for t in tags:
    print(f"{t}: {dict(tot[t])}  13 章に出ない OK でない段落 {silent[t]}  照合の時間 {secs[t]:.0f}s")
for t in tags[1:]:
    w = worse[t]
    print(f"{t}: base より悪い段落 {len(w)}（うち VIOLATION {sum(1 for x in w if x[5].startswith('VIOLATION'))}）、よい段落 {better[t]}")
    for (x, y), k in trans[t].most_common(12):
        print(f"     {x} → {y}: {k}")
    if verbose:
        for x in w[:int(os.environ.get("NW", "40"))]:
            print("   worse:", x)
