"""judge: quick（rvB2p/quick.py の形）の結果を、版ごとに数え、base と比べる。

  python sum_q.py TAG... [-v]       # 最初の TAG が比べる相手（base）
判定は guard の qsum.py・joint の sum_suites.py と同じ（truth に照らす。MISS は 13 章に出るか〈見つからない段落・直せない違い・
直さなかった箇所・照合に使わなかった文字〉で分ける）。
"""
import json
import sys
from collections import Counter
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
V = S / "n10" / "judge" / "v" / "q"
sys.path.insert(0, str(S / "oracle"))
sys.path.insert(0, str(S / "n10" / "judge" / "tools"))
import quick  # noqa: E402
from runner import describe  # noqa: E402

RANK = {"OK": 0, "MISS(13章)": 1, "MISS(黙って)": 2, "VIOLATION": 3}
tags = [a for a in sys.argv[1:] if not a.startswith("-")]
verbose = "-v" in sys.argv
files = {}
for line in open(S / "n10" / "judge" / "tools" / "qfiles.sh", encoding="utf-8").read().split('"')[1].split():
    p = Path(line.replace("$S", str(S)).strip("\\"))
    if p.suffix in (".py", ".json"):
        files[f"{p.parent.name}_{p.stem}"] = p


def qverdicts(case, r):
    truth = case.get("truth", {})
    out = {}
    for src, x in r["paras"].items():
        want = truth.get(x["orig"], x["orig"])
        if x["fixed"] == want:
            out[src] = "OK"
            continue
        d = describe(x["orig"], x["fixed"], want)
        if d["added"] or d["deleted"]:
            out[src] = "VIOLATION"
            continue
        rep = (src in (r.get("unmatched") or []) or any(dd[0] == src and not dd[3] for dd in r.get("diffs", []))
               or any(f[0] == src and f[4] for f in r.get("fixes", []))
               or any(i[0] == src for i in (r.get("ignored") or [])))
        out[src] = "MISS(13章)" if rep else "MISS(黙って)"
    return out


tot = {t: Counter() for t in tags}
worse = {t: [] for t in tags[1:]}
better = {t: 0 for t in tags[1:]}
rows = []
for base, path in files.items():
    cases = quick.load(path)
    data = {}
    for t in tags:
        f = V / f"{base}_{t}.json"
        data[t] = json.loads(f.read_text(encoding="utf-8"))["cases"] if f.exists() else None
    if any(d is None for d in data.values()):
        rows.append((base, "結果がない: " + ",".join(t for t, d in data.items() if d is None)))
        continue
    cnt = {t: Counter() for t in tags}
    for name, c in cases.items():
        if any(name not in data[t] for t in tags):
            continue
        vs = {t: qverdicts(c, data[t][name]) for t in tags}
        for s in vs[tags[0]]:
            for t in tags:
                cnt[t][vs[t][s]] += 1
            for t in tags[1:]:
                a, b = vs[tags[0]][s], vs[t][s]
                if RANK[b] > RANK[a]:
                    worse[t].append((base, name, s, a, b, data[t][name]["paras"][s]))
                elif RANK[b] < RANK[a]:
                    better[t] += 1
    for t in tags:
        tot[t] += cnt[t]
    rows.append((base, " | ".join(f"{t}: " + "/".join(str(cnt[t][k]) for k in RANK) for t in tags)))
print("判定の順: OK / MISS(13章) / MISS(黙って) / VIOLATION")
for b, r in rows:
    print(f"{b:28} {r}")
print("合計:", " | ".join(f"{t}: " + "/".join(str(tot[t][k]) for k in RANK) for t in tags))
for t in tags[1:]:
    w = worse[t]
    print(f"{t}: base より悪い段落 {len(w)}（うち VIOLATION {sum(1 for x in w if x[4] == 'VIOLATION')}）、よい段落 {better[t]}")
    if verbose:
        for x in w:
            print("   ", x[0], x[1], x[2], x[3], "→", x[4], "| orig:", x[5]["orig"][:50], "| fixed:", x[5]["fixed"][:70])
