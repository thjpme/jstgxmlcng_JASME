"""judge: 照合（compare）の速さ。本誌の出版版 PDF 7 通り（確かめ用 docx と組）と、小さな論文（fuzz8 の 1 組 300 本）。
  python -I t_speed.py SRC [回数]"""
import json
import sys
import time
from pathlib import Path
src = sys.argv[1]
reps = int(sys.argv[2]) if len(sys.argv) > 2 else 3
sys.path.insert(0, src)
from jasme_jats.config import JournalConfig  # noqa: E402
from jasme_jats.pdfdocx import _mechanical  # noqa: E402
from jasme_jats.pdfmatch import compare, extract_pages  # noqa: E402
J = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/n10/judge")
S = J.parents[1]
jn = JournalConfig.load()
total = 0.0
rows = []
for d in sorted((J / "realpdf" / "out" / "docx").glob("*.docx")):
    stem = "_".join(d.stem.split("_")[:4])
    pages = extract_pages(Path("/home/user/jstgxmlcng_JASME/tests/private/pdf") / f"{stem}.pdf")
    _, plan = _mechanical(d, jn)
    best = min((lambda t0: (compare(plan, pages), time.perf_counter() - t0)[1])(time.perf_counter()) for _ in range(reps))
    rows.append((d.stem, best))
    total += best
small = json.load(open(S / "rvB8_regress" / "fuzz8" / "m_mix_311" / "cases.json", encoding="utf-8"))[:100]
plans = [(_mechanical(c["docx"], jn)[1], c["pages"]) for c in small]
t0 = time.perf_counter()
for plan, pages in plans:
    compare(plan, pages)
small_t = time.perf_counter() - t0
print(json.dumps({"real": rows, "real_total": total, "small100": small_t}, ensure_ascii=False))
