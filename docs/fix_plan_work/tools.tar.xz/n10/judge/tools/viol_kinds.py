"""judge: fuzz8 の VIOLATION の段落を、足した・消した文字の形で分ける。  python viol_kinds.py TAG..."""
import json
import sys
from collections import Counter
from pathlib import Path
S = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad")
V = S / "n10" / "judge" / "v" / "f8"
sys.path.insert(0, str(S / "oracle"))
sys.path.insert(0, str(S / "rvB8_regress" / "fuzz8"))
import judge8  # noqa: E402
groups = [(d / "cases.json", d.name) for d in sorted((S / "rvB8_regress" / "fuzz8").glob("*_3[0-9][0-9]")) if (d / "cases.json").exists()]
for tag in sys.argv[1:]:
    kinds = Counter()
    for cp, g in groups:
        r = json.load(open(V / f"{g}_{tag}.json", encoding="utf-8"))
        cases = json.load(open(cp, encoding="utf-8"))
        for k, c in enumerate(cases):
            for doc, p in c["truth"].items():
                x = r["cases"][k]["paras"].get(doc)
                if x is None:
                    continue
                v, _, ds = judge8.verdict(doc, p, x)
                if v != "VIOLATION":
                    continue
                add = [a for a in ds["added"] if a.strip()]
                dele = [a for a in ds["deleted"] if a.strip()]
                if not add and not dele:
                    kinds["空白だけ（足す位置が空白の前後で違う）"] += 1
                elif add and all(len(a) == 1 and a in "，,．.、" for a in add) and not dele:
                    kinds["句読点 1 文字だけを足した"] += 1
                elif add and not dele:
                    kinds["文字を足した（2 文字以上）" if any(len(a) > 1 for a in add) else "文字を足した（1 文字）"] += 1
                elif dele and not add:
                    kinds["文字を消した"] += 1
                else:
                    kinds["足して消した"] += 1
    print(tag, dict(kinds.most_common()))
