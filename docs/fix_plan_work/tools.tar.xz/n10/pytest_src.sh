#!/bin/sh
# 本体の tests を、指定した src のコードで実行する。
#   sh pytest_src.sh <src のフォルダ> [pytest の引数...]
# 注意: pyproject.toml の [tool.pytest.ini_options] pythonpath = ["src", "tests"] は PYTHONPATH より前に入るので、
# PYTHONPATH=<src> だけでは本体の src（0.20.0）が読まれる。-o pythonpath=... で上書きする（読んだコードは WHICH の行で確かめる）。
SRC=$(cd "$1" && pwd); shift
H=$(cd "$(dirname "$0")" && pwd)
cd /home/user/jstgxmlcng_JASME && PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$H/guard/tools/pt:$SRC" \
  python -m pytest -p no:cacheprovider -p guard_which -o pythonpath="$SRC /home/user/jstgxmlcng_JASME/tests" "$@"
