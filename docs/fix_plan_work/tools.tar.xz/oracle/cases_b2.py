"""反例集（oracle_b2: 単位 B2〈0.21.0〉の対象。実装を見ない担当が、原則と本誌の出版版 PDF の形だけから作ったもの）。

文字はすべて架空（実際の論文の文字を書き写していない）。書式と判定は runner.py の docstring。実行:
  python oracle/run_all.py <src> oracle/cases_b2.py --name <名前>

期待（原則だけで決める）:
- 出版版 PDF の本文と同じにする（直す。expect "exact"）。
- 組版の文字・docx にない図や表の中の文字・ほかの段落の文字を足さない。PDF の本文にある docx の文字を消さない
  （truth を書かない段落は docx のまま。変われば FAIL）。
- 決められない違いは docx のまま残し、13 章に出す。

このファイルで足した期待の書き方（runner.judge を、この 2 つの期待のときだけ包む。ほかのファイルの反例には影響しない）:
  "keep"        : docx のまま（1 文字も変えない）で、違いが 13 章に出ること（REPORTED）。docx を少しでも変えたら FAIL。
                  数式の欠けた文字を足す、など「部分だけ直す」ことを FAIL にするため（runner の "reported" は、truth に
                  ある文字を足しても「足した」と数えないので、数式の欠けた文字を足しても FAIL にならない）。
  "fix_or_keep" : truth と同じに直す（OK）か、docx のまま残して 13 章に出す（REPORTED）のどちらか。途中まで直す・別の文字に
                  する・docx の文字を消すのは FAIL。期待の判断に迷うもの（直してよいが、決められないとして残してもよいもの）。

docx の数式: 段落の文字の中の「￼」（OBJ）の位置に、Word の数式（m:oMath）を 1 つずつ入れる（runner._fixtures を包む。
OBJ を含む段落だけが変わる）。XML の本文に直した段落の文字があるかは、数式（inline-formula・disp-formula・mml:math）の中の
文字を除いて見る（runner._xml_text を包む）。

本誌の PDF の形（tests/private/pdf/ の 5 本と Colab の td1〜3 で確かめた形。文字は書き写していない）:
- 2 段組で、1 段 24 文字の行。pdfium は左の段・右の段の順に読む。段落の 1 行目は全角の空白 1 つで字下げ。英文要旨の段落の
  1 行目は「全角の空白 2 つ＋半角の空白」で始まる。
- 行の両端そろえで、句読点・かっこの後や、和文と英数字の間に半角の空白が 1 つ入る。図・表のキャプション「図１　…」、見出し
  「２．研　究」、「◦　」の後などには全角の空白が 1 つある。著者の行・誌名の行には全角の空白が 1 つずつ並ぶ。
- 文字として取り出せない数式（pdfium の文字に入らない字形）は、全角の空白・半角の空白・U+2002 の並び（「　 　」
  「　 　」など、2 文字以上）になる。和文の本文の行で 2 文字以上の空白の並びに全角の空白が入るのは、数式の
  位置か行頭の字下げだけだった。
- 2 段ぶち抜きの図（問題文の図など）は、ページの最後（右の段の後ろ）に、キャプションと 48 文字ほどの長い行で出る。
  段落はその前で切れて、次のページの最初の行から続く。図の中の文字には「。」「…」「？ 」がある。
- 引用文献のページの範囲は、行末なら「pp.45-」の後で改行して次の行が「58）」「58．」などで始まる。英単語の途中の行末の
  ハイフンは U+FFFE になり、次の行と改行なしでつながる。PDF の中に「–」があるのは 5 本で 1 か所だけ。

組（名前の前置き）:
- b2m_*  : 数式が空白の並びになる位置への校正の挿入・置き換え（keep）と、その対照（ふつうの直しは直す）。
- b2f_*  : 段落を分断する図・表（2 段ぶち抜き・段の途中・ページの最初）の中の文字を足さない。分断の前・後ろ・途中の直し。
- b2d_*  : 引用文献・本文のページの範囲・年の範囲の en dash（決定 20 の (b): PDF の「-」に直す）。U+FFFE・em dash・ハイフン。
- b2e_*  : 段落の最初・最後に校正で足された語・句読点（同じ行・次の行）と、図の中の文字が同じ行につながる対照。
- b2o_*  : その他（組み合わせ・行末のハイフンをまたぐ 2 つの直し）。
どの反例にも、確かめ用の違い（段落 2: docx「3回」→ PDF「３回」）を置く（照合が働いていることを確かめるため）。
"""
from __future__ import annotations

import runner as _r
from runner import BREAK, DEFAULTS, OBJ, Raw, flow, journal_line, wrap

# ============================================================================ runner を包む（このファイルの期待の書き方と、docx の数式）
_orig_judge = _r.judge


def _keep_judge(orig, fixed, truth, ev_fn, label):
    if fixed != orig:
        d = _r.describe(orig, fixed, orig)
        parts = []
        if d["added"]:
            parts.append(f"足した{_r._q(d['added'])}")
        if d["deleted"]:
            parts.append(f"消した{_r._q(d['deleted'])}")
        return "FAIL", f"{label}: docx から変えた（" + ("・".join(parts) or "違いがある") + f"）。直した後「{fixed}」"
    d = _r.describe(orig, fixed, truth)
    ev = ev_fn(d["left"] + d["not_added"])
    if not ev:
        return "FAIL", f"{label}: docx のまま残したが、違いが 13 章に出ていない"
    return "REPORTED", "docx のまま（13 章: " + "・".join(ev) + "）"


def _judge(orig, fixed, truth, has_truth, expect, ev_fn):
    if expect == "keep":
        return _keep_judge(orig, fixed, truth, ev_fn, "docx のまま 13 章に出すべき")
    if expect == "fix_or_keep":
        if fixed == truth:
            return "OK", ""
        if fixed == orig:
            return _keep_judge(orig, fixed, truth, ev_fn, "直すか docx のまま 13 章に出すべき")
        v, why = _orig_judge(orig, fixed, truth, has_truth, "exact", ev_fn)
        return "FAIL", "直すか docx のまま残すかのどちらでもない: " + why
    return _orig_judge(orig, fixed, truth, has_truth, expect, ev_fn)


_r.judge = _judge

_orig_fixtures = _r._fixtures
_orig_xml_text = _r._xml_text


class _MathFixtures:
    """make_fixtures の代わり: para() の文字の中の OBJ を、Word の数式に置き換える（ほかはそのまま）。"""

    def __init__(self, mf):
        self._mf = mf

    def __getattr__(self, k):
        return getattr(self._mf, k)

    def para(self, style, *parts, jc=None):
        mf = self._mf
        out = []
        for p in parts:
            if p and not p.startswith("<") and OBJ in p:
                bits = p.split(OBJ)
                for k, b in enumerate(bits):
                    if b:
                        out.append(mf.run(b))
                    if k < len(bits) - 1:
                        out.append(mf.omath(mf.mr("p")))
            else:
                out.append(p)
        return mf.para(style, *out, jc=jc)


def _fixtures(code_root):
    return _MathFixtures(_orig_fixtures(code_root))


def _xml_text(path):
    from pathlib import Path

    from lxml import etree
    parser = etree.XMLParser(load_dtd=False, no_network=True, resolve_entities=False)
    root = etree.fromstring(Path(path).read_bytes(), parser)
    skip = {"inline-formula", "disp-formula", "math"}
    out = []

    def walk(el):
        name = etree.QName(el).localname if isinstance(el.tag, str) else ""
        if name not in skip:
            if el.text:
                out.append(el.text)
            for ch in el:
                walk(ch)
        if el.tail:
            out.append(el.tail)
    walk(root)
    return _r._strip("".join(out))


_r._fixtures = _fixtures
_r._xml_text = _xml_text

# ============================================================================ 架空の論文
I = "　"          # 全角の空白（段落の字下げ）
EN_SP = " "      # PDF の数式の位置に出る空白の一つ


def bl(text):
    """本文の段落の行（1 行目は全角の空白で字下げ）。"""
    return wrap(I + text)


def _check(cond, msg):
    if not cond:
        raise ValueError("反例の組み立ての誤り: " + msg)


H1 = "１．はじめに"
A = ("本研究の目的は，架空の中学校で行われた確率の授業において，生徒が試行の結果と確率をどのように関係づけたかを，"
     "授業中の発話と記述の分析によって明らかにすることである。")
CTRL_DOCX = "分析の対象は，第２学年の一つの学級で3回行った授業の記録である。授業者は架空の教諭である。"
CTRL_PUB = CTRL_DOCX.replace("3回", "３回")
H2 = "２．研究の方法"
RH = "引用および参考文献"
REF1 = "架空一郎（2019）．「架空の数の研究」．『架空数学研究』，第29号，pp.11-16．"
REF1_LINES = ["架空一郎（2019）．「架空の数の研究」．『架空", "数学研究』，第29号，pp.11-16．"]
_check("".join(REF1_LINES) == REF1, "REF1")
EN_ABS = DEFAULTS["英文要旨"]


def front():
    return Raw(journal_line(vol=31, no=1, year=2026, fp=1, lp=12), DEFAULTS["題目"], DEFAULTS["副題"], "架空大学　試験　五郎")


def wordwrap(text, n=50):
    """英文を単語の間で折り返す（1 行 n 文字まで。行の変わり目の空白は PDF の改行になる）。"""
    out, cur = [], ""
    for w in text.split(" "):
        if cur and len(cur) + 1 + len(w) > n:
            out.append(cur)
            cur = w
        else:
            cur = f"{cur} {w}" if cur else w
    if cur:
        out.append(cur)
    return out


def english(abstract=EN_ABS, lines=None):
    """最後のページの英文（題目・副題・著者・Abstract・要旨）。要旨の 1 行目は「全角の空白 2 つ＋半角の空白」で始まる。"""
    ls = lines if lines is not None else wordwrap(abstract)
    ls = [I + I + " " + ls[0]] + ls[1:]
    return Raw(DEFAULTS["英文題目"], DEFAULTS["英文副題"], "Goro SHIKEN", "Fictional University", "Abstract", *ls)


def case(name, angle, extra, mid, truth=None, expect="exact", note="", refs=((("引用文献", REF1),)),
         ref_blocks=None, eng=None, item="N10", tail_blocks=(), eng_expect="exact"):
    """標準の小さな論文の反例。

    eng: (docx の英文要旨, 出版版の英文要旨, PDF の行〈None なら単語で折り返す〉)。違えば、英文要旨（最後の段落）の
    truth を出版版にし、期待を eng_expect にする。

    docx の段落: 0 見出し / 1 A / 2 確かめ用 / 3 見出し / 4〜 extra / 文献見出し / refs（/ 英文要旨〈eng があれば〉）。
    PDF: 1 ページ目の冒頭・見出し・A・確かめ用・見出し、mid のブロック（Raw・BREAK）、文献見出し、ref_blocks（省くと
    REF1_LINES）、tail_blocks、英文。
    truth: extra の中の番号（4 から）での truth。expect: 同じく（dict なら段落ごと）。
    """
    refs = list(refs)
    paras = [("見出し", H1), ("本文", A), ("本文", CTRL_DOCX), ("見出し", H2)] + list(extra) + \
            [("引用文献見出し", RH)] + refs
    en_text = EN_ABS
    if eng is not None:
        en_docx, en_text, en_lines = eng
        paras.append(("英文要旨", en_docx))
    t = {2: CTRL_PUB}
    t.update(truth or {})
    blocks = [front(), Raw(H1), Raw(*bl(A)), Raw(*bl(CTRL_PUB)), Raw(H2)] + list(mid) + [Raw(RH)]
    blocks += list(ref_blocks) if ref_blocks is not None else [Raw(*REF1_LINES)]
    blocks += list(tail_blocks)
    blocks.append(english(en_text, en_lines if eng is not None else None))
    if isinstance(expect, dict):
        exp = {"default": "exact"}
        exp.update(expect)
    else:
        exp = {"default": "exact"}
        exp.update({k: expect for k in t if k != 2})
    if eng is not None and en_text != en_docx:
        t[len(paras) - 1] = en_text
        exp[len(paras) - 1] = eng_expect
    return {"name": name, "angle": angle, "item": item, "paras": paras, "truth": t,
            "pages": flow(blocks, first=1), "expect": exp, "note": note}


def lines_of(pdf_text, width=24):
    return wrap(I + pdf_text, width)


CASES = []

# ============================================================================ math: 数式が空白の並びになる位置
M_SP = I + " " + I                 # 数式（添字付きの文字）1 つの PDF の形
M_SP2 = I + EN_SP + I              # もう一つの形
M1_DOCX = ("各回の結果から相対度数を求め，これを経験的確率とよぶことにした。経験的確率の変化を，試行の回数を"
           "増やしながら記録した。")
M1_TRUTH = M1_DOCX.replace("経験的確率とよぶ", f"経験的確率（{OBJ}，…，{OBJ}とする）とよぶ")
M1_PDF = M1_DOCX.replace("経験的確率とよぶ", f"経験的確率 （{M_SP}， …， {M_SP}とする） とよぶ")
M1_L = lines_of(M1_PDF)
_check(any("とする）" in ln and "（" in ln for ln in M1_L), "M1 は 1 行に入る")

CASES.append(case(
    "b2m_ins_paren_sameline", "edit", [("本文", M1_DOCX)], [Raw(*M1_L)], {4: M1_TRUTH}, "keep",
    "td1 の d71 の形（架空）: 校正で足された「（p1，…，p6 とする）」の数式が PDF の文字に入らず、空白の並び"
    "「（\\u3000 \\u3000， …， \\u3000 \\u3000とする）」になる。足すと数式の欠けた文になるので、docx のまま 13 章に出す。"))

# 「経験的確率」で 1 行が終わるように組み直す（挿入が行をまたぐ形）
_pre, _post = M1_DOCX.split("経験的確率とよぶ")
_first = wrap(I + _pre + "経験的確率")
M1B_LINES = _first[:-1] + [_first[-1] + f" （{M_SP}， …， {M_SP}"] + wrap("とする） とよぶ" + _post)
_check(len(_first[-1]) >= 8, "M1B の行")
CASES.append(case(
    "b2m_ins_paren_linebreak", "edit", [("本文", M1_DOCX)], [Raw(*M1B_LINES)], {4: M1_TRUTH}, "keep",
    "b2m_ins_paren_sameline と同じ挿入が、PDF の行をまたぐ（行末「（\\u3000 \\u3000， …， \\u3000 \\u3000」・次の行の"
    "行頭「とする）」。td1 にある形）。docx のまま 13 章に出す。"))

M3_DOCX = "生徒は，表の値を確率として求めた。その後，求めた値を全体で比べた。"
M3_TRUTH = M3_DOCX.replace("表の値を確率", f"表の値を{OBJ}を用いて確率")
M3_PDF = M3_DOCX.replace("表の値を確率", f"表の値を{M_SP}を用いて確率")
CASES.append(case(
    "b2m_ins_word_after_math", "edit", [("本文", M3_DOCX)], [Raw(*lines_of(M3_PDF))], {4: M3_TRUTH}, "keep",
    "校正で「（数式）を用いて」が足され、PDF では「\\u3000 \\u3000を用いて」（数式の位置が空白の並び）。足す文字の前に"
    "全角空白を含む空白の並びがある。「を用いて」だけ足すと数式が欠けるので、docx のまま 13 章に出す。"))

M4_DOCX = f"値の組（{OBJ}，{OBJ}）を順に調べ，その結果を表にまとめた。"
M4_TRUTH = f"値の組（{OBJ}，{OBJ}，{OBJ}）を順に調べ，その結果を表にまとめた。"
M4_PDF = f"値の組（{M_SP2}， {M_SP2}， {M_SP2}）を順に調べ，その結果を表にまとめた。"
CASES.append(case(
    "b2m_ins_comma_between_math", "edit", [("本文", M4_DOCX)], [Raw(*lines_of(M4_PDF))], {4: M4_TRUTH}, "keep",
    "docx には数式が 2 つ（「（p，p）」）、PDF では数式が 3 つ（「（\\u3000\\u2002\\u3000， \\u3000\\u2002\\u3000， "
    "\\u3000\\u2002\\u3000）」。td2 の形）。違いは「，」1 つだが、その両隣が数式の空白の並びで、足すべき数式を docx に"
    "入れられない。「，」だけ足すと数式の欠けた式になるので、docx のまま 13 章に出す。"))

M5_DOCX = "この試行で赤が出る確率をpとし，その値を予想させた。"
M5_TRUTH = M5_DOCX
M5_PDF = M5_DOCX.replace("確率をpとし", f"確率を{M_SP}とし")
CASES.append(case(
    "b2m_docx_text_pdf_math", "edit", [("本文", M5_DOCX)], [Raw(*lines_of(M5_PDF))], None, "exact",
    "docx は文字の「p」、PDF では組版で数式になり、文字に入らず空白の並び（「確率を\\u3000 \\u3000とし」）。PDF の本文には"
    "その位置に字形がある（消された文字ではない）ので、docx の「p」を消してはいけない（truth なし。docx のまま）。"
    "13 章に出すかは問わない（runner の判定では、変わらなければ OK）。"))

M6_DOCX = f"各回の経験的確率（{OBJ}，…，{OBJ}とする）を表に記録した。回数が増えると，値の変化は小さくなった。"
CASES.append(case(
    "b2m_docx_math_same", "edit", [("本文", M6_DOCX)],
    [Raw(*lines_of(M6_DOCX.replace(f"（{OBJ}，…，{OBJ}とする）", f" （{M_SP}， …， {M_SP}とする） ")))], None, "exact",
    "対照: docx にも数式がある位置で、PDF が空白の並び。違いにしない（docx のまま。13 章に出さなくてよい）。"))

M7_DOCX = f"各回の経験的確率（{OBJ}，…，{OBJ}とする）を表に記録した。回数が増えると，値の変化は小さくなった。"
M7_TRUTH = M7_DOCX.replace("値の変化は小さく", "値の変化は次第に小さく")
M7_PDF = M7_TRUTH.replace(f"（{OBJ}，…，{OBJ}とする）", f" （{M_SP}， …， {M_SP}とする） ")
CASES.append(case(
    "b2m_docx_math_fix_far", "edit", [("本文", M7_DOCX)], [Raw(*lines_of(M7_PDF))], {4: M7_TRUTH}, "exact",
    "対照: docx にも数式があり、PDF は空白の並び。数式から離れた位置（20 文字ほど後ろ）の校正の挿入「次第に」は直す。"))

M8_DOCX = f"各回の確率（{OBJ}）を求め，その結果を比べた。"
M8_TRUTH = f"各回の確率（{OBJ}）を順に求め，その結果を比べた。"
M8_PDF = f"各回の確率 （{M_SP}） を順に求め，その結果を比べた。"
CASES.append(case(
    "b2m_docx_math_fix_near", "edit", [("本文", M8_DOCX)], [Raw(*lines_of(M8_PDF))], {4: M8_TRUTH}, "exact",
    "境界: docx にも数式があり、PDF は空白の並び。数式の 2 文字後ろ（「）を」の後）に校正の挿入「順に」。足す文字の両隣は"
    "一致した和文の文字で、空白の並びに接していない。足す文字はすべて読み取れるので直す。"))

M9_DOCX = "授業では，最初に予想を書かせた。次に，班ごとに実験を行わせた。"
M9_TRUTH = M9_DOCX.replace("次に，班ごとに", "次に，三人の班ごとに")
M9_PDF = M9_TRUTH.replace("。次に，", "。 次に， ")
CASES.append(case(
    "b2m_ctrl_punct_space", "edit", [("本文", M9_DOCX)], [Raw(*lines_of(M9_PDF))], {4: M9_TRUTH}, "exact",
    "対照: 行の両端そろえで句読点の後に半角の空白が 1 つ入る（「。 次に， 三人の」）。その空白のすぐ後ろの校正の挿入"
    "「三人の」は、ふつうの直しとして直す。"))

M10_DOCX = "生徒の記述は，架空の枠組みを用いて分類した。"
M10_TRUTH = M10_DOCX.replace("架空の枠組み", "Toulmin（1958）の架空の枠組み")
M10_PDF = M10_DOCX.replace("架空の枠組み", "Toulmin （1958） の架空の枠組み")
CASES.append(case(
    "b2m_ctrl_latin_word", "edit", [("本文", M10_DOCX)], [Raw(*lines_of(M10_PDF))], {4: M10_TRUTH}, "exact",
    "対照: 和文の中に校正で足された英単語と年「Toulmin（1958）の」。PDF では和文と英数字・かっこの間に半角の空白が 1 つずつ"
    "入る（本誌の形）。ふつうの直しとして直す。"))

M11_EN_DOCX = "This study examines how students related the results of trials to probability in a fictional lesson."
M11_EN_PUB = "This study examines how students carefully related the results of repeated trials to probability in a fictional lesson."
CASES.append(case(
    "b2m_ctrl_english_words", "edit", [], [], None, "exact",
    "対照: 英文要旨の単語の間（半角の空白 1 つ）に校正で足された英単語「carefully」「repeated」。英文の単語の間の空白は"
    "数式の手がかりにしない。直す。",
    eng=(M11_EN_DOCX, M11_EN_PUB, None)))

M12_DOCX = "本研究では，生徒の発話を記録した。"
M12_TRUTH = "なお，本研究では，生徒の発話を記録した。"
CASES.append(case(
    "b2m_ctrl_indent_head", "edit", [("本文", M12_DOCX)], [Raw(*lines_of(M12_TRUTH))], {4: M12_TRUTH}, "exact",
    "対照: 全角空白の字下げ（段落の 1 行目の行頭）のすぐ後ろに、校正で足された「なお，」。字下げの空白は数式の手がかりに"
    "しない。直す。"))

M13_CAP_DOCX = "図１　記述の例"
M13_CAP_PUB = "図１　生徒の記述の例"
CASES.append(case(
    "b2m_ctrl_caption_ideo_space", "edit", [("本文", M1_DOCX),
                                            ("画像", "図1"), ("図キャプション", M13_CAP_DOCX)],
    [Raw(*lines_of(M1_DOCX)), Raw(M13_CAP_PUB)], {6: M13_CAP_PUB}, "exact",
    "対照: キャプション「図１　…」の全角空白 1 つ（docx にもある）のすぐ後ろに、校正で足された「生徒の」。1 つだけの全角"
    "空白は数式の手がかりにしない。直す。"))

M_BUL_DOCX = "◦　生徒は表を作り，値の変化を調べた。"
M_BUL_PUB = "◦　多くの生徒は表を作り，値の変化を調べた。"
CASES.append(case(
    "b2m_ctrl_bullet_ideo", "edit", [("本文", M_BUL_DOCX)], [Raw(*wrap(M_BUL_PUB))], {4: M_BUL_PUB}, "exact",
    "対照: 箇条の記号「◦」の後の全角の空白 1 つ（docx にもある。本誌の PDF に多い形）のすぐ後ろに、校正で足された"
    "「多くの」。1 つだけの全角の空白は数式の手がかりにしない。直す。"))

M14_DOCX = "結果を集計した。その後，表を用いて全体で検討した。"
M14_TRUTH = M14_DOCX.replace("その後，表を", "その後，二つの表を")
M14_PDF = M14_TRUTH.replace("その後，", "その後，  ")
CASES.append(case(
    "b2m_two_ascii_spaces", "edit", [("本文", M14_DOCX)], [Raw(*lines_of(M14_PDF))], {4: M14_TRUTH}, "fix_or_keep",
    "境界（判断に迷う）: 校正で足された「二つの」の前に半角の空白が 2 つ（全角の空白を含まない）。両端そろえの空白が広がった"
    "ものか、数式の位置かは決められない。直す（OK）か、docx のまま 13 章に出す（REPORTED）。"))

M15_DOCX = "結果を集計し，表にまとめた。"
M15_TRUTH = f"結果を集計し，{OBJ}の値を表にまとめた。"
M15_PDF = f"結果を集計し，{I}{I}の値を表にまとめた。"
CASES.append(case(
    "b2m_ins_ideo_pair", "edit", [("本文", M15_DOCX)], [Raw(*lines_of(M15_PDF))], {4: M15_TRUTH}, "keep",
    "校正で「（数式）の値を」が足され、PDF では「，\\u3000\\u3000の値を」（全角の空白 2 つだけの並び）。「の値を」だけ足すと"
    "数式が欠けるので、docx のまま 13 章に出す。"))

M16_DOCX = "結果を集計し，その値を表にまとめた。"
M16_TRUTH = f"結果を集計し，その値{OBJ}を表にまとめた。"
M16_PDF = f"結果を集計し，その値{M_SP}を表にまとめた。"
CASES.append(case(
    "b2m_ins_math_only", "edit", [("本文", M16_DOCX)], [Raw(*lines_of(M16_PDF))], {4: M16_TRUTH}, "keep",
    "校正で数式だけが足され（「その値（数式）を」）、PDF では空白の並びだけ。文字の違いはないが、XML の本文は PDF と違う"
    "（数式が足りない）。理想は 13 章に出すこと（判断に迷う: 文字の違いがないので気づけないのは 0.20.0 からの限界かもしれない）。"
    "docx を変えたら FAIL。"))

# ============================================================================ figsplit: 段落を分断する図・表
X_PRE = "このような活動の後に，生徒は「回数を増やすと割合が一つの値に向かって次第に近づいていくものだ」"
_check([len(x) for x in bl(X_PRE)] == [24, 24], "X_PRE は 2 行ちょうど")
X_POST = ("という確信をもつようになった。その確信は，次の時間の話し合いの中で，ほかの生徒の考えと比べられながら，"
          "少しずつ確かめられていった。")
X_DOCX = X_PRE + X_POST
FIG_CAP = "図１　架空の問題の文"
FIG_SPAN = [FIG_CAP,
            "問題　袋の中に赤い玉と白い玉が入っている。玉を一つ取り出して色を調べ，袋に戻す。これを",
            "何回もくり返したとき，赤い玉が出る割合はどうなるだろうか。……",
            "Ａさん「十回では，わからない？ 」　Ｂさん「百回なら？ 」　Ｃさん「千回なら？ 」",
            "Ｄさん「割合は，ある値に近づく…。」"]
X_PRE_L = bl(X_PRE)
X_POST_L = wrap(X_POST)
FIG_PARAS = [("画像", "図1"), ("図キャプション", FIG_CAP)]


def xcase(name, x_docx, x_pub, pre_l, post_l, figure, expect="exact", note="", item="N10", fig_after=True, more=()):
    """段落 X（番号 4）が図で分断される反例。docx では X の後ろに図（画像・キャプション）を置く。"""
    extra = [("本文", x_docx)] + (FIG_PARAS if fig_after else []) + list(more)
    truth = {4: x_pub} if x_pub != x_docx else {}
    mid = [Raw(*pre_l)] + list(figure) + [Raw(*post_l)]
    return case(name, "artifact", extra, mid, truth, expect, note, item=item)


CASES.append(xcase(
    "b2f_span_bottom_nofix", X_DOCX, X_DOCX, X_PRE_L, X_POST_L, [Raw(*FIG_SPAN), BREAK],
    note="td2 の d56 の形（架空）: 段落 4 が「…ものだ」」で切れ、ページの最後に 2 段ぶち抜きの問題文の図（キャプション"
         "と 48 文字ほどの行。「。」「…」「？ 」を含む）、次のページの最初の行から「という確信…」。図の中の文字を足さない"
         "（段落 4 は docx のまま）。"))

X2_PUB = X_DOCX.replace("比べられながら", "比べられつつ")
CASES.append(xcase(
    "b2f_span_bottom_fix_after", X_DOCX, X2_PUB, X_PRE_L, wrap(X2_PUB[len(X_PRE):]), [Raw(*FIG_SPAN), BREAK],
    note="b2f_span_bottom_nofix の形で、分断の後ろ（次のページ）に校正の置き換え「比べられながら」→「比べられつつ」。直す。"
         "図の中の文字は足さない。"))

X3_PUB = X_DOCX.replace("生徒は「", "生徒たちは「")
CASES.append(xcase(
    "b2f_span_bottom_fix_before", X_DOCX, X3_PUB, bl(X3_PUB[:len(X_PRE) + 2]), X_POST_L, [Raw(*FIG_SPAN), BREAK],
    note="分断の前（図の直前の行）に校正の挿入「たち」。直す。図の中の文字は足さない。"))

X4_PUB = X_DOCX.replace("近づいていくものだ」", "近づいていくはずのものだ」")
CASES.append(xcase(
    "b2f_span_bottom_fix_at_cut", X_DOCX, X4_PUB, bl(X4_PUB[:len(X_PRE) + 3]), X_POST_L, [Raw(*FIG_SPAN), BREAK],
    note="分断のすぐ前（段落の前の部分の最後の 4 文字の前）に校正の挿入「はずの」。直す。図の中の文字は足さない。"))

X5_PUB = X_DOCX.replace("」という確信", "」などという確信")
CASES.append(xcase(
    "b2f_span_bottom_ins_at_resume", X_DOCX, X5_PUB, X_PRE_L, wrap(X5_PUB[len(X_PRE):]), [Raw(*FIG_SPAN), BREAK],
    expect="fix_or_keep",
    note="境界（判断に迷う）: 分断の後ろの最初の文字の位置（次のページの最初の行の行頭）に校正の挿入「など」。本文の行の"
         "文字なので直すのが望ましいが、図の最後の行との境目でもあるので、docx のまま 13 章に出してもよい。図の中の文字"
         "（「。」「…」など）を足すのは FAIL。"))

CASES.append(xcase(
    "b2f_span_top_fix_after", X_DOCX, X2_PUB, X_PRE_L, wrap(X2_PUB[len(X_PRE):]), [BREAK, Raw(*FIG_SPAN)],
    note="2 段ぶち抜きの図が次のページの最初（ページ番号の次）にあり、段落 4 は図の後ろから続く。分断の後ろの置き換え"
         "「比べられつつ」を直す。図の中の文字は足さない。"))

FIG_COL = ["人数", "30", "20", "10", "0", "1　2　3　4　5（回）", "図２　架空の記録のグラフ"]
Y_DOCX = ("各回の記録は，班ごとに用紙へ書き込ませた。回数が増えるにつれて，赤い玉が出た割合を表す点は，横軸に"
          "沿って少しずつ一定の高さに集まっていった。生徒はこのグラフを見て，割合の変化について話し合った。")
Y_PUB = Y_DOCX.replace("話し合った", "班で話し合った")
_yl = bl(Y_PUB)
CASES.append(case(
    "b2f_column_mid_fix_after", "artifact", [("本文", Y_DOCX), ("画像", "図2"), ("図キャプション", FIG_COL[-1])],
    [Raw(*_yl[:2]), Raw(*FIG_COL), Raw(*_yl[2:])], {4: Y_PUB}, "exact",
    "段の途中の図（グラフ。軸の名前「人数」・目盛りの数字・「1　2　3　4　5（回）」・キャプション）が段落 4 を分断する。"
    "分断の後ろの校正の挿入「班で」を直す。図の中の文字（目盛りの数字など）を足さない。"))

FIG_PUNCT = ["（　　　　）。", "…", "答え？", "。"]
CASES.append(case(
    "b2f_column_mid_punct_lines", "artifact", [("本文", Y_DOCX), ("画像", "図2")],
    [Raw(*bl(Y_DOCX)[:3]), Raw(*FIG_PUNCT), Raw(*bl(Y_DOCX)[3:])], None, "exact",
    "段の途中のワークシートの図の中の文字が「（　　　　）。」「…」「答え？」「。」だけの短い行で、段落 4 を分断する。"
    "段落 4 は docx のまま（句読点を足さない）。"))

TAB_LINES = ["表１　架空の正答数", "学級　Ａ組　Ｂ組", "正答　　12　　15", "誤答　　8　　5"]
Z_DOCX = ("二つの学級の結果を表１に示す。どちらの学級でも，正答の数は誤答の数より多かった。特に，Ｂ組では多くの"
          "生徒が割合の変化を言葉で説明した。")
Z_PUB = Z_DOCX.replace("言葉で説明した", "自分の言葉で説明した")
_zl = bl(Z_PUB)
CASES.append(case(
    "b2f_table_mid_fix_after", "artifact",
    [("本文", Z_DOCX), ("表キャプション", TAB_LINES[0]), ("表", [["学級", "Ａ組", "Ｂ組"], ["正答", "12", "15"],
                                                               ["誤答", "8", "5"]])],
    [Raw(*_zl[:2]), Raw(*TAB_LINES), Raw(*_zl[2:])], {4: Z_PUB}, "exact",
    "段の途中の表（docx は Word の表。PDF ではキャプションとセルの行。セルの間に全角の空白 1〜2 つ）が段落 4 を分断する。"
    "分断の後ろの校正の挿入「自分の」を直す。表の中の文字を足さない。"))

X9_DOCX = X_DOCX.replace("比べられながら，", "比べられながら，さらに")
CASES.append(xcase(
    "b2f_span_bottom_del_after", X9_DOCX, X_DOCX, X_PRE_L, X_POST_L, [Raw(*FIG_SPAN), BREAK],
    note="分断の後ろの校正の削除（docx の「さらに」が PDF にない）。直す（消すのは PDF にない文字だけ）。図の中の文字は"
         "足さない。"))

X10_PUB = X_DOCX.replace("次の時間の", "次の時間の全体の")
_x10 = wrap(X10_PUB[len(X_PRE):])
CASES.append(xcase(
    "b2f_two_figs_fix_mid", X_DOCX, X10_PUB, X_PRE_L, _x10[2:],
    [Raw(*FIG_SPAN), BREAK, Raw(*_x10[:2]), Raw(*FIG_COL)],
    note="段落 4 が 2 回分断される（ページの最後の 2 段ぶち抜きの図、次のページの段の途中のグラフ）。真ん中の部分の校正の"
         "挿入「全体の」を直す。どちらの図の中の文字も足さない。"))

X11_DOCX = ("生徒は，問題の「赤い玉が出る割合はどうなるだろうか」という問いについて，班で話し合った。"
            "多くの班は，回数を増やして確かめるという方法を選んだ。")
_x11 = bl(X11_DOCX)
CASES.append(case(
    "b2f_fig_text_quoted_in_body", "artifact", [("本文", X11_DOCX)] + FIG_PARAS,
    [Raw(*_x11[:2]), Raw(*FIG_SPAN), BREAK, Raw(*_x11[2:])], None, "exact",
    "本文が図の中の問題文の一部（「赤い玉が出る割合はどうなるだろうか」）を引用し、その段落が図で分断される。図の中の文字と"
    "本文が同じ文字列を含んでも、図の文字を足さず、本文の文字を消さない（段落 4 は docx のまま）。"))

PROB = FIG_SPAN[1] + FIG_SPAN[2]
CASES.append(xcase(
    "b2f_problem_as_docx_para", X_DOCX, X_DOCX, X_PRE_L, X_POST_L, [Raw(*FIG_SPAN[:3]), BREAK],
    fig_after=False, more=[("引用", PROB)],
    note="docx では図の問題文が段落 4 の後ろの引用の段落 5（文字）で、PDF ではその文字が段落 4 の途中（ページの最後の 2 段"
         "ぶち抜きの図）にある（docx と PDF で順序が違う）。段落 4 に問題文を足さない。段落 5 の文字を消さない（PDF にある）。"
         "どちらも docx のまま。"))
CAP12_DOCX = "図1　架空の問題の文"
CASES.append(xcase(
    "b2f_span_bottom_caption_width", X_DOCX, X_DOCX, X_PRE_L, X_POST_L, [Raw(*FIG_SPAN), BREAK],
    fig_after=False, more=[("画像", "図1"), ("図キャプション", CAP12_DOCX)],
    note="docx のキャプションは「図1」（半角）、PDF は「図１」（全角）。キャプション（段落 6）は全角に直す。段落 4 は docx の"
         "まま（図の中の文字を足さない）。"))
CASES[-1]["truth"][6] = FIG_CAP
CASES[-1]["expect"][6] = "exact"

X13_PUB = X_DOCX.replace("という確信を", "という強い確信を")
CASES.append(xcase(
    "b2f_span_bottom_fix_after_near", X_DOCX, X13_PUB, X_PRE_L, wrap(X13_PUB[len(X_PRE):]), [Raw(*FIG_SPAN), BREAK],
    note="分断の後ろの最初の行の 4 文字目に校正の挿入「強い」（行頭の「という」の後ろ）。直す。図の中の文字は足さない。"))

# ============================================================================ dash: en dash（決定 20 の (b)）
REF2_D = "架空二郎（2021）．「架空の比の研究」．『架空教育研究』，第12巻，pp.45–58．"
REF2_P = REF2_D.replace("–", "-")
REF2_HEAD = "架空二郎（2021）．「架空の比の研究」．『架空"


def dcase(name, ref_docx, ref_pub, ref_lines, expect="exact", note="", extra=(), mid=(), truth=None):
    refs = [("引用文献", REF1), ("引用文献", ref_docx)]
    n = 4 + len(extra) + 2            # 引用文献 2 の番号（見出し 4 つ・extra・文献見出し・REF1）
    t = dict(truth or {})
    exp = {}
    if ref_pub != ref_docx:
        t[n] = ref_pub
        exp[n] = expect
    for k in (truth or {}):
        exp.setdefault(k, "exact")
    return case(name, "edit", list(extra), list(mid), t, exp, note, refs=refs,
                ref_blocks=[Raw(*REF1_LINES), Raw(*ref_lines)], item="endash")


CASES.append(dcase(
    "b2d_ref_midline", REF2_D, REF2_P, [REF2_HEAD, "教育研究』，第12巻，pp.45-58．"],
    note="引用文献のページの範囲「pp.45–58」（docx は en dash）が、PDF では行の途中の「pp.45-58」。PDF の「-」に直す。"))
CASES.append(dcase(
    "b2d_ref_eol", REF2_D, REF2_P, [REF2_HEAD, "教育研究』，第12巻，pp.45-", "58．"],
    note="td2 の d365 の形（架空）: PDF では「pp.45-」の後で改行し、次の行が「58．」。決定 20 の (b) で PDF の「-」に直す。"
         "docx の「–」を消してはいけない（0.20.0 は「4558」にした）。"))
CASES.append(dcase(
    "b2d_ref_eol_bare", REF2_D.rstrip("．"), REF2_P.rstrip("．"), [REF2_HEAD, "教育研究』，第12巻，pp.45-", "58"],
    note="「pp.45-」の後で改行し、次の行が数字だけの「58」（前の行の続き）。PDF の「-」に直し、「58」を消さない。"))
CASES.append(dcase(
    "b2d_ref_eol_fffe", REF2_D, REF2_D, [REF2_HEAD, "教育研究』，第12巻，pp.45￾58．"],
    note="PDF の行末が U+FFFE（何の字形か分からない）で次の行とつながる「pp.45\\ufffe58．」。docx のまま（「–」を消さない。"
         "違いにしない。DESIGN_N10.md 8 章）。"))
CASES.append(dcase(
    "b2d_ref_eol_pagebreak", REF2_D, REF2_P, [],
    note="ページの最後の行が「…pp.45-」で、次のページの最初（ページ番号の次）の行が「58．」。PDF の「-」に直し、"
         "「58．」を消さない。"))
# ページの区切りは Raw の中に書けないので、ref_blocks を直接組み直す
CASES[-1]["pages"] = flow([front(), Raw(H1), Raw(*bl(A)), Raw(*bl(CTRL_PUB)), Raw(H2), Raw(RH), Raw(*REF1_LINES),
                           Raw(REF2_HEAD, "教育研究』，第12巻，pp.45-"), BREAK, Raw("58．"), english()], first=1)

REF_EM = REF2_D.replace("–", "—")
CASES.append(dcase(
    "b2d_emdash_eol", REF_EM, REF2_P, [REF2_HEAD, "教育研究』，第12巻，pp.45-", "58．"], expect="fix_or_keep",
    note="docx は em dash「—」、PDF は行末の「-」。em dash を「-」に直すかは利用者の判断待ち（DESIGN_N10.md 8 章）なので、"
         "docx のまま 13 章に出すか、「-」に直すか。docx の「—」を消して「4558」にするのは FAIL（PDF の本文にダッシュがある）。"))
CASES.append(dcase(
    "b2d_emdash_midline", REF_EM, REF2_P, [REF2_HEAD, "教育研究』，第12巻，pp.45-58．"], expect="fix_or_keep",
    note="docx は em dash「—」、PDF は行の途中の「-」。直す（0.20.0 からのふつうの違い）か、docx のまま 13 章に出す。"
         "消すのは FAIL。"))
REF_HY = REF2_P
CASES.append(dcase(
    "b2d_hyphen_eol_ctrl", REF_HY, REF_HY, [REF2_HEAD, "教育研究』，第12巻，pp.45-", "58．"],
    note="対照: docx も「-」、PDF は行末の「-」。docx のまま（「-」を消さない）。"))
CASES.append(dcase(
    "b2d_pdf_endash_ctrl", REF2_D, REF2_D, [REF2_HEAD, "教育研究』，第12巻，pp.45–58．"],
    note="対照: PDF にも「–」がある（5 本で 1 か所ある形）。docx のまま。"))
CASES.append(dcase(
    "b2d_docx_hyphen_pdf_endash", REF2_P, REF2_D, [REF2_HEAD, "教育研究』，第12巻，pp.45–58．"],
    note="docx は「-」、PDF は行の途中の「–」。PDF に合わせて「–」に直す（ふつうの違い）。"))

REF3_D = "架空三郎（2018）．『架空の算数教育』．架空出版，pp.101–115．"
REF3_P = REF3_D.replace("–", "-")
CASES.append(case(
    "b2d_two_refs_mid_and_eol", "edit", [], [], None, "exact", refs=[("引用文献", REF1), ("引用文献", REF2_D),
                                                                     ("引用文献", REF3_D)],
    ref_blocks=[Raw(*REF1_LINES), Raw(REF2_HEAD, "教育研究』，第12巻，pp.45-58．"),
                Raw("架空三郎（2018）．『架空の算数教育』．架空出", "版，pp.101-", "115．")],
    note="同じ論文の 2 つの文献: 一つは行の途中の「-」、もう一つは行末の「-」。どちらも PDF の「-」に直す（行の途中は直し"
         "行末は直さない、ということがない）。", item="endash"))
CASES[-1]["truth"].update({6: REF2_P, 7: REF3_P})
CASES[-1]["expect"].update({6: "exact", 7: "exact"})

B_DOCX = "調査は2019–2021年度に，架空の三つの中学校で行った。"
B_PUB = B_DOCX.replace("–", "-")
_b = bl(B_PUB)
_k = _b[0].index("2019-") + 5
B_LINES = [_b[0][:_k]] + wrap(_b[0][_k:] + "".join(_b[1:]))
_check("".join(B_LINES) == I + B_PUB and B_LINES[0].endswith("2019-"), "B の行")
CASES.append(case(
    "b2d_body_years_eol", "edit", [("本文", B_DOCX)], [Raw(*B_LINES)], {4: B_PUB}, "exact",
    "本文の年の範囲「2019–2021年度」（docx は en dash）が、PDF では行末の「2019-」と次の行の「2021年度…」。PDF の「-」に"
    "直す。「–」を消さない。", item="endash"))

CASES.append(dcase(
    "b2d_fix_across_eol", REF2_P, REF2_P.replace("pp.45-58", "pp.46-59"),
    [REF2_HEAD, "教育研究』，第12巻，pp.46-", "59．"],
    note="行末のハイフンをまたぐ 2 つの直し: docx「pp.45-58」、PDF「pp.46-」改行「59．」。「pp.46-59」に直す（0.20.0 は"
         "「pp.46 59」の形にした）。"))
CASES.append(dcase(
    "b2d_fix_across_eol_endash", REF2_D, REF2_P.replace("pp.45-58", "pp.46-59"),
    [REF2_HEAD, "教育研究』，第12巻，pp.46-", "59．"],
    note="docx「pp.45–58」（en dash）、PDF「pp.46-」改行「59．」。「pp.46-59」に直す（ダッシュを消さない）。"))
CASES.append(dcase(
    "b2d_fix_before_eol_dash", REF2_D, REF2_P.replace("pp.45-58", "pp.46-58"),
    [REF2_HEAD, "教育研究』，第12巻，pp.46-", "58．"],
    note="docx「pp.45–58」、PDF「pp.46-」改行「58．」。前の数字の直しと en dash の直しを両方して「pp.46-58」にする。"))

# ============================================================================ edge: 段落の最初・最後
E_BASE = "本研究では，架空の授業の記録をもとに，生徒の考えの変化を分析した。"
E_NEXT = "分析の方法は次の節で述べる。分析の対象は，架空の二つの学級の授業である。"


def ecase(name, docx, pub, lines, expect="exact", note="", sameline=None):
    """段落 4 の最初・最後の反例。段落 4 の後ろに、ふつうの段落 5（E_NEXT。docx と PDF で同じ）を置く。
    sameline: 校正で足された文字が、PDF の段落 4 の最初（"head"）・最後（"tail"）の行にあることを確かめる。"""
    t = {4: pub} if pub != docx else {}
    if sameline == "tail":
        _check(lines[-1].endswith(pub[-6:]) and len(lines[-1]) > 7, f"{name}: 最後の行")
    if sameline == "head":
        _check(lines[0].lstrip(I).startswith(pub[:8]) or lines[0].startswith("人数"), f"{name}: 最初の行")
    return case(name, "edit", [("本文", docx), ("本文", E_NEXT)], [Raw(*lines), Raw(*bl(E_NEXT))], t, expect, note,
                item="edge")


CASES.append(ecase(
    "b2e_head_word_sameline", E_BASE, "なお，" + E_BASE, bl("なお，" + E_BASE),
    note="段落の最初（字下げの後ろ）に校正で足された「なお，」（同じ行）。直す。", sameline="head"))
CASES.append(ecase(
    "b2e_head_quote", "架空の問い」について考える。" + E_BASE, "「架空の問い」について考える。" + E_BASE,
    bl("「架空の問い」について考える。" + E_BASE),
    note="段落の最初に校正で足された「「」（1 文字の句読点）。直す。", sameline="head"))
CASES.append(ecase(
    "b2e_tail_period_sameline", E_BASE.rstrip("。"), E_BASE, bl(E_BASE),
    note="段落の最後に校正で足された「。」（同じ行）。直す。", sameline="tail"))
E4_DOCX = E_BASE.rstrip("。")
E4_PUB = E4_DOCX + "（架空，2020）。"
CASES.append(ecase(
    "b2e_tail_cite_sameline", E4_DOCX, E4_PUB, bl(E4_PUB),
    note="段落の最後に校正で足された「（架空，2020）。」（同じ行）。直す。", sameline="tail"))

E5_DOCX = "本研究では，架空の授業の記録をもとに，生徒の考えの変化を分析した。分析の方法は次の各節で述べる"
_e5 = bl(E5_DOCX)
_check(len(_e5[-1]) == 24 or sum(_r._w(c) for c in _e5[-1]) == 24, "E5 の最後の行は 24 文字")
E5_PUB = E5_DOCX + "（架空，2020）。"
CASES.append(ecase(
    "b2e_tail_cite_nextline", E5_DOCX, E5_PUB, _e5 + ["（架空，2020）。"],
    expect="fix_or_keep",
    note="docx の段落の最後の行がちょうど 1 行（24 文字）で終わり、校正で足された「（架空，2020）。」が PDF の次の行に"
         "1 行だけで出る（その次の行は段落 5 の字下げの行）。本文の行なので直すのが望ましいが、段落 5 の前の、どの段落とも"
         "一致しない行でもあるので、docx のまま 13 章に出してもよい（黙って落とすのは FAIL）。段落 5 に足すのは FAIL。"))
CASES.append(ecase(
    "b2e_tail_period_nextline", E5_DOCX, E5_DOCX + "。", _e5 + ["。"], expect="fix_or_keep",
    note="境界（判断に迷う）: 段落の最後の行がちょうど 24 文字で、校正で足された「。」が次の行に 1 文字だけで出る（短い行は"
         "図の中の文字のこともある）。直すか、docx のまま 13 章に出す。"))
CASES.append(ecase(
    "b2e_tail_figtext_space_ctrl", E_BASE, E_BASE, bl(E_BASE)[:-1] + [bl(E_BASE)[-1] + " 時間（分）"],
    note="対照: 段落の最後の行の後ろに、同じ行で横の図の中の文字「時間（分）」が半角の空白をはさんでつながる。足さない"
         "（docx のまま）。"))
CASES.append(ecase(
    "b2e_head_figtext_space_ctrl", E_BASE, E_BASE, ["人数 " + bl(E_BASE)[0]] + bl(E_BASE)[1:],
    note="対照: 段落の最初の行の前に、同じ行で横の図の中の文字「人数」が半角の空白をはさんでつながる（「人数 \\u3000本研究"
         "では…」）。足さない（docx のまま）。"))
CASES.append(ecase(
    "b2e_tail_figtext_nospace", E_BASE, E_BASE, bl(E_BASE)[:-1] + [bl(E_BASE)[-1] + "図３"],
    note="段落の最後の行の後ろに、空白をはさまずに図の中の文字「図３」がつながる。足してはいけない（docx のまま）。"
         "DESIGN_N10.md 9 章 5 の限界（空白を手がかりにする）に当たる形で、組み合わせ C でも足しうる。"))
CASES.append(ecase(
    "b2e_head_figtext_indent_ctrl", E_BASE, E_BASE, ["人数" + bl(E_BASE)[0]] + bl(E_BASE)[1:],
    note="対照: 段落の最初の行の前に、横の図の中の文字「人数」が字下げの全角の空白だけをはさんでつながる（「人数\\u3000本研究"
         "では…」）。足さない（docx のまま）。"))
E10_DOCX = E_BASE.rstrip("。")
CASES.append(ecase(
    "b2e_tail_period_and_figtext", E10_DOCX, E_BASE, bl(E_BASE)[:-1] + [bl(E_BASE)[-1] + " 時間（分）"],
    expect="fix_or_keep",
    note="段落の最後に校正で足された「。」と、その後ろに半角の空白をはさんで横の図の中の文字「時間（分）」が同じ行に"
         "つながる。「。」は（一致した文字に空白なしでつながるので）直すのが望ましいが、どこまでが段落の文字か決められない"
         "として docx のまま 13 章に出してもよい。図の中の文字を足すのは FAIL。"))
E11_PUB = "なお，" + E_BASE.rstrip("。") + "（架空，2020）。"
CASES.append(ecase(
    "b2e_head_and_tail", E_BASE, E11_PUB, bl(E11_PUB),
    note="段落の最初の「なお，」と最後の「（架空，2020）」の両方が校正で足された（どちらも同じ行）。両方直す。",
    sameline="tail"))

EN12_DOCX = "This study examines how students related the results of trials to probability in the lesson"
EN12_PUB = EN12_DOCX + " design."
CASES.append(case(
    "b2e_english_tail", "edit", [], [], None, "exact",
    "英文要旨の段落の最後に校正で足された「design.」（同じ行。単語の間の空白 1 つ）。直す（英文の段落の端に足すときは、"
    "単語の間の空白も足す）。", item="edge",
    eng=(EN12_DOCX, EN12_PUB, ["This study examines how students related the",
                               "results of trials to probability in the lesson design."])))
CASES.append(case(
    "b2e_english_tail_nextline", "edit", [], [], None, "exact",
    "英文要旨の段落の最後に校正で足された「design.」が、PDF の次の行に 1 語だけで出る（ページの最後の行）。直すか、"
    "docx のまま 13 章に出す（黙って落とすのは FAIL）。", item="edge", eng_expect="fix_or_keep",
    eng=(EN12_DOCX, EN12_PUB, ["This study examines how students related the",
                               "results of trials to probability in the lesson", "design."])))

EN13_DOCX = "This study examines how students related the results of trials to probability."
EN13_PUB = "The present study examines how students related the results of trials to probability."
CASES.append(case(
    "b2e_english_head", "edit", [], [], None, "exact",
    "英文要旨の段落の最初（PDF では「\\u3000\\u3000 」の字下げの後ろ）の校正の置き換え「This」→「The present」。直す。",
    eng=(EN13_DOCX, EN13_PUB, None), item="edge"))

# ============================================================================ その他
O1_DOCX = "生徒の self-regulated な学習の過程を，記述の分析によって明らかにした。"
_o1 = bl(O1_DOCX)
CASES.append(case(
    "b2o_true_hyphen_fffe", "edit", [("本文", O1_DOCX)],
    [Raw(I + "生徒の self￾" + "regulated な学習の過程を，記述の分析に", "よって明らかにした。")], None, "exact",
    "対照: 本当のハイフン「self-regulated」が行末に来て、PDF は U+FFFE で次の行とつながる。docx のまま（「-」を消さない）。",
    item="new"))

O2_DOCX = f"各回の経験的確率（{OBJ}，…，{OBJ}とする）を求め，その変化を記録した。"
O2_TRUTH = O2_DOCX.replace("を求め，", "を求め，表と")
O2_PDF = O2_TRUTH.replace(f"（{OBJ}，…，{OBJ}とする）", f" （{M_SP}， …， {M_SP}とする） ")
_o2 = lines_of(O2_PDF)
CASES.append(case(
    "b2o_math_and_figsplit", "artifact", [("本文", O2_DOCX)] + FIG_PARAS,
    [Raw(*_o2[:1]), Raw(*FIG_SPAN), BREAK, Raw(*_o2[1:])], {4: O2_TRUTH}, "exact",
    "docx にも数式があり（PDF は空白の並び）、その段落がページの最後の 2 段ぶち抜きの図で分断される。分断の後ろの校正の"
    "挿入「表と」（数式から離れた位置）を直す。図の中の文字は足さない。", item="N10"))

O3_DOCX = "各回の記録を集計した。"
O3_TRUTH = f"各回の記録（{OBJ}，…，{OBJ}）を集計した。"
O3_PDF = f"各回の記録 （{M_SP}， …， {M_SP}） を集計した。"
CASES.append(case(
    "b2o_math_ins_short_para", "edit", [("本文", O3_DOCX)], [Raw(*lines_of(O3_PDF))], {4: O3_TRUTH}, "keep",
    "短い段落（11 文字）に校正で数式の組「（p，…，p）」が足され、PDF では空白の並び。「（，…，）」だけ足すと数式の欠けた"
    "文字になるので、docx のまま 13 章に出す。", item="math"))

O4_DOCX = "架空四郎（2020）．「架空の割合の研究」．『架空数学教育』，第5巻，pp.7–9．"
O4_PUB = O4_DOCX.replace("–", "-")
CASES.append(dcase(
    "b2d_ref_eol_single_digit", O4_DOCX, O4_PUB, ["架空四郎（2020）．「架空の割合の研究」．『架", "空数学教育』，第5巻，pp.7-",
                                                    "9．"],
    note="1 けたのページの範囲「pp.7–9」が行末で分かれる（「pp.7-」改行「9．」）。PDF の「-」に直す。"))

# 名前の重なりを確かめる
_names = [c["name"] for c in CASES]
_check(len(_names) == len(set(_names)), "名前が重なっている")
