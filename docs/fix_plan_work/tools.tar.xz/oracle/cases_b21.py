"""反例集（oracle_b21: 単位 B2.1〈0.21.1〉の対象。実装を見ない担当が、原則と本誌の出版版 PDF の形だけから作ったもの）。

文字はすべて架空（実際の論文の文字を書き写していない）。書式と判定は runner.py の docstring。実行:
  python oracle/run_all.py <src> oracle/cases_b21.py --name <名前>

対象: PDF の中で分断された段落の端の 1 行（または段落の最初・最後の行）と、すぐ隣の図・表の中の行・キャプション・ほかの段落・
投稿受付日の行・柱がよく似ている、または入れ替わって見える配置。

期待（原則だけで決める）:
- 出版版 PDF の本文と同じにする（直す）。ただし、端の行のすぐ隣に、よく似た図・表の中の行などがあって、どの行が段落の行かを
  PDF から決められないときは、docx のまま残し、理由を付けて 13 章に出してもよい（fix_or_keep）。
- 組版の文字（受付日・柱・ページ番号）・docx にない図や表の中の文字・ほかの段落の文字を足さない。PDF の本文にある docx の文字を
  消さない。途中まで直す・別の文字にする（docx にも PDF にもない文字にする）のは FAIL。
- truth を書かない段落は docx のまま（1 文字でも変われば FAIL。図の中の文字に合わせて全角・半角を変えるのも FAIL）。
- 図も分断もない、ふつうの位置の直し（対照）は直す（exact）。

期待の書き方（cases_b2.py と同じ。runner.judge を、この 2 つの期待のときだけ包む。ほかの期待の判定は変えない）:
  "keep"        : docx のまま（1 文字も変えない）で、違いが 13 章に出ること（REPORTED）。docx を少しでも変えたら FAIL。
  "fix_or_keep" : truth と同じに直す（OK）か、docx のまま残して 13 章に出す（REPORTED）のどちらか。それ以外は FAIL。

反例の名前: b21_<組>_<配置>_<内容>。内容の印:
  none   : 校正の直しなし。図の中に、段落の端の行とよく似た行（取り違えやすい行）がある。段落は docx のまま（exact）。
  snone / srep / sins : 強いよく似た行（図の中の行が、docx の端の行の写し〈校正の前の文〉にごく近い）での none・rep・ins。
  rep / ins / del / width / dash / case : 端の行の本当の校正の直し（置き換え・挿入・削除・全角半角・ダッシュ・大文字小文字）。
           すぐ隣によく似た行があるものは fix_or_keep（直すのが望ましいが、13 章に出してもよい。REPORTED の数が「13.2 に
           回る本当の直し」の数になる）。図も分断もない対照（X 組・F の一部・D の対照）は exact。
           b21_D_copy_capbelow（消された文とまったく同じ図の中の行）は、PDF の文字だけからは段落の続きと見分けられない形で、
           どの案でも落ちうるので、別に数える。
  wdec   : 直しなし。本当の行は docx と同じ全角の「２」で、図の中のよく似た行だけが半角の「2」。docx のまま（exact）。

組:
  T : 段落 4 の最後の行（端）。図（キャプションの上・下）・ページ・段の区切り・受付日・柱・1 行だけの図で分断・隣接。
  H : 段落 7（書き出し）。段落のすぐ前の図（キャプションは図の下・上）、書き出しの 1 行だけが図の前に出る分断など。
  D : 段落の最後の文が校正で消され、消された文とよく似た 1 行の図・1 行だけの表が次のページ（段）の最初にある。
  F : 向かい合う 2 段落（段落 4 の最後・段落 7 の書き出し）の両方・片方の直し（図のあり・なし）。
  K : 柱（2 ページ目以降の最初の行）が、段落の端の行・校正で直される前の語の文字を含む。
  C : キャプションとよく似た段落の端の行、表のキャプション「表１」の隣の「13点」（「113点」にしない）。
  O : 2 段組みの読み順のずれで、段落の最後の行がほかの段落（よく似た最後の行をもつ）の後ろに出る。
  R : 投稿受付日の行（日付が段落の最後の行の日付とよく似ている）が、段落の途中・すぐ後ろに入る。
  X : 対照（図も分断もない、または分断から離れた行の直し。直す）。
  E : 端の行の英字の大文字・小文字とダッシュ（図の中の行は大文字・波ダッシュ）。
どの反例にも、確かめ用の違い（段落 2: docx「3回」→ PDF「３回」）を置く（照合が働いていることを確かめるため）。
"""
from __future__ import annotations

import runner as _r
from runner import BREAK, DEFAULTS, Raw, flow, journal_line, received_line, wrap

# ============================================================================ runner を包む（keep / fix_or_keep）
_orig_judge = _r.judge


def _keep_judge(orig, fixed, truth, ev_fn, label):
    if fixed != orig:
        d = _r.describe(orig, fixed, orig)
        parts = []
        if d["added"]:
            parts.append(f"足した{_r._q(d['added'])}")
        if d["deleted"]:
            parts.append(f"消した{_r._q(d['deleted'])}")
        return "FAIL", f"{label}: docx から変えた（" + ("・".join(parts) or "違いがある") + f"）。直した後「{fixed}」"
    d = _r.describe(orig, fixed, truth)
    ev = ev_fn(d["left"] + d["not_added"])
    if not ev:
        return "FAIL", f"{label}: docx のまま残したが、違いが 13 章に出ていない"
    return "REPORTED", "docx のまま（13 章: " + "・".join(ev) + "）"


def _judge(orig, fixed, truth, has_truth, expect, ev_fn):
    if expect == "keep":
        return _keep_judge(orig, fixed, truth, ev_fn, "docx のまま 13 章に出すべき")
    if expect == "fix_or_keep":
        if fixed == truth:
            return "OK", ""
        if fixed == orig:
            return _keep_judge(orig, fixed, truth, ev_fn, "直すか docx のまま 13 章に出すべき")
        v, why = _orig_judge(orig, fixed, truth, has_truth, "exact", ev_fn)
        return "FAIL", "直すか docx のまま残すかのどちらでもない: " + why
    return _orig_judge(orig, fixed, truth, has_truth, expect, ev_fn)


_r.judge = _judge


def _check(cond, msg):
    if not cond:
        raise ValueError("反例の組み立ての誤り: " + msg)


# ============================================================================ 架空の論文
I = "　"          # 全角の空白（段落の字下げ）


def bl(text):
    """本文の段落の行（1 行目は全角の空白で字下げ）。"""
    return wrap(I + text)


H1 = "１．はじめに"
A = ("本研究の目的は，架空の中学校で行われた確率の授業において，生徒が試行の結果と確率をどのように関係づけたかを，"
     "授業中の発話と記述の分析によって明らかにすることである。")
CTRL_DOCX = "分析の対象は，第２学年の一つの学級で3回行った授業の記録である。授業者は架空の教諭である。"
CTRL_PUB = CTRL_DOCX.replace("3回", "３回")
H2 = "２．研究の方法"
RH = "引用および参考文献"
REF1 = "架空一郎（2019）．「架空の数の研究」．『架空数学研究』，第29号，pp.11-16．"
REF1_LINES = ["架空一郎（2019）．「架空の数の研究」．『架空", "数学研究』，第29号，pp.11-16．"]
EN_ABS = DEFAULTS["英文要旨"]
HEAD_LINE = "架空の確率の授業の分析"          # 2 ページ目以降の最初の柱（ほかの雑誌の形）
RECV = received_line("2025年８月31日", "2025年11月24日")


def front():
    return Raw(journal_line(vol=31, no=1, year=2026, fp=1, lp=12), DEFAULTS["題目"], DEFAULTS["副題"], "架空大学　試験　五郎")


def english():
    return Raw(DEFAULTS["英文題目"], DEFAULTS["英文副題"], "Goro SHIKEN", "Fictional University", "Abstract",
               I + I + " " + EN_ABS)


def _with_heads(pages, head):
    """2 ページ目以降の、ページ番号の行のすぐ後ろに柱の行を入れる。"""
    out = []
    for k, p in enumerate(pages):
        if k == 0 or not head:
            out.append(p)
            continue
        ls = p.split("\n")
        out.append("\n".join([ls[0], head] + ls[1:]))
    return out


def art(name, extra, mid, truth=None, expect=None, note="", heads=None, item="B2.1", angle="artifact"):
    """標準の小さな論文の反例。

    docx の段落: 0 見出し / 1 A / 2 確かめ用 / 3 見出し / 4〜 extra / 文献見出し / 文献。
    PDF: 1 ページ目の冒頭・見出し・A・確かめ用・見出し、mid のブロック（Raw・BREAK）、文献見出し、文献、英文。
    truth・expect は extra の中の番号（4 から）。expect を書かない truth の段落は fix_or_keep。
    heads: 2 ページ目以降の最初（ページ番号の次）の柱の行。
    """
    paras = [("見出し", H1), ("本文", A), ("本文", CTRL_DOCX), ("見出し", H2)] + list(extra) + \
            [("引用文献見出し", RH), ("引用文献", REF1)]
    t = {2: CTRL_PUB}
    t.update(truth or {})
    exp = {"default": "exact"}
    for k in (truth or {}):
        exp[k] = "fix_or_keep"
    exp.update(expect or {})
    for k, v in (truth or {}).items():
        _check(v != paras[k][1], f"{name}: 段落 {k} の truth が docx と同じ")
    blocks = [front(), Raw(H1), Raw(*bl(A)), Raw(*bl(CTRL_PUB)), Raw(H2)] + list(mid) + \
             [Raw(RH), Raw(*REF1_LINES), english()]
    pages = _with_heads(flow(blocks, first=1), heads)
    return {"name": name, "angle": angle, "item": item, "paras": paras, "truth": t, "pages": pages,
            "expect": exp, "note": note}


CASES = []

# ---------------------------------------------------------------------------- 段落の文字
# 段落 P（最後の行が端）・Q（書き出しが端）・R（その後ろのふつうの段落）
PT = ("授業の後半では，各班の結果を黒板に並べて全体で比べた。教師は割合の変化に注目するよう促し，生徒が気づいたことを"
      "説明し合う時間を取った。")
QH = ("班の話し合いでは，ある生徒が回数を増やすと割合の変化が小さくなることを指摘した。ほかの生徒もその考えに同意し，"
      "記録を見直した。")
RN = "次の時間には，各自が予想を立ててから実験を行った。予想と結果のずれについては，全体で確かめた。"
_check(bl(PT)[-1] == "が気づいたことを説明し合う時間を取った。", "PT の最後の行")
_check(bl(QH)[0] == I + "班の話し合いでは，ある生徒が回数を増やすと割合", "QH の最初の行")

CAP = "図１　架空のワークシートの例"
FIGB = ["問い　赤い玉が出る割合を調べよう", "予想　結果　理由"]       # 図の中の文字（docx にない）
IMG = ("画像", "図1")

# 段落 P の最後の行の内容: (docx, truth〈None なら直しなし〉, 図の中のよく似た行, 説明)
T_CONTENTS = {
    "rep": (PT, PT.replace("時間を取った。", "時間を設けた。"), "説明し合う時間を取る",
            "最後の行の校正の置き換え「取った」→「設けた」。図の中の行「説明し合う時間を取る」は docx の文字とよく似ている。"),
    "width": (PT.replace("時間を取った", "時間を2回取った"), PT.replace("時間を取った", "時間を２回取った"), "時間を2回見る",
              "最後の行の全角・半角の違い（docx「2回」→ PDF「２回」）。図の中の行は半角の「時間を2回見る」。"),
    "wdec": (PT.replace("時間を取った", "時間を２回取った"), None, "時間を2回見る",
             "直しなし（docx も PDF の本当の行も全角の「２回」）。図の中の行だけが半角の「時間を2回見る」。図の中の文字に合わせて"
             "「２」を「2」にしてはいけない。"),
    # 強いよく似た行: 図の中の行が、docx の最後の行の写し（原稿の段階の文のワークシートなど）にごく近い
    "snone": (PT, None, "気づいたことを説明し合う時間を取る",
              "直しなし。図の中の行「気づいたことを説明し合う時間を取る」が、段落の最後の行の写しにごく近い。"),
    "srep": (PT, PT.replace("時間を取った。", "時間を設けた。"), "気づいたことを説明し合う時間を取る",
             "最後の行の校正の置き換え「取った」→「設けた」。図の中の行「気づいたことを説明し合う時間を取る」は、PDF の本当の"
             "最後の行より docx の最後の行に近い（校正の前の文の写し）。"),
    "sins": (PT, PT.replace("説明し合う時間", "説明し合う短い時間"), "が気づいたことを説明し合う時間",
             "最後の行の校正の挿入「短い」。図の中の行「が気づいたことを説明し合う時間」は、docx の最後の行の前の部分の写し。"),
}
T_DEL = (PT.replace("ことを説明", "ことを互いに説明"), PT, "互いに説明し合う",
         "最後の行の校正の削除（docx の「互いに」が PDF にない）。図の中の行「互いに説明し合う」は消された語を含む。")
for key, (d, tr, dec, _) in list(T_CONTENTS.items()) + [("del", T_DEL)]:
    _check(bl(d)[:-1] == bl(tr or d)[:-1], f"T の {key}: 違いは最後の行だけ")


def t_layout(kind, p, d):
    """段落 P（行のリスト p）の最後の行のまわりの配置。d は図の中のよく似た行。戻り値: (docx の extra, mid, 説明)。"""
    q, r = bl(QH), bl(RN)
    fig_docx = [IMG, ("図キャプション", CAP)]
    if kind == "cb_col":
        return fig_docx, [Raw(*p[:-1]), Raw(*FIGB, d), Raw(CAP), Raw(p[-1]), Raw(*q), Raw(*r)], \
            "段の区切りの後ろ（右の段の最初）に図、その下にキャプション、その後ろに段落 4 の最後の行（分断）。よく似た行はキャプションのすぐ前。"
    if kind == "cb_page":
        return fig_docx, [Raw(*p[:-1]), BREAK, Raw(*FIGB, d), Raw(CAP), Raw(p[-1]), Raw(*q), Raw(*r)], \
            "ページの区切りの後ろ（次のページの最初）に図とキャプション（図の下）、その後ろに段落 4 の最後の行（分断）。"
    if kind == "ca_col":
        return fig_docx, [Raw(*p[:-1]), Raw(CAP), Raw(*FIGB, d), Raw(p[-1]), Raw(*q), Raw(*r)], \
            "キャプションが図の上。図の最後の行（よく似た行）のすぐ後ろに段落 4 の最後の行（分断）。"
    if kind == "recv":
        return fig_docx, [Raw(*p[:-1]), Raw(RECV), Raw(*FIGB, d), Raw(CAP), Raw(p[-1]), Raw(*q), Raw(*r)], \
            "1 ページ目の左の段の最後に投稿受付日の行、右の段の最初に図とキャプション、その後ろに段落 4 の最後の行（分断）。"
    if kind == "head":
        return fig_docx, [Raw(*p[:-1]), BREAK, Raw(*FIGB, d), Raw(CAP), Raw(p[-1]), Raw(*q), Raw(*r)], \
            "次のページの最初に柱の行、その後ろに図とキャプション、その後ろに段落 4 の最後の行（分断）。"
    if kind == "in_cb":
        return fig_docx, [Raw(*p), Raw(d, *FIGB), Raw(CAP), Raw(*q), Raw(*r)], \
            "段落 4 は分断されず、すぐ後ろ（間に行なし）に図（最初の行がよく似た行）とキャプション（図の下）。ページの途中。"
    if kind == "in_page":
        return fig_docx, [Raw(*p), BREAK, Raw(d, *FIGB), Raw(CAP), Raw(*q), Raw(*r)], \
            "段落 4 はページの最後で終わり、次のページの最初に図（最初の行がよく似た行）とキャプション。"
    if kind == "one_page":
        return [IMG], [Raw(*p), BREAK, Raw(d), Raw(*q), Raw(*r)], \
            "段落 4 はページの最後で終わり、次のページの最初に 1 行だけの図（キャプションなし。よく似た行）。"
    raise ValueError(kind)


T_KINDS = ["cb_col", "cb_page", "ca_col", "recv", "head", "in_cb", "one_page"]


def t_case(kind, key, content):
    d_text, tr, dec, desc = content
    p = bl(tr or d_text)
    fig_docx, mid, ldesc = t_layout(kind, p, dec)
    extra = [("本文", d_text)] + fig_docx + [("本文", QH), ("本文", RN)]
    truth = {4: tr} if tr else None
    tag = "直す" if tr else "取り違え"
    exp_note = ("直すか、よく似た行と決められないとして docx のまま 13 章に出す（fix_or_keep）。図の中の文字を足す・docx の文字を"
                "消す・途中まで直すのは FAIL。" if tr else "段落 4 は docx のまま（図の中の文字を足さない・消さない・全角半角を変えない）。")
    return art(f"b21_T_{kind}_{key}", extra, mid, truth, None,
               f"[{tag}] {ldesc} {desc} {exp_note}", heads=HEAD_LINE if kind == "head" else None)


for kind in T_KINDS:
    for key, content in T_CONTENTS.items():
        CASES.append(t_case(kind, key, content))
for kind in ("cb_col", "in_cb"):
    CASES.append(t_case(kind, "del", T_DEL))

# ---------------------------------------------------------------------------- H: 書き出し
H_CONTENTS = {
    "ins": (QH, "各" + QH, "班の話し合いでは",
            "書き出しの校正の挿入「各」（「各班の話し合いでは，」）。図の中の行「班の話し合いでは」は docx の書き出しの写し。"),
    "rep": (QH, QH.replace("ある生徒が", "一人の生徒が"), "ある生徒の記録",
            "最初の行の校正の置き換え「ある」→「一人の」。図の中の行「ある生徒の記録」。"),
    "width": ("第2" + QH, "第２" + QH, "第2班の話し合い",
              "書き出しの全角・半角の違い（docx「第2班」→ PDF「第２班」）。図の中の行は半角の「第2班の話し合い」。"),
    # 強いよく似た行: 図の中の行が、docx の最初の行の写し（原稿の段階の文）にごく近い
    "snone": (QH, None, "班の話し合いでは，ある生徒が回数を増やすと",
              "直しなし。図の中の行「班の話し合いでは，ある生徒が回数を増やすと」が、段落 7 の最初の行の写しにごく近い。"),
    "sins": (QH, "各" + QH, "班の話し合いでは，ある生徒が回数を増やすと",
             "書き出しの校正の挿入「各」。図の中の行は docx の最初の行の写しにごく近い。"),
    "srep": (QH, QH.replace("班の話し合いでは", "班の協議では"), "班の話し合いでは，ある生徒が回数を",
             "書き出しの校正の置き換え「話し合い」→「協議」。図の中の行「班の話し合いでは，ある生徒が回数を」は、PDF の本当の"
             "最初の行より docx の最初の行に近い（校正の前の文の写し）。"),
}
for key, (d, tr, dec, _) in H_CONTENTS.items():
    _check(bl(d)[0] != bl(tr)[0] if tr else True, f"H の {key}: 最初の行に違いがある")


def h_layout(kind, q, d):
    """段落 Q（行のリスト q）の書き出しのまわりの配置。"""
    p, r = bl(PT), bl(RN)
    fig_docx = [IMG, ("図キャプション", CAP)]
    if kind == "in_cb":
        return fig_docx, [Raw(*p), Raw(*FIGB, d), Raw(CAP), Raw(*q), Raw(*r)], \
            "段落 7 のすぐ前に図（よく似た行は図の最後の行）とキャプション（図の下）。段落 7 は分断されない。"
    if kind == "in_ca":
        return fig_docx, [Raw(*p), Raw(CAP), Raw(*FIGB, d), Raw(*q), Raw(*r)], \
            "段落 7 のすぐ前に、キャプション（図の上）と図。図の最後の行（よく似た行）のすぐ後ろが段落 7 の書き出し。"
    if kind == "in_page":
        return fig_docx, [Raw(*p), BREAK, Raw(*FIGB, d), Raw(CAP), Raw(*q), Raw(*r)], \
            "ページの最初に図とキャプション（図の下）、その後ろから段落 7。"
    if kind == "sp_cb":
        return fig_docx, [Raw(*p), Raw(q[0]), Raw(d, *FIGB), Raw(CAP), Raw(*q[1:]), Raw(*r)], \
            "段落 7 の最初の行だけが図の前に出て、図（最初の行がよく似た行）とキャプションの後ろから 2 行目以降が続く（分断）。"
    if kind == "sp_page":
        return fig_docx, [Raw(*p), Raw(q[0]), BREAK, Raw(d, *FIGB), Raw(CAP), Raw(*q[1:]), Raw(*r)], \
            "段落 7 の最初の行がページの最後の行。次のページの最初に図（最初の行がよく似た行）とキャプション、その後ろから続く。"
    if kind == "sp_recv":
        return fig_docx, [Raw(*p), Raw(q[0]), Raw(RECV), Raw(d, *FIGB), Raw(CAP), Raw(*q[1:]), Raw(*r)], \
            "段落 7 の最初の行の後ろに投稿受付日の行（左の段の最後）、右の段の最初に図とキャプション、その後ろから続く。"
    if kind == "sp_head":
        return fig_docx, [Raw(*p), Raw(q[0]), BREAK, Raw(d, *FIGB), Raw(CAP), Raw(*q[1:]), Raw(*r)], \
            "段落 7 の最初の行がページの最後。次のページの最初に柱、図（最初の行がよく似た行）とキャプション、その後ろから続く。"
    if kind == "one":
        return [IMG], [Raw(*p), Raw(d), Raw(*q), Raw(*r)], \
            "段落 7 のすぐ前に 1 行だけの図（キャプションなし。よく似た行）。ページの途中。"
    raise ValueError(kind)


H_KINDS = ["in_cb", "in_ca", "in_page", "sp_cb", "sp_head", "one"]
for kind in H_KINDS:
    for key, (d_text, tr, dec, desc) in H_CONTENTS.items():
        q = bl(tr or d_text)
        fig_docx, mid, ldesc = h_layout(kind, q, dec)
        extra = [("本文", PT)] + fig_docx + [("本文", d_text), ("本文", RN)]
        qi = 4 + 1 + len(fig_docx)
        truth = {qi: tr} if tr else None
        tag = "直す" if tr else "取り違え"
        exp_note = (f"段落 {qi} は直すか docx のまま 13 章に出す（fix_or_keep）。図の中の文字を足す・消す・途中まで直すのは FAIL。"
                    if tr else f"段落 {qi} は docx のまま。")
        CASES.append(art(f"b21_H_{kind}_{key}", extra, mid, truth, None,
                         f"[{tag}] {ldesc} {desc} {exp_note}段落 4 は docx のまま。",
                         heads=HEAD_LINE if kind == "sp_head" else None))

# ---------------------------------------------------------------------------- D: 消された最後の文と小さな図
PD = PT + "その時間は短かった。"
_check(bl(PT)[-1].endswith("取った。"), "D")


def d_case(name, fig_docx, mid_fig, note, expect="fix_or_keep", brk=True, heads=None, recv=False):
    p, q, r = bl(PT), bl(QH), bl(RN)
    mid = [Raw(*p)] + ([Raw(RECV)] if recv else []) + ([BREAK] if brk else []) + list(mid_fig) + [Raw(*q), Raw(*r)]
    extra = [("本文", PD)] + list(fig_docx) + [("本文", QH), ("本文", RN)]
    return art(name, extra, mid, {4: PT}, {4: expect}, note, heads=heads)


D_BASE = "段落 4 の最後の文「その時間は短かった。」が校正で消された（PDF の段落 4 は「…時間を取った。」で終わる）。"
D_EXP = "消された文を消して直すか、docx のまま 13 章に出す（fix_or_keep）。図・表の中の文字を足す・消された文の一部だけを残すのは FAIL。"
CASES += [
    d_case("b21_D_page_1line", [IMG], [Raw("その時間の様子")],
           f"[取り違え] {D_BASE}次のページの最初に 1 行だけの図「その時間の様子」（キャプションなし）。{D_EXP}"),
    d_case("b21_D_page_table1", [("表", [["その時間", "短かった"]])], [Raw("その時間　短かった")],
           f"[取り違え] {D_BASE}次のページの最初に 1 行だけの表（docx は Word の表。PDF の行「その時間　短かった」）。"
           f"表のセルの文字は表の段落の文字なので、段落 4 に残す・足すのは FAIL。{D_EXP}"),
    d_case("b21_D_page_capbelow", [IMG, ("図キャプション", CAP)], [Raw("その時間は短い"), Raw(CAP)],
           f"[取り違え] {D_BASE}次のページの最初に 1 行だけの図「その時間は短い」とキャプション（図の下）。{D_EXP}"),
    d_case("b21_D_col_1line", [IMG], [Raw("その時間の様子")],
           f"[取り違え] {D_BASE}段の区切りの後ろ（右の段の最初）に 1 行だけの図「その時間の様子」。{D_EXP}", brk=False),
    d_case("b21_D_head_1line", [IMG], [Raw("その時間の様子")],
           f"[取り違え] {D_BASE}次のページの最初に柱、その後ろに 1 行だけの図「その時間の様子」。{D_EXP}", heads=HEAD_LINE),
    d_case("b21_D_ctrl_nofig", [], [],
           f"[対照] {D_BASE}図も表もない（次のページの最初から段落 7）。消された文を消して直す（exact）。", expect="exact"),
    d_case("b21_D_copy_capbelow", [IMG, ("図キャプション", CAP)], [Raw("その時間は短かった。"), Raw(CAP)],
           f"[取り違え] {D_BASE}次のページの最初に、消された文とまったく同じ 1 行の図の中の文字（ワークシートの写し）と"
           f"キャプション。PDF からはどちらとも決められないので、直すか docx のまま 13 章に出す。{D_EXP}"),
    d_case("b21_D_recv_1line", [IMG], [Raw("その時間の様子")],
           f"[取り違え] {D_BASE}段落 4 の後ろに投稿受付日の行（左の段の最後）、右の段の最初に 1 行だけの図「その時間の様子」。"
           f"{D_EXP}", brk=False, recv=True),
]

# ---------------------------------------------------------------------------- F: 向かい合う 2 段落
P_REP = T_CONTENTS["rep"][1]
Q_INS = H_CONTENTS["ins"][1]


def f_case(name, fig, mid_fn, truth, expect, note):
    p, q, r = bl(truth.get("P", PT)), bl(truth.get("Q", QH)), bl(RN)
    extra = [("本文", PT)] + fig + [("本文", QH), ("本文", RN)]
    qi = 4 + 1 + len(fig)
    t = {}
    if "P" in truth:
        t[4] = truth["P"]
    if "Q" in truth:
        t[qi] = truth["Q"]
    exp = {k: expect for k in t}
    return art(name, extra, mid_fn(p, q, r), t, exp, note)


FIGD = [IMG, ("図キャプション", CAP)]
CASES += [
    f_case("b21_F_nofig_both", [], lambda p, q, r: [Raw(*p), Raw(*q), Raw(*r)], {"P": P_REP, "Q": Q_INS}, "exact",
           "[対照] 図なし。段落 4 の最後の行（「取った」→「設けた」）と、すぐ後ろの段落 5 の書き出し（「各」の挿入）の両方に"
           "校正の直し。両方直す。"),
    f_case("b21_F_nofig_page_both", [], lambda p, q, r: [Raw(*p), BREAK, Raw(*q), Raw(*r)], {"P": P_REP, "Q": Q_INS},
           "exact",
           "[対照] 図なし。段落 4 がページの最後で終わり、段落 5 が次のページの最初から。向かい合う端の両方の直しを直す。"),
    f_case("b21_F_nofig_recv_both", [], lambda p, q, r: [Raw(*p), Raw(RECV), Raw(*q), Raw(*r)], {"P": P_REP, "Q": Q_INS},
           "fix_or_keep",
           "[直す] 図なし。段落 4 と段落 5 の間に投稿受付日の行（左の段の最後）。向かい合う端の両方の直し。直す（望ましい）か"
           "13 章に出す。受付日の文字を足すのは FAIL。"),
    f_case("b21_F_fig_between_both", FIGD,
           lambda p, q, r: [Raw(*p), Raw(*FIGB, "班の話し合いの記録"), Raw(CAP), Raw(*q), Raw(*r)],
           {"P": P_REP, "Q": Q_INS}, "fix_or_keep",
           "[直す] 段落 4 と段落 7 の間に図（最後の行「班の話し合いの記録」）とキャプション。両方の端の直し。"),
    f_case("b21_F_psplit_q_only", FIGD,
           lambda p, q, r: [Raw(*p[:-1]), Raw(*FIGB, "説明し合う時間を見る"), Raw(CAP), Raw(p[-1]), Raw(*q), Raw(*r)],
           {"Q": Q_INS}, "fix_or_keep",
           "[直す] 段落 4 の最後の行がキャプションの後ろに出る（分断。直しなし）。段落 7 の書き出しだけが直された。段落 4 は"
           "docx のまま（変えたら FAIL）。段落 7 は直すか 13 章に出す。"),
    f_case("b21_F_psplit_both", FIGD,
           lambda p, q, r: [Raw(*p[:-1]), Raw(*FIGB, "説明し合う時間を取る"), Raw(CAP), Raw(p[-1]), Raw(*q), Raw(*r)],
           {"P": P_REP, "Q": Q_INS}, "fix_or_keep",
           "[直す] 段落 4 の最後の行（直しあり）がキャプションの後ろに出て、すぐ後ろの段落 7 の書き出しも直された（facing の形）。"
           "どちらも直すか 13 章に出す。"),
    f_case("b21_F_qsplit_p_only", FIGD,
           lambda p, q, r: [Raw(*p), Raw(q[0]), Raw("班の話し合いの記録", *FIGB), Raw(CAP), Raw(*q[1:]), Raw(*r)],
           {"P": P_REP}, "fix_or_keep",
           "[直す] 段落 7 の最初の行だけが図の前に出る（分断。直しなし）。段落 4 の最後の行だけが直された。段落 7 は docx の"
           "まま。段落 4 は直すか 13 章に出す。"),
]

# ---------------------------------------------------------------------------- K: 柱
CASES += [
    art("b21_K_lastline_top_rep", [("本文", PT), ("本文", QH), ("本文", RN)],
        [Raw(*bl(P_REP)[:-1]), BREAK, Raw(bl(P_REP)[-1]), Raw(*bl(QH)), Raw(*bl(RN))], {4: P_REP}, None,
        "[直す] 段落 4 の最後の行（「取った」→「設けた」）が次のページの最初の柱「時間を取る授業の工夫」のすぐ後ろ。柱は"
        "直される前の docx の語の文字を含む。直すか 13 章に出す。柱の文字を足すのは FAIL。", heads="時間を取る授業の工夫"),
    art("b21_K_lastline_top_none", [("本文", PT), ("本文", QH), ("本文", RN)],
        [Raw(*bl(PT)[:-1]), BREAK, Raw(bl(PT)[-1]), Raw(*bl(QH)), Raw(*bl(RN))], None, None,
        "[取り違え] 直しなし。段落 4 の最後の行が次のページの最初の柱「説明し合う時間の工夫」のすぐ後ろ。段落 4 は docx のまま。",
        heads="説明し合う時間の工夫"),
    art("b21_K_head_top_ins", [("本文", PT), ("本文", QH), ("本文", RN)],
        [Raw(*bl(PT)), BREAK, Raw(*bl(Q_INS)), Raw(*bl(RN))], {5: Q_INS}, None,
        "[直す] 段落 5 が次のページの最初（柱「班の話し合いの工夫」のすぐ後ろ）から始まり、書き出しに校正の挿入「各」。"
        "直すか 13 章に出す。", heads="班の話し合いの工夫"),
    art("b21_K_lastline_bottom_rep", [("本文", PT), ("本文", QH), ("本文", RN)],
        [Raw(*bl(P_REP)), BREAK, Raw(*bl(QH)), Raw(*bl(RN))], {4: P_REP}, None,
        "[直す] 段落 4 の最後の行（直しあり）がページの最後の行。次のページの最初の柱「説明し合う時間を取る」が、直される前"
        "の docx の語の文字を順に含む。直すか 13 章に出す。", heads="説明し合う時間を取る"),
    art("b21_K_fig_top_rep", [("本文", PT), IMG, ("図キャプション", CAP), ("本文", QH), ("本文", RN)],
        [Raw(*bl(P_REP)[:-1]), BREAK, Raw(*FIGB, "説明し合う時間を取る"), Raw(CAP), Raw(bl(P_REP)[-1]), Raw(*bl(QH)),
         Raw(*bl(RN))], {4: P_REP}, None,
        "[直す] 次のページの最初に柱「説明し合う時間を取る授業」、図（最後の行「説明し合う時間を取る」）とキャプション、その後ろ"
        "に段落 4 の最後の行（直しあり。分断）。直すか 13 章に出す。", heads="説明し合う時間を取る授業"),
]

# ---------------------------------------------------------------------------- C: キャプション・表のキャプション
PC = "授業の後半では，各班の結果を黒板に並べて全体で比べた。そのときの記録をもとに，教師は各班の考えを整理した。各班の記録の例を図１に示す。"
PC_FIX = PC.replace("記録の例を", "記録の一例を")
CAPC = "図１　各班の記録の例"
CAPC_FIX = "図１　各班の記録の一例"
_check(bl(PC)[-1] == "を整理した。各班の記録の例を図１に示す。", "PC の最後の行")
_check(bl(PC)[:-1] == bl(PC_FIX)[:-1], "PC_FIX")

PS = "二つの学級の結果を表１に示す。どちらの学級でも正答の数は誤答の数よりも多かった。また，平均点は13点であった。"
PS_FIX = PS.replace("13点", "１３点")
TABCAP = "表１　架空の得点"
TAB = [["学級", "Ａ組", "Ｂ組"], ["平均", "13", "13"]]
TAB_LINES = ["学級　Ａ組　Ｂ組", "平均　13　13"]
_flat = "".join(bl(PS_FIX))
_k = _flat.index("１３点")
PS_LINES = wrap(_flat[:_k]) + [_flat[_k:]]
_check("".join(PS_LINES) == I + PS_FIX and PS_LINES[-1] == "１３点であった。", "PS_LINES")

CASES += [
    art("b21_C_caption_after_rep", [("本文", PC), IMG, ("図キャプション", CAPC), ("本文", QH)],
        [Raw(*bl(PC_FIX)), Raw(*FIGB), Raw(CAPC), Raw(*bl(QH))], {4: PC_FIX}, None,
        "[直す] 段落 4 の最後の行（「記録の例」→「記録の一例」）が、すぐ後ろの図のキャプション「図１　各班の記録の例」とよく"
        "似ている（キャプションは docx の段落で、直しなし）。段落 4 は直すか 13 章に出す。キャプションは docx のまま。",
        angle="edit"),
    art("b21_C_split_caption_fix", [("本文", PC), IMG, ("図キャプション", CAPC), ("本文", QH)],
        [Raw(*bl(PC)[:-1]), Raw(*FIGB), Raw(CAPC_FIX), Raw(bl(PC)[-1]), Raw(*bl(QH))], {6: CAPC_FIX}, None,
        "[直す] 段落 4 の最後の行（直しなし）がキャプションのすぐ後ろに出る（分断）。キャプションだけが校正で「一例」に直された。"
        "キャプションは直すか 13 章に出す。段落 4 は docx のまま（キャプションの文字を足さない）。"),
    art("b21_C_split_caption_none", [("本文", PC), IMG, ("図キャプション", CAPC), ("本文", QH)],
        [Raw(*bl(PC)[:-1]), Raw(CAPC), Raw(*FIGB), Raw(bl(PC)[-1]), Raw(*bl(QH))], None, None,
        "[取り違え] 直しなし。キャプション（図の上）・図の後ろに、キャプションとよく似た段落 4 の最後の行（分断）。どの段落も"
        "docx のまま。"),
    art("b21_C_tabcap_above_113", [("本文", PS), ("表キャプション", TABCAP), ("表", TAB), ("本文", QH)],
        [Raw(*PS_LINES[:-1]), Raw(TABCAP, *TAB_LINES), Raw(PS_LINES[-1]), Raw(*bl(QH))], {4: PS_FIX}, None,
        "[直す] 段落 4 の最後の行「１３点であった。」（docx は半角の「13点」）が、表のキャプション「表１　…」と表の行の後ろに"
        "出る（分断）。全角に直すか 13 章に出す。キャプションの「１」を足して「113点」「１１３点」にするのは FAIL。"),
    art("b21_C_tabcap_below_113", [("本文", PS), ("表", TAB), ("表キャプション", TABCAP), ("本文", QH)],
        [Raw(*PS_LINES[:-1]), Raw(*TAB_LINES, TABCAP), Raw(PS_LINES[-1]), Raw(*bl(QH))], {4: PS_FIX}, None,
        "[直す] b21_C_tabcap_above_113 の形で、表のキャプションが表の下（段落 4 の最後の行のすぐ前が「表１　架空の得点」）。"),
]

# ---------------------------------------------------------------------------- O: ほかの段落（読み順のずれ）
QO = "次の時間には，各自が予想を立ててから実験を行った。その結果について，各班の生徒が気づいたことを説明し合う時間をもった。"
_qo = bl(QO)
_check("説明し合う時間" in _qo[-1] and len(_qo[-1]) > 8, f"QO の最後の行 {_qo}")
R2 = "授業の記録は，二人の観察者が独立に整理した。整理の結果は，その後の協議で確かめた。"


def o_case(name, p_docx, p_pub, qo_pub, note):
    p, qo, r = bl(p_pub), bl(qo_pub), bl(R2)
    t = {}
    if p_pub != p_docx:
        t[4] = p_pub
    if qo_pub != QO:
        t[5] = qo_pub
    return art(name, [("本文", p_docx), ("本文", QO), ("本文", R2)],
               [Raw(*p[:-1]), Raw(*qo), Raw(p[-1]), Raw(*r)], t, None, note, angle="layout")


QO_FIX = QO.replace("時間をもった", "時間を設けた")
CASES += [
    o_case("b21_O_swap_none", PT, PT, QO,
           "[取り違え] 2 段組みの読み順のずれ: 段落 4 の最後の行が、段落 5 の後ろに出る。段落 5 の最後の行「…説明し合う時間をもった。」"
           "は段落 4 の最後の行とよく似ている。どの段落も docx のまま（ほかの段落の文字を足さない・消さない）。"),
    o_case("b21_O_swap_rep", PT, P_REP, QO,
           "[直す] b21_O_swap_none の形で、段落 4 の最後の行に校正の置き換え「取った」→「設けた」。段落 4 は直すか 13 章に出す。"
           "段落 5 の文字を足すのは FAIL。段落 5 は docx のまま。"),
    o_case("b21_O_swap_width", T_CONTENTS["width"][0], T_CONTENTS["width"][1], QO,
           "[直す] b21_O_swap_none の形で、段落 4 の最後の行の全角・半角の違い（「2回」→「２回」）。直すか 13 章に出す。"),
    o_case("b21_O_swap_other_fix", PT, PT, QO_FIX,
           "[直す] b21_O_swap_none の形で、段落 5 の最後の行だけが校正で「設けた」に直された（段落 4 の最後の行は直しなし）。"
           "段落 5 は直すか 13 章に出す。段落 4 は docx のまま（段落 5 の文字に合わせない）。"),
]

# ---------------------------------------------------------------------------- R: 投稿受付日の行
PR = "授業の後半では，各班の結果を黒板に並べて全体で比べた。教師は割合の変化に注目するよう促した。この調査は，2025年8月に行った。"
PR_FIX = PR.replace("8月", "８月")
_check(bl(PR_FIX)[-1].startswith("の調査は，2025年８月"), f"PR {bl(PR_FIX)}")
_pr = bl(PR_FIX)
CASES += [
    art("b21_R_split_width", [("本文", PR), ("本文", QH), ("本文", RN)],
        [Raw(*_pr[:-1]), Raw(RECV), Raw(_pr[-1]), Raw(*bl(QH)), Raw(*bl(RN))], {4: PR_FIX}, None,
        "[直す] 段落 4 の最後の行「…2025年８月に行った。」（docx は半角の「8月」）の前に、投稿受付日の行「2025年８月31日投稿受付，"
        "…」（左の段の最後）。直すか 13 章に出す。受付日の文字（「31日投稿受付」など）を足すのは FAIL。"),
    art("b21_R_after_width", [("本文", PR), ("本文", QH), ("本文", RN)],
        [Raw(*_pr), Raw(RECV), Raw(*bl(QH)), Raw(*bl(RN))], {4: PR_FIX}, None,
        "[直す] 段落 4 は分断されず、最後の行のすぐ後ろに投稿受付日の行（日付がよく似ている）。直すか 13 章に出す。"),
    art("b21_R_split_none", [("本文", PR_FIX), ("本文", QH), ("本文", RN)],
        [Raw(*_pr[:-1]), Raw(RECV), Raw(_pr[-1]), Raw(*bl(QH)), Raw(*bl(RN))], None, None,
        "[取り違え] 直しなし（docx も全角の「８月」）。段落 4 の最後の行の前に投稿受付日の行。段落 4 は docx のまま。"),
    art("b21_R_split_fig_width", [("本文", PR), IMG, ("図キャプション", CAP), ("本文", QH), ("本文", RN)],
        [Raw(*_pr[:-1]), Raw(RECV), Raw(*FIGB, "2025年8月の記録"), Raw(CAP), Raw(_pr[-1]), Raw(*bl(QH)), Raw(*bl(RN))],
        {4: PR_FIX}, None,
        "[直す] 段落 4 の最後の行の前に、投稿受付日の行、図（最後の行「2025年8月の記録」。半角）とキャプション（分断）。"
        "直すか 13 章に出す。図の中の文字・受付日の文字を足す・図に合わせて半角のままにして黙るのは FAIL。"),
]

# ---------------------------------------------------------------------------- X: 対照
P_FIRST = PT.replace("授業の後半では", "授業の終盤では")
P_MID = PT.replace("注目するよう促し", "注目するよう求め")
_check(bl(P_MID)[-1] == bl(PT)[-1], "P_MID")
CASES += [
    art("b21_X_nofig_last_rep", [("本文", PT), ("本文", QH), ("本文", RN)],
        [Raw(*bl(P_REP)), Raw(*bl(QH)), Raw(*bl(RN))], {4: P_REP}, {4: "exact"},
        "[対照] 図も分断もない。段落 4 の最後の行の校正の置き換え「取った」→「設けた」。直す。", angle="edit"),
    art("b21_X_nofig_head_ins", [("本文", PT), ("本文", QH), ("本文", RN)],
        [Raw(*bl(PT)), Raw(*bl(Q_INS)), Raw(*bl(RN))], {5: Q_INS}, {5: "exact"},
        "[対照] 図も分断もない。段落 5 の書き出しの校正の挿入「各」。直す。", angle="edit"),
    art("b21_X_pagesplit_last_rep", [("本文", PT), ("本文", QH), ("本文", RN)],
        [Raw(*bl(P_REP)[:-1]), BREAK, Raw(bl(P_REP)[-1]), Raw(*bl(QH)), Raw(*bl(RN))], {4: P_REP}, {4: "exact"},
        "[対照] 段落 4 の最後の行だけが次のページの最初（柱なし。図なし）に出る。その行の校正の置き換えを直す。"),
    art("b21_X_figsplit_first_rep", [("本文", PT), IMG, ("図キャプション", CAP), ("本文", QH), ("本文", RN)],
        [Raw(*bl(P_FIRST)[:-1]), Raw(*FIGB, "説明し合う時間を見る"), Raw(CAP), Raw(bl(P_FIRST)[-1]), Raw(*bl(QH)),
         Raw(*bl(RN))], {4: P_FIRST}, {4: "exact"},
        "[対照] 段落 4 の最後の行が図の後ろに出る（分断。最後の行は直しなし）が、校正の置き換え「後半」→「終盤」は分断から"
        "離れた最初の行（段落の本体）。直す（B2 で直るもの。13 章に回すと、守りが広すぎる）。"),
    art("b21_X_figsplit_mid_rep", [("本文", PT), IMG, ("図キャプション", CAP), ("本文", QH), ("本文", RN)],
        [Raw(*bl(P_MID)[:-1]), Raw(*FIGB, "説明し合う時間を見る"), Raw(CAP), Raw(bl(P_MID)[-1]), Raw(*bl(QH)),
         Raw(*bl(RN))], {4: P_MID}, {4: "exact"},
        "[対照] b21_X_figsplit_first_rep の形で、校正の置き換え「促し」→「求め」が段落の 2 行目（分断の前の、段落の本体）。直す。"),
]

# ---------------------------------------------------------------------------- E: 英字の大文字・小文字とダッシュ
PE = "授業の後半では，各班の結果を黒板に並べて全体で比べた。教師は割合の変化に注目するよう促し，生徒は気づいたことをExcelの表に記録した。"
PE_LOW = PE.replace("Excel", "excel")
PE2 = "授業の後半では，各班の結果を黒板に並べて全体で比べた。教師は割合の変化に注目するよう促し，生徒は2019–2021年の記録と比べた。"
PE2_FIX = PE2.replace("–", "-")
_check(bl(PE)[-1] == "は気づいたことをExcelの表に記録した。", "PE")


def e_case(name, d_text, tr, dec, note):
    p = bl(tr or d_text)
    return art(name, [("本文", d_text), IMG, ("図キャプション", CAP), ("本文", QH), ("本文", RN)],
               [Raw(*p[:-1]), Raw(*FIGB, dec), Raw(CAP), Raw(p[-1]), Raw(*bl(QH)), Raw(*bl(RN))],
               {4: tr} if tr else None, None, note, angle="edit")


CASES += [
    e_case("b21_E_case_fix", PE_LOW, PE, "EXCEL の表",
           "[直す] docx は小文字の「excel」、PDF の本当の行は「Excel」（校正の直し）。図の最後の行は「EXCEL の表」。PDF の"
           "本当の行に直すか 13 章に出す。図に合わせて「EXCEL」にするのは FAIL。"),
    e_case("b21_E_dash_fix", PE2, PE2_FIX, "2019～2021年の記録",
           "[直す] docx は en dash の「2019–2021年」、PDF の本当の行は「2019-2021年」（決定 20 の (b) で「-」に直す）。図の最後の"
           "行は波ダッシュの「2019～2021年の記録」。「-」に直すか 13 章に出す。「～」にする・ダッシュを消すのは FAIL。"),
]

# 名前の重なりを確かめる
_names = [c["name"] for c in CASES]
_check(len(_names) == len(set(_names)), "名前が重なっている")
