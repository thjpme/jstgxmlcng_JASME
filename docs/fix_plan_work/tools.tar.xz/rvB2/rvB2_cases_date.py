"""本文の中の日付（RE_RECEIVED に合う「…日受付分」「…日受理された」）が出版版で直されている（架空の文字）。"""
import sys
from pathlib import Path
HERE = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/rvB2")
sys.path.insert(0, str(HERE))
from rvB2_mk import build  # noqa

B1 = "架空の調査では，申込みは2020年８月30日受付分までを対象とし，回答は二回に分けて集めた。"
B2 = "架空の論文は2021年3月1日受理されたものであり，その内容を改めて検討した。"
D = HERE / "docx" / "date.docx"
if not D.exists():
    build(D, [("body", B1), ("body", B2)])
FRONT = ["全国数学教育学会誌　数学教育学研究　第31巻　第１号　2026　pp.1～2", "照合の窓の検証用文書", "―検証用の小さな論文―",
         "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
P1 = B1.replace("30日", "31日")
P2 = B2.replace("3月1日", "3月2日")
CASES = {"date_fix": (str(D), ["\n".join(["（1）", *FRONT, P1, P2, "引用および参考文献", REF, *EN])]),
         "date_same": (str(D), ["\n".join(["（1）", *FRONT, B1, B2, "引用および参考文献", REF, *EN])])}
