"""図の中の文字（docx では画像）が、段落の途中のページの端の行・ページの途中にある（架空の文字）。"""
import sys
sys.path.insert(0, "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/rvB2")
from rvB2_common import PUBLISHED as P, FRONT, EN
PUB12 = P["d12"]
CUT = PUB12.index("基づく")
REST = [P["d13"], P["d14"], P["d15"], "引用および参考文献", P["d17"], P["d18"], *EN]
CASES = {}
for name, fig in (("short1", ["図中Ａ"]), ("short3", ["図中Ａ", "図中Ｂ", "図中Ｃ"]), ("mixed", ["図中Ａ", "16", "図中Ｃ"])):
    # ページの最初の行から（端の行 2 行 + 途中）
    CASES[f"top_{name}"] = ("pdfcheck", ["\n".join(["（1）", *FRONT, PUB12[:CUT]]), "\n".join(["（2）", *fig, PUB12[CUT:], *REST])])
    # ページの途中
    CASES[f"mid_{name}"] = ("pdfcheck", ["\n".join(["（1）", *FRONT, PUB12[:CUT], *fig, PUB12[CUT:], *REST])])
