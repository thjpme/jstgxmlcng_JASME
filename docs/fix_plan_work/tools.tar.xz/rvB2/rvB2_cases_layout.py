"""別の形の PDF: 2 段組（左の段の最後で段落が切れ、右の段の最初に続く）、1 ページだけ、空のページを挟む（架空の文字）。"""
import sys
sys.path.insert(0, "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/rvB2")
from rvB2_common import PUBLISHED as P, FRONT, EN
PUB12 = P["d12"]
CUT = PUB12.index("基づく")
R1 = "2025年８月31日投稿受付，2025年11月24日採用決定"
REST = [P["d13"], P["d14"], P["d15"], "引用および参考文献", P["d17"], P["d18"]]
CASES = {
    # 2 段組: 左の段の最後に受付日、右の段の最初から段落の続き（ページの途中なので端の行ではない）
    "twocol_date": ("pdfcheck", ["\n".join(["（1）", *FRONT, PUB12[:CUT], R1, PUB12[CUT:], *REST, *EN])]),
    # 2 段組: 柱（著者名）がページの最初、段落はページをまたぐ
    "twocol_head": ("pdfcheck", ["\n".join(["（1）", *FRONT, PUB12[:CUT]]), "\n".join(["（2）", "試験四郎", PUB12[CUT:], *REST, *EN])]),
    # 1 ページだけ（ページ番号なし、最後の行が英文要旨）
    "onepage_nopn": ("pdfcheck", ["\n".join([*FRONT, PUB12, *REST, *EN])]),
    # 空のページを挟む
    "blank_between": ("pdfcheck", ["\n".join(["（1）", *FRONT, PUB12[:CUT]]), "", "\n".join(["（3）", PUB12[CUT:], *REST, *EN])]),
}
