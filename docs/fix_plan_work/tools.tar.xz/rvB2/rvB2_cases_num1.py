"""段落の中の数（docx「12点」→ PDF「13点」）が、出版版で直され、その直前に整数のセルの表がある（架空の文字）。"""
D = "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/rvB2/docx/num1.docx"
B1 = "架空の調査の結果を表１に示す。その結果，生徒の平均は12点であり，前回の調査より高かった。"
B2 = "次の段落は表の後ろに続く本文の段落であり，照合の確かめに使う。"
FRONT = ["全国数学教育学会誌　数学教育学研究　第31巻　第１号　2026　pp.1～2", "照合の窓の検証用文書", "―検証用の小さな論文―",
         "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
CASES = {}
cut = B1.index("12点")
for pub in ("12点", "13点", "１３点"):
    p1 = B1.replace("12点", pub)
    for n in (4, 8, 12):
        cells = ["31", "27", "14", "23", "35", "16", "9", "21", "13", "18", "25", "30"][:n]
        page1 = ["（1）", *FRONT, p1[:cut], "表１　架空の得点", *cells, p1[cut:], B2, "引用および参考文献", REF, *EN]
        CASES[f"pub{pub}_cells{n}"] = (D, ["\n".join(page1)])
        # 表がページの最後、段落の続きが次のページ
        page1 = ["（1）", *FRONT, p1[:cut], "表１　架空の得点", *cells]
        page2 = ["（2）", p1[cut:], B2, "引用および参考文献", REF, *EN]
        CASES[f"pb_pub{pub}_cells{n}"] = (D, ["\n".join(page1), "\n".join(page2)])
