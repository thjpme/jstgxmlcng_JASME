"""段落の中の数（docx「12点」→ PDF「13点」）が出版版で直され、PDF ではその直前に整数のセルの表（docx では段落の後ろの
Word の表）がある（架空の文字）。"""
import sys
from pathlib import Path
HERE = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/rvB2")
sys.path.insert(0, str(HERE))
from rvB2_mk import build  # noqa

B1 = "架空の調査の結果を表１に示す。その結果，生徒の平均は12点であり，前回の調査より高かった。"
B2 = "次の段落は表の後ろに続く本文の段落であり，照合の確かめに使う。"
CAP = "表１　架空の得点"
ROWS = [["組", "男子", "女子"], ["1組", "31", "27"], ["2組", "14", "23"], ["3組", "35", "16"], ["4組", "9", "21"]]
D = HERE / "docx" / "num2.docx"
if not D.exists():
    build(D, [("body", B1), ("tab_cap", CAP), ("table", ROWS), ("body", B2)])
FRONT = ["全国数学教育学会誌　数学教育学研究　第31巻　第１号　2026　pp.1～2", "照合の窓の検証用文書", "―検証用の小さな論文―",
         "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
CASES = {}
cut = B1.index("12点")
cells = [c for row in ROWS for c in row]
for pub in ("12点", "13点", "１３点", "12名"):
    p1 = B1.replace("12点", pub)
    page1 = ["（1）", *FRONT, p1[:cut], CAP, *cells, p1[cut:], B2, "引用および参考文献", REF, *EN]
    CASES[f"mid_{pub}"] = (str(D), ["\n".join(page1)])
    page1 = ["（1）", *FRONT, p1[:cut], CAP, *cells]
    page2 = ["（2）", p1[cut:], B2, "引用および参考文献", REF, *EN]
    CASES[f"pb_{pub}"] = (str(D), ["\n".join(page1), "\n".join(page2)])
    # 表がない（比べるため）
    page1 = ["（1）", *FRONT, p1, CAP, *cells, B2, "引用および参考文献", REF, *EN]
    CASES[f"after_{pub}"] = (str(D), ["\n".join(page1)])
