"""段落の中の数が出版版で直され（docx「平均は12点」→ PDF「平均は13点」など）、PDF ではその直前に表がある。表の見出し・組の
セルは 4 文字以上（docx の表のセルとして照合に使われる）、得点のセルは整数（架空の文字）。"""
import sys
from pathlib import Path
HERE = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/rvB2")
sys.path.insert(0, str(HERE))
from rvB2_mk import build  # noqa

B1 = "架空の調査の結果を表１に示す。その結果，生徒の平均は12点であり，前回の調査より高かった。"
B2 = "次の段落は表の後ろに続く本文の段落であり，照合の確かめに使う。"
CAP = "表１　架空の組ごとの得点"
ROWS = [["組の名前", "一回目の得点", "二回目の得点"], ["第一の組", "31", "27"], ["第二の組", "14", "23"], ["第三の組", "35", "16"],
        ["第四の組", "19", "21"]]
D = HERE / "docx" / "num3.docx"
if not D.exists():
    build(D, [("body", B1), ("tab_cap", CAP), ("table", ROWS), ("body", B2)])
FRONT = ["全国数学教育学会誌　数学教育学研究　第31巻　第１号　2026　pp.1～2", "照合の窓の検証用文書", "―検証用の小さな論文―",
         "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
cells = [c for row in ROWS for c in row]
CASES = {}
for name, old, new in (("same", "12点", "12点"), ("13", "12点", "13点"), ("fw13", "12点", "１３点"), ("ten", "は12点", "は12.5点"),
                       ("unit", "12点", "12名"), ("noun", "生徒の平均は12点", "生徒の得点の平均は12点")):
    p1 = B1.replace(old, new)
    cut = p1.index("点であり") - 2 if name != "unit" else p1.index("名であり") - 2
    page1 = ["（1）", *FRONT, p1[:cut], CAP, *cells, p1[cut:], B2, "引用および参考文献", REF, *EN]
    CASES[f"mid_{name}"] = (str(D), ["\n".join(page1)])
    page1 = ["（1）", *FRONT, p1[:cut], CAP, *cells]
    page2 = ["（2）", p1[cut:], B2, "引用および参考文献", REF, *EN]
    CASES[f"pb_{name}"] = (str(D), ["\n".join(page1), "\n".join(page2)])
