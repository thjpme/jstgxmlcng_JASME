"""ページ番号がページの最後の行にある PDF（本誌とは別の形）で、ページの最初の行が引用文献の「pp.11-」の続きの「16」
（架空の文字）。"""
import sys
from pathlib import Path
HERE = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/rvB2")
sys.path.insert(0, str(HERE))
from rvB2_mk import build  # noqa

BODY = "本文の段落の途中に，表の数字だけの行が入る場合を確かめる。"
REF16 = "架空太郎（2019）．「架空の題目」．『架空学会誌』，第29号，pp.11-16"
D = HERE / "docx" / "pbottom.docx"
if not D.exists():
    build(D, [("body", BODY)], refs=[REF16], title="ページ番号の判定の検証用文書")
FRONT = ["ページ番号の判定の検証用文書", "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
CASES = {}
for fmt in ("{}", "－ {} －", "（{}）"):
    p1 = [*FRONT, BODY, "引用および参考文献", REF, REF16[:-2], fmt.format(1)]
    p2 = [REF16[-2:], *EN, fmt.format(2)]
    CASES[f"bottom_{fmt}"] = (str(D), ["\n".join(p1), "\n".join(p2)])
    # 比べるため: 本誌と同じく最初の行
    p1 = [fmt.format(1), *FRONT, BODY, "引用および参考文献", REF, REF16[:-2]]
    p2 = [fmt.format(2), REF16[-2:], *EN]
    CASES[f"top_{fmt}"] = (str(D), ["\n".join(p1), "\n".join(p2)])
