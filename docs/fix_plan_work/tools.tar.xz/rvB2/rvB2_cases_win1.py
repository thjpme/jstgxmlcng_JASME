"""照合の窓: 本文の段落（数字なし・リンクなし）が、ページの途中の整数だけのセルの表で分断される（架空の文字）。"""
D = "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/rvB2/docx/win1.docx"
B1 = "本研究では，架空の授業における生徒の発言を記録し，その特徴を三つの観点から整理したうえで，考察を加えることにする。"
B2 = "次の段落は表の後ろに続く本文の段落であり，照合の確かめに使う。"
FRONT = ["全国数学教育学会誌　数学教育学研究　第31巻　第１号　2026　pp.1～2", "照合の窓の検証用文書", "―検証用の小さな論文―",
         "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]


def lines(s, w=24):
    return [s[i:i + w] for i in range(0, len(s), w)]


CASES = {}
for k in (4, 6, 8):
    for n in (40, 60, 80, 100, 120, 150):
        cells = [str(10 + (i * 7) % 89) for i in range(n)]
        page1 = ["（1）", *FRONT, *lines(B1[:-k]), *cells, B1[-k:], *lines(B2), "引用および参考文献", REF, *EN]
        CASES[f"tail{k}_cells{n}"] = (D, ["\n".join(page1)])
        # 表がページの最後にあり、段落の後ろは次のページの最初の行（本誌でよくある形）
        page1 = ["（1）", *FRONT, *lines(B1[:-k]), *cells]
        page2 = ["（2）", B1[-k:], *lines(B2), "引用および参考文献", REF, *EN]
        CASES[f"pb_tail{k}_cells{n}"] = (D, ["\n".join(page1), "\n".join(page2)])
