"""照合の窓: 本文の段落（3 行・5 行）の最後の行の前に、見出しの行・組の列と整数のセルの表がある（docx では段落の後ろの
Word の表。架空の文字）。表の大きさを変えて、段落の後ろが消えるかを見る。"""
import sys
from pathlib import Path
HERE = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/rvB2")
sys.path.insert(0, str(HERE))
from rvB2_mk import build  # noqa

BODIES = {
    "n72": "本研究では，架空の授業における生徒の発言を記録し，その特徴を観点ごとに整理したうえで，考察を加えることにする。授業は全部で五回",
    "n120": ("本研究では，架空の授業における生徒の発言を記録し，その特徴を観点ごとに整理したうえで，考察を加えることにする。"
             "授業は全部で五回行い，毎回の授業の後に，生徒の記述と教師の振り返りを集めた。集めた記述は，二人で読み合わせて分類した。"),
}
B2 = "次の段落は表の後ろに続く本文の段落であり，照合の確かめに使う。"
CAP = "表１　架空の組ごとの得点"
FRONT = ["全国数学教育学会誌　数学教育学研究　第31巻　第１号　2026　pp.1～2", "照合の窓の検証用文書", "―検証用の小さな論文―",
         "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]


def lines(s, w=24):
    return [s[i:i + w] for i in range(0, len(s), w)]


CASES = {}
for bn, B1 in BODIES.items():
    for rows in (4, 6, 8, 10, 12):
        for cols in (4, 6):
            head = ["組"] + [f"問{c}" for c in range(1, cols)]
            grid = [head] + [[f"{r}組"] + [str(10 + (r * 7 + c * 13) % 89) for c in range(1, cols)] for r in range(1, rows + 1)]
            D = HERE / "docx" / f"win2_{bn}_{rows}x{cols}.docx"
            if not D.exists():
                build(D, [("body", B1), ("tab_cap", CAP), ("table", grid), ("body", B2)])
            cells = [c for row in grid for c in row]
            ls = lines(B1)
            page1 = ["（1）", *FRONT, *ls[:-1], CAP, *cells]
            page2 = ["（2）", ls[-1], *lines(B2), "引用および参考文献", REF, *EN]
            CASES[f"{bn}_{rows}x{cols}"] = (str(D), ["\n".join(page1), "\n".join(page2)])
