"""照合の窓（最小の表）: 本文の段落の最後の短い行（4 文字）の前に、整数のセルの表がある（架空の文字）。"""
import sys
from pathlib import Path
HERE = Path("/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/rvB2")
sys.path.insert(0, str(HERE))
from rvB2_mk import build  # noqa

LS = ["本研究では，架空の授業における生徒の発言を記", "録し，その特徴を観点ごとに整理したうえで，考", "察を加えることにする。授業は全部で五回行い，",
      "行った。"]
B1 = "".join(LS)
B2 = "次の段落は表の後ろに続く本文の段落であり，照合の確かめに使う。"
CAP = "表１　架空の組ごとの得点"
FRONT = ["全国数学教育学会誌　数学教育学研究　第31巻　第１号　2026　pp.1～2", "照合の窓の検証用文書", "―検証用の小さな論文―",
         "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
CASES = {}
for rows, cols in ((2, 4), (3, 4), (4, 4), (2, 6), (3, 6), (4, 6), (5, 6)):
    head = ["組"] + [f"問{c}" for c in range(1, cols)]
    grid = [head] + [[f"{r}組"] + [str(10 + (r * 7 + c * 13) % 89) for c in range(1, cols)] for r in range(1, rows + 1)]
    D = HERE / "docx" / f"win4_{rows}x{cols}.docx"
    if not D.exists():
        build(D, [("body", B1), ("tab_cap", CAP), ("table", grid), ("body", B2)])
    cells = [c for row in grid for c in row]
    page1 = ["（1）", *FRONT, *LS[:-1], CAP, *cells]
    page2 = ["（2）", LS[-1], B2, "引用および参考文献", REF, *EN]
    CASES[f"pb_{rows}x{cols}"] = (str(D), ["\n".join(page1), "\n".join(page2)])
    page1 = ["（1）", *FRONT, *LS[:-1], CAP, *cells, LS[-1], B2, "引用および参考文献", REF, *EN]
    CASES[f"mid_{rows}x{cols}"] = (str(D), ["\n".join(page1)])
