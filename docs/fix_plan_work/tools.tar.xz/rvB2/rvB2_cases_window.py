"""N9 で残すことにしたページの途中の数字だけの行（表のセル）が段落を分断すると、照合の窓（_window）の外に段落の後ろが出て、
ルート2 で docx の文字を消すようになるか（0.19.0 では数字だけの行を除いていたので、分断されない）。"""
import sys
sys.path.insert(0, "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/rvB2")
from rvB2_common import PUBLISHED as P, FRONT, EN

CASES = {}
for src in ("d12", "d13"):
    t = P[src]
    for k in (3, 4, 6, 8):
        for n in (20, 40, 60, 80, 100, 120):
            cells = [str(10 + (i * 7) % 89) for i in range(n)]     # 2 桁の整数のセル（表の数字）
            body = []
            for s in ("d12", "d13", "d14", "d15"):
                if s == src:
                    body += [t[:-k], *cells, t[-k:]]
                else:
                    body.append(P[s])
            page1 = ["（1）", *FRONT, *body, "引用および参考文献", P["d17"], P["d18"], *EN]
            CASES[f"{src}_tail{k}_cells{n}"] = ("pdfcheck", ["\n".join(page1)])
