"""rvB2 の実験の共通部分（架空の文字。tests/test_pdfmatch.py の PUBLISHED と同じもの）。"""
PUBLISHED = {
    "d12": "本研究は架空理論（Fictional Theory, 以下，FT）に基づく（試験，2020；見本，2021）。",
    "d13": "詳しくは付録の学習指導案を参照されたい。授業は２回行った。",
    "d14": "（1）方法の概要",
    "d15": "この段落は出版版と同じで，架空の資料を https://example.com/a で公開している。",
    "d17": "試験四郎（2020）．「架空の研究」．『架空誌』，第1巻，pp.1-10．",
    "d18": "見本花子（2021）．「見本の研究」．『見本誌』，第2巻，pp.11-20．",
}
FRONT = ["全国数学教育学会誌　数学教育学研究　第31巻　第１号　2026　pp.1～2", "出版版 PDF との照合の検証用文書",
         "―全角と半角の違い―", "架空大学　試験　四郎", "１．はじめに"]
EN = ["Checking against the published PDF", "Width of characters", "Shiro SHIKEN", "Fictional University", "Abstract",
      "This abstract is the same in the published version."]


def body_lines():
    P = PUBLISHED
    return [P["d12"], P["d13"], P["d14"], P["d15"], "引用および参考文献", P["d17"], P["d18"]]
