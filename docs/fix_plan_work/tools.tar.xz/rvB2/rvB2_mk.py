"""rvB2: 実験用の小さな論文の docx（架空の文字。scratchpad にだけ置く）。

  from rvB2_mk import build
  build(path, [("body", "段落"), ("tab_cap", "表１　…"), ("table", [["a", "b"], ["1", "2"]]), ...], refs=[...])
"""
import sys
sys.path.insert(0, "/home/user/jstgxmlcng_JASME/src")
sys.path.insert(1, "/home/user/jstgxmlcng_JASME/tests")
import make_fixtures as mf  # noqa


def build(path, parts, refs=(), title="照合の窓の検証用文書"):
    def body(b):
        out = [mf.para(mf.S["sec1"], "１．はじめに")]
        for kind, x in parts:
            if kind == "table":
                out.append(mf.table([[mf.cell(c) for c in row] for row in x]))
            else:
                out.append(mf.para(mf.S[kind], x))
        return out
    mf.make_article(path, title, body, refs=(lambda b: [mf.para(mf.S["ref"], r) for r in refs]) if refs else None)
