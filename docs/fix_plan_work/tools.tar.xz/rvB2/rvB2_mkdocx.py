"""rvB2: 実験用の小さな論文の docx を作る（make_fixtures.make_article。架空の文字。scratchpad にだけ置く）。

  python -I rvB2_mkdocx.py OUT.docx '本文の段落1' ['本文の段落2' ...] [--ref '引用文献の段落' ...]
"""
import sys
sys.path.insert(0, "/home/user/jstgxmlcng_JASME/src")
sys.path.insert(1, "/home/user/jstgxmlcng_JASME/tests")
import make_fixtures as mf  # noqa

args = sys.argv[2:]
body, refs = [], []
cur = body
for x in args:
    if x == "--ref":
        cur = refs
        continue
    cur.append(x)
mf.make_article(sys.argv[1], "照合の窓の検証用文書",
                lambda b: [mf.para(mf.S["sec1"], "１．はじめに")] + [mf.para(mf.S["body"], t) for t in body],
                refs=(lambda b: [mf.para(mf.S["ref"], r) for r in refs]) if refs else None)
print("wrote", sys.argv[1])
