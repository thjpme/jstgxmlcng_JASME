"""単位 B の点検（rvB2）: 1 つのコード（--src）で、架空の文字のケースを照合し、結果を JSON で出す。

  python -I rvB2_run.py --src SRC_DIR --cases rvB2_cases.py [--only NAME ...]
ケースのファイルは CASES = {名前: (docx の作り方, pages)} を定義する。docx の作り方は "pdfcheck" か、docx のパス。
"""
import argparse, json, sys, importlib.util
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("--src", required=True)
ap.add_argument("--cases", required=True)
ap.add_argument("--only", nargs="*")
a = ap.parse_args()
sys.path.insert(0, a.src)
sys.path.insert(1, "/home/user/jstgxmlcng_JASME/tests")
from jasme_jats.config import JournalConfig  # noqa
from jasme_jats.pipeline import _mechanical  # noqa
from jasme_jats import pdfmatch  # noqa
from jasme_jats.pdfdocx import plan_fixes  # noqa
from conftest import PDFCHECK  # noqa

spec = importlib.util.spec_from_file_location("cases", a.cases)
mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
j = JournalConfig.load()
plans = {}
out = {}
for name, (docx, pages) in mod.CASES.items():
    if a.only and name not in a.only:
        continue
    path = PDFCHECK if docx == "pdfcheck" else Path(docx)
    if str(path) not in plans:
        plans[str(path)] = _mechanical(path, j)[1]
    plan = plans[str(path)]
    pc = pdfmatch.compare(plan, pages)
    fixes = plan_fixes(plan, pc)
    out[name] = {
        "unmatched": pc.unmatched,
        "diffs": [(d.src, d.docx, d.pdf, d.fixable, getattr(d, "why", "")[:10]) for d in pc.diffs],
        "fixes": [(f.src, f.kind, f.old, f.new, f.reason[:12]) for f in fixes if f.kind == "text"],
        "ignored": getattr(pc, "ignored_lines", None),
    }
print(json.dumps(out, ensure_ascii=False))
