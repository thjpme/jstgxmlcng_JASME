"""反例集（rvB2_principle: 単位 B の 2 回目の点検の、原則と文字の不変性の観点）。文字はすべて架空。

oracle/run_all.py の書式（runner.py の docstring）。実行:
  python oracle/run_all.py <src> rvB2_principle_cases.py --name <名前>
期待は原則だけで決める（出版版 PDF の本文と同じにする。組版の文字・図や表の中の文字を足さない。本文の文字を消さない）。

- rvB2p_cont_*: 前の行が「，」などで終わる数字だけの行（PdfStream で「続きの行」とみなされ、行全体でしか一致させない行
  〈line_only〉にならない）が、表のセルや図の目盛りのとき。docx の数字が出版版で直された位置の直前にあると、セルの数字が
  docx の数字と 1 文字だけ偶然一致して、その行が「段落に当たる行」になり、セルの残りの数字が docx に足される。
  0.19.0 は数字だけの行をすべて列から除いていたので起きない。
- rvB2p_len20_*: PDF にだけある 20 文字以上の文字を足さない規則が、列に残した line_only の行（0.19.0 では列になかった表の
  数字の行・柱）の文字も数えるので、そのすぐ後ろの、校正で足された短い文字（「全部で」）を足さない。13 章にも出ない
  （照合に使わなかった文字の一覧には表の数字・柱しか載らない）。0.19.0 は足す。
- rvB2p_split_*: 行全体でしか一致させない行（図の目盛りの数字・柱）が文献 A の 2 行の間に入り、すぐ後に A と書名の始まりが
  同じ文献 B（2018a・2018b の形）がある。line_only の文字（None）が A の一致の塊を 2 つに分けるので、A の docx の文字が、
  より長く続けて一致する B の文字と並べられ、ルート2 で A の文字を消す。0.19.0 は列から除いていたので塊が分かれない。
- rvB2p_bound_*: 境界（1 ページだけの PDF・ページ番号のない PDF・8 文字未満の柱の次の「16」）。0.19.0 も FAIL（悪くなっていない）。

結果（2026-10-18。作業ツリーの 0.20.0 / 0.19.0）: cont_comma_table・cont_comma_cell1・cont_pagetop_figure・len20_digits・
len20_head・split_similar_refs_head・split_similar_refs_figure は 0.20.0 だけ FAIL（0.19.0 は OK）。cont_dash_cell は両方 FAIL
（足す文字が違う。0.20.0 は表の「2」、0.19.0 は「－」）。bound_* は両方 FAIL（「16」を消す）。
scratchpad の rvB2p/ に、直し方の試作（patchA2BC: 続きの行を「数字＋ハイフン・波線」の後に限る、20 文字の規則で line_only の
文字を数えない、_align を line_only を除いた文字の上で照合する）があり、bound_* 以外はすべて OK、テストは 260 件通る。
"""
from runner import Raw, flow, wrap  # noqa: F401
from cases_artifact import (BASE, C, CTRL_DOCX, CTRL_PUB, D, H1, H2, LC, LCTRL, LD, RH, REF1, REF1_LINES, REF1_SPLIT,
                            REF2, REF2_LINES, english_lines, front_lines, pg)

# ---------------------------------------------------------------------------- 続きの行とみなされる数字だけの行
X_DOCX = "本研究では，架空の中学校の二つの学級で行った調査の結果を整理した。その結果，12点の生徒が最も多く，前回の調査より増えた。"
X_PUB = X_DOCX.replace("12点", "13点")
X_LINES_A = ["　本研究では，架空の中学校の二つの学級で行った", "調査の結果を整理した。その結果，"]   # 2 行目は「，」で終わる
X_LINES_B = ["13点の生徒が最も多く，前回の調査より増えた。"]
assert "".join(X_LINES_A + X_LINES_B).lstrip("　") == X_PUB

Z_DOCX = "架空の調査の結果を図１に示す。回答の数は，12件から13件に増えた。この変化について次の節で詳しく述べる。"
Z_PUB = Z_DOCX.replace("12件から13件", "12件から14件")
Z_LINES_A = ["　架空の調査の結果を図１に示す。回答の数は，"]          # ページの最後の行（「，」で終わる）
Z_LINES_B = ["12件から14件に増えた。この変化について次の節で", "詳しく述べる。"]
assert "".join(Z_LINES_A + Z_LINES_B).lstrip("　") == Z_PUB

# ---------------------------------------------------------------------------- 20 文字の規則
W_DOCX = "本稿は架空の授業を対象とする。授業は五回行い，記録の方法は次の節で述べる。分析の結果は第３節で述べる。"
W_PUB = W_DOCX.replace("授業は五回", "授業は全部で五回")
W_LINES_A = ["　本稿は架空の授業を対象とする。授業は"]
W_LINES_B = ["全部で五回行い，記録の方法は次の節で述べる。分", "析の結果は第３節で述べる。"]
assert "".join(W_LINES_A + W_LINES_B).lstrip("　") == W_PUB
CELLS10 = [str(10 + (k * 7) % 89) for k in range(10)]         # 表の整数のセル（20 文字）
HEAD = "架空の比例の授業における生徒の発話の分析"                  # 柱（20 文字。2〜4 ページの最初）


def with_x(x_docx):
    return [("見出し", H1), ("本文", x_docx), ("本文", CTRL_DOCX), ("見出し", H2), ("本文", C), ("本文", D),
            ("引用文献見出し", RH), ("引用文献", REF1), ("引用文献", REF2)]


CASES = [
    {
        "name": "rvB2p_cont_comma_table",
        "angle": "artifact",
        "item": "new",
        "paras": with_x(X_DOCX),
        "truth": {1: X_PUB, 2: CTRL_PUB},
        "pages": [pg(front_lines() + [H1] + X_LINES_A + ["31", "27", "14"] + X_LINES_B + LCTRL + [H2] + LC[:3], top="（25）"),
                  pg(LC[3:] + LD + [RH] + REF1_LINES + REF2_LINES, top="（26）")],
        "expect": "exact",
        "note": "段落 1 の PDF の行が「…その結果，」で終わり、次の行から表の整数のセル「31」「27」「14」、その後に段落 1 の続き"
                "「13点の…」（docx は「12点」）。「31」は前の行が「，」で終わるので続きの行とみなされ、行全体でしか一致させない行に"
                "ならない。docx の「1」が「31」の「1」と一致して、「3」が docx に足される（0.19.0 は数字だけの行を除くので「2」→"
                "「3」だけを直す）。段落 1 は X_PUB になるはず。",
    },
    {
        "name": "rvB2p_cont_comma_cell1",
        "angle": "artifact",
        "item": "new",
        "paras": with_x(X_DOCX),
        "truth": {1: X_PUB, 2: CTRL_PUB},
        "pages": [pg(front_lines() + [H1] + X_LINES_A + ["21"] + X_LINES_B + LCTRL + [H2] + LC[:3], top="（25）"),
                  pg(LC[3:] + LD + [RH] + REF1_LINES + REF2_LINES, top="（26）")],
        "expect": "exact",
        "note": "rvB2p_cont_comma_table と同じ形で、表のセルが「21」の 1 つだけ。",
    },
    {
        "name": "rvB2p_cont_pagetop_figure",
        "angle": "artifact",
        "item": "new",
        "paras": with_x(Z_DOCX),
        "truth": {1: Z_PUB, 2: CTRL_PUB},
        "pages": [pg(front_lines() + [H1] + Z_LINES_A, top="（25）"),
                  pg(["10", "20", "30", "40"] + Z_LINES_B + LCTRL + [H2] + LC + LD + [RH] + REF1_LINES + REF2_LINES,
                     top="（26）")],
        "expect": "exact",
        "note": "1 ページ目の最後の行が段落 1 の「…回答の数は，」（「，」で終わる）。2 ページ目の最初（ページ番号の次）に図の"
                "目盛りの数字「10」「20」「30」「40」があり、その後に段落 1 の続き「12件から14件に…」（docx は「13件」）。「10」は"
                "続きの行とみなされ、docx の「1」と一致して、「0」が docx に足される（0.19.0 は「3」→「4」だけを直す）。",
    },
    {
        "name": "rvB2p_len20_digits",
        "angle": "artifact",
        "item": "new",
        "paras": with_x(W_DOCX),
        "truth": {1: W_PUB, 2: CTRL_PUB},
        "pages": [pg(front_lines() + [H1] + W_LINES_A + CELLS10 + W_LINES_B + LCTRL + [H2] + LC[:3], top="（25）"),
                  pg(LC[3:] + LD + [RH] + REF1_LINES + REF2_LINES, top="（26）")],
        "expect": "exact",
        "note": "段落 1 は出版版で「授業は」の後に「全部で」が足された。PDF では「授業は」の行の後に表の整数のセル 10 個"
                "（20 文字。ページの途中の数字だけの行）があり、その後に「全部で五回…」。0.19.0 は数字だけの行を列から除くので"
                "「全部で」を足す。表のセルの文字も 20 文字の規則に数えると、「全部で」を足さず、13 章にも出ない。",
    },
    {
        "name": "rvB2p_len20_head",
        "angle": "artifact",
        "item": "new",
        "paras": with_x(W_DOCX),
        "truth": {1: W_PUB, 2: CTRL_PUB},
        "pages": [pg(front_lines() + [H1] + W_LINES_A, top="（25）"),
                  pg(W_LINES_B + LCTRL + [H2] + LC[:3], top="（26）", heads=(HEAD,)),
                  pg(LC[3:] + LD, top="（27）", heads=(HEAD,)),
                  pg([RH] + REF1_LINES + REF2_LINES, top="（28）", heads=(HEAD,))],
        "expect": "exact",
        "note": "段落 1 は出版版で「授業は」の後に「全部で」が足された。PDF では 1 ページ目が「授業は」で終わり、2 ページ目の"
                "最初（ページ番号の次）に柱（2〜4 ページの最初に出る 20 文字の行）、その後に「全部で五回…」。0.19.0 は柱を"
                "列から除くので「全部で」を足す。柱の文字も 20 文字の規則に数えると、「全部で」を足さず、13 章にも出ない。",
    },
    {
        "name": "rvB2p_bound_one_page_no_pageno",
        "angle": "layout",
        "item": "new",
        "paras": BASE,
        "truth": {2: CTRL_PUB},
        "pages": [pg(front_lines() + [H1] + ["　" + x for x in []] + wrap("　" + BASE[1][1]) + LCTRL + [H2] + LC + LD + [RH]
                     + REF2_LINES + REF1_SPLIT)],
        "expect": "exact",
        "note": "1 ページだけの PDF で、ページ番号がない。ページの最後の行が引用文献の「pp.11-」の後の「16」。番号が続く候補が"
                "どのページにもないので、最後の行の「16」をページ番号とみなして除き、ルート2 で docx の「16」を消す"
                "（0.19.0 も数字だけの行をすべて除くので消す）。",
    },
    {
        "name": "rvB2p_bound_two_pages_no_pageno",
        "angle": "layout",
        "item": "new",
        "paras": BASE,
        "truth": {2: CTRL_PUB},
        "pages": [pg(front_lines() + [H1] + wrap("　" + BASE[1][1]) + LCTRL + [H2] + LC + LD + [RH] + REF2_LINES
                     + REF1_SPLIT),
                  pg(english_lines())],
        "expect": "exact",
        "note": "2 ページの PDF で、ページ番号がない。1 ページ目の最後の行が引用文献の「16」。2 ページ目には数字だけの行がない。"
                "番号が続く候補がないので、「16」をページ番号とみなして除き、docx の「16」を消す（0.19.0 も消す）。",
    },
]

# ---------------------------------------------------------------------------- 表のセル「－」（該当なし）の次の数字のセル
V_DOCX = "架空の授業の記録を表１にまとめた。授業は11回行い，生徒の発言の数は回を追うごとに増えた。"
V_PUB = V_DOCX.replace("11回", "12回")
V_LINES_A = ["　架空の授業の記録を表１にまとめた。授業は"]
V_LINES_B = ["12回行い，生徒の発言の数は回を追うごとに増えた。"]
assert "".join(V_LINES_A + V_LINES_B).lstrip("　") == V_PUB

CASES += [
    {
        "name": "rvB2p_cont_dash_cell",
        "angle": "artifact",
        "item": "new",
        "paras": with_x(V_DOCX),
        "truth": {1: V_PUB, 2: CTRL_PUB},
        "pages": [pg(front_lines() + [H1] + V_LINES_A + ["－", "21"] + V_LINES_B + LCTRL + [H2] + LC[:3], top="（25）"),
                  pg(LC[3:] + LD + [RH] + REF1_LINES + REF2_LINES, top="（26）")],
        "expect": "exact",
        "note": "段落 1 の行「…授業は」の後に表のセル「－」（該当なし）と「21」、その後に段落 1 の続き「12回行い…」（docx は「11回」）。"
                "「21」は前の行が「－」で終わるので続きの行とみなされ、docx の「11」が「21」の「1」と「12」の「1」に当たって、"
                "表の「2」が docx に足される。0.19.0 は「－」の行を足す（どちらも FAIL。足す文字が違う）。",
    },
]

# ---------------------------------------------------------------------------- 行全体でしか一致させない行が文献を分け、よく似た文献が続く
P_COMMON = "架空省（2017）．『架空学校学習指導要領解説　架空数学編』．架空出版，"
RA = P_COMMON + "pp.9-10．"          # 文献 A（ページの区切りで 2 行に分かれる）
RB = P_COMMON + "p.9"                # 文献 B（A とよく似た文献。同じ著者・同じ書名の始まり）
RA_LINES = [RA[:24], RA[24:]]
RB_LINES = [RB[:24], RB[24:]]
SPLIT_HEAD = "架空の比例の授業における生徒の発話の分析"     # 柱（2〜4 ページの最初）


def similar_refs_pages(between):
    """文献 A の 1 行目で 1 ページ目が終わり、2 ページ目の最初（ページ番号の次）に between の行、その後に A の 2 行目と B。"""
    paras_pages = [pg(front_lines() + [H1] + wrap("　" + BASE[1][1]) + LCTRL + [H2] + LC + LD + [RH] + RA_LINES[:1],
                      top="（25）"),
                   pg(list(between) + RA_LINES[1:] + RB_LINES + english_lines()[:2], top="（26）")]
    return paras_pages


CASES += [
    {
        "name": "rvB2p_split_similar_refs_head",
        "angle": "layout",
        "item": "new",
        "paras": BASE[:6] + [("引用文献見出し", RH), ("引用文献", RA), ("引用文献", RB)],
        "truth": {2: CTRL_PUB},
        "pages": similar_refs_pages([SPLIT_HEAD])
                 + [pg(["Goro SHIKEN"], top="（27）", heads=(SPLIT_HEAD,)), pg(["Fictional University"], top="（28）", heads=(SPLIT_HEAD,))],
        "expect": "exact",
        "note": "文献 A がページの区切りで 2 行に分かれ、2 ページ目の最初に柱（3 ページに出る 20 文字の行。行全体でしか一致させない"
                "行）がある。すぐ後に、A と書名の始まりが同じ文献 B。柱の行が A の文字の一致の塊を 2 つに分けるので、A の docx の"
                "文字は、より長く続けて一致する B の文字と並べられ、ルート2 で A の「pp.9-10．」を消す・変える。0.19.0 は柱を列から"
                "除くので A は一続きに一致する。A・B は docx のまま（出版版と同じ）のはず。",
    },
    {
        "name": "rvB2p_split_similar_refs_figure",
        "angle": "layout",
        "item": "new",
        "paras": BASE[:6] + [("引用文献見出し", RH), ("引用文献", RA), ("引用文献", RB)],
        "truth": {2: CTRL_PUB},
        "pages": similar_refs_pages(["0", "10", "20", "30", "40", "50"]),
        "expect": "exact",
        "note": "rvB2p_split_similar_refs_head と同じ形で、柱の代わりに 2 ページ目の最初の図の目盛りの数字（ページの途中の"
                "数字だけの行。行全体でしか一致させない行）が A の 2 行を分ける。",
    },
    {
        "name": "rvB2p_bound_short_head_ref16",
        "angle": "layout",
        "item": "new",
        "paras": BASE,
        "truth": {2: CTRL_PUB},
        "pages": [pg(front_lines() + [H1] + wrap("　" + BASE[1][1]) + LCTRL + [H2] + LC + LD + [RH] + REF1_SPLIT[:2],
                     top="（25）"),
                  pg(REF1_SPLIT[2:] + REF2_LINES, top="（26）", heads=("試験五郎",)),
                  pg(english_lines()[:3], top="（27）", heads=("試験五郎",))],
        "expect": "exact",
        "note": "8 文字未満の柱（2 ページ目以降の最初の著者名「試験五郎」）が、引用文献 1 の「pp.11-」と次のページの「16」の間に"
                "入る。数字だけの行が前の行の続きかを見るときに短い柱を飛ばさないので、「16」は続きの行にならず、docx の「16」を"
                "消す（0.19.0 も消す）。",
    },
]
