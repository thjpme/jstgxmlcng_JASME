"""rvB2p: 境界（1 ページだけの PDF・空のページ・ページ番号のない PDF・ページ番号が飛ぶ PDF・行が 1 文字だけの表）。架空の文字。"""
FR = ["照合の原則の検証用文書", "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
REF16 = "架空太郎（2019）．「架空の題目」．『架空学会誌』，第29号，pp.11-16"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
NEXT = "次の段落は表の後ろに続く本文の段落であり，照合の確かめに使う。"
X = "本研究では，架空の授業における生徒の発言を記録し，その特徴を三つの観点から整理したうえで，考察を加える。"
XP = X.replace("三つ", "四つ")
cx = XP.index("観点")

CASES = {}
# 1 ページだけの PDF
CASES["one_page_top"] = dict(body=[("body", X), ("body", NEXT)], refs=[REF, REF16],
                             pages=["\n".join(["（1）", *FR, XP, NEXT, "引用および参考文献", REF, REF16[:-2], REF16[-2:], *EN])],
                             truth={X: XP})
CASES["one_page_none_ref16_last"] = dict(body=[("body", X), ("body", NEXT)], refs=[REF, REF16],
                                         pages=["\n".join([*FR, XP, NEXT, "引用および参考文献", REF, *EN, REF16[:-2], REF16[-2:]])],
                                         truth={X: XP})
CASES["one_page_bottom"] = dict(body=[("body", X), ("body", NEXT)], refs=[REF, REF16],
                                pages=["\n".join([*FR, XP, NEXT, "引用および参考文献", REF, REF16, *EN, "25"])],
                                truth={X: XP})
# 1 ページだけで、ページ番号が最後、最初の行は数字だけの行（見出しの番号が別の行など）
CASES["one_page_bottom_first_digit"] = dict(body=[("body", X), ("body", NEXT)], refs=[REF],
                                            pages=["\n".join(["（1）", "方法の概要", XP, NEXT, "引用および参考文献", REF, *EN, "25"])],
                                            truth={X: XP})
# 空のページ（図だけのページ）が段落の途中に入る
CASES["empty_page_mid"] = dict(body=[("body", X), ("body", NEXT)], refs=[REF],
                               pages=["\n".join(["（1）", *FR, XP[:cx]]), "", "\n".join(["（3）", XP[cx:], NEXT, "引用および参考文献", REF, *EN])],
                               truth={X: XP})
CASES["empty_page_blank_lines"] = dict(body=[("body", X), ("body", NEXT)], refs=[REF],
                                       pages=["\n".join(["（1）", *FR, XP[:cx]]), "\r\n \r\n", "\n".join(["（3）", XP[cx:], NEXT, "引用および参考文献", REF, *EN])],
                                       truth={X: XP})
# ページ番号のない PDF（2 ページ）。段落の途中でページが変わる
CASES["no_pageno_2pages"] = dict(body=[("body", X), ("body", NEXT)], refs=[REF, REF16],
                                 pages=["\n".join([*FR, XP[:cx]]), "\n".join([XP[cx:], NEXT, "引用および参考文献", REF, REF16[:-2], REF16[-2:], *EN])],
                                 truth={X: XP})
CASES["no_pageno_ref16_page_end"] = dict(body=[("body", X), ("body", NEXT)], refs=[REF, REF16],
                                         pages=["\n".join([*FR, XP, NEXT, "引用および参考文献", REF, REF16[:-2], REF16[-2:]]),
                                                "\n".join(EN)],
                                         truth={X: XP})
# ページ番号が飛ぶ（25, 26, 28: 27 ページは別の場所）
CASES["skip_pageno"] = dict(body=[("body", X), ("body", NEXT)], refs=[REF],
                            pages=["\n".join(["（25）", *FR, XP[:cx]]), "\n".join(["（26）", XP[cx:]]), "\n".join(["（28）", NEXT, "引用および参考文献", REF, *EN])],
                            truth={X: XP})
# ページ番号が 1 ページだけ合わない（25, 30, 27）。合わないページ番号が段落の途中
CASES["odd_pageno_mid_para"] = dict(body=[("body", X), ("body", NEXT)], refs=[REF],
                                    pages=["\n".join(["（25）", *FR, XP[:cx]]), "\n".join(["（30）", XP[cx:]]), "\n".join(["（27）", NEXT, "引用および参考文献", REF, *EN])],
                                    truth={X: XP})
# 行が 1 文字だけの表が段落の途中に入る（○×・数字）
for cells in (["○", "×", "○", "1", "2"], ["1", "2", "3"], ["－", "1", "－", "2"], ["Ａ", "Ｂ"]):
    CASES["onechar_" + "".join(cells)] = dict(body=[("body", X), ("body", NEXT)], refs=[REF],
                                              pages=["\n".join(["（1）", *FR, XP[:cx], *cells, XP[cx:], NEXT, "引用および参考文献", REF, *EN])],
                                              truth={X: XP})
# 2 ページの PDF で、2 ページ目の最初の行が引用文献の続きの「16」、ページ番号は最後
CASES["pb_bottom_ref16_top"] = dict(body=[("body", X), ("body", NEXT)], refs=[REF, REF16],
                                    pages=["\n".join([*FR, XP, NEXT, "引用および参考文献", REF, REF16[:-2], "1"]),
                                           "\n".join([REF16[-2:], *EN, "2"])],
                                    truth={X: XP})
