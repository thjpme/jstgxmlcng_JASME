"""rvB2p: 前の行が「，」「－」などで終わる、数字だけの行（続きの行とみなされ、line_only にならない）。表・図の数字（架空）。"""
FRONT = ["（1）", "照合の原則の検証用文書", "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
TAIL = ["引用および参考文献", REF, "A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract",
        "Small article abstract."]
NEXT = "次の段落は表の後ろに続く本文の段落であり，照合の確かめに使う。"

CASES = {}

# 1. 段落の行が「，」で終わり、次の行から数字だけのセルの表（または図の目盛り）。出版版で直された数字（12→13）の直前。
X = "本研究では，架空の調査の結果を整理した。その結果，12点の生徒が最も多く，前回より増えた。"
XP = X.replace("12点", "13点")
cut = XP.index("13点")
for cells in (["31", "27", "14"], ["31"], ["21", "40"], ["0", "10", "20", "30"]):
    name = "comma_" + "_".join(cells)
    CASES[name] = dict(
        body=[("body", X), ("body", NEXT)],
        refs=[REF],
        pages=["\n".join([*FRONT, XP[:cut], *cells, XP[cut:], NEXT, *TAIL])],
        truth={X: XP},
    )
    # 直しがない（docx と PDF が同じ）
    CASES[name + "_same"] = dict(
        body=[("body", X), ("body", NEXT)],
        refs=[REF],
        pages=["\n".join([*FRONT, X[:X.index("12点")], *cells, X[X.index("12点"):], NEXT, *TAIL])],
        truth={},
    )

# 2. 表のセル「－」（該当なし）の次の数字だけのセル。段落の途中に表が入り、直しが表の後ろ。
Y = "架空の授業の記録を表１にまとめた。授業は1回目と2回目で生徒の発言の数が大きく変わった。"
YP = Y.replace("1回目と2回目", "１回目と３回目")
cut = YP.index("１回目")
for cells in (["－", "21", "－", "12"], ["A", "－", "31", "B", "－", "23"]):
    name = "dash_" + "_".join(cells)
    CASES[name] = dict(
        body=[("body", Y), ("body", NEXT)],
        refs=[REF],
        pages=["\n".join([*FRONT, YP[:cut], *cells, YP[cut:], NEXT, *TAIL])],
        truth={Y: YP},
    )

# 3. ページの最後の行が「，」で終わり、次のページの最初（ページ番号の次）が図の目盛りの数字
Z = "架空の調査の結果を図１に示す。回答の数は，12件から13件に増えた。この変化について次に述べる。"
ZP = Z.replace("12件から13件", "12件から14件")
cut = ZP.index("12件")
CASES["pagetop_comma"] = dict(
    body=[("body", Z), ("body", NEXT)],
    refs=[REF],
    pages=["\n".join([*FRONT, ZP[:cut]]), "\n".join(["（2）", "10", "20", "30", "40", ZP[cut:], NEXT, *TAIL])],
    truth={Z: ZP},
)
