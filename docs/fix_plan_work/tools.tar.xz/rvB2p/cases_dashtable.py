"""rvB2p: 「－」（該当なし）と数字のセルが交互に並ぶ表が段落を分断する（数字のセルは続きの行とみなされ、全体の照合と窓に数える）。"""
FR = ["（1）", "ページ番号の判定の検証用文書", "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
CAP = "表１　架空の組ごとの得点"
NEXT = "次の段落は表の後ろに続く本文の段落であり，照合の確かめに使う。"
BODY = ("本稿では，架空の授業における生徒の発話を記録し，その特徴を三つの観点から整理する。各観点の記録の件数を表１に示す。"
        "以下では表の結果を観点ごとに述べる。")
CASES = {}
for rows in (3, 6, 10):
    for tail in (9, 20):
        cells = []
        for r in range(rows):
            cells.append(f"第{r + 1}群の記録")
            for c in range(5):
                cells += ["－", str(10 + (r * 11 + c * 7) % 89)]
        cut = len(BODY) - tail
        table = [[f"第{r + 1}群の記録"] + sum((["－", str(10 + (r * 11 + c * 7) % 89)] for c in range(5)), []) for r in range(rows)]
        CASES[f"dashtable_r{rows}_t{tail}"] = dict(
            body=[("body", BODY), ("tab_cap", CAP), ("table", table), ("body", NEXT)], refs=[],
            pages=["\n".join([*FR, BODY[:cut], CAP, *cells, BODY[cut:], NEXT, "引用および参考文献", REF, *EN])],
            truth={})
        # 表がページの最後、段落の後ろは次のページ
        CASES[f"dashtable_pb_r{rows}_t{tail}"] = dict(
            body=[("body", BODY), ("tab_cap", CAP), ("table", table), ("body", NEXT)], refs=[],
            pages=["\n".join([*FR, BODY[:cut], CAP, *cells]), "\n".join(["（2）", BODY[cut:], NEXT, "引用および参考文献", REF, *EN])],
            truth={})
