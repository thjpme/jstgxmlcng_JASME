"""rvB2p: 窓の端・列の端と、短い柱の次の引用文献の続きの数字（架空の文字）。"""
FR = ["（1）", "照合の原則の検証用文書", "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
X = "本研究では，架空の授業における生徒の発言を記録し，その特徴を三つの観点から整理したうえで，考察を加える。"
XP = X.replace("三つ", "四つ")
R16 = "架空太郎（2019）．「架空の題目」．『架空学会誌』，第29号，p.16"
R1116 = "架空太郎（2019）．「架空の題目」．『架空学会誌』，第29号，pp.11-16"
CASES = {}
# 列の最後が、段落の最後の行全体でしか一致させない行（PDF の最後の文字）
CASES["stream_end_p16"] = dict(body=[("body", X)], refs=[R16],
                               pages=["\n".join([*FR, XP, "引用および参考文献", REF, *EN]), "\n".join(["（2）", R16[:-2], R16[-2:]])],
                               truth={X: XP})
# 列の最初が数字だけの行（ページ番号・誌名の行がない PDF の 1 行目が見出しの番号）
CASES["stream_start_digit"] = dict(body=[("body", X)], refs=[],
                                   pages=["\n".join(["1", "はじめに", XP, "引用および参考文献", REF, *EN]), "\n".join(["2", "Small"])],
                                   truth={X: XP})
# 短い柱（2 ページ目以降の最初の著者名）の次の行が、引用文献の「pp.11-」の続きの「16」
for head in ("試験六郎", "架空の比例の授業における分析"):
    CASES[f"short_head_ref16_{len(head)}"] = dict(
        body=[("body", X)], refs=[R1116],
        pages=["\n".join([*FR, XP, "引用および参考文献", REF, R1116[:-2]]),
               "\n".join(["（2）", head, R1116[-2:], *EN]),
               "\n".join(["（3）", head, "Small"]), "\n".join(["（4）", head, "End"])],
        truth={X: XP})
