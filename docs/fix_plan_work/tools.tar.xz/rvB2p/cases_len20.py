"""rvB2p: PDF にだけある 20 文字以上の文字を足さない規則と、列に残した行（line_only）の文字数（架空の文字）。"""
FRONT = ["（1）", "照合の原則の検証用文書", "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
TAIL = ["引用および参考文献", REF, "A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract",
        "Small article abstract."]
NEXT = "次の段落は表の後ろに続く本文の段落であり，照合の確かめに使う。"

CASES = {}
# 出版版では「授業は」の後ろに「全部で」が足された（docx にない）。PDF では「授業は」の後ろに表の数字の行が入る
X = "本稿は架空の授業を対象とする。授業は五回行い，記録の方法は次の節で述べる。"
XP = X.replace("授業は五回", "授業は全部で五回")
cut = XP.index("全部で")
for n in (3, 6, 10):
    cells = [str(10 + (k * 7) % 89) for k in range(n)]
    CASES[f"digits{n}"] = dict(body=[("body", X), ("body", NEXT)], refs=[REF],
                               pages=["\n".join([*FRONT, XP[:cut], *cells, XP[cut:], NEXT, *TAIL])],
                               truth={X: XP})
# 柱（3 ページ以上に出る 8 文字以上の行。ページの端）の直後に、足された文字
HEAD = "架空の比例の授業における生徒の発話の分析"
W = "本稿は架空の授業を対象とする。授業は五回行い，記録の方法は次の節で述べる。分析の結果は第３節で述べる。"
WP = W.replace("授業は五回", "授業は全部で五回")
cut = WP.index("全部で")
CASES["head_then_added"] = dict(
    body=[("body", W), ("body", NEXT)], refs=[REF],
    pages=["\n".join([*FRONT, WP[:cut]]), "\n".join(["（2）", HEAD, WP[cut:]]), "\n".join(["（3）", HEAD, NEXT]),
           "\n".join(["（4）", HEAD, *TAIL])],
    truth={W: WP})
