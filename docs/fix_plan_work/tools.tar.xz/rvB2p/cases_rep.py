"""rvB2p: 3 ページに出る同じ文字列の行（柱の形の行。line_only）が、本文の段落の最後・最初・途中の行のとき（架空の文字）。"""
FR = ["照合の原則の検証用文書", "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
REP = "ことが明らかになった。"
E1 = "一つ目の場面では，生徒は表の横の並びに着目し，架空の量が一定の割合で増えることを述べた。この発言から，横の見方が先に出る" + REP
E2 = "二つ目の場面では，生徒は二つの量の値の組を順に書き出し，架空の比が変わらないことを確かめた。このことから，比の一定に気が付く" + REP
E3 = "三つ目の場面では，生徒はグラフの傾きに着目し，架空の二つの量の関係を式で表そうとした。全体の分析から，式による表現が後に現れる" + REP
E3D = E3.replace(REP, "ことが明らかとなった。")      # docx（出版版で「と」→「に」）


def lines(t, w=24):
    t = "　" + t
    out = [t[i:i + w] for i in range(0, len(t), w)]
    # 最後の行を REP にする
    body = t[:-len(REP)]
    out = [body[i:i + w] for i in range(0, len(body), w)] + [REP]
    return out


CASES = {}
# 段落の最後の行（3 ページ）。E3 だけ docx が違う
pages = ["\n".join(["（1）", *FR, *lines(E1)]), "\n".join(["（2）", *lines(E2)]), "\n".join(["（3）", *lines(E3), "引用および参考文献", REF, *EN])]
CASES["rep_end_same"] = dict(body=[("body", E1), ("body", E2), ("body", E3)], refs=[REF], pages=pages, truth={})
CASES["rep_end_fixed"] = dict(body=[("body", E1), ("body", E2), ("body", E3D)], refs=[REF], pages=pages, truth={E3D: E3})
# 段落の途中（ページの最後の行が REP で、段落は次のページに続く）。docx が違う
M = "四つ目の場面では，生徒は式とグラフを結び付けた。このことから二つの表現の関係が分かる" + REP + "その後，生徒は表に戻って確かめた。"
MD = M.replace(REP, "ことが明らかとなった。")
mlines = lines(M[:M.index(REP) + len(REP)])
pages2 = ["\n".join(["（1）", *FR, *lines(E1)]), "\n".join(["（2）", *lines(E2), *mlines]),
          "\n".join(["（3）", "その後，生徒は表に戻って確かめた。", *lines(E3), "引用および参考文献", REF, *EN])]
CASES["rep_mid_fixed"] = dict(body=[("body", E1), ("body", E2), ("body", MD), ("body", E3)], refs=[REF], pages=pages2, truth={MD: M})
CASES["rep_mid_same"] = dict(body=[("body", E1), ("body", E2), ("body", M), ("body", E3)], refs=[REF], pages=pages2, truth={})
