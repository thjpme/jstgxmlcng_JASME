"""rvB2p: 段落の最後の行が line_only（3 ページに出る行・数字だけの行）で、出版版で句点が「。」→「．」に直されたとき（架空の文字）。"""
FR = ["照合の原則の検証用文書", "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
REP = "ことが明らかになった。"
REPP = "ことが明らかになった．"
BODY = ["一つ目の場面では，生徒は表の横の並びに着目し，架空の量が一定の割合で増えることを述べた。この発言から，横の見方が先に出る",
        "二つ目の場面では，生徒は二つの量の値の組を順に書き出し，架空の比が変わらないことを確かめた。このことから，比の一定に気が付く",
        "三つ目の場面では，生徒はグラフの傾きに着目し，架空の二つの量の関係を式で表そうとした。全体の分析から，式による表現が後に現れる"]


def lines(b):
    t = "　" + b
    return [t[i:i + 24] for i in range(0, len(t), 24)]


CASES = {}
docx = [b + REP for b in BODY]
pub = [b + REPP for b in BODY]
pages = ["\n".join(["（1）", *FR, *lines(BODY[0]), REPP]), "\n".join(["（2）", *lines(BODY[1]), REPP]),
         "\n".join(["（3）", *lines(BODY[2]), REPP, "引用および参考文献", REF, *EN])]
CASES["rep_end_period"] = dict(body=[("body", x) for x in docx], refs=[REF], pages=pages, truth=dict(zip(docx, pub)))
