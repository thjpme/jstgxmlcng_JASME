"""rvB2p: 行全体でしか一致させない行（line_only）が段落の文字を分け、窓の中の別の場所に同じ文字列があるとき（架空の文字）。"""
FR = ["（1）", "照合の原則の検証用文書", "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
CASES = {}

# 1. 本文: 段落 P1 の途中に表の数字の行。次の段落 P2 が P1 とよく似た文で始まる。P1 は出版版で「比べた」→「比較した」
P1 = "第1回の調査では，回答者の多くが比の値に着目して二つの量を比べた。"
P2 = "第2回の調査では，回答者の多くが比の値に着目して二つの量を比べたが，その理由は様々であった。"
P1P = P1.replace("比べた。", "比較した。")
for cut_at in ("多", "比の", "着目"):
    cut = P1P.index(cut_at)
    for cells in (["31", "27", "14"], ["12"]):
        CASES[f"body_{cut_at}_{len(cells)}"] = dict(
            body=[("body", P1), ("body", P2)], refs=[REF],
            pages=["\n".join([*FR, "　" + P1P[:cut], *cells, P1P[cut:], "　" + P2, "引用および参考文献", REF, *EN])],
            truth={P1: P1P})
        CASES[f"body_{cut_at}_{len(cells)}_same"] = dict(
            body=[("body", P1), ("body", P2)], refs=[REF],
            pages=["\n".join([*FR, "　" + P1[:P1.index(cut_at)], *cells, P1[P1.index(cut_at):], "　" + P2, "引用および参考文献", REF, *EN])],
            truth={})

# 2. 引用文献: 同じ著者・同じ書名の始まりの文献が並ぶ（文部科学省の学習指導要領の解説など。架空の書名）。R1 の最後の行が
#    「p.」の改行の後の数字だけの行（line_only）。出版版で R1 の数字が直された
R1 = "架空省（2017）．『架空学校学習指導要領解説　架空数学編』．架空出版，p.16"
R2 = "架空省（2018）．『架空学校学習指導要領解説　架空数学編』．架空出版，p.25"
R1P = R1.replace("2017", "２０１７")
at = R1P.index("p.") + 2
CASES["ref_similar_p16"] = dict(body=[("body", P2)], refs=[R1, R2],
                                pages=["\n".join([*FR, "　" + P2, "引用および参考文献", REF, R1P[:24], R1P[24:at], R1P[at:], R2[:24], R2[24:], *EN])],
                                truth={R1: R1P})
