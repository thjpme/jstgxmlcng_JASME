"""反例集（rvB2x_principle の数式の組）。文字はすべて架空。docx の数式は oracle/cases_b2.py の仕組み（段落の文字の中の OBJ を
Word の数式にする。期待 "keep" は docx を 1 文字も変えずに 13 章に出すこと）を使う。

  python run_all.py <src> ../rvB2x_math_cases.py --name <名前>

- x_math_lead_indentlike: 校正で足された「（数式とおく）」の数式が、PDF の行の最初にあり、pdfium の文字では全角の空白 2 つ
  （段落の字下げと同じ形）になる。数式の欠けた「（とおく）」を足してはいけない（keep）。
- x_math_halfspaces: 同じ挿入で、数式の位置が半角の空白 2 つ（全角の空白を含まない）になる形（keep）。
- x_math_ctrl_*: 対照。数式のすぐ近く（隣ではない）のふつうの直しは直す（exact）。
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "oracle"))

import cases_b2 as B  # noqa: E402  （runner の数式と期待 keep の仕組みを入れる）
from runner import OBJ, Raw  # noqa: E402

CASES = []
I = "　"
DOCX = "生徒は，表の値を確率として求めた。その値を予想させたうえで，試行の結果と比べた。"
TRUTH = DOCX.replace("その値を予想", f"その値（{OBJ}とおく）を予想")
# 行の組み方: 1 行目の最後が「（」、2 行目の最初に数式の空白の並び、続いて「とおく）を予想…」
L1 = B.lines_of(DOCX.split("を予想")[0] + "（")
for tag, gap in (("lead_indentlike", I + I), ("halfspaces", "  "), ("lead_mixed", I + " " + I)):
    lines = L1[:-1] + [L1[-1]] + [gap + "とおく）を予想させたうえで，試行の結果と比べた。"]
    CASES.append(B.case(
        f"x_math_{tag}", "edit", [("本文", DOCX)], [Raw(*lines)], {4: TRUTH}, "keep",
        f"校正で足された「（数式とおく）」の数式が、PDF では行の最初の {[hex(ord(c)) for c in gap]} の並びになる。"
        "数式の欠けた「（とおく）」を足さず、docx のまま 13 章に出す。"))
# 同じ挿入が行の途中にあり、数式の位置が半角の空白 2 つ
lines = B.lines_of(DOCX.replace("その値を予想", "その値（  とおく）を予想"))
CASES.append(B.case(
    "x_math_mid_halfspaces", "edit", [("本文", DOCX)], [Raw(*lines)], {4: TRUTH}, "keep",
    "校正で足された「（数式とおく）」の数式が、PDF では行の途中の半角の空白 2 つになる。数式の欠けた「（とおく）」を足さず、"
    "docx のまま 13 章に出す。"))
# 対照: 数式のある段落の、数式から離れたふつうの直し（直す）
CD = f"値の組（{OBJ}，{OBJ}）を順に調べ，その結果を表にまとめた。最後に，表の値を全体で比べた。"
CT = CD.replace("全体で比べた", "全体で確かめた")
CP = f"値の組（{B.M_SP}， {B.M_SP}）を順に調べ，その結果を表にまとめた。最後に，表の値を全体で確かめた。"
CASES.append(B.case(
    "x_math_ctrl_far", "edit", [("本文", CD)], [Raw(*B.lines_of(CP))], {4: CT}, "exact",
    "数式が 2 つある段落の、数式から離れた位置のふつうの直し（「比べた」→「確かめた」）。直す。"))
