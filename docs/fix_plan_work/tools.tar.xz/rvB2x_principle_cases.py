"""反例集（rvB2x_principle: 単位 B2〈0.21.0〉の点検の、原則と文字の不変性〈ルート2〉の観点）。文字はすべて架空。

oracle/run_all.py の書式（oracle/runner.py の docstring）。実行（scratchpad の oracle/ で）:
  python run_all.py <src> ../rvB2x_principle_cases.py --name <名前>
期待は原則だけで決める（出版版 PDF の本文と同じにする。組版の文字・図や表の中の文字・ほかの段落の文字を足さない。本文の文字を
消さない。決められないものは docx のまま 13 章に出す）。0.20.0 にも B2 にも合わせない。

組（名前の前置き）:
  x_tailfix_*  分断の後ろが段落の最後の数文字（1 行）だけで、その数文字に校正の直しがある（まとめての照合が分断の後ろを
               見つけられないと、段落の窓に入らず、docx の最後の文字を消す）
               （_pb: 段落の最後の数文字の前でページが変わり、次のページの最初に表がある）
  x_rev_*      読み順の逆転と校正の直し
  x_dup_*      同じ文のくり返し（離れた段落・表の注・隣り合う段落の境目）
  x_few_*      アンカーの少ない論文
  x_en_*       英文の段落
  x_page_*     ページの端・1 ページだけ・空のページ・ページ番号なし
  x_wrong_*    別の記事の PDF
  x_tabimg_*   docx の表が PDF では画像（表の文字が PDF にない）
  x_rewrite_*  校正で書き換えられた文（段落の最後・最初・途中）
  x_wholerep_* 校正の置き換えの PDF の文字が、行まるごとを含む（C3 が行まるごとだけを外し、残りで置き換える）
  x_runin_*    追い込みの見出し（4 文字以上）と、その直し（_contests）
  x_contest_*  docx の 2 つの段落が PDF では 1 つにつながり、前の段落の最後が直された（_contests）
数式の組は rvB2x_math_cases.py（cases_b2 の数式の仕組みを使う）。

結果（2026-10-19。作業ツリー W〈0.21.0。fix_verify の F3 とコードが同じ〉・試作 C・0.20.0）:
  97 件で W・C は FAIL 37・REPORTED 19・OK 41（どの反例も W と C は同じ判定）、0.20.0 は FAIL 43・REPORTED 11・OK 43。
  x_tailfix の 50 件: W の FAIL 30 はすべて docx の最後の文字を消す。0.20.0 の FAIL 32 は表の文字を足す 11・足して消す 2・
  黙って直さない 6・消す 13。0.20.0 が OK で W が消すもの: x_tailfix3_para20・x_tailfix6_para60・x_tailfix7_para60・
  x_tailfix4b_tab20_pb・x_tailfix6_tab20_pb・x_tailfix7_tab20_pb。
  x_wholerep_3to30・3to56: W は「…班の生徒は授業つの表にも…」（docx にも PDF にもない文字）にする（runner の判定は、足した
  文字が truth にあるので REPORTED になる）。0.20.0 は OK。_pb は両方とも同じ形に崩す。
  x_runin_head: W は見出し「（１）架空の目的」を「（１）架空の目」にする（「標」は次の段落の EDGE_WHY）。0.20.0 は OK。
  x_contest_join_fix・join_period: W は前の段落の直された最後（「た。」「。」）を次の段落の頭に足す。0.20.0 は前の段落を
  「…確かめた。る」に崩す・黙って直さない。
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "n10"))

from runner import BREAK, DEFAULTS, Raw, flow, journal_line  # noqa: E402,F401
import cases_n10 as N  # noqa: E402

CASES = []


def case(name, item, paras, pages, note, truth=None, expect="exact", angle="layout"):
    CASES.append({"name": name, "angle": angle, "item": item, "paras": paras, "truth": truth or {},
                  "pages": pages, "expect": expect, "note": note})


def idx(paras, text):
    found = [i for i, (_, t) in enumerate(paras) if t == text]
    if len(found) != 1:
        raise ValueError(f"段落「{str(text)[:16]}」が {len(found)} 個")
    return found[0]


T0_KEY = None   # 確かめ用の段落（N.CTRL_DOCX）の番号は反例ごとに idx で求める

# ============================================================================ 1. 分断の後ろが最後の数文字だけで、そこに校正の直し
# TARGET の最後は「…説明し合う時間を取った。」。分断の後ろの 1 行に最後の数文字だけを置き、その数文字を校正で直す
TAILFIX = [
    # 名前, 分断の後ろの文字数（docx の側）, 出版版の TARGET
    ("4a", 4, N.TARGET[:-4] + "持った。"),          # 「取った。」→「持った。」（4 文字の 1 文字目）
    ("4b", 4, N.TARGET[:-4] + "取れた。"),          # 「取った。」→「取れた。」（2 文字目）
    ("3", 3, N.TARGET[:-3] + "てた。"),             # 「った。」→「てた。」（3 文字の 1 文字目）
    ("6", 6, N.TARGET[:-6] + "間を取る。"),          # 最後の 6 文字「間を取った。」→「間を取る。」
]
for tag, k, pub in TAILFIX:
    head_pdf, tail_pdf = pub[:len(N.TARGET) - k], pub[len(N.TARGET) - k:]
    assert head_pdf == N.TARGET[:-k], tag
    for kind in ("tab", "fig", "para"):
        for n in (20, 60):
            m_before, m_after, others, lines = N.material(kind, n, "tail")
            paras = N.article_paras(N.TARGET, m_before, m_after, others_after=others)
            pages = N.article_pages([Raw(*N.body(head_pdf)), Raw(*lines), Raw(tail_pdf)])
            case(f"x_tailfix{tag}_{kind}{n}", "N10", paras, pages,
                 f"PDF では段落の最後の {len(tail_pdf)} 文字（「{tail_pdf}」の 1 行。docx の「{N.TARGET[-k:]}」を校正で直した"
                 f"もの）の前に、{N.KIND_NOTE[kind].format(side='後ろ', side2='2 つ後ろ')}が約 {N.chars(lines)} 文字入る。"
                 "直すか、決められなければ docx のまま 13 章に出す（docx の最後の文字を消さない。分断する文字を足さない）。",
                 truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): pub},
                 expect={"default": "exact", idx(paras, N.TARGET): "reported"})

# 分断の後ろが 7〜12 文字で、そのうち 2〜3 文字を校正で直したもの（一致が 85% に届かない）
TAILFIX_LONG = [
    ("7", 7, N.TARGET[:-7] + "時間を設けた。"),            # 「時間を取った。」→「時間を設けた。」（7 文字の 2 文字）
    ("9", 9, N.TARGET[:-9] + "合う場を設けた。"),          # 「合う時間を取った。」→「合う場を設けた。」
    ("12", 12, N.TARGET[:-12] + "説明する時間を取った。"),  # 「説明し合う時間を取った。」→「説明する時間を取った。」
]
for tag, k, pub in TAILFIX_LONG:
    head_pdf, tail_pdf = pub[:len(N.TARGET) - k], pub[len(N.TARGET) - k:]
    assert head_pdf == N.TARGET[:-k], tag
    for kind in ("tab", "para"):
        for n in (20, 60):
            m_before, m_after, others, lines = N.material(kind, n, "tail")
            paras = N.article_paras(N.TARGET, m_before, m_after, others_after=others)
            pages = N.article_pages([Raw(*N.body(head_pdf)), Raw(*lines), Raw(tail_pdf)])
            case(f"x_tailfix{tag}_{kind}{n}", "N10", paras, pages,
                 f"PDF では段落の最後の {len(tail_pdf)} 文字（「{tail_pdf}」の 1 行。docx の「{N.TARGET[-k:]}」を校正で直した"
                 f"もの）の前に、{N.KIND_NOTE[kind].format(side='後ろ', side2='2 つ後ろ')}が約 {N.chars(lines)} 文字入る。"
                 "直すか、決められなければ docx のまま 13 章に出す（docx の最後の文字を消さない。分断する文字を足さない）。",
                 truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): pub},
                 expect={"default": "exact", idx(paras, N.TARGET): "reported"})


def base_paras(target=N.TARGET, after=N.P_AFTER, disc=N.P_DISC, end=N.P_END, extra=()):
    return ([("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("見出し", N.H2), ("本文", target),
             ("本文", after), *extra, ("見出し", N.H3), ("本文", disc), ("本文", end), ("引用文献見出し", N.RH),
             ("引用文献", N.REF1), ("引用文献", N.REF2)])


def tail_blocks():
    return [N.RH, Raw(*N.REF1_LINES), Raw(*N.REF2_LINES), BREAK, N.en_block()]


# ============================================================================ 2. 読み順の逆転と校正の直し
T_TAIL_E = N.T_TAIL.replace("説明し合う", "話し合う")
T_HEAD_E = N.T_HEAD.replace("教師はまず", "教師は初めに")
for tag, head_pdf, tail_pdf in (("tailedit", N.T_HEAD, T_TAIL_E), ("headedit", T_HEAD_E, N.T_TAIL)):
    paras = base_paras()
    pub = head_pdf + tail_pdf
    # (a) 段落の後ろの文が前より先に出る
    pages = flow([N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*N.jwrap(tail_pdf)),
                  Raw(*N.body(head_pdf)), Raw(*N.body(N.P_AFTER)), N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)),
                  *tail_blocks()], first=25)
    case(f"x_rev_{tag}", "N10", paras, pages,
         "PDF では段落の最後の文が段落の前半より先に出る（読み順の逆転）。" + ("最後の文" if tag == "tailedit" else "前半")
         + "に校正の直しがある。直すか、決められなければ 13 章に出す。ほかの段落は変えない。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): pub},
         expect={"default": "exact", idx(paras, N.TARGET): "reported"})
    # (b) 右の段（段落の最後の文と次の段落）が左の段（段落の前半）より先に出る
    pages = flow([N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*N.jwrap(tail_pdf)),
                  Raw(*N.body(N.P_AFTER)), Raw(*N.body(head_pdf)), N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)),
                  *tail_blocks()], first=25)
    case(f"x_rev_col_{tag}", "N10", paras, pages,
         "PDF では、段落の最後の文と次の段落（右の段）が、段落の前半（左の段）より先に出る（2 段組みの読み順の逆転）。"
         + ("最後の文" if tag == "tailedit" else "前半") + "に校正の直しがある。直すか、決められなければ 13 章に出す。"
         "ほかの段落は変えない。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): pub},
         expect={"default": "exact", idx(paras, N.TARGET): "reported"})

# ============================================================================ 3. 同じ文のくり返し
# (a) 表の注が二つの表の下に同じ文字であり、二つ目だけが校正で直された
NOTE_DOCX = "注）数値は架空の調査で得た人数を示す。"
NOTE_PUB = "注）数値は架空の調査で得た延べ人数を示す。"
cap1, rows1 = N.table_rows(60)
cap2 = "表２　架空の学級ごとの発話の数"
rows2 = [["学級", "一回目", "二回目"], ["Ａ組", "31", "27"], ["Ｂ組", "19", "22"], ["Ｃ組", "25", "14"]]
for which in (1, 2):
    paras = ([("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("見出し", N.H2), ("本文", N.TARGET),
              ("表キャプション", cap1), ("表", rows1), ("本文", NOTE_DOCX), ("本文", N.P_AFTER), ("表キャプション", cap2),
              ("表", rows2), ("本文", NOTE_DOCX), ("見出し", N.H3), ("本文", N.P_DISC), ("本文", N.P_END),
              ("引用文献見出し", N.RH), ("引用文献", N.REF1), ("引用文献", N.REF2)])
    notes = [k for k, (_, t) in enumerate(paras) if t == NOTE_DOCX]
    pdf_notes = [NOTE_PUB if which == 1 else NOTE_DOCX, NOTE_PUB if which == 2 else NOTE_DOCX]
    pages = flow([N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*N.body(N.TARGET)),
                  Raw(*N.table_lines(cap1, rows1)), Raw(*N.jwrap(pdf_notes[0])), Raw(*N.body(N.P_AFTER)),
                  Raw(*N.table_lines(cap2, rows2)), Raw(*N.jwrap(pdf_notes[1])), N.H3, Raw(*N.body(N.P_DISC)),
                  Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
    case(f"x_dup_note{which}", "new", paras, pages,
         f"二つの表の下に同じ文字の注（docx の段落）があり、出版版では{'一' if which == 1 else '二'}つ目の注だけが直された。"
         "直された注だけを直し、もう一つの注は変えない。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, notes[which - 1]: NOTE_PUB})
# (b) 「はじめに」の一文が、考察の最後にもそのまま出て、考察の側だけが校正で直された
S = "本研究では，表を縦に見る活動が二つの量の対応の理解を促すかを確かめる。"
S_E = S.replace("促すかを確かめる", "促すかを検討する")
INTRO2 = N.P_INTRO + S
DISC2 = N.P_DISC + S
for which in ("intro", "disc"):
    paras = base_paras(disc=DISC2)
    paras[1] = ("本文", INTRO2)
    intro_pdf = INTRO2 if which == "disc" else N.P_INTRO + S_E
    disc_pdf = DISC2 if which == "intro" else N.P_DISC + S_E
    pages = flow([N.front(), N.H1, Raw(*N.body(intro_pdf)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*N.body(N.TARGET)),
                  Raw(*N.body(N.P_AFTER)), N.H3, Raw(*N.body(disc_pdf)), Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
    truth = {idx(paras, N.CTRL_DOCX): N.CTRL_PUB}
    truth[1 if which == "intro" else idx(paras, DISC2)] = intro_pdf if which == "intro" else disc_pdf
    case(f"x_dup_far_{which}", "new", paras, pages,
         "「はじめに」の段落の最後の一文が、考察の段落の最後にもそのまま出る。出版版では"
         + ("「はじめに」" if which == "intro" else "考察") + "の側だけが直された。直された側だけを直し、もう一方は変えない。",
         truth=truth)
# (c) 隣り合う段落の境目に同じ文（前の段落の最後の文と、次の段落の最初の文）。前の段落の側だけが校正で直された
S2 = "以上のことから，表の縦の見方が対応の理解を支えたと考えられる。"
S2_E = S2.replace("支えたと考えられる", "支えたと言える")
X_DOCX = N.T_HEAD + S2
Y_DOCX = S2 + "次の節では，この見方がどのように生まれたかを発話から確かめる。"
for which in ("x", "y"):
    paras = base_paras(target=X_DOCX, after=Y_DOCX)
    x_pdf = N.T_HEAD + S2_E if which == "x" else X_DOCX
    y_pdf = S2_E + Y_DOCX[len(S2):] if which == "y" else Y_DOCX
    pages = flow([N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*N.body(x_pdf)),
                  Raw(*N.body(y_pdf)), N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
    truth = {idx(paras, N.CTRL_DOCX): N.CTRL_PUB}
    truth[idx(paras, X_DOCX) if which == "x" else idx(paras, Y_DOCX)] = x_pdf if which == "x" else y_pdf
    case(f"x_dup_adj_{which}", "new", paras, pages,
         "段落の最後の文と、次の段落の最初の文が同じ文字。出版版では" + ("前の段落" if which == "x" else "次の段落")
         + "の側だけが直された。直された側だけを直し、もう一方は変えない（ほかの段落の文字を足したり消したりしない）。",
         truth=truth)

# ============================================================================ 4. アンカーの少ない論文
# (a) 同じ型の文がくり返す段落（学級ごと）。数字だけが違い、出版版で一つの数字が直された
TPL = "{g}組では，表を横に見て増え方を答えた生徒が{a}名，縦に見て対応を答えた生徒が{b}名であった。"
GROUPS = [("Ａ", 12, 5), ("Ｂ", 14, 7), ("Ｃ", 11, 6), ("Ｄ", 13, 8)]
G_DOCX = [TPL.format(g=g, a=a, b=b) for g, a, b in GROUPS]
G_PUB = list(G_DOCX)
G_PUB[1] = TPL.format(g="Ｂ", a=14, b=9)
paras = ([("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("見出し", N.H2)]
         + [("本文", t) for t in G_DOCX] + [("見出し", N.H3), ("本文", N.P_DISC), ("引用文献見出し", N.RH),
                                            ("引用文献", N.REF1)])
pages = flow([N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2]
             + [Raw(*N.body(t)) for t in G_PUB] + [N.H3, Raw(*N.body(N.P_DISC)), N.RH, Raw(*N.REF1_LINES), BREAK,
                                                    N.en_block()], first=25)
case("x_few_template", "new", paras, pages,
     "同じ型の文の段落が 4 つ続き（学級ごと。数字だけが違う）、出版版でＢ組の「7名」が「9名」に直された。Ｂ組の段落だけを直す。",
     truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, G_DOCX[1]): G_PUB[1]})
# (b) (a) で、Ｂ組とＣ組の段落の順が PDF では逆（読み順のずれ）
pages = flow([N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2]
             + [Raw(*N.body(t)) for t in (G_PUB[0], G_PUB[2], G_PUB[1], G_PUB[3])]
             + [N.H3, Raw(*N.body(N.P_DISC)), N.RH, Raw(*N.REF1_LINES), BREAK, N.en_block()], first=25)
case("x_few_template_rev", "new", paras, pages,
     "x_few_template で、PDF ではＢ組とＣ組の段落の順が逆。Ｂ組の段落だけを「9名」に直すか、決められなければ 13 章に出す。"
     "ほかの段落は変えない。",
     truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, G_DOCX[1]): G_PUB[1]},
     expect={"default": "exact", idx(paras, G_DOCX[1]): "reported"})
# (c) 短い箇条の段落（8 文字未満。アンカーにならない）が並び、一つが校正で直された
ITEMS = ["（１）比の値", "（２）比の利用", "（３）比と割合", "（４）比の性質", "（５）比の式"]
ITEMS_PUB = list(ITEMS)
ITEMS_PUB[2] = "（３）比と百分率"
paras = ([("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("見出し", N.H2)]
         + [("本文", t) for t in ITEMS] + [("本文", N.TARGET), ("見出し", N.H3), ("本文", N.P_DISC),
                                           ("引用文献見出し", N.RH), ("引用文献", N.REF1)])
pages = flow([N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*ITEMS_PUB),
              Raw(*N.body(N.TARGET)), N.H3, Raw(*N.body(N.P_DISC)), N.RH, Raw(*N.REF1_LINES), BREAK, N.en_block()],
             first=25)
case("x_few_items", "new", paras, pages,
     "短い箇条の段落が 5 つ並び（どれも 8 文字未満）、出版版で 3 つ目が直された。直すか、決められなければ 13 章に出す。"
     "ほかの段落は変えない。",
     truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, ITEMS[2]): ITEMS_PUB[2]},
     expect={"default": "exact", idx(paras, ITEMS[2]): "reported"})

# ============================================================================ 5. 英文の段落
EN = ("This study examines how students in a fictional class compare two quantities. The analysis of utterances "
      "shows three stages of reasoning about proportional relationships, and the third stage appears after the "
      "use of tables.")
EN_LINES = ["　　 This study examines how students in a fictional class",
            "compare two quantities. The analysis of utterances shows",
            "three stages of reasoning about proportional relation￾" + "ships, and the third stage appears after the use of",
            "tables."]
assert " ".join(EN_LINES).replace("￾", "").replace("　　 ", "") == EN.replace("relationships", "relationships"), \
    " ".join(EN_LINES)
EN_EDITS = [
    ("first", EN.replace("This study", "This paper"), [EN_LINES[0].replace("study", "paper")] + EN_LINES[1:]),
    ("linestart", EN.replace("compare two", "contrast two"), [EN_LINES[0], EN_LINES[1].replace("compare", "contrast")]
     + EN_LINES[2:]),
    ("hyphen", EN.replace("relationships", "relations"), EN_LINES[:2]
     + ["three stages of reasoning about proportional rela￾" + "tions, and the third stage appears after the use of"]
     + EN_LINES[3:]),
    ("last", EN.replace("use of tables.", "use of tables in class."), EN_LINES[:3] + ["tables in class."]),
    ("added_sentence", EN + " The results suggest a new design.", EN_LINES[:3] + ["tables. The results suggest a new design."]),
]


def en_pages(lines):
    return flow([N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*N.body(N.TARGET)),
                 N.H3, Raw(*N.body(N.P_DISC)), N.RH, Raw(*N.REF1_LINES), BREAK,
                 Raw(DEFAULTS["英文題目"], DEFAULTS["英文副題"], "Goro SHIKEN", "Fictional University", "Abstract"),
                 Raw(*lines)], first=25)


for tag, pub, lines in EN_EDITS:
    paras = [("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("見出し", N.H2), ("本文", N.TARGET),
             ("見出し", N.H3), ("本文", N.P_DISC), ("引用文献見出し", N.RH), ("引用文献", N.REF1), ("英文要旨", EN)]
    case(f"x_en_{tag}", "new", paras, en_pages(lines),
         "英文要旨の段落に校正の直し（" + tag + "）がある。直すか、決められなければ 13 章に出す（単語の間の空白を落とさない）。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, EN): pub},
         expect={"default": "exact", idx(paras, EN): "reported"})

# ============================================================================ 6. ページの端・1 ページだけ・空のページ・ページ番号なし
T_EDIT = N.TARGET.replace("自分のノート", "各自のノート")
T_LINES = N.body(T_EDIT)
_k = next(k for k, ln in enumerate(T_LINES) if "各自" in ln)
for tag, style, empty in (("nopageno", None, False), ("emptypage", "paren", True), ("nopageno_empty", None, True)):
    pre, post = T_LINES[:_k], T_LINES[_k:]
    blocks = [N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*pre), BREAK]
    if empty:
        blocks += [Raw(""), BREAK]
    blocks += [Raw(*post), Raw(*N.body(N.P_AFTER)), N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()]
    paras = base_paras()
    case(f"x_page_{tag}", "new", paras, flow(blocks, first=25, style=style),
         "段落がページの区切りで続き、次のページの最初の行（ページの端の行）に校正の直し（「自分の」→「各自の」）がある。"
         + ("ページ番号がない。" if style is None else "") + ("間に空のページ（文字のないページ）がある。" if empty else "")
         + "直すか、決められなければ 13 章に出す。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): T_EDIT},
         expect={"default": "exact", idx(paras, N.TARGET): "reported"})
# 1 ページだけの PDF（ページ番号なし）で、最初の段落の最初と最後の段落の最後に校正の直し
P1_INTRO = N.P_INTRO.replace("本研究の目的は", "本稿の目的は")
P1_END = N.P_END.replace("確かめていきたい。", "確かめたい。")
paras = [("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("本文", N.P_END)]
page1 = "\n".join([N.H1] + N.body(P1_INTRO) + N.body(N.CTRL_PUB) + N.body(P1_END)) + "\n"
case("x_page_onepage", "new", paras, [page1],
     "1 ページだけの PDF（誌名の行・ページ番号なし。docx の冒頭の段落は PDF にない）で、最初の段落の書き出しと最後の段落の"
     "最後に校正の直しがある。直すか、決められなければ 13 章に出す。",
     truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.P_INTRO): P1_INTRO, idx(paras, N.P_END): P1_END},
     expect={"default": "exact", idx(paras, N.P_INTRO): "reported", idx(paras, N.P_END): "reported"})

# ============================================================================ 7. 別の記事の PDF（引用文献の 1 つと見出しが同じ）
REF1_OTHER = N.REF1.replace("pp.11-16", "pp.11-17")
paras = base_paras()
pages = flow([Raw(journal_line(fp=53, lp=64), "架空の図形の学習における証明の読み方", "―架空の副題―", "架空大学　見本　七郎"),
              N.H1, Raw(*N.body("本稿の目的は，架空の中学校で行った図形の証明の授業において，生徒が証明をどのように読んだかを"
                                "明らかにすることである。")),
              N.H2, Raw(*N.body("証明の読み方を調べるために，生徒に証明の各行の理由を書かせる課題を作った。")),
              N.H3, Raw(*N.body("その結果，理由を書けた生徒は学級の半数ほどであった。")), N.RH,
              Raw(*N.jwrap(REF1_OTHER)), BREAK, Raw("A Fictional Study of Reading Proofs", "Abstract",
                                                    "This is another fictional abstract.")], first=53)
case("x_wrong_pdf_ref", "new", paras, pages,
     "別の記事の PDF（見出しと、引用文献の 1 つが同じ。その文献のページだけが違う）。どの段落も変えない（別の記事の文字と"
     "並べて直さない）。",
     truth={})

# ============================================================================ 8. docx の表が PDF では画像（表の文字が PDF にない）
rows = [["学級", "前半", "後半"], ["Ａ組", "12", "13"], ["Ｂ組", "13", "12"]]
AFTER_T = "前半の12名と後半の13名は，表を縦に見て対応を答えた生徒の数である。"
AFTER_T_PUB = AFTER_T.replace("後半の13名", "後半の14名")
paras = ([("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("見出し", N.H2), ("本文", N.TARGET),
          ("表キャプション", "表１　架空の学級ごとの人数"), ("表", rows), ("本文", AFTER_T), ("見出し", N.H3),
          ("本文", N.P_DISC), ("引用文献見出し", N.RH), ("引用文献", N.REF1)])
pages = flow([N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*N.body(N.TARGET)),
              Raw("表１　架空の学級ごとの人数"), Raw(*N.body(AFTER_T_PUB)), N.H3, Raw(*N.body(N.P_DISC)), N.RH,
              Raw(*N.REF1_LINES), BREAK, N.en_block()], first=25)
case("x_tabimg_digits", "new", paras, pages,
     "docx の Word の表が、PDF では画像（表のセルの文字が PDF にない）。表の後ろの段落はセルと同じ数字・語を含み、出版版で"
     "「13名」が「14名」に直された。その段落を直し、ほかの段落は変えない（セルの文字と並べて本文の文字を消さない）。",
     truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, AFTER_T): AFTER_T_PUB})

# ============================================================================ 9. 校正で書き換えられた文（段落の最後・最初・途中）。分断なし
REW_LAST = "授業の終わりには，学級全体で増え方の決まりを言葉にまとめ，ノートに書かせて振り返りとした。"
REW_FIRST = "この授業の初めに，教師は前の時間に使った表をもう一度示し，時間と深さの関係を全員で確かめた。"
REW_MID = "どの生徒も矢印の数をそろえてかき，同じ増え方がくり返されることを言葉で説明した。"
_T1 = "第三時の授業では，教師はまず前時に作った表を黒板に掲げ，水を入れる時間と水の深さの関係を振り返らせた。"
_T2 = "続いて，表の隣り合う値の間に矢印をかき，深さがどれだけ増えたかを矢印の上に書き込む活動を示した。"
_T3 = "生徒は自分のノートの表にも矢印をかき，増え方がいつも同じであることを確かめた。"
assert _T1 + _T2 + _T3 == N.T_HEAD
for tag, pub in (("last", N.T_HEAD + REW_LAST), ("first", REW_FIRST + _T2 + _T3 + N.T_TAIL),
                 ("mid", _T1 + _T2 + REW_MID + N.T_TAIL)):
    for split in ("none", "tab60", "fig60"):
        paras = base_paras()
        if split == "none":
            blocks = [Raw(*N.body(pub))]
        else:
            m_before, m_after, _, lines = N.material(split[:3], 60, "head" if tag == "first" else "tail")
            paras = N.article_paras(N.TARGET, m_before, m_after)
            if tag == "first":
                blocks = [Raw(*lines), Raw(*N.body(pub))]
            else:
                blocks = [Raw(*N.body(pub)), Raw(*lines)]
        pages = N.article_pages(blocks)
        case(f"x_rewrite_{tag}_{split}", "new", paras, pages,
             f"段落の{'最後' if tag == 'last' else '最初' if tag == 'first' else '途中'}の文が校正で書き換えられた（同じくらいの"
             "長さの別の文）。" + ("" if split == "none" else f"段落の{'前' if tag == 'first' else '後ろ'}に表・図がある。")
             + "直すか、決められなければ docx のまま 13 章に出す（docx の文を消すだけにしない）。",
             truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): pub},
             expect={"default": "exact", idx(paras, N.TARGET): "reported"})

# ============================================================================ 10. 校正の置き換えの PDF の文字が、行まるごとを含む（C3）
# docx の語句 OLD を、出版版では NEW（26 文字以上）に置き換えた。PDF では NEW の途中の 1 行が、NEW の文字だけでできている
# （NEW の最初の数文字が前の行の最後、残りが次の行の最初）。行まるごとを外して残りだけで置き換えると、docx にも PDF にもない文字になる
RP_PRE = "第三時の授業では，教師はまず前時に作った表を黒板に掲げ，水を入れる時間と水の深さの関係を振り返らせた。その後，教師の指示により，班の生徒は"
RP_POST = "の表にも矢印をかき，増え方がいつも同じであることを確かめた。"
RP_CASES = [
    ("10to28", "自分のノート", "配られた架空のワークシートに印刷された二つの表のそれぞれ"),
    ("3to30", "各自", "授業の初めに配られた架空のワークシートに印刷された二つ"),
    ("insert", "", "授業の初めに配られた架空のワークシートに印刷された二つ"),
]
for tag, old, new in RP_CASES:
    docx_t = RP_PRE + old + RP_POST
    pub = RP_PRE + new + RP_POST
    first = N.body(RP_PRE + new[:2])          # 最後の行が NEW の最初の 2 文字で終わる（行の幅いっぱい）
    assert len(first[-1]) == 24, (tag, first[-1])
    rest = new[2:]
    assert len(rest) >= 24 + 1, (tag, len(rest))
    lines = first + [rest[:24]] + N.jwrap(rest[24:] + RP_POST)
    assert "".join(lines).lstrip("　") == pub, tag
    paras = base_paras(target=docx_t)
    pages = N.article_pages([Raw(*lines)])
    case(f"x_wholerep_{tag}", "new", paras, pages,
         f"docx の「{old}」を、出版版では「{new}」（{len(new)} 文字）に{'置き換えた' if old else '足した'}。PDF では、その文字の途中の "
         "1 行がまるごとその文字だけでできている。直すか、決められなければ docx のまま 13 章に出す（行まるごとを外した残りの"
         "文字だけで直さない）。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_t): pub},
         expect={"default": "exact", idx(paras, docx_t): "reported"})

# 変わり型: 置き換える docx の語句が長い（8 文字）、新しい語句に行まるごとが 2 行、ページの区切りをまたぐ
RP_MORE = [
    ("8to30", "自分の作った", "授業の初めに配られた架空のワークシートに印刷された二つ", 1, False),
    ("3to56", "各自", "授業の初めに配られた架空のワークシートに印刷された二つの表と，前の時間に自分たちで作った架空の表の両方", 2, False),
    ("3to30_pb", "各自", "授業の初めに配られた架空のワークシートに印刷された二つ", 1, True),
]
for tag, old, new, nwhole, pb in RP_MORE:
    docx_t = RP_PRE + old + RP_POST
    pub = RP_PRE + new + RP_POST
    first = N.body(RP_PRE + new[:2])
    assert len(first[-1]) == 24, (tag, first[-1])
    rest = new[2:]
    assert len(rest) >= 24 * nwhole + 1, (tag, len(rest))
    whole = [rest[24 * k:24 * (k + 1)] for k in range(nwhole)]
    after = N.jwrap(rest[24 * nwhole:] + RP_POST)
    assert "".join(first + whole + after).lstrip("　") == pub, tag
    paras = base_paras(target=docx_t)
    blocks = [Raw(*first)] + ([BREAK] if pb else []) + [Raw(*whole), Raw(*after)]
    pages = N.article_pages(blocks)
    case(f"x_wholerep_{tag}", "new", paras, pages,
         f"x_wholerep_* の変わり型（docx の「{old}」→ 出版版「{new}」{len(new)} 文字。行まるごと {nwhole} 行"
         + ("。その行はページの最初" if pb else "") + "）。直すか、決められなければ docx のまま 13 章に出す（行まるごとを外した"
         "残りの文字だけで直さない）。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_t): pub},
         expect={"default": "exact", idx(paras, docx_t): "reported"})

# 変わり型: 段落の最後の数文字の前でページが変わり、次のページの最初（ページ番号の次）に表がある（表は docx では段落の後ろの
# Word の表）。最後の数文字に校正の直し
for tag, k, pub in TAILFIX + TAILFIX_LONG:
    head_pdf, tail_pdf = pub[:len(N.TARGET) - k], pub[len(N.TARGET) - k:]
    for n in (20, 60):
        m_before, m_after, others, lines = N.material("tab", n, "tail")
        paras = N.article_paras(N.TARGET, m_before, m_after, others_after=others)
        blocks = [N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*N.body(head_pdf)), BREAK,
                  Raw(*lines), Raw(tail_pdf), Raw(*N.body(N.P_AFTER)), N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)),
                  *tail_blocks()]
        case(f"x_tailfix{tag}_tab{n}_pb", "N10", paras, flow(blocks, first=25),
             f"段落の最後の {len(tail_pdf)} 文字（「{tail_pdf}」。docx の「{N.TARGET[-k:]}」を校正で直したもの）の前でページが"
             f"変わり、次のページの最初に表（約 {N.chars(lines)} 文字。docx では段落の後ろの Word の表）がある。直すか、決められ"
             "なければ docx のまま 13 章に出す（docx の最後の文字を消さない。表の文字を足さない）。",
             truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): pub},
             expect={"default": "exact", idx(paras, N.TARGET): "reported"})

# ============================================================================ 11. 追い込みの見出し（4 文字以上。docx では別の段落、PDF では次の段落の最初の行の頭）
RH_DOCX = "（１）架空の目的"
for tag, h_pub, p_pub in (("none", RH_DOCX, N.P_AFTER), ("head", "（１）架空の目標", N.P_AFTER),
                          ("body", RH_DOCX, N.P_AFTER.replace("話し合いの中で", "話し合いでは")),
                          ("both", "（１）架空の目標", N.P_AFTER.replace("話し合いの中で", "話し合いでは"))):
    paras = ([("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("見出し", N.H2), ("本文", N.TARGET),
              ("見出し2", RH_DOCX), ("本文", N.P_AFTER), ("見出し", N.H3), ("本文", N.P_DISC), ("本文", N.P_END),
              ("引用文献見出し", N.RH), ("引用文献", N.REF1), ("引用文献", N.REF2)])
    lines = N.jwrap(h_pub + "　" + p_pub)
    pages = N.article_pages([Raw(*N.body(N.TARGET)), Raw(*lines)])
    paras_ = paras
    truth = {idx(paras_, N.CTRL_DOCX): N.CTRL_PUB}
    exp = {"default": "exact"}
    if h_pub != RH_DOCX:
        truth[idx(paras_, RH_DOCX)] = h_pub
        exp[idx(paras_, RH_DOCX)] = "reported"
    if p_pub != N.P_AFTER:
        truth[idx(paras_, N.P_AFTER)] = p_pub
        exp[idx(paras_, N.P_AFTER)] = "reported"
    case(f"x_runin_{tag}", "new", paras_, pages,
         "見出し（docx では別の段落「" + RH_DOCX + "」）が、PDF では次の段落の最初の行の頭に追い込まれる（全角の空白をはさむ）。"
         + {"none": "違いはない。", "head": "見出しが校正で直された。", "body": "次の段落の書き出しが校正で直された。",
            "both": "見出しと次の段落の書き出しの両方が直された。"}[tag]
         + "直すか、決められなければ 13 章に出す（見出しの文字を本文に足したり、本文の文字を見出しに足したりしない）。",
         truth=truth, expect=exp)

# ============================================================================ 12. 同じ行に 2 つの段落が並ぶ境目の直し（_contests）
# (a) 校正で 2 つの段落が 1 つにつながり（PDF では段落 X の最後と段落 Y の最初が同じ行）、X の最後の文字も直された
X_END_DOCX = N.T_HEAD[:-5] + "確かめる"            # docx は「…確かめる」で終わる（「。」なし）
assert N.T_HEAD.endswith("確かめた。")
X_END_PUB = N.T_HEAD                               # 出版版は「…確かめた。」
for tag, x_pub in (("join_fix", X_END_PUB), ("join_same", X_END_DOCX), ("join_period", X_END_DOCX + "。")):
    paras = base_paras(target=X_END_DOCX, after=N.P_AFTER)
    lines = N.body(x_pub + N.P_AFTER)
    pages = N.article_pages([Raw(*lines)])
    truth = {idx(paras, N.CTRL_DOCX): N.CTRL_PUB}
    exp = {"default": "exact"}
    if x_pub != X_END_DOCX:
        truth[idx(paras, X_END_DOCX)] = x_pub
        exp[idx(paras, X_END_DOCX)] = "reported"
    case(f"x_contest_{tag}", "new", paras, pages,
         "docx の段落 X と次の段落 Y が、PDF では 1 つの段落につながっている（X の最後と Y の最初が同じ行）。"
         + ("X の最後の「確かめる」が校正で「確かめた。」に直された。直すか、決められなければ 13 章に出す。" if x_pub != X_END_DOCX
            else "違いはない。") + "Y に X の文字を足したり、X を途中まで直したりしない。",
         truth=truth, expect=exp)
# (b) 追い込みの見出しで、見出しの最後の 2 文字が直された
paras = ([("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("見出し", N.H2), ("本文", N.TARGET),
          ("見出し2", RH_DOCX), ("本文", N.P_AFTER), ("見出し", N.H3), ("本文", N.P_DISC), ("本文", N.P_END),
          ("引用文献見出し", N.RH), ("引用文献", N.REF1), ("引用文献", N.REF2)])
pages = N.article_pages([Raw(*N.body(N.TARGET)), Raw(*N.jwrap("（１）架空のねらい　" + N.P_AFTER))])
case("x_runin_head2", "new", paras, pages,
     "追い込みの見出し「（１）架空の目的」の最後の 2 文字が、出版版では「ねらい」に直された。直すか、決められなければ 13 章に"
     "出す（見出しを途中まで直したり、見出しの文字を次の段落に足したりしない）。",
     truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, RH_DOCX): "（１）架空のねらい"},
     expect={"default": "exact", idx(paras, RH_DOCX): "reported"})


# ############################################################################ 2 回目の点検（b2_review/r2p。1 回目の修正の後）の反例
# 組（名前の前置き）:
#   y_tailpb*    x_tailfix の形で、分断の後ろの最後の行がページの最後にあり、次のページの最初（ページ番号の次）に柱（著者名。8 文字
#                未満なので何ページにも出る行にならない）がある（_auth）か、ない（_none。対照）
#   y_taildate*  x_tailfix の形で、分断の後ろの最後の行のすぐ後ろ（1 ページ目の最後）に、投稿受付日の行が別の行である（本誌の
#                1 ページ目の形。date1: 1 行、date2b: 2 行の受付日の 2 行目だけ）。次のページは次の段落から始まる
#   y_taildatej* 対照: 受付日が最後の行の後ろに同じ行でつながる
#   y_tailfix*_fig* / y_tailfig*  分断の後ろが最後の 7〜12 文字（校正の直しあり）で、分断する文字が小さな図（図の中の文字は、よく
#                使う文字〈の・を・時など〉を含む）
#   y_loose_*    段落の最後の文が校正で消され、段落のすぐ後ろの図（キャプションは図の上）の中の文字の最後の行が、消された文と半分
#                以上同じ文字で、最後の「。」も同じ
#   y_loosehead_* 段落の最初の語が校正で消され、すぐ前の図（キャプションは図の下）の中の文字の最初の行が、消された語と似ている
#   y_rep1_*     校正の置き換えの PDF の文字が、段落の行の幅の行まるごと 1 行を含み、その行が置き換えの最初（行の最初から）か
#                最後（行の最後まで）にある（x_wholerep は行の前と後ろの両方に PDF の文字が続く形）。x: 置き換えられる docx の語句が、
#                行まるごとの文字と 1 文字も同じでない
# 結果（2026-10-19。作業ツリー〈0.21.0。修正担当の v6〉・点検した版 W・0.20.0。oracle/results_r2p_x_cur3・W3・base3.json）:
#   y_tailpb 24: 作業ツリー FAIL 9（_auth だけ。どれも docx の最後の文字を消す）。0.20.0 が OK で作業ツリーが FAIL: 3
#   y_taildate 32 と _col 12: 作業ツリー FAIL 26（docx の最後の文字を消す。fig20 の 7 文字は図の文字も足す）。0.20.0 が OK で FAIL: 11
#   y_taildatej 8（対照）: 作業ツリーは 8 件とも REPORTED（UNSURE。docx のまま）
#   y_tailfix*_fig* 6・y_tailfig* 24: 作業ツリー FAIL 5（図の中の文字「の表」を足し、docx の「間」を消す）。0.20.0 が OK で FAIL: 3
#     （0.20.0 は y_tailfig* で FAIL 11。全体では作業ツリーのほうがよい）
#   y_loose 3: 作業ツリー FAIL 3（図の中の文字を足す。W は OK 2・REPORTED 1、0.20.0 は FAIL 3〈もっと多く足す〉）
#   y_loosehead 2: 作業ツリー REPORTED 2（W・0.20.0 は OK）
#   y_rep1 9: 0.20.0 が OK で、作業ツリーが docx にも PDF にもない文にするもの 4（end8x・end10x は FAIL、start8x・start10x は
#     「…生徒たちはた二つの表…」。runner は足した文字が truth にあるので REPORTED と判定する）
#   試作（b2_review/r2p/proto4_vs_cur_pdfmatch.patch。proto4_src）: y_ の FAIL はすべてなくなる（x_ の 97 件は作業ツリーと同じ）。
#     ほかの反例集・pytest 442 件・本誌の PDF 7 通り・td1〜3 の照合は作業ツリーと同じ。quick は VIOLATION 30 → 21（悪い段落 0）、
#     fuzz4 は同じ、fuzz8 は悪い段落 0・よい段落 1（proto3 は片側の行まるごとの違いの範囲が狭く、fuzz8 で 10 段落悪くなった）。
from runner import received_line  # noqa: E402

Y_TAILFIX = [
    ("4a", 4, N.TARGET[:-4] + "持った。"),
    ("3", 3, N.TARGET[:-3] + "てた。"),
    ("6", 6, N.TARGET[:-6] + "間を取る。"),
    ("7", 7, N.TARGET[:-7] + "時間を設けた。"),
]


def y_with_head(pages, k, head):
    """k ページ目（0 から）のページ番号の行の次に、柱の行 head を入れる。"""
    ls = pages[k].split("\n")
    pages = list(pages)
    pages[k] = "\n".join(ls[:1] + [head] + ls[1:])
    return pages


def y_blocks(head_pdf, lines, tail_rows):
    return [N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*N.body(head_pdf)),
            Raw(*lines), Raw(*tail_rows), BREAK, Raw(*N.body(N.P_AFTER)), N.H3, Raw(*N.body(N.P_DISC)),
            Raw(*N.body(N.P_END)), *tail_blocks()]


Y_DATE2 = ("2025年２月27日投稿受付，2025年７月30日再投稿受付，", "2025年10月10日採用決定")
for tag, k, pub in Y_TAILFIX:
    head_pdf, tail_pdf = pub[:len(N.TARGET) - k], pub[len(N.TARGET) - k:]
    assert head_pdf == N.TARGET[:-k], tag
    truth_note = (f"段落の最後の {len(tail_pdf)} 文字（「{tail_pdf}」。docx の「{N.TARGET[-k:]}」を校正で直したもの）が、")
    for kind, n in (("tab", 20), ("tab", 60), ("para", 20), ("para", 60), ("fig", 20)):
        m_before, m_after, others, lines = N.material(kind, n, "tail")
        paras = N.article_paras(N.TARGET, m_before, m_after, others_after=others)
        what = f"{N.KIND_NOTE[kind].format(side='後ろ', side2='2 つ後ろ')}（約 {N.chars(lines)} 文字）"
        truth = {idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): pub}
        exp = {"default": "exact", idx(paras, N.TARGET): "reported"}
        if kind != "fig" and (kind, n) != ("para", 60):
            for hk, head in (("auth", "試験　五郎"), ("none", None)):
                pages = flow(y_blocks(head_pdf, lines, [tail_pdf]), first=25)
                if head:
                    pages = y_with_head(pages, 1, head)
                case(f"y_tailpb{tag}_{kind}{n}_{hk}", "N10", paras, pages,
                     truth_note + f"{what}の後ろの、ページの最後の行にある。次のページは"
                     + (f"柱「{head}」の行の後に" if head else "") + "次の段落から始まる。直すか、決められなければ docx のまま"
                     " 13 章に出す（docx の最後の文字を消さない。分断する文字を足さない）。", truth=truth, expect=exp)
        if kind != "tab" or n == 20:
            for dk, dl in (("date1", (received_line(),)), ("date2b", Y_DATE2[1:])):
                case(f"y_taildate{tag}_{kind}{n}_{dk}", "N10", paras, flow(y_blocks(head_pdf, lines, [tail_pdf, *dl]), first=25),
                     truth_note + f"{what}の後ろの行にあり、そのすぐ後ろ（1 ページ目の最後）に投稿受付日の行（{len(dl)} 行。別の行）"
                     "がある。次のページは次の段落から始まる。直すか、決められなければ docx のまま 13 章に出す（docx の最後の文字を"
                     "消さない。分断する文字・受付日の文字を足さない）。", truth=truth, expect=exp)
        if (kind, n) in (("tab", 20), ("para", 60)):
            case(f"y_taildatej{tag}_{kind}{n}", "N10", paras,
                 flow(y_blocks(head_pdf, lines, [tail_pdf + received_line()]), first=25),
                 truth_note + f"{what}の後ろの行にあり、その行に受付日が同じ行でつながる（対照）。直すか、決められなければ"
                 " docx のまま 13 章に出す。", truth=truth, expect=exp)

# 分断の後ろが最後の 7〜12 文字（校正の直しあり）で、分断する文字が図（x_tailfix の TAILFIX_LONG は表・段落だけ）
for tag, k, pub in (("7", 7, N.TARGET[:-7] + "時間を設けた。"), ("9", 9, N.TARGET[:-9] + "合う場を設けた。"),
                    ("12", 12, N.TARGET[:-12] + "説明する時間を取った。")):
    head_pdf, tail_pdf = pub[:len(N.TARGET) - k], pub[len(N.TARGET) - k:]
    for n in (20, 60):
        m_before, m_after, others, lines = N.material("fig", n, "tail")
        paras = N.article_paras(N.TARGET, m_before, m_after, others_after=others)
        pages = N.article_pages([Raw(*N.body(head_pdf)), Raw(*lines), Raw(tail_pdf)])
        case(f"y_tailfix{tag}_fig{n}", "N10", paras, pages,
             f"PDF では段落の最後の {len(tail_pdf)} 文字（「{tail_pdf}」の 1 行。docx の「{N.TARGET[-k:]}」を校正で直したもの）の"
             f"前に、図の中の文字と図のキャプション（約 {N.chars(lines)} 文字）が入る。直すか、決められなければ docx のまま 13 章に"
             "出す（docx の最後の文字を消さない。図の中の文字を足さない）。",
             truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): pub},
             expect={"default": "exact", idx(paras, N.TARGET): "reported"})

Y_FIGS = {
    "a": ["導入", "↓", "前時の表を振り返る"],
    "b": ["まとめ", "↓", "分かったことを書く"],
    "c": ["課題の提示", "↓", "個人で考える時間"],
    "d": ["説明を聞く", "↓", "取り組みを話し合う"],
}
Y_CAP = "図１　架空の授業の流れ"
for tag, k, pub in (("4a", 4, N.TARGET[:-4] + "持った。"), ("6", 6, N.TARGET[:-6] + "間を取る。"),
                    ("7", 7, N.TARGET[:-7] + "時間を設けた。"), ("9", 9, N.TARGET[:-9] + "合う場を設けた。"),
                    ("7b", 7, N.TARGET[:-7] + "機会を取った。"), ("8", 8, N.TARGET[:-8] + "う時間をとった。")):
    head_pdf, tail_pdf = pub[:len(N.TARGET) - k], pub[len(N.TARGET) - k:]
    for fk, fig in Y_FIGS.items():
        paras = N.article_paras(N.TARGET, (), [("画像", "".join(fig)), ("図キャプション", Y_CAP)])
        pages = N.article_pages([Raw(*N.body(head_pdf)), Raw(*fig, Y_CAP), Raw(tail_pdf)])
        case(f"y_tailfig{tag}_{fk}", "N10", paras, pages,
             f"段落の最後の {len(tail_pdf)} 文字（「{tail_pdf}」。docx の「{N.TARGET[-k:]}」を校正で直したもの）が、小さな図"
             f"（図の中の文字「{'／'.join(fig)}」とキャプション）の後ろの行に出る。直すか、決められなければ docx のまま 13 章に出す"
             "（docx の最後の文字を消さない。図の中の文字を足さない）。",
             truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): pub},
             expect={"default": "exact", idx(paras, N.TARGET): "reported"})

# 消された最後の文と、すぐ後ろの図の中の文字の最後の行（キャプションは図の上）
Y_FIG2_CAP = "図２　架空の問題"
for tag, deleted, fig in (("solve", "その問題を示す。", ["問題　水を入れる時間と深さの", "関係を表に表し，その決まりを",
                                                     "問題を解きなさい。"]),
                          ("answer", "これを図２に示す。", ["次の表を完成させ，", "これを示しなさい。"]),
                          ("short", "を示した。", ["表に数を書き入れ", "を示せ。"])):
    docx_t = N.TARGET + deleted
    paras = ([("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("見出し", N.H2), ("本文", docx_t),
              ("図キャプション", Y_FIG2_CAP), ("画像", "".join(fig)), ("本文", N.P_AFTER), ("見出し", N.H3),
              ("本文", N.P_DISC), ("本文", N.P_END), ("引用文献見出し", N.RH), ("引用文献", N.REF1), ("引用文献", N.REF2)])
    pages = N.article_pages([Raw(*N.body(N.TARGET)), Raw(Y_FIG2_CAP, *fig)])
    case(f"y_loose_{tag}", "new", paras, pages,
         f"docx の段落の最後の文「{deleted}」は、出版版では消されている。段落のすぐ後ろに図（docx では画像で、キャプションは"
         f"図の上）があり、図の中の文字の最後の行「{fig[-1]}」が、消された文と似ている。消すか、決められなければ docx のまま"
         " 13 章に出す（図の中の文字を段落に足さない）。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_t): N.TARGET},
         expect={"default": "exact", idx(paras, docx_t): "reported"})
# 段落の最初の語が消され、すぐ前の図（キャプションは図の下）の中の文字の最初の行が似ている
for tag, deleted, fig in (("then", "そこで，", ["そこで", "表を作る", "↓", "規則を見つける"]),
                          ("first", "まず初めに，", ["まず表を作る", "↓", "規則を言葉で書く"])):
    docx_a = deleted + N.P_AFTER
    paras = ([("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("見出し", N.H2), ("本文", N.TARGET),
              ("画像", "".join(fig)), ("図キャプション", Y_FIG2_CAP), ("本文", docx_a), ("見出し", N.H3),
              ("本文", N.P_DISC), ("本文", N.P_END), ("引用文献見出し", N.RH), ("引用文献", N.REF1), ("引用文献", N.REF2)])
    pages = N.article_pages([Raw(*N.body(N.TARGET)), Raw(*fig, Y_FIG2_CAP)])
    case(f"y_loosehead_{tag}", "new", paras, pages,
         f"docx の段落の最初の語「{deleted}」は、出版版では消されている。段落のすぐ前に図（docx では画像で、キャプションは"
         f"図の下）があり、図の中の文字の最初の行「{fig[0]}」が、消された語と似ている。消すか、決められなければ docx のまま"
         " 13 章に出す（図の中の文字を段落に足さない）。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_a): N.P_AFTER},
         expect={"default": "exact", idx(paras, docx_a): "reported"})

# 行まるごと 1 行を含む置き換えで、その行が置き換えの最初・最後
Y_PRE24 = ("第三時の授業では，教師はまず前時に作った表を黒板に掲げ，水を入れる時間と水の深さの関係を振り返らせた。"
           "その後，教師の指示により，班の生徒たちは")        # 最後の行が 24 文字（行の幅いっぱい）
Y_PRE22 = ("第三時の授業では，教師はまず前時に作った表を黒板に掲げ，水を入れる時間と水の深さの関係を振り返らせた。"
           "その後，教師の指示により，班の生徒は")            # 最後の行が 22 文字
Y_POST = "の表にも矢印をかき，増え方がいつも同じであることを確かめた。"
Y_NEW27 = "授業の初めに配られた架空のワークシートに印刷された二つ"          # 27 文字
Y_NEW26 = "授業の初めに配られた架空のワークシートに印刷された二"            # 26 文字
assert len(N.body(Y_PRE24)[-1]) == 24 and len(N.body(Y_PRE22)[-1]) == 22
Y_REP1 = []
for old in ("自分たちの作った", "自分自身が書いて", "自分自身が書いて持参"):
    x = "x" if "身" in old else ""
    lines = N.body(Y_PRE24) + [Y_NEW27[:24]] + N.jwrap(Y_NEW27[24:] + Y_POST)
    for pb in (False, True):
        Y_REP1.append((f"start{len(old)}{x}{'_pb' if pb else ''}", Y_PRE24 + old + Y_POST, Y_PRE24 + Y_NEW27 + Y_POST,
                       lines, old, Y_NEW27, pb, len(N.body(Y_PRE24))))
    first = N.body(Y_PRE22 + Y_NEW26[:2])
    assert len(first[-1]) == 24 and len(Y_NEW26[2:]) == 24
    Y_REP1.append((f"end{len(old)}{x}", Y_PRE22 + old + Y_POST, Y_PRE22 + Y_NEW26 + Y_POST,
                   first + [Y_NEW26[2:]] + N.jwrap(Y_POST), old, Y_NEW26, False, 0))
for tag, docx_t, pub, lines, old, new, pb, cut in Y_REP1:
    assert "".join(lines).lstrip("　") == pub, tag
    paras = ([("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("見出し", N.H2), ("本文", docx_t),
              ("本文", N.P_AFTER), ("見出し", N.H3), ("本文", N.P_DISC), ("本文", N.P_END), ("引用文献見出し", N.RH),
              ("引用文献", N.REF1), ("引用文献", N.REF2)])
    blocks = [Raw(*lines[:cut]), BREAK, Raw(*lines[cut:])] if pb else [Raw(*lines)]
    case(f"y_rep1_{tag}", "new", paras, N.article_pages(blocks),
         f"docx の「{old}」（{len(old)} 文字）を、出版版では「{new}」（{len(new)} 文字）に置き換えた。PDF では、その文字の"
         + ("最初の 24 文字が行まるごと（行の最初から）" if tag.startswith("start") else "最後の 24 文字が行まるごと（行の最後まで）")
         + ("。その行は次のページの最初の行" if pb else "") + "。直すか、決められなければ docx のまま 13 章に出す（行まるごとを"
         "外した残りの文字だけで直さない）。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_t): pub},
         expect={"default": "exact", idx(paras, docx_t): "reported"})

# y_taildate の変わり型（_col）: 受付日の行が段の区切り（ページの途中。左の段の最後）にあり、次の段落が同じページの次の段から始まる
for tag, k, pub in Y_TAILFIX:
    head_pdf, tail_pdf = pub[:len(N.TARGET) - k], pub[len(N.TARGET) - k:]
    for kind, n in (("tab", 20), ("para", 20), ("para", 60)):
        m_before, m_after, others, lines = N.material(kind, n, "tail")
        paras = N.article_paras(N.TARGET, m_before, m_after, others_after=others)
        blocks = [x for x in y_blocks(head_pdf, lines, [tail_pdf, Y_DATE2[1]]) if x is not BREAK] + []
        blocks = y_blocks(head_pdf, lines, [tail_pdf, Y_DATE2[1]])
        blocks = blocks[:blocks.index(BREAK)] + blocks[blocks.index(BREAK) + 1:]
        case(f"y_taildate{tag}_{kind}{n}_col", "N10", paras, flow(blocks, first=25),
             f"段落の最後の {len(tail_pdf)} 文字（「{tail_pdf}」。docx の「{N.TARGET[-k:]}」を校正で直したもの）が、"
             f"{N.KIND_NOTE[kind].format(side='後ろ', side2='2 つ後ろ')}の後ろの行にあり、そのすぐ後ろに投稿受付日だけの行（段の"
             "区切り）があって、次の段落が同じページで続く。直すか、決められなければ docx のまま 13 章に出す（docx の最後の文字を"
             "消さない）。",
             truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): pub},
             expect={"default": "exact", idx(paras, N.TARGET): "reported"})


# ############################################################################ 3 回目の点検（b2_review/r3p。2 回目の修正の後）の反例
# 組（名前の前置き）:
#   z_figsim_del*   段落の最後の文が校正で消され（「…時間を取った。その結果を表に示す。」→「…時間を取った。」）、PDF では段落の最後の
#                   行「時間を取った。」が小さな図（docx では段落のすぐ後ろの画像。キャプションは図の下）の後ろに出る。図の中の文字の
#                   キャプションの前の行が、段落の最後の行と最初の 3 文字（「時間を」）が同じ（「時間を見る」「時間を書く」「時間を計る」）
#   z_figsim_rew*   段落の最後の語句が校正で書き換えられ（docx「…時間を取る」〈句点なし〉→「…場を設けた。」）、図の中の最後の行が
#                   docx の最後の文字とよく似ている（「時間を見る」）か、docx の最後の文字と同じ文字で終わる（「表を見る」）
#   z_figsim_head*  段落の最初の語句が書き換えられ（「話し合いの中で」→「議論の中で」）、PDF では段落の最初の 7 文字の行の後ろに
#                   小さな図（docx では段落のすぐ前の画像とキャプション）があり、図の中の最初の行（「話し合いの場面」）が docx の
#                   最初の文字とよく似ている
#   z_copy_*        段落の最後の語句が直され（「合う時間を取った。」→「合う場を設けた。」）、段落の最後の行が小さな図（キャプションは
#                   図の上）の後ろに出る。図の中の最後の行が段落の文字の写し（「説明し合う時間」）
#   （_date: 段落の最後の行のすぐ後ろが 1 ページ目の最後の投稿受付日の行、_pbhead: 次のページの最初に柱、_direct: すぐ次の段落）
# 結果（2026-10-19。作業ツリー〈0.21.0。2 回目の修正の後〉・2 回目の点検の版 R2〈fixB2r2/before_src〉・0.20.0。
#   oracle/results_r3p_z_cases_cur・R2・base.json）:
#   z_figsim_del 9: 作業ツリー・R2 は 9 件とも FAIL（図の中の文字「見る」「書く」「計る」を足し、PDF の本文の「取った。」を消す）。
#     0.20.0 は _date・_pbhead の 6 件が REPORTED（docx のまま 13 章）、_direct の 3 件が FAIL（黙って直さない）
#   z_figsim_rew 4: 作業ツリー・R2 は REPORTED 4。0.20.0 は FAIL 3・REPORTED 1
#   z_figsim_head 2: 3 つの版とも FAIL（0.20.0 からの形）
#   z_copy 2: 作業ツリーは OK 2（R2 は _pbhead が REPORTED、0.20.0 は REPORTED 1・FAIL 1）
#   試作 proto3（b2_review/r3p/proto3_vs_cur_pdfmatch.patch。_Joint.result で、本文の流れの段落の最後〈最初〉の塊の行が、前〈後ろ〉の
#     塊の行から、どの段落にも当たらない行〈図の中の文字〉だけで隔てられ、その行のすぐ後ろ〈前〉が本文の流れでない段落〈キャプション
#     など〉の塊なら、その行を doubt〈DISPLACED_WHY〉にする）: z_figsim_del 9 件 → REPORTED（docx のまま 13 章）。pytest 507 件は通り、
#     反例集（この 234 件・y・y2・o34・n10・n10g・rv89・cj・cj2・b2・xm・r1）で作業ツリーより悪い例は 0。本誌の PDF 7 通りと td1〜3 の
#     出力は作業ツリーと同じ。架空の生成例（b2_review/r3p/exp の gen_*.py。h2.py）で、作業ツリーが FAIL で 0.20.0 が OK・REPORTED の
#     例は figpre 16・figsim 15・tail 3・pages 8 → 0（dup 9 → 5、head 2 → 2 は残る）。
#   （別の試作 proto〈stray_edge で穴の最初の部分とも比べる〉も z_figsim_del を直すが、図の中の行の一致が消された文の文字に散る形
#     〈図の中の行「時間の表」〉は直らない）
Z_CAP = "図１　架空の授業の流れ"
FIG_HEAD = ["導入", "↓", "課題の提示", "↓"]


def z_pages(head_pdf_lines, mid, tail_rows, after):
    """1 ページ目: 冒頭〜段落の最後の行の前まで・mid（図）・tail_rows（段落の最後の行）。after: direct（そのまま次の段落）・
    date（受付日の行の後でページが変わる）・pbhead（ページが変わり、次のページの最初に柱）。"""
    first = [N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*head_pdf_lines), Raw(*mid),
             Raw(*tail_rows)]
    if after == "date":
        first += [Raw(received_line()), BREAK]
    elif after == "pbhead":
        first += [BREAK]
    rest = [Raw(*N.body(N.P_AFTER)), N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()]
    pages = flow(first + rest, first=25)
    if after == "pbhead":
        ls = pages[1].split("\n")
        pages[1] = "\n".join(ls[:1] + ["試験　五郎"] + ls[1:])
    return pages


# z_figsim_del*: 消された最後の文と、段落の最後の行と同じ文字で始まる図の中の行
DELETED = "その結果を表に示す。"
for fk, last in (("see", "時間を見る"), ("write", "時間を書く"), ("measure", "時間を計る")):
    docx_t = N.TARGET + DELETED
    paras = N.article_paras(docx_t, (), [("画像", "".join(FIG_HEAD + [last])), ("図キャプション", Z_CAP)])
    for after in ("date", "pbhead", "direct"):
        pages = z_pages(N.body(N.TARGET[:-7]), FIG_HEAD + [last, Z_CAP], [N.TARGET[-7:]], after)
        case(f"z_figsim_del_{fk}_{after}", "N10", paras, pages,
             f"docx の段落の最後の文「{DELETED}」は出版版で消されている。PDF では段落の最後の行「{N.TARGET[-7:]}」が、小さな図"
             f"（図の中の文字「{'／'.join(FIG_HEAD + [last])}」とキャプション）の後ろに出る。図の中の最後の行「{last}」は、段落の"
             "最後の行と最初の 3 文字が同じ。消すか、決められなければ docx のまま 13 章に出す（図の中の文字を足さない。段落の最後の"
             "行の文字を消さない）。",
             truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_t): N.TARGET},
             expect={"default": "exact", idx(paras, docx_t): "reported"})

# z_figsim_rew*: 書き換えられた最後の語句（docx は句点なし）と、よく似た図の中の行
REW_DOCX = N.TARGET[:-len("時間を取った。")] + "時間を取る"
REW_PUB = N.TARGET[:-len("時間を取った。")] + "場を設けた。"
for fk, last in (("see", "時間を見る"), ("table", "表を見る")):
    paras = N.article_paras(REW_DOCX, (), [("画像", "".join(FIG_HEAD + [last])), ("図キャプション", Z_CAP)])
    lines = N.body(REW_PUB)
    for after in ("date", "direct"):
        pages = z_pages(lines[:-1], FIG_HEAD + [last, Z_CAP], lines[-1:], after)
        case(f"z_figsim_rew_{fk}_{after}", "N10", paras, pages,
             f"docx の段落の最後の「時間を取る」（句点なし）は、出版版で「場を設けた。」に書き換えられている。PDF では段落の最後の"
             f"行「{lines[-1]}」が、小さな図の後ろに出る。図の中の最後の行「{last}」が docx の最後の文字とよく似ている。直すか、"
             "決められなければ docx のまま 13 章に出す（図の中の文字を足さない。段落の文字を消さない）。",
             truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, REW_DOCX): REW_PUB},
             expect={"default": "exact", idx(paras, REW_DOCX): "reported"})

# z_figsim_head*: 段落の最初の語句の書き換えと、よく似た図の中の最初の行
HEAD_PUB = N.P_AFTER.replace("話し合いの中で", "議論の中で")
FIG_H = ["話し合いの場面", "↓", "課題の提示", "↓", "まとめ"]
paras_h = ([("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("見出し", N.H2), ("本文", N.TARGET),
            ("画像", "".join(FIG_H)), ("図キャプション", Z_CAP), ("本文", N.P_AFTER), ("見出し", N.H3),
            ("本文", N.P_DISC), ("本文", N.P_END), ("引用文献見出し", N.RH), ("引用文献", N.REF1), ("引用文献", N.REF2)])
for before in ("date", "pbhead"):
    first = [N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*N.body(N.TARGET))]
    first += [Raw(received_line()), BREAK] if before == "date" else [BREAK]
    rest = [Raw("　" + HEAD_PUB[:7]), Raw(*FIG_H, Z_CAP), Raw(*N.jwrap(HEAD_PUB[7:])), N.H3, Raw(*N.body(N.P_DISC)),
            Raw(*N.body(N.P_END)), *tail_blocks()]
    pages = flow(first + rest, first=25)
    if before == "pbhead":
        ls = pages[1].split("\n")
        pages[1] = "\n".join(ls[:1] + ["試験　五郎"] + ls[1:])
    case(f"z_figsim_head_{before}", "N10", paras_h, pages,
         "docx の段落の最初の「話し合いの中で」は、出版版で「議論の中で」に書き換えられている。PDF では段落の最初の 7 文字の行の"
         "後ろに小さな図（docx では段落のすぐ前の画像とキャプション）があり、図の中の最初の行「話し合いの場面」が docx の最初の"
         "文字とよく似ている。直すか、決められなければ docx のまま 13 章に出す（図の中の文字を足さない。段落の文字を消さない）。",
         truth={idx(paras_h, N.CTRL_DOCX): N.CTRL_PUB, idx(paras_h, N.P_AFTER): HEAD_PUB},
         expect={"default": "exact", idx(paras_h, N.P_AFTER): "reported"})

# z_copy_pbhead: 図の中の段落の文字の写しと、ページの区切り・柱（2 回目の修正の _loose_edge の飛ばしで REPORTED → FAIL）
COPY_PUB = N.TARGET[:-len("合う時間を取った。")] + "合う場を設けた。"
FIG_C = ["導入", "↓", "課題の提示", "↓", "説明し合う時間"]
paras_c = N.article_paras(N.TARGET, (), [("図キャプション", Z_CAP), ("画像", "".join(FIG_C))])
lines_c = N.body(COPY_PUB)
for after in ("pbhead", "direct"):
    pages = z_pages(lines_c[:-1], [Z_CAP] + FIG_C, lines_c[-1:], after)
    case(f"z_copy_{after}", "N10", paras_c, pages,
         "段落の最後の「合う時間を取った。」は、出版版で「合う場を設けた。」に直されている。PDF では段落の最後の行が、小さな図"
         "（キャプションは図の上）の後ろに出る。図の中の最後の行「説明し合う時間」は段落の文字の写し。直すか、決められなければ"
         " docx のまま 13 章に出す（図の中の文字を足さない。段落の文字を消さない）。",
         truth={idx(paras_c, N.CTRL_DOCX): N.CTRL_PUB, idx(paras_c, N.TARGET): COPY_PUB},
         expect={"default": "exact", idx(paras_c, N.TARGET): "reported"})


# ############################################################################ 4 回目の点検（b2_review/r4p。3 回目の修正の後）の反例
# 組（名前の前置き）:
#   w_figwidth_*  z_figsim_del の形（段落の最後の文が校正で消され、本文の最後の行がキャプションの後ろに出て、キャプションのすぐ前の
#                 図の中の行が最後の行とよく似ている）で、図の中の行と本文の最後の行が、英数字の全角・半角（_digit・_letter）か
#                 大文字・小文字（_case）だけ違う（「時間を2回見る」と本文「時間を２回取った。」）。3 回目の修正の
#                 _Joint.figure_edge_lines は、その行の文字の違いを直さない（DISPLACED_WHY）が、その行と並べた docx の文字の
#                 全角・半角・大文字・小文字は、図の中の文字に合わせて直してしまう（「２回」→「2回」）
#   w_capnext_*   段落の最後の 1 行が、1 ページ目の最後の投稿受付日の行の後ろ（次のページの最初・同じページの次の段の最初）に出て、
#                 そのすぐ後ろに表のキャプション（表は docx でも段落のすぐ後ろ）か図の上のキャプションがある（本当の段落の行）。
#                 その行の校正の直しは直すのが望ましい（_Joint.figure_edge_lines の (A) は、間の行が受付日の行だけでも働き、
#                 直さない違い〈DISPLACED_WHY〉にする）
#   w_capprev_*   段落の最初の 1 行が、図のキャプション（図の下）のすぐ後ろ、1 ページ目の最後の投稿受付日の行の前にある（頭の側の同じ形）
#   w_copywidth_* 図の中の原稿の写し（recheck_runs の doubt）の数字が半角（「3倍」）。写しと並べた docx の「３」を「3」にしないか
#   w_figwidth_head_* 頭の側。段落の最初の行のすぐ後ろの図の中の行（「第2時の話し合い」）と、段落ごとの照合が分断する図の中の
#                 文字とみなした位置（floaty）で並べた docx の「２」を「2」にしないか
# 結果（2026-10-19。作業ツリー〈0.21.0。3 回目の修正の後〉・3 回目の修正の前の版 R3〈fixB2r3/before_src〉・0.20.0・試作 p8・p58。
#   oracle/results_r4p_w_cases_cur・R3・base・p8・p58.json。19 件）:
#   w_figwidth 5: 作業ツリー FAIL 5（「２」→「2」・「Ａ」→「A」・「A」→「a」。13.1 にふつうの全角・半角の直しとして出る）、R3 FAIL 5
#     （図の中の文字「見る」も足す）、0.20.0 REPORTED 4・FAIL 1（_direct。黙って直さない）
#   w_capnext 8・w_capprev 2: 作業ツリー FAIL 10（直していない。13.2 に DISPLACED_WHY）、R3 OK 10、0.20.0 OK 6・FAIL 4（delsent。
#     表のセルを足す・消された文の一部を残す）
#   w_copywidth: dup は 4 つの版とも OK。deldup は 4 つの版とも FAIL（「3」を足す。0.20.0 は「．」も）
#   w_figwidth_head 2: 作業ツリー・R3 FAIL（「２」→「2」）、0.20.0 FAIL（「提示」を足し「第２時」を消す）
#   試作 p8（b2_review/r4p/proto8_vs_cur_pdfmatch.patch。figure_edge_lines の行と floaty の位置の全角・半角・大文字・小文字・ダッシュを
#     直さない）: w_figwidth 5・w_figwidth_head 2 → REPORTED。試作 p58（p8 + proto5〈間が受付日・ページの端の行だけなら、キャプションの
#     側の隣の段落の端に穴があるときだけ (A)〉。proto58_vs_cur_pdfmatch.patch）: OK 11・REPORTED 7・FAIL 1（w_copywidth deldup だけ）
W_BASE = N.TARGET[:-len("時間を取った。")]
W_DEL = "その結果を表に示す。"
W_VARIANTS = {
    # 名前: (docx と本文の最後の行の文字, 図の中のキャプションのすぐ前の行)
    "digit": ("時間を２回取った。", "時間を2回見る"),
    "letter": ("時間をＡ班で取った。", "時間をA班で見る"),
    "case": ("時間をA班で取った。", "時間をa班で見る"),
}
for vk, (last, figline) in W_VARIANTS.items():
    docx_t, pub_t = W_BASE + last + W_DEL, W_BASE + last
    paras = N.article_paras(docx_t, (), [("画像", "".join(FIG_HEAD + [figline])), ("図キャプション", Z_CAP)])
    for after in (("date", "pbhead", "direct") if vk == "digit" else ("date",)):
        pages = z_pages(N.body(pub_t[:-len(last)]), FIG_HEAD + [figline, Z_CAP], [last], after)
        case(f"w_figwidth_{vk}_{after}", "N10", paras, pages,
             f"docx の段落の最後の文「{W_DEL}」は出版版で消されている。PDF では段落の最後の行「{last}」が、小さな図（キャプションは"
             f"図の下）の後ろに出る。図の中のキャプションのすぐ前の行「{figline}」は、本文の最後の行と英数字の全角・半角（大文字・"
             "小文字）だけが違う。消すか、決められなければ docx のまま 13 章に出す（図の中の文字に合わせて、本文の英数字の全角・半角・"
             "大文字・小文字を変えない）。",
             truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_t): pub_t},
             expect={"default": "exact", idx(paras, docx_t): "reported"})


def w_front_pages(first_blocks, second_blocks):
    """1 ページ目: 冒頭・見出し・first_blocks、2 ページ目以降: second_blocks と残り（引用文献・英文）。"""
    return flow([N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, *first_blocks, *second_blocks,
                 N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()], first=25)


W_TCAP, W_ROWS = N.table_rows(20)
W_EDITS = {"e4": (N.TARGET, N.TARGET[:-4] + "持った。"),
           "delsent": (N.TARGET + W_DEL, N.TARGET)}
for ek, (docx_t, pub_t) in W_EDITS.items():
    lines = N.body(pub_t)
    for mk in ("tab", "figabove"):
        if mk == "tab":
            mat = [("表キャプション", W_TCAP), ("表", W_ROWS)]
            mid = N.table_lines(W_TCAP, W_ROWS)
        else:
            mat = [("図キャプション", Z_CAP), ("画像", "授業の流れ")]
            mid = [Z_CAP, *FIG_HEAD, "まとめ"]
        paras = N.article_paras(docx_t, (), mat)
        for ak in ("date", "coldate"):
            head = [Raw(*lines[:-1]), Raw(received_line())] + ([BREAK] if ak == "date" else [])
            pages = w_front_pages(head, [Raw(lines[-1]), Raw(*mid), Raw(*N.body(N.P_AFTER))])
            case(f"w_capnext_{ek}_{mk}_{ak}", "N10", paras, pages,
                 f"段落の最後の行「{lines[-1]}」（校正の直しあり）が、1 ページ目の最後の投稿受付日の行の後ろ（"
                 f"{'次のページの最初' if ak == 'date' else '同じページの次の段の最初'}）に出て、そのすぐ後ろに"
                 f"{'表のキャプション（表は docx でも段落のすぐ後ろ）' if mk == 'tab' else '図の上のキャプション'}がある。"
                 "本当の段落の行なので、出版版の文字に直す（0.20.0 と 3 回目の修正の前の版は直す）。",
                 truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_t): pub_t})

# w_capprev_*: 頭の側。段落 P_AFTER の最初の行が、図のキャプション（図の下）のすぐ後ろ、1 ページ目の最後の受付日の行の前にある
W_HEAD_PUB = N.P_AFTER.replace("話し合いの中で", "議論の中で")
for ak in ("date", "coldate"):
    hl = N.body(W_HEAD_PUB)
    paras = N.article_paras(N.TARGET, (), [("画像", "授業の流れ"), ("図キャプション", Z_CAP)])
    head = [Raw(*N.body(N.TARGET)), Raw(*FIG_HEAD, "まとめ", Z_CAP), Raw(hl[0]), Raw(received_line())] + \
        ([BREAK] if ak == "date" else [])
    pages = flow([N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, *head, Raw(*hl[1:]),
                  N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
    case(f"w_capprev_w1_{ak}", "N10", paras, pages,
         f"段落の最初の行「{hl[0]}」（「話し合いの中で」→「議論の中で」の校正の直しあり）が、図のキャプション（図の下）のすぐ"
         f"後ろ、1 ページ目の最後の投稿受付日の行の前にあり、段落の残りは{'次のページ' if ak == 'date' else '同じページの次の段'}"
         "に続く。本当の段落の行なので、出版版の文字に直す（0.20.0 と 3 回目の修正の前の版は直す）。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.P_AFTER): W_HEAD_PUB})

# w_copywidth_*: 図の中の原稿の写し（recheck_runs・find_hole の doubt。DISPLACED_WHY）の英数字が、docx・本文と全角・半角だけ違う形
# （N10 の n10_tail_fig200_dup・deldup の写しの「３倍」を「3倍」にしたもの）。写しと並べた docx の文字の全角・半角を、写しの文字に
# 合わせて直さないか
W_COPY = N.T_TAIL.replace("。", "．").replace("３", "3")
for dk in ("dup", "deldup"):
    m_before, m_after, others, lines = N.material("fig", 200, "tail")
    half = len(lines) // 2
    fig = lines[:half] + N.jwrap(W_COPY) + lines[half:]
    paras = N.article_paras(N.TARGET, m_before, m_after)
    first = [Raw(*N.body(N.TARGET))] if dk == "dup" else [Raw(*N.body(N.T_HEAD))]
    pages = N.article_pages([*first, Raw(*fig)]) if dk == "deldup" else \
        N.article_pages([Raw(*N.body(N.T_HEAD)), Raw(*fig), Raw(*N.jwrap(N.T_TAIL))])
    truth = {idx(paras, N.CTRL_DOCX): N.CTRL_PUB}
    if dk == "deldup":
        truth[idx(paras, N.TARGET)] = N.T_HEAD
    case(f"w_copywidth_fig200_{dk}", "N10", paras, pages,
         ("PDF では段落の最後の文の前に約 200 文字の図があり、" if dk == "dup" else
          "PDF では段落の最後の文が校正で消されていて、段落の後ろに約 200 文字の図があり、") +
         f"図の中の文字に、段落の最後の文の写し（句点が「．」で、数字が半角の「3倍」）がある。docx と本文は全角の「３倍」。"
         "写しに合わせて「３」を「3」にしない（" + ("どの段落も変えない" if dk == "dup" else
                                                 "最後の文を消すか、決められなければ docx のまま 13 章に出す") + "）。",
         truth=truth, expect={"default": "exact", idx(paras, N.TARGET): "reported"} if dk == "deldup" else "exact")

# w_figwidth_head_*: 頭の側。段落の最初の語句の書き換え（「第２時の話し合いの中で」→「第２時の議論の中で」）。PDF では段落の最初の
# 9 文字の行の後ろに小さな図（docx では段落のすぐ前の画像とキャプション）があり、図の中の最初の行「第2時の話し合い」（半角の 2）が
# docx の段落の最初の文字とよく似ている。段落ごとの照合が、分断する図の中の文字とみなした位置（floaty）の行と docx の文字を
# 並べ、その全角・半角を図の中の文字に合わせて直さないか（「２」→「2」）
WH_DOCX = "第２時の" + N.P_AFTER
WH_PUB = WH_DOCX.replace("話し合いの中で", "議論の中で")
WH_FIG = ["第2時の話し合い", "↓", "課題の提示", "↓", "まとめ"]
for before in ("date", "pbhead"):
    paras = N.article_paras(N.TARGET, (), [("画像", "".join(WH_FIG)), ("図キャプション", Z_CAP)], after=WH_DOCX)
    first = [N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*N.body(N.TARGET))]
    first += [Raw(received_line()), BREAK] if before == "date" else [BREAK]
    rest = [Raw("　" + WH_PUB[:9]), Raw(*WH_FIG, Z_CAP), Raw(*N.jwrap(WH_PUB[9:])), N.H3, Raw(*N.body(N.P_DISC)),
            Raw(*N.body(N.P_END)), *tail_blocks()]
    pages = flow(first + rest, first=25)
    if before == "pbhead":
        ls = pages[1].split("\n")
        pages[1] = "\n".join(ls[:1] + ["試験　五郎"] + ls[1:])
    case(f"w_figwidth_head_{before}", "N10", paras, pages,
         "docx の段落の最初の「第２時の話し合いの中で」は、出版版で「第２時の議論の中で」に書き換えられている。PDF では段落の最初の"
         "9 文字の行の後ろに小さな図（docx では段落のすぐ前の画像とキャプション）があり、図の中の最初の行「第2時の話し合い」（半角の"
         " 2）が docx の最初の文字とよく似ている。直すか、決められなければ docx のまま 13 章に出す（図の中の文字に合わせて、本文の"
         "「２」を「2」にしない）。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, WH_DOCX): WH_PUB},
         expect={"default": "exact", idx(paras, WH_DOCX): "reported"})


# ############################################################################ 5 回目の点検（b2_review/r5p。4 回目の修正の後）の反例
# 組（名前の前置き）:
#   v_headfig_*  段落 P_AFTER のすぐ前に小さな図（docx では画像。キャプションは図の下）があり、PDF では図の中の文字・キャプション・
#                P_AFTER の順に並ぶ（ふつうの組み方）。図の中の行が P_AFTER の docx の書き出しとよく似ているか同じ（手順「話し合いの
#                中で考える」・写し「話し合いの中で，ある」）で、P_AFTER の書き出しが校正で直されている（「話し合いの中で」→「議論の
#                中で」など）。まとめての照合は、書き出しの docx の文字を図の中の行に置く（_Joint.find_hole の (2) が、図の中の短い行
#                「導入」「↓」を柱の候補の行として飛ばして図の中に入る。写しが 10 文字ほどあると、アンカーの最長増加列がキャプションの
#                アンカーと同じ長さになり、写しの側を選ぶ）
#   v_figtop_*   段落 TARGET の最後の文が校正で消され（「課題の提示を行った。」）、次のページの最初（柱の後ろ）の 1 行だけの小さな図の
#                行（「課題の把握」）が、消された文の書き出しとよく似ている（4 回目の修正の _Joint.figure_edge_lines の (A) は、間が
#                柱だけなので facing_hole か better_line のときだけ働く）
#   v_better_*   段落 TARGET の最後の行（本当の段落の行）が校正で大きく書き換えられ、すぐ後ろに図の上のキャプションがあり、その下の
#                図の中の行が docx の最後の語句とよく似ている（better_line が、本当の最後の行を図の中の行とみなす）
#   v_face_*     w_capnext の形（段落の最後の 1 行が受付日の行・柱の後ろに出て、すぐ後ろに表・図のキャプション）で、表・図の後ろの
#                段落 P_AFTER の書き出しが校正で直されている（facing_hole が、P_AFTER の書き出しの穴を、P_AFTER の行を取ったものと
#                みなす）
# 結果（2026-10-19。作業ツリー〈0.21.0。4 回目の修正の後〉・4 回目の点検の版 R4〈b2_review/r4p/cur_src〉・0.20.0・試作 pc。
#   oracle/results_r5p_v_cases_cur・R4・base・pc.json。11 件）:
#   v_headfig 6: 作業ツリー FAIL 6（足した「の中で考える」「考える」「の中で，ある」。13.1 にふつうの直しとして出て、13.4 は
#     「PDF と同じ文字になりました」）、R4 FAIL 6、0.20.0 OK 6。試作 pc（b2_review/r5p/proto_c_vs_cur_pdfmatch.patch。
#     figure_edge_lines の (C)）は REPORTED 6
#   v_figtop 2: 作業ツリー FAIL 2（「把握」を足す・13 章に出さずに「課題の提示」を残す）、R4 REPORTED 2、0.20.0 FAIL 2
#   v_better 1: 作業ツリー FAIL（直さない。13.2 に DISPLACED_WHY）、R4 OK、0.20.0 FAIL（「る」を足す）
#   v_face 2: 作業ツリー FAIL 2（直さない。13.2 に DISPLACED_WHY）、R4 FAIL 2、0.20.0 OK 2
V_FIG_STEP = ["導入", "↓", "話し合いの中で考える", "↓", "まとめ"]
V_FIG_COPY = ["導入", "↓", "話し合いの中で，ある", "↓", "まとめ"]
V_HEAD_EDITS = {"w1": ("話し合いの中で", "議論の中で"), "heavy": ("話し合いの中で，ある生徒は", "議論の場で，一人の生徒が")}


def v_head_pages(fig, head_pub, before):
    first = [N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*N.body(N.TARGET))]
    if before == "pbhead":
        first += [BREAK]
    rest = [Raw(*fig, Z_CAP), Raw(*N.body(head_pub)), N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)),
            *tail_blocks()]
    pages = flow(first + rest, first=25)
    if before == "pbhead":
        ls = pages[1].split("\n")
        pages[1] = "\n".join(ls[:1] + ["試験　五郎"] + ls[1:])
    return pages


for fk, fig in (("step", V_FIG_STEP), ("copy", V_FIG_COPY)):
    for ek, (dt, pt) in V_HEAD_EDITS.items():
        if fk == "copy" and ek == "heavy":
            continue
        head_pub = N.P_AFTER.replace(dt, pt, 1)
        paras = ([("見出し", N.H1), ("本文", N.P_INTRO), ("本文", N.CTRL_DOCX), ("見出し", N.H2), ("本文", N.TARGET),
                  ("画像", "".join(fig)), ("図キャプション", Z_CAP), ("本文", N.P_AFTER), ("見出し", N.H3),
                  ("本文", N.P_DISC), ("本文", N.P_END), ("引用文献見出し", N.RH), ("引用文献", N.REF1),
                  ("引用文献", N.REF2)])
        for before in ("direct", "pbhead"):
            case(f"v_headfig_{fk}_{ek}_{before}", "N10", paras, v_head_pages(fig, head_pub, before),
                 f"docx の段落の書き出し「{dt}」は、出版版で「{pt}」に直されている。PDF では、段落のすぐ前に小さな図（docx では"
                 f"画像。キャプションは図の下）があり、図の中の行「{fig[2]}」が docx の書き出しとよく似ている（同じ）。図の中の文字を"
                 "段落に足さない（図の中の行と並べた docx の文字を残して、本当の書き出しを足すこともしない）。直すか、決められなければ"
                 " docx のまま 13 章に出す（0.20.0 は直すか 13 章に出す）。",
                 truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.P_AFTER): head_pub},
                 expect={"default": "exact", idx(paras, N.P_AFTER): "reported"})

# v_figtop_*: 消された最後の文と、次のページの最初の 1 行だけの図の中の行
V_DEL = "課題の提示を行った。"
for fk, fl in (("sim", "課題の把握"), ("copy", "課題の提示")):
    docx_t = N.TARGET + V_DEL
    paras = N.article_paras(docx_t, (), [("画像", fl), ("図キャプション", Z_CAP)])
    first = [N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*N.body(N.TARGET)), BREAK]
    rest = [Raw(fl, Z_CAP), Raw(*N.body(N.P_AFTER)), N.H3, Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()]
    pages = flow(first + rest, first=25)
    ls = pages[1].split("\n")
    pages[1] = "\n".join(ls[:1] + ["試験　五郎"] + ls[1:])
    case(f"v_figtop_{fk}_pbhead", "N10", paras, pages,
         f"docx の段落の最後の文「{V_DEL}」は出版版で消されている。PDF では段落の本当の最後の行がページの最後にあり、次のページの"
         f"最初（柱の後ろ）に 1 行だけの小さな図（行「{fl}」。キャプションは図の下）がある。図の中の文字を足さない。消された文を"
         "消すか、決められなければ docx のまま 13 章に出す（4 回目の修正の前の版は 13 章に出す）。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_t): N.TARGET},
         expect={"default": "exact", idx(paras, docx_t): "reported"})

# v_better_*: 書き換えられた本当の最後の行と、キャプションの下の、docx の最後の語句とよく似た図の中の行
V_LAST_PUB = N.TARGET.replace("で説明し合う時間を取った。", "で議論する場を設けた。")
paras = N.article_paras(N.TARGET, (), [("図キャプション", Z_CAP), ("画像", "説明し合う時間を取る")])
pages = flow([N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, Raw(*N.body(V_LAST_PUB)),
              Raw(Z_CAP, "導入", "↓", "説明し合う時間を取る", "↓", "まとめ"), Raw(*N.body(N.P_AFTER)), N.H3,
              Raw(*N.body(N.P_DISC)), Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
case("v_better_rew_direct", "N10", paras, pages,
     "段落の最後の行（本当の段落の行）が校正で「で説明し合う時間を取った。」→「で議論する場を設けた。」と書き換えられ、すぐ後ろに"
     "図の上のキャプションがあり、その下の図の中の行「説明し合う時間を取る」が docx の最後の語句とよく似ている。本当の最後の行の"
     "直しなので、出版版の文字に直す（4 回目の修正の前の版は直す）。",
     truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, N.TARGET): V_LAST_PUB})

# v_face_*: w_capnext（e4・表）の形で、表の後ろの段落 P_AFTER の書き出しが校正で直されている
V_FACE_HEAD = N.P_AFTER.replace("話し合いの中で", "議論の中で")
for ak in ("date", "coldate"):
    docx_t, pub_t = N.TARGET, N.TARGET[:-4] + "持った。"
    lines = N.body(pub_t)
    paras = N.article_paras(docx_t, (), [("表キャプション", W_TCAP), ("表", W_ROWS)])
    head = [Raw(*lines[:-1]), Raw(received_line())] + ([BREAK] if ak == "date" else [])
    pages = flow([N.front(), N.H1, Raw(*N.body(N.P_INTRO)), Raw(*N.body(N.CTRL_PUB)), N.H2, *head, Raw(lines[-1]),
                  Raw(*N.table_lines(W_TCAP, W_ROWS)), Raw(*N.body(V_FACE_HEAD)), N.H3, Raw(*N.body(N.P_DISC)),
                  Raw(*N.body(N.P_END)), *tail_blocks()], first=25)
    case(f"v_face_e4_w1_tab_{ak}", "N10", paras, pages,
         f"w_capnext_e4_tab_{ak} の形（段落の最後の行「{lines[-1]}」が受付日の行の後ろに出て、すぐ後ろに表のキャプション）で、表の"
         "後ろの段落の書き出しが校正で「話し合いの中で」→「議論の中で」と直されている。どちらも本当の段落の行の直しなので、出版版の"
         "文字に直す（0.20.0 は両方を直す）。",
         truth={idx(paras, N.CTRL_DOCX): N.CTRL_PUB, idx(paras, docx_t): pub_t, idx(paras, N.P_AFTER): V_FACE_HEAD})
