"""rvB4_regress: 照合の回帰を探すための、無作為の架空の論文（docx と出版版 PDF の文字）を作る（scratchpad だけ）。

  python -I gen.py 出力フォルダ 件数 [種]
各ケース: docx（make_fixtures.make_article）と cases.json（PDF の各ページの文字、docx の段落の文字 -> 出版版の文字、作り方）。
出版版の文字は docx の文字に「校正の直し」（全角・半角、語の置き換え、語の追加・削除、数の直し）を入れたもの。PDF には、
ページ番号・誌名の行・柱・投稿受付日・表のセル・図の中の文字を、本誌の形をまねて入れる。文字はすべて架空。
"""
import json
import random
import re
import sys
from pathlib import Path

sys.path.insert(0, "/home/user/jstgxmlcng_JASME/tests")
sys.path.insert(0, "/home/user/jstgxmlcng_JASME/src")
import make_fixtures as mf  # noqa: E402

TITLE = "ページ番号の判定の検証用文書"
FRONT = [TITLE, "―検証用の小さな論文―", "架空大学　試験　六郎"]
SMALL_REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
JOURNAL = "全国数学教育学会誌　数学教育学研究　第31巻　第１号　2026　pp.1～8"
R1 = "2025年８月31日投稿受付，2025年11月24日採用決定"
R2A, R2B = "2025年２月27日投稿受付，2025年７月30日再投稿受付，", "2025年10月10日採用決定"

SUBJ = ["架空の生徒", "授業の記録", "本稿の分析", "教師の発問", "二つの量の関係", "架空の課題", "学習の過程", "表の見方",
        "比例の考え", "グラフの傾き", "生徒の記述", "発話の記録", "対応の見方", "変化の割合", "図形の性質"]
OBJ = ["観点ごとの特徴", "値の組の並び", "式による表現", "考察の手がかり", "授業の流れ", "記録の件数", "比の一定",
       "数学的な活動", "見方の変容", "説明の仕方", "証明の構成", "問題の解決", "一次関数の式", "二つの方法"]
VERB = ["整理した", "明らかにした", "取り上げた", "比べた", "検討した", "示した", "分析した", "確かめた", "記述した",
        "見いだした", "考察した", "述べた"]
LATIN = ["self-explanation", "Fictional Theory", "model", "argumentation", "design-based research", "proof"]


def sentence(rnd):
    s = rnd.choice(SUBJ) + "は，" + rnd.choice(OBJ) + "を" + rnd.choice(VERB) + "。"
    r = rnd.random()
    if r < 0.15:
        s = s[:-1] + f"（試験，{rnd.choice([2019, 2020, 2021])}）。"
    elif r < 0.27:
        s = s.replace("を", f"を{rnd.randint(1, 30)}回", 1)
    elif r < 0.37:
        s = s.replace("は，", f"は，{rnd.choice(LATIN)} の", 1)
    elif r < 0.47:
        s = s.replace("を", "を資料に", 1)
    return s


def proof(rnd, base):
    """出版版の文字（全角のかっこ）base から、docx（校正の前）の文字 d と出版版の文字 p を作る。"""
    d = p = base
    kinds = []
    for _ in range(rnd.choice([0, 0, 1, 1, 2])):
        r = rnd.random()
        if r < 0.25 and "資料" in p:
            k = p.index("資料")
            p = p[:k] + "付録" + p[k + 2:]
            kinds.append("word")
        elif r < 0.45:
            ks = [i + 1 for i, c in enumerate(p[:-1]) if c == "。"]
            if ks:
                k = rnd.choice(ks)
                p = p[:k] + "さらに，" + p[k:]
                kinds.append("ins")
        elif r < 0.6:
            ks = [i + 1 for i, c in enumerate(d[:-1]) if c == "。"]
            if ks:
                k = rnd.choice(ks)
                d = d[:k] + "なお，" + d[k:]
                kinds.append("del")
        elif r < 0.8:
            m = list(re.finditer(r"[0-9]+回", p))
            if m:
                x = rnd.choice(m)
                p = p[:x.start()] + str(int(x.group()[:-1]) + 1) + "回" + p[x.end():]
                kinds.append("num")
        else:
            d = "".join({"（": "(", "）": ")"}.get(c, c) if rnd.random() < 0.7 else c for c in d)
            kinds.append("width")
    return d, p, kinds


def wrap(text, width=24):
    lines, cur, w = [], "", 0.0
    for c in text:
        cw = 0.5 if ord(c) < 0x2000 else 1.0
        if w + cw > width:
            lines.append(cur)
            cur, w = "", 0.0
        cur += c
        w += cw
    if cur:
        lines.append(cur)
    return lines


def make_case(out, idx, rnd):
    blocks = []                    # (役割, docx の文字, 出版版の文字, 直しの種類)
    seen = set()
    for s in range(rnd.randint(1, 3)):
        h = ["１．はじめに", "２．方法", "３．結果と考察"][s]
        blocks.append(("sec1", h, h, []))
        for _ in range(rnd.randint(1, 4)):
            base = "".join(sentence(rnd) for _ in range(rnd.randint(1, 6)))
            d, p, kinds = proof(rnd, base)
            if d in seen:
                continue
            seen.add(d)
            blocks.append(("body", d, p, kinds))
    refs = []
    for k in range(rnd.randint(0, 3)):
        a, b2 = rnd.randint(1, 50), rnd.randint(51, 99)
        refs.append(f"架空{['太郎', '次郎', '花子'][k % 3]}（{2015 + k}）．「架空の題目その{k + 1}」．『架空学会誌』，第{20 + k}号，"
                    f"pp.{a}-{b2}．")
    lines = []
    for role, d, p, _ in blocks:
        lines += [p] if role == "sec1" else wrap(p)
    body_end = len(lines)
    arts = []
    for _ in range(rnd.choice([0, 0, 1, 1, 2])):
        at = rnd.randint(1, max(1, body_end - 1))
        kind = rnd.random()
        if kind < 0.35:
            block = ["表１　架空の得点"]
            for r in range(rnd.randint(2, 6)):
                block += [f"{r + 1}組"] + [str(rnd.randint(1, 99)) for _ in range(rnd.randint(1, 4))]
        elif kind < 0.55:
            block = [rnd.choice(["A", "B", "C", "O", "x", "y", "1", "2"]) for _ in range(rnd.randint(1, 5))]
        elif kind < 0.75:
            block = ["図１　架空の図", "図中の文字その一", "図中の文字その二"]
        else:
            block = []
            for r in range(rnd.randint(2, 4)):
                block += [f"第{r + 1}群", rnd.choice(["－", "―", str(rnd.randint(1, 99))]), str(rnd.randint(1, 99))]
        lines[at:at] = block
        arts.append(block[0])
    lines.append("引用および参考文献")
    for r in [SMALL_REF] + refs:
        ws = wrap(r)
        if r != SMALL_REF and rnd.random() < 0.5:
            k = r.rindex("-") + 1
            ws = wrap(r[:k]) + [r[k:]]
        lines += ws
    lines += EN
    per = rnd.randint(14, 30)
    pages = [lines[k:k + per] for k in range(0, len(lines), per)]
    style = rnd.choice(["top", "top", "top", "bottom", "dash_bottom"])
    head = rnd.choice([None, None, None, "試験六郎", "架空の論文の柱の文字列です"])
    rv = rnd.random()
    out_pages = []
    for n, ls in enumerate(pages):
        ls = list(ls)
        if n == 0:
            ls = FRONT + ls
            if rv < 0.3:
                ls.insert(3, R1)
            elif rv < 0.5 and len(ls) > 6:
                k = rnd.randint(4, len(ls) - 1)
                ls[k] = ls[k] + " " + R1
            elif rv < 0.6 and len(ls) > 6:
                k = rnd.randint(4, len(ls) - 2)
                ls[k] = ls[k] + " " + R2A
                ls.insert(k + 1, R2B)
            ls = [JOURNAL] + ls
        elif head:
            ls = [head] + ls if rnd.random() < 0.8 else ls + [head]
        if style == "top":
            ls = [f"（{n + 1}）"] + ls
        elif style == "bottom":
            ls = ls + [f"{n + 1}"]
        else:
            ls = ls + [f"－ {n + 1} －"]
        out_pages.append("\n".join(ls))
    path = out / f"case{idx:04d}.docx"
    mf.make_article(path, TITLE, lambda b: [mf.para(mf.S[r], d) for r, d, _, _ in blocks],
                    refs=lambda b: [mf.para(mf.S["ref"], r) for r in refs])
    truth = {d: p for _, d, p, _ in blocks}
    truth.update({r: r for r in refs})
    return {"docx": str(path), "pages": out_pages, "truth": truth, "style": style, "head": head, "received": rv,
            "artifacts": arts, "kinds": {d: k for _, d, _, k in blocks if k}}


if __name__ == "__main__":
    out = Path(sys.argv[1])
    n = int(sys.argv[2])
    seed = int(sys.argv[3]) if len(sys.argv) > 3 else 1
    out.mkdir(parents=True, exist_ok=True)
    rnd0 = random.Random(seed)
    cases = [make_case(out, i, random.Random(rnd0.random())) for i in range(n)]
    (out / "cases.json").write_text(json.dumps(cases, ensure_ascii=False, indent=0), encoding="utf-8")
    print(len(cases), "cases")
