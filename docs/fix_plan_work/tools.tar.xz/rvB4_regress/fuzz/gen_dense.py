"""rvB4_regress: gen.py と同じ作り方で、校正の直しと表・図の文字を多くしたケース（架空の文字）。

  python -I gen_dense.py 出力フォルダ 件数 種
"""
import json
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gen  # noqa: E402

out, n, seed = Path(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
out.mkdir(parents=True, exist_ok=True)


class R(random.Random):
    def choice(self, seq):
        if list(seq) == [0, 0, 1, 1, 2]:
            return super().choice([2, 3, 4])
        return super().choice(seq)


rnd0 = random.Random(seed)
cases = [gen.make_case(out, i, R(rnd0.random())) for i in range(n)]
(out / "cases.json").write_text(json.dumps(cases, ensure_ascii=False, indent=0), encoding="utf-8")
print(len(cases), "cases")
