"""rvB4_regress: gen.py と同じケースを、すべてのページ（2 ページ目以降）に本物の柱（3 ページ以上に出る行）がある形で作る。

  python -I gen_head.py 出力フォルダ 件数 種 柱の文字
"""
import json
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gen  # noqa: E402

out, n, seed, head = Path(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
out.mkdir(parents=True, exist_ok=True)


class R(random.Random):
    def choice(self, seq):
        if None in seq and "試験六郎" in seq:      # 柱の選び方だけ固定する
            return head
        return super().choice(seq)


rnd0 = random.Random(seed)
cases = [gen.make_case(out, i, R(rnd0.random())) for i in range(n)]
(out / "cases.json").write_text(json.dumps(cases, ensure_ascii=False, indent=0), encoding="utf-8")
print(len(cases), "cases")
