"""rvB4_regress: run.py の結果を、出版版の文字（truth）との距離で比べる。

  python -I judge.py cases.json A.json B.json
段落ごとに harm = 距離(直した後, 出版版) - 距離(docx, 出版版)。B の harm が A より大きい段落（B で悪くなった段落）と、
B で harm > 0（何もしないより悪い）の段落を出す。
"""
import json
import sys


def lev(a, b):
    i = 0
    while i < len(a) and i < len(b) and a[i] == b[i]:
        i += 1
    a, b = a[i:], b[i:]
    j = 0
    while j < len(a) and j < len(b) and a[-1 - j] == b[-1 - j]:
        j += 1
    if j:
        a, b = a[:-j], b[:-j]
    if not a:
        return len(b)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for x, ca in enumerate(a, 1):
        cur = [x] + [0] * len(b)
        for y, cb in enumerate(b, 1):
            cur[y] = min(prev[y] + 1, cur[y - 1] + 1, prev[y - 1] + (ca != cb))
        prev = cur
    return prev[-1]


cases = json.load(open(sys.argv[1], encoding="utf-8"))
A = json.load(open(sys.argv[2], encoding="utf-8"))
B = json.load(open(sys.argv[3], encoding="utf-8"))
print("A:", A["version"], A["file"])
print("B:", B["version"], B["file"])
worse = better = harmB = harmA = same = 0
rows_worse, rows_harm = [], []
for n, (c, ra, rb) in enumerate(zip(cases, A["cases"], B["cases"])):
    for d, p in c["truth"].items():
        if d not in ra["paras"] or d not in rb["paras"]:
            continue
        fa, fb = ra["paras"][d]["fixed"], rb["paras"][d]["fixed"]
        base = lev(d, p)
        ha, hb = lev(fa, p) - base, lev(fb, p) - base
        if hb > ha:
            worse += 1
            rows_worse.append((n, d, p, fa, fb, ha, hb))
        elif hb < ha:
            better += 1
        else:
            same += 1
        if hb > 0:
            harmB += 1
            rows_harm.append((n, d, p, fb, hb))
        if ha > 0:
            harmA += 1
print(f"paragraphs: B worse {worse}, B better {better}, same {same}; harm>0: A {harmA}, B {harmB}")


def show(d, p, f):
    import difflib
    out = []
    for t, i1, i2, j1, j2 in difflib.SequenceMatcher(None, p, f, autojunk=False).get_opcodes():
        if t != "equal":
            out.append(f"{t}: 出版版「{p[i1:i2]}」→ 直した後「{f[j1:j2]}」")
    return "; ".join(out)


for n, d, p, fa, fb, ha, hb in rows_worse:
    print(f"## WORSE case{n:04d} harm A={ha} B={hb}")
    print("   A:", show(d, p, fa))
    print("   B:", show(d, p, fb))
for n, d, p, fb, hb in rows_harm:
    print(f"## HARM(B) case{n:04d} harm={hb}: {show(d, p, fb)}")
