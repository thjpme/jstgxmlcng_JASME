"""rvB4_regress: gen.py のケースを、指定したコードで照合して、直した後の段落の文字を JSON に書く。

  python -I run.py SRC cases.json 出力.json
"""
import json
import sys

src, cases_path, out_path = sys.argv[1:4]
sys.path.insert(0, src)
import jasme_jats  # noqa: E402
from jasme_jats.config import JournalConfig  # noqa: E402
from jasme_jats.pdfdocx import _mechanical, plan_fixes  # noqa: E402
from jasme_jats.pdfmatch import compare  # noqa: E402

j = JournalConfig.load()
cases = json.load(open(cases_path, encoding="utf-8"))
res = {"version": jasme_jats.__version__, "file": jasme_jats.__file__, "cases": []}
for c in cases:
    _, plan = _mechanical(c["docx"], j)
    pc = compare(plan, c["pages"])
    fixes = [f for f in plan_fixes(plan, pc) if f.kind == "text"]
    out = {}
    for s, p in plan.paras.items():
        t = p.plain()
        if t not in c["truth"]:
            continue
        fx = sorted((f for f in fixes if f.src == s and not f.reason), key=lambda f: -f.start)
        new = t
        for f in fx:
            new = new[:f.start] + f.new + new[f.end:]
        out[t] = {"src": s, "fixed": new, "skipped": [(f.old, f.new) for f in fixes if f.src == s and f.reason],
                  "unmatched": s in pc.unmatched}
    res["cases"].append({"paras": out, "ignored": getattr(pc, "ignored_lines", None)})
json.dump(res, open(out_path, "w", encoding="utf-8"), ensure_ascii=False)
print(res["version"], len(res["cases"]))
