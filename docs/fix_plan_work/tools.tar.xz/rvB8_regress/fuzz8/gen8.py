"""rvB8_regress: 2 回目の修正で入った仕組み（_opcodes の None を除いた照合・_slide_inserts・stray・LONG_WHY・_continues・
ページ番号の代わりの規則）の回帰を探す、無作為の架空の論文（docx と出版版 PDF の文字）を作る（scratchpad だけ）。

  python -I gen8.py 出力フォルダ 件数 種 [形]
形: mix（既定）/ caption（キャプション・柱の最初の文字が次の行の最初の文字と同じ）/ long（PDF にだけある長い文字と短い直しが
近い）/ refs（引用文献の「pp.11-」「16」とページ・柱）/ nopage（ページ番号のない PDF）
各ケース: docx（make_fixtures.make_article）と cases.json（PDF の各ページの文字、docx の段落の文字 -> 出版版の文字）。
文字はすべて架空。rvB4_regress/fuzz/gen.py の作り方をもとに、組版の文字・図表の文字の入れ方を増やしたもの。
"""
import json
import random
import re
import sys
from pathlib import Path

sys.path.insert(0, "/home/user/jstgxmlcng_JASME/tests")
sys.path.insert(0, "/home/user/jstgxmlcng_JASME/src")
import make_fixtures as mf  # noqa: E402

TITLE = "照合の回帰の検証用文書"
FRONT = [TITLE, "―検証用の小さな論文―", "架空大学　試験　六郎"]     # make_article の前付けと同じ
SMALL_REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"   # make_article の引用文献
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
JOURNAL = "全国数学教育学会誌　数学教育学研究　第32巻　第１号　2027　pp.1～8"
R1 = "2026年８月31日投稿受付，2026年11月24日採用決定"
R2A, R2B = "2026年２月27日投稿受付，2026年７月30日再投稿受付，", "2026年10月10日採用決定"

SUBJ = ["架空の生徒", "授業の記録", "本稿の分析", "教師の発問", "二つの量の関係", "架空の課題", "学習の過程", "表の見方",
        "比例の考え", "グラフの傾き", "生徒の記述", "発話の記録", "対応の見方", "変化の割合", "図形の性質", "表現の工夫",
        "図の読み方", "基づく考え", "試験の結果", "架空の学級", "第二の場面", "式の意味"]
OBJ = ["観点ごとの特徴", "値の組の並び", "式による表現", "考察の手がかり", "授業の流れ", "記録の件数", "比の一定",
       "数学的な活動", "見方の変容", "説明の仕方", "証明の構成", "問題の解決", "一次関数の式", "二つの方法", "表の数",
       "図の形", "架空の手順"]
VERB = ["整理した", "明らかにした", "取り上げた", "比べた", "検討した", "示した", "分析した", "確かめた", "記述した",
        "見いだした", "考察した", "述べた"]
LATIN = ["self-explanation", "Fictional Theory", "model", "argumentation", "design-based research", "proof",
         "problem-solving"]
SHORT_INS = ["全部で", "約", "架空の", "さらに，", "また，", "二つの", "それぞれ"]
LONG_INS = ["なお，授業の記録は二人の観察者が別々に取り，後で照らし合わせた。",
            "この点については，第３節で改めて詳しく述べることにする。"]


def sentence(rnd):
    s = rnd.choice(SUBJ) + "は，" + rnd.choice(OBJ) + "を" + rnd.choice(VERB) + "。"
    r = rnd.random()
    if r < 0.12:
        s = s[:-1] + f"（試験，{rnd.choice([2019, 2020, 2021])}）。"
    elif r < 0.30:
        s = s.replace("を", f"を{rnd.randint(1, 30)}{rnd.choice(['回', '点', '名', '件'])}", 1)
    elif r < 0.40:
        s = s.replace("は，", f"は，{rnd.choice(LATIN)} の", 1)
    elif r < 0.48:
        s = s.replace("を", "を資料に", 1)
    elif r < 0.56:
        s = s.replace("は，", "は，", 1).replace("を", "を，", 1)       # 読点で終わる行ができやすく
    return s


def proof(rnd, base, kinds_w):
    """出版版の文字 base から、docx（校正の前）の文字 d と出版版の文字 p を作る。kinds_w: 直しの種類と重み。"""
    d = p = base
    kinds = []
    n = rnd.choice([0, 1, 1, 2, 2, 3])
    names, weights = zip(*kinds_w)
    for _ in range(n):
        k = rnd.choices(names, weights)[0]
        if k == "word" and "資料" in p:
            i = p.index("資料")
            p = p[:i] + "付録" + p[i + 2:]
        elif k == "ins_after_period":
            ks = [i + 1 for i, c in enumerate(p[:-1]) if c == "。"]
            if not ks:
                continue
            i = rnd.choice(ks)
            p = p[:i] + rnd.choice(["さらに，", "また，"]) + p[i:]
        elif k == "ins_short":                     # 語の途中ではなく、文字の切れ目のどこかに短い文字
            i = rnd.randrange(1, len(p) - 1)
            p = p[:i] + rnd.choice(SHORT_INS) + p[i:]
        elif k == "ins_long":
            ks = [i + 1 for i, c in enumerate(p[:-1]) if c == "。"]
            if not ks:
                continue
            i = rnd.choice(ks)
            p = p[:i] + rnd.choice(LONG_INS) + p[i:]
        elif k == "del":
            ks = [i + 1 for i, c in enumerate(d[:-1]) if c == "。"]
            if not ks:
                continue
            i = rnd.choice(ks)
            d = d[:i] + "なお，" + d[i:]
        elif k == "num":
            m = list(re.finditer(r"[0-9]+", p))
            if not m:
                continue
            x = rnd.choice(m)
            p = p[:x.start()] + str(int(x.group()) + rnd.randint(1, 3)) + p[x.end():]
        elif k == "swap":                           # 1 文字の置き換え（かなの直し）
            ks = [i for i, c in enumerate(p[:-1]) if c in "はがをにでと"]
            if not ks:
                continue
            i = rnd.choice(ks)
            p = p[:i] + {"は": "が", "が": "は", "を": "に", "に": "を", "で": "に", "と": "や"}[p[i]] + p[i + 1:]
        elif k == "width":
            d = "".join({"（": "(", "）": ")", "，": ",", "１": "1", "２": "2"}.get(c, c) if rnd.random() < 0.7 else c
                        for c in d)
        else:
            continue
        kinds.append(k)
    return d, p, kinds


def wrap(text, width=24):
    lines, cur, w = [], "", 0.0
    for c in text:
        cw = 0.5 if ord(c) < 0x2000 else 1.0
        if w + cw > width:
            lines.append(cur)
            cur, w = "", 0.0
        cur += c
        w += cw
    if cur:
        lines.append(cur)
    return lines


def hyphen_join(lines, rnd):
    """英単語の途中の行末の「-」（pdfium は U+FFFE にして次の行とつなぐことがある）。"""
    out = []
    for ln in lines:
        if out and out[-1].endswith("-") and re.search(r"[A-Za-z]-$", out[-1]) and rnd.random() < 0.5:
            out[-1] = out[-1][:-1] + "￾" + ln
        else:
            out.append(ln)
    return out


def artifact(rnd, next_line, kind):
    if kind == "table":
        cap = rnd.choice(["表１　架空の得点", "表２　組ごとの記録", "表３　架空の件数"])
        block = [cap]
        for r in range(rnd.randint(1, 5)):
            block += [f"{r + 1}組"] + [rnd.choice([str(rnd.randint(1, 99)), "－"]) for _ in range(rnd.randint(1, 4))]
        return block
    if kind == "labels":
        return [rnd.choice(["A", "B", "C", "O", "x", "y", "1", "2", "P"]) for _ in range(rnd.randint(1, 5))]
    if kind == "figure":
        return [rnd.choice(["図１　架空の図", "図２　架空の関係"]), "図中の文字その一", "図中の文字その二"][:rnd.randint(1, 3)]
    if kind == "ticks":
        return [str(10 * k) for k in range(rnd.randint(1, 5))]
    if kind == "caption_like":                     # キャプションの最初の文字が次の行の最初の文字と同じ
        c0 = next_line[:1] or "表"
        if not re.match(r"[぀-ヿ一-鿿]", c0):
            c0 = "表"
        return [c0 + rnd.choice(["１　架空の表の題", "　架空の図の題目", "の架空の説明"])] + \
            [str(rnd.randint(1, 99)) for _ in range(rnd.randint(0, 3))]
    if kind == "longfig":
        return ["図の中の架空の文字その一です", "図の中の架空の文字その二です"][:rnd.randint(1, 2)]
    if kind == "dash":
        out = []
        for r in range(rnd.randint(1, 3)):
            out += [f"第{r + 1}群", rnd.choice(["－", "―", str(rnd.randint(1, 99))]), str(rnd.randint(1, 99))]
        return out
    return []


ART_KINDS = {
    "mix": [("table", 3), ("labels", 2), ("figure", 2), ("ticks", 2), ("caption_like", 2), ("longfig", 1), ("dash", 1)],
    "caption": [("caption_like", 6), ("table", 1), ("labels", 1)],
    "long": [("longfig", 3), ("table", 2), ("figure", 2), ("ticks", 1)],
    "refs": [("table", 2), ("ticks", 2), ("labels", 1)],
    "nopage": [("table", 2), ("labels", 1), ("ticks", 1), ("figure", 1)],
}
PROOF_KINDS = {
    "mix": [("word", 2), ("ins_after_period", 2), ("ins_short", 3), ("del", 2), ("num", 3), ("swap", 2), ("width", 2),
            ("ins_long", 1)],
    "caption": [("ins_short", 3), ("num", 2), ("swap", 2), ("ins_after_period", 2), ("width", 1)],
    "long": [("ins_short", 3), ("ins_long", 3), ("ins_after_period", 2), ("num", 2)],
    "refs": [("num", 3), ("ins_short", 2), ("swap", 1), ("width", 1)],
    "nopage": [("num", 3), ("ins_short", 2), ("swap", 1), ("width", 1), ("del", 1)],
}


def make_case(out, idx, rnd, shape):
    blocks = []                    # (役割, docx の文字, 出版版の文字, 直しの種類)
    seen = set()
    for s in range(rnd.randint(1, 3)):
        h = ["１．はじめに", "２．方法", "３．結果と考察"][s]
        blocks.append(("sec1", h, h, []))
        for _ in range(rnd.randint(1, 4)):
            base = "".join(sentence(rnd) for _ in range(rnd.randint(1, 6)))
            d, p, kinds = proof(rnd, base, PROOF_KINDS[shape])
            if d in seen or p in seen:
                continue
            seen.update((d, p))
            blocks.append(("body", d, p, kinds))
    refs, refs_pub = [], []
    for k in range(rnd.randint(1 if shape == "refs" else 0, 4)):
        a = rnd.randint(1, 50)
        b2 = a + rnd.randint(1, 30)
        r = (f"架空{['太郎', '次郎', '花子', '三郎'][k % 4]}（{2015 + k}）．「架空の題目その{k + 1}」．『架空学会誌』，"
             f"第{20 + k}号，pp.{a}-{b2}．")
        pub = r
        if rnd.random() < 0.3:                       # 出版版で終わりのページの数が直っている
            pub = r.replace(f"-{b2}．", f"-{b2 + 1}．")
        refs.append(r)
        refs_pub.append(pub)
    lines = []
    for role, d, p, _ in blocks:
        lines += [p] if role == "sec1" else wrap(p)
    body_end = len(lines)
    arts = []
    kinds_w = ART_KINDS[shape]
    names, weights = zip(*kinds_w)
    for _ in range(rnd.choice([0, 1, 1, 2, 2, 3])):
        at = rnd.randint(1, max(1, body_end - 1))
        kind = rnd.choices(names, weights)[0]
        block = artifact(rnd, lines[at] if at < len(lines) else "", kind)
        lines[at:at] = block
        arts.append(kind)
    lines.append("引用および参考文献")
    for r in [SMALL_REF] + refs_pub:
        ws = wrap(r)
        if r != SMALL_REF and rnd.random() < 0.6:
            k = r.rindex("-") + 1
            ws = wrap(r[:k]) + [r[k:]]
        lines += ws
    lines += EN
    lines = hyphen_join(lines, rnd)
    per = rnd.randint(10, 26)
    pages = [lines[k:k + per] for k in range(0, len(lines), per)]
    style = "none" if shape == "nopage" else rnd.choice(["top", "top", "top", "bottom", "dash_bottom", "none"])
    head = rnd.choice([None, None, "試験七郎", "架空の論文の柱の文字列です", "基づく", "表の柱"])
    head_mode = rnd.choice(["top", "top", "bottom", "two_pages"])
    rv = rnd.random()
    out_pages = []
    for n, ls in enumerate(pages):
        ls = list(ls)
        if n == 0:
            ls = FRONT + ls
            if rv < 0.25:
                ls.insert(3, R1)
            elif rv < 0.45 and len(ls) > 6:
                k = rnd.randint(4, len(ls) - 1)
                ls[k] = ls[k] + " " + R1
            elif rv < 0.55 and len(ls) > 6:
                k = rnd.randint(4, len(ls) - 2)
                ls[k] = ls[k] + " " + R2A
                ls.insert(k + 1, R2B)
            ls = [JOURNAL] + ls
        elif head and (head_mode != "two_pages" or n <= 2):     # two_pages: 2・3 ページ目だけ（3 ページ以上に出ない柱）
            if head_mode == "bottom":
                ls = ls + [head]
            else:
                ls = [head] + ls
        if style == "top":
            ls = [f"（{n + 1}）"] + ls
        elif style == "bottom":
            ls = ls + [f"{n + 1}"]
        elif style == "dash_bottom":
            ls = ls + [f"－ {n + 1} －"]
        out_pages.append("\n".join(ls))
    path = out / f"case{idx:04d}.docx"
    mf.make_article(path, TITLE, lambda b: [mf.para(mf.S[r], d) for r, d, _, _ in blocks],
                    refs=(lambda b: [mf.para(mf.S["ref"], r) for r in refs]) if refs else None)
    truth = {d: p for _, d, p, _ in blocks}
    truth.update(dict(zip(refs, refs_pub)))
    return {"docx": str(path), "pages": out_pages, "truth": truth, "style": style, "head": head, "head_mode": head_mode,
            "received": rv, "artifacts": arts, "kinds": {d: k for _, d, _, k in blocks if k}}


if __name__ == "__main__":
    out = Path(sys.argv[1])
    n = int(sys.argv[2])
    seed = int(sys.argv[3])
    shape = sys.argv[4] if len(sys.argv) > 4 else "mix"
    out.mkdir(parents=True, exist_ok=True)
    rnd0 = random.Random(seed)
    cases = [make_case(out, i, random.Random(rnd0.random()), shape) for i in range(n)]
    (out / "cases.json").write_text(json.dumps(cases, ensure_ascii=False, indent=0), encoding="utf-8")
    print(len(cases), "cases")
