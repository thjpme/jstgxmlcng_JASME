"""rvB8_regress: run8.py の 2 つの結果（A: 比べる相手〈0.19.0 など〉、B: 今のコード）を、出版版の文字（truth）に照らして比べる。

  python -I judge8.py cases.json A.json B.json [-v]
段落ごとに、判定（OK / MISS〈直していないだけ〉/ VIOLATION〈docx にも truth にもない文字を足した、truth にある docx の文字を
消した〉）と harm（距離(直した後, truth) - 距離(docx, truth)）を出し、B が A より悪い段落（判定が悪い、または同じ判定で harm が
大きい）を出す。B の MISS が 13 章に出るか（直さなかった箇所・直せない違い・見つからない段落）も添える。
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, "/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/oracle")
from runner import describe  # noqa: E402

RANK = {"OK": 0, "MISS": 1, "VIOLATION": 2}


def lev(a, b):
    i = 0
    while i < len(a) and i < len(b) and a[i] == b[i]:
        i += 1
    a, b = a[i:], b[i:]
    j = 0
    while j < len(a) and j < len(b) and a[-1 - j] == b[-1 - j]:
        j += 1
    if j:
        a, b = a[:-j], b[:-j]
    if not a:
        return len(b)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for x, ca in enumerate(a, 1):
        cur = [x] + [0] * len(b)
        for y, cb in enumerate(b, 1):
            cur[y] = min(prev[y] + 1, cur[y - 1] + 1, prev[y - 1] + (ca != cb))
        prev = cur
    return prev[-1]


def verdict(d, p, r):
    f = r["fixed"]
    if f == p:
        return "OK", 0, None
    ds = describe(d, f, p)
    v = "VIOLATION" if ds["added"] or ds["deleted"] else "MISS"
    return v, lev(f, p) - lev(d, p), ds


def main():
    cases = json.load(open(sys.argv[1], encoding="utf-8"))
    A = json.load(open(sys.argv[2], encoding="utf-8"))
    B = json.load(open(sys.argv[3], encoding="utf-8"))
    verbose = "-v" in sys.argv
    print("A:", A["version"], A["file"], f"{A.get('seconds', 0):.1f}s")
    print("B:", B["version"], B["file"], f"{B.get('seconds', 0):.1f}s")
    tot = {"A": {"OK": 0, "MISS": 0, "VIOLATION": 0}, "B": {"OK": 0, "MISS": 0, "VIOLATION": 0}}
    worse, better, silent_b = [], 0, 0
    for n, (c, ra, rb) in enumerate(zip(cases, A["cases"], B["cases"])):
        for d, p in c["truth"].items():
            if d not in ra["paras"] or d not in rb["paras"]:
                continue
            va, ha, _ = verdict(d, p, ra["paras"][d])
            vb, hb, dsb = verdict(d, p, rb["paras"][d])
            tot["A"][va] += 1
            tot["B"][vb] += 1
            x = rb["paras"][d]
            reported = bool(x["skipped"] or x["whys"] or x["unmatched"])
            if vb != "OK" and not reported:
                silent_b += 1
            if (RANK[vb], hb) > (RANK[va], ha):
                worse.append((n, d, p, ra["paras"][d], x, va, vb, ha, hb, dsb, reported))
            elif (RANK[vb], hb) < (RANK[va], ha):
                better += 1
    print("段落の判定:", tot)
    print(f"B が悪い段落 {len(worse)}（うち VIOLATION {sum(1 for w in worse if w[6] == 'VIOLATION')}）、B がよい段落 {better}、"
          f"B の OK でない段落で 13 章に出ないもの {silent_b}")
    for n, d, p, xa, xb, va, vb, ha, hb, ds, reported in worse:
        print(f"## case{n:04d} {xb['src']}: A={va}({ha}) B={vb}({hb}) 13章={'出る' if reported else '出ない'}")
        if ds:
            print(f"   added={ds['added']} deleted={ds['deleted']} left={ds['left']} not_added={ds['not_added']}")
        if verbose:
            print(f"   docx ={d}")
            print(f"   truth={p}")
            print(f"   A    ={xa['fixed']}")
            print(f"   B    ={xb['fixed']}")
            print(f"   B skipped={xb['skipped']} whys={xb['whys']} unmatched={xb['unmatched']} ignored={xb['ignored'][:6]}")


if __name__ == "__main__":
    main()
