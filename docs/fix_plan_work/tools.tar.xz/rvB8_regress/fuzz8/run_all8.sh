#!/bin/sh
# rvB8_regress: gen8.py の形ごとにケースを作り、今のコード（cur）・0.19.0（v019）・2 回目の修正の前（prefix）で照合する。
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
F=$S/rvB8_regress/fuzz8
CUR=$S/rvB8_regress/t_cur/src; V019=$S/oracle/wt_head/src; PRE=$S/fixB2/before_src
for spec in "mix 301" "caption 302" "long 303" "refs 304" "nopage 305" "mix 306"; do
  set -- $spec; shape=$1; seed=$2; d=$F/${shape}_$seed
  [ -f $d/cases.json ] || python -I $F/gen8.py $d 300 $seed $shape > /dev/null
done
for d in $F/*_30?; do
  for v in cur:$CUR v019:$V019 pre:$PRE; do
    tag=${v%%:*}; src=${v#*:}
    python -I $F/run8.py $src $d/cases.json $d/res_$tag.json > $d/res_$tag.log 2>&1 &
  done
  wait
done
echo done
