#!/bin/sh
# rvB8_regress: gen8.py の形ごとに種を変えてケースを増やし、cur・v019・pre で照合する。
S=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad
F=$S/rvB8_regress/fuzz8
CUR=$S/rvB8_regress/t_cur/src; V019=$S/oracle/wt_head/src; PRE=$S/fixB2/before_src
for seed in 311 312 313 314 315 316 317 318 319 320 321 322 323 324 325; do
  for shape in mix caption long refs nopage; do
    d=$F/m_${shape}_$seed
    [ -f $d/cases.json ] || python -I $F/gen8.py $d 300 $seed$shape_seed $shape > /dev/null 2>&1 || python -I $F/gen8.py $d 300 $seed $shape > /dev/null
  done
done
for d in $F/m_*; do
  [ -f $d/res_pre.json ] && continue
  for v in cur:$CUR v019:$V019 pre:$PRE; do
    tag=${v%%:*}; src=${v#*:}
    python -I $F/run8.py $src $d/cases.json $d/res_$tag.json > $d/res_$tag.log 2>&1 &
  done
  wait
done
echo done
