"""rvB8_regress: 全角・半角の違い（width）と落とす空白（drops）を、段落ごとに JSON に書く。  python -I runw8.py SRC cases.json 出力.json"""
import json
import sys

src, cases_path, out_path = sys.argv[1:4]
sys.path.insert(0, src)
import jasme_jats  # noqa: E402
from jasme_jats.config import JournalConfig  # noqa: E402
from jasme_jats.pdfdocx import _mechanical  # noqa: E402
from jasme_jats.pdfmatch import compare  # noqa: E402

j = JournalConfig.load()
out = []
for c in json.load(open(cases_path, encoding="utf-8")):
    _, plan = _mechanical(c["docx"], j)
    pc = compare(plan, c["pages"])
    out.append({"width": {s: sorted(v.items()) for s, v in pc.width.items()},
                "drops": {s: sorted(v) for s, v in pc.drops.items()}})
json.dump({"version": jasme_jats.__version__, "cases": out}, open(out_path, "w", encoding="utf-8"), ensure_ascii=False)
