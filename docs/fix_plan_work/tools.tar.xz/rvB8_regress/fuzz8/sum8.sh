#!/bin/sh
# rvB8_regress: fuzz8 のすべての組を、v019→cur と pre→cur で judge8 にかけ、悪くなった段落の数をまとめる。  sh sum8.sh [glob]
F=/tmp/claude-0/-home-user-jstgxmlcng-JASME/fb4d86bb-6ffb-5369-990a-10fe830c8789/scratchpad/rvB8_regress/fuzz8
G=${1:-*_3[0-9][0-9]}
for d in $F/$G; do
  [ -f $d/res_pre.json ] || continue
  a=$(python -I $F/judge8.py $d/cases.json $d/res_v019.json $d/res_cur.json | sed -n 4p)
  b=$(python -I $F/judge8.py $d/cases.json $d/res_pre.json $d/res_cur.json | sed -n 4p)
  echo "$(basename $d) | v019->cur: $a | pre->cur: $b"
done
