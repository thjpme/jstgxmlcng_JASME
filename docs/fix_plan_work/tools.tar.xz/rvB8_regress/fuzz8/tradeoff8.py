"""rvB8_regress: 壊した版（A）と今のコード（B）を、fuzz8 のすべての組で比べ、B がよい・悪い段落と、VIOLATION の増減を数える。

  python -I tradeoff8.py 壊した版の名前
"""
import glob
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import judge8  # noqa: E402

F = Path(__file__).resolve().parent
m = sys.argv[1]
better = worse = vb_new = vb_gone = 0
rows = []
n_cases = n_paras = 0
for d in sorted(glob.glob(str(F / "*_3[0-9][0-9]"))):
    a_path = Path(d) / f"res_{m}.json"
    if not a_path.exists():
        continue
    cases = json.load(open(Path(d) / "cases.json", encoding="utf-8"))
    A = json.load(open(a_path, encoding="utf-8"))["cases"]
    B = json.load(open(Path(d) / "res_cur.json", encoding="utf-8"))["cases"]
    n_cases += len(cases)
    for n, (c, ra, rb) in enumerate(zip(cases, A, B)):
        for t, p in c["truth"].items():
            if t not in ra["paras"] or t not in rb["paras"]:
                continue
            n_paras += 1
            va, ha, _ = judge8.verdict(t, p, ra["paras"][t])
            vb, hb, _ = judge8.verdict(t, p, rb["paras"][t])
            ka, kb = (judge8.RANK[va], ha), (judge8.RANK[vb], hb)
            if kb < ka:
                better += 1
            elif kb > ka:
                worse += 1
                rows.append((Path(d).name, n, rb["paras"][t]["src"], va, ha, vb, hb))
            if vb == "VIOLATION" and va != "VIOLATION":
                vb_new += 1
            if va == "VIOLATION" and vb != "VIOLATION":
                vb_gone += 1
print(f"{m}: {n_cases} cases, {n_paras} paragraphs; cur better {better}, cur worse {worse}; "
      f"VIOLATION only in cur {vb_new}, VIOLATION only in {m} {vb_gone}")
for r in rows:
    print("   worse:", r)
