"""rvB8p: _slide_inserts の境界（架空の文字）。PDF にだけある文字が、その前の docx の文字と同じ文字で終わる
（「生徒の」→「生徒の記述の」）とき、行の境目にそろえると、足す文字の行が「段落に当たらない行」になる。"""
FRONT = ["ページ番号の判定の検証用文書", "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
TAIL = ["引用および参考文献", REF, *EN]

B1 = "本稿では，架空の授業における生徒の発言を記録し，その特徴を観点ごとに整理したうえで考察を加える。"
P1 = B1.replace("生徒の発言", "生徒の記述の発言")
k = P1.index("の記述")

B2 = "本稿では，架空の授業で扱った数学の授業の記録を観点ごとに整理し，その特徴を述べたうえで考察を加える。"
P2 = B2.replace("数学の授業の記録", "数学の時間と数学の授業の記録")
k2 = P2.index("数学の時間と")
k2b = P2.index("数学の授業の記録")

CASES = {
    # 短い行（3 文字。柱の候補）がページの途中で「の記述」になる形
    "short_line_rotation": dict(body=[("body", B1)], pages=["\n".join(["（1）", *FRONT, P1[:k], P1[k:k + 3], P1[k + 3:], *TAIL])],
                                truth={B1: P1}),
    # 同じ形で、行の境目がそろわない（行の途中で分かれる）もの
    "short_line_no_rotation": dict(body=[("body", B1)], pages=["\n".join(["（1）", *FRONT, P1[:k + 1], P1[k + 1:], *TAIL])],
                                   truth={B1: P1}),
    # ページの最後の行（ページの端の行）が「数学の時間と」になる形
    "edge_line_rotation": dict(body=[("body", B2)], pages=["\n".join(["（1）", *FRONT, P2[:k2], P2[k2:k2b]]),
                                                         "\n".join(["（2）", P2[k2b:], *TAIL])],
                               truth={B2: P2}),
    # ページの最初の行（ページの端の行）
    "edge_line_rotation_top": dict(body=[("body", B2)], pages=["\n".join(["（1）", *FRONT, P2[:k2]]),
                                                             "\n".join(["（2）", P2[k2:k2b], P2[k2b:], *TAIL])],
                                   truth={B2: P2}),
    # ページの途中の普通の行（柱の候補でない）
    "mid_line_rotation": dict(body=[("body", B2)], pages=["\n".join(["（1）", *FRONT, "ページの最初の本文ではない行その一", "ページの最初の本文ではない行その二",
                                                                     P2[:k2], P2[k2:k2b], P2[k2b:], *TAIL])],
                              truth={B2: P2}),
}
