"""rvB8p: _slide_inserts で、校正で足された文字が行の境目にそろえられ、ページの端の行（柱の候補）だけになる形（架空の文字）。
前の一致の塊が長く、difflib がページの端の行の最初の文字まで一致させるとき。"""
FRONT = ["ページ番号の判定の検証用文書", "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
TAIL = ["引用および参考文献", REF, *EN]

B = "本稿では，架空の授業の記録を観点ごとに整理し，その特徴を三つに分けて考察したうえで，架空の授業で扱った数学の授業の記録を述べる。"
P = B.replace("扱った数学の授業", "扱った数学の時間と数学の授業")
a = P.index("数学の時間と")
b = P.index("数学の授業の記録を述べる")
assert P[a:b] == "数学の時間と"
CASES = {
    # ページの最初の行（ページの端の行）が「数学の時間と」
    "slide_to_page_top": dict(body=[("body", B)], pages=["\n".join(["（1）", *FRONT, P[:a]]),
                                                        "\n".join(["（2）", P[a:b], P[b:], *TAIL])], truth={B: P}),
    # ページの最後の行
    "slide_to_page_bottom": dict(body=[("body", B)], pages=["\n".join(["（1）", *FRONT, P[:a], P[a:b]]),
                                                           "\n".join(["（2）", P[b:], *TAIL])], truth={B: P}),
    # ページの途中の普通の行（比べるため）
    "slide_mid_page": dict(body=[("body", B)], pages=["\n".join(["（1）", *FRONT, P[:a], P[a:b], P[b:], *TAIL])], truth={B: P}),
}
B2 = "本稿では，架空の授業の記録を観点ごとに整理し，その特徴を三つに分けて考察したうえで，生徒の発言を述べる。"
P2 = B2.replace("生徒の発言", "生徒の記述の発言")
a2 = P2.index("の記述の発言") 
CASES.update({
    # ページの途中の短い行（3 文字）
    "slide_to_short_line": dict(body=[("body", B2)], pages=["\n".join(["（1）", *FRONT, P2[:a2], P2[a2:a2 + 3], P2[a2 + 3:], *TAIL])],
                                truth={B2: P2}),
})
