"""rvB8p: 行全体でしか一致させない数字だけの行（ページの途中）のすぐ前後の文字が、出版版で直されているとき（架空の文字）。
docx の数字（PDF にもある）を消さないか。"""
FRONT = ["ページ番号の判定の検証用文書", "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
TAIL = ["引用および参考文献", REF, *EN]

B = "教職経験は大学卒27年目と院卒16年目である。二人とも架空の授業の記録を担当した。"
def lines(p, *cuts):
    out, k = [], 0
    for c in cuts:
        out.append(p[k:c]); k = c
    out.append(p[k:])
    return out
CASES = {}
for name, pub in [("next_changed", B.replace("16年目", "16年め")),          # 数字の行のすぐ後ろの文字が直された
                  ("prev_changed", B.replace("院卒16", "院修了16")),       # すぐ前の文字が直された
                  ("both_same", B),                                       # 直しなし（比べるため）
                  ("number_changed", B.replace("16年目", "17年目"))]:     # 数字そのものが直された（DESIGN の限界）
    a = pub.index("16") if "16" in pub else pub.index("17")
    CASES[name] = dict(body=[("body", B)], pages=["\n".join(["（1）", *FRONT, *lines(pub, a, a + 2), *TAIL])], truth={B: pub})
# 段落の最初の数字だけの行（見出しの番号）のすぐ後ろが直された
H = "（1）方法の概要と記録の観点"
for name, pub in [("heading_next_changed", "（1）手法の概要と記録の観点"), ("heading_same", H)]:
    CASES[name] = dict(body=[("sec2", H), ("body", "本文の段落の途中に，表の数字だけの行が入る場合を確かめる。")],
                       pages=["\n".join(["（1）", *FRONT, "（1）", pub[3:], "本文の段落の途中に，表の数字だけの行が入る場合を確かめる。", *TAIL])],
                       truth={H: pub})
