"""rvB8p: 行全体でしか一致させない数字だけの行のすぐ後ろの文字が、出版版で直されているとき（架空の文字）。"""
FRONT = ["ページ番号の判定の検証用文書", "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
TAIL = ["引用および参考文献", REF, *EN]
B = "教職経験は大学卒27年目と院卒16年目である。二人とも架空の授業の記録を担当した。"
CASES = {}
for name, pub in [("next_char_changed", B.replace("16年目", "16か年目")), ("next_char_replaced", B.replace("16年目", "16回目"))]:
    a = pub.index("16")
    CASES[name] = dict(body=[("body", B)], pages=["\n".join(["（1）", *FRONT, pub[:a], "16", pub[a + 2:], *TAIL])], truth={B: pub})
