"""rvB8p: 「，」で終わる行の後ろの数字だけの行（前の行の続きとみなさない行。行全体でしか一致させない）が、出版版で直された
数のとき（架空の文字）。段落の途中なら直さずに 13 章（HEAD_WHY）、段落の最後なら？"""
FRONT = ["ページ番号の判定の検証用文書", "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
BODY = "本文の段落の途中に，表の数字だけの行が入る場合を確かめる。"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
Y_END = "架空二郎（2021）．「架空の比の研究」．『架空教育研究』，第12巻，2018"        # 年で終わる（終わりの「．」なし）
Y_MID = "架空二郎（2021）．「架空の比の研究」．『架空教育研究』，第12巻，2018，pp.45-58"
def page(*lines):
    return "\n".join(["（1）", *FRONT, BODY, "引用および参考文献", REF, *lines, *EN])
CASES = {}
for name, ref, pub in [("year_end_same", Y_END, Y_END), ("year_end_fixed", Y_END, Y_END.replace("2018", "2019")),
                       ("year_mid_same", Y_MID, Y_MID), ("year_mid_fixed", Y_MID, Y_MID.replace("2018", "2019"))]:
    k = pub.index("巻，") + 2
    rest = pub[k:]
    if rest.startswith("201") and "，" in rest:
        lines = [pub[:k], rest[:4], rest[4:]]
    else:
        lines = [pub[:k], rest]
    CASES[name] = dict(body=[("body", BODY)], refs=[ref], pages=[page(*lines)], truth={ref: pub} if ref != pub else {})
# 次のページの最初の行（ページの区切りをまたぐ）
for name, ref, pub in [("year_end_fixed_pagebreak", Y_END, Y_END.replace("2018", "2019"))]:
    k = pub.index("巻，") + 2
    CASES[name] = dict(body=[("body", BODY)], refs=[ref],
                       pages=["\n".join(["（1）", *FRONT, BODY, "引用および参考文献", REF, pub[:k]]), "\n".join(["（2）", pub[k:], *EN])],
                       truth={ref: pub})
