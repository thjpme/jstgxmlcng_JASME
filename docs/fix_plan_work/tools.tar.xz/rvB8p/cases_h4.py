"""rvB8p: docx にない図の中の文字（4 文字以上・20 文字未満の行）が、ページの途中で段落を分断する（照合に使わない行が近くにない）。"""
FRONT = ["ページ番号の判定の検証用文書", "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
TAIL = ["引用および参考文献", REF, *EN]
B = "本稿では，架空の授業の記録を観点ごとに整理し，その特徴を三つに分けて考察したうえで，生徒の発言を述べる。"
k = B.index("その特徴")
CASES = {}
for name, fig in [("fig_axis_titles", ["時間（分）", "得点の平均"]), ("fig_one_line", ["架空の量の変化"]),
                  ("fig_with_label", ["時間（分）", "A", "得点の平均"])]:
    CASES[name] = dict(body=[("body", B)], pages=["\n".join(["（1）", *FRONT, B[:k], *fig, B[k:], *TAIL])])
