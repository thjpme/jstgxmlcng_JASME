"""rvB8p（単位 B の 2 回目の修正の後の原則の点検）の反例。文字はすべて架空。

  python run_all.py <src> .../rvB8p/cases_rvB8p.py --name rvB8p_xxx
"""
from runner import (BREAK, DEFAULTS, Join, Raw, flow, journal_line, wrap)  # noqa: F401

H1 = "１．はじめに"
RH = "引用および参考文献"
REF = "架空一郎（2019）．「架空の数の研究」．『架空数学研究』，第29号，pp.11-16"


def front(first_page=25):
    return Raw(journal_line(fp=first_page, lp=first_page + 11), DEFAULTS["題目"], DEFAULTS["副題"], "試験　五郎")


# (1) 「，」で終わる行の後ろの、段落の最後の年（数字だけの行）が出版版で直されている
Y_END = "架空二郎（2021）．「架空の比の研究」．『架空教育研究』，第12巻，2018"
Y_PUB = Y_END.replace("2018", "2019")
YK = Y_PUB.index("巻，") + 2
P1 = ("本研究の目的は，架空の教室で行われた比の授業において，生徒が二つの量の関係をどのように捉えたかを，"
      "発話の記録と記述の分析によって明らかにすることである。")

# (2) 校正で足された文字（「生徒の」→「生徒の記述の」）が、行の境目にそろえるとページの端の行・短い行だけになる
B2 = "本稿では，架空の授業の記録を観点ごとに整理し，その特徴を三つに分けて考察したうえで，生徒の発言を述べる。"
P2 = B2.replace("生徒の発言", "生徒の記述の発言")
A2 = P2.index("の記述の発言")
B3 = "本稿では，架空の授業の記録を観点ごとに整理し，その特徴を三つに分けて考察したうえで，架空の授業で扱った数学の授業の記録を述べる。"
P3 = B3.replace("扱った数学の授業", "扱った数学の時間と数学の授業")
A3, Z3 = P3.index("数学の時間と"), P3.index("数学の授業の記録を述べる")

CASES = [
    {
        "name": "rvB8p_year_end_fixed",
        "angle": "edit",
        "item": "new",
        "paras": [("見出し", H1), ("本文", P1), ("引用文献見出し", RH), ("引用文献", Y_END)],
        "truth": {3: Y_PUB},
        # 引用文献の最後の行が「2019」だけ（前の行は「…第12巻，」で終わる）
        "pages": flow([front(), H1, P1, RH, Raw(*wrap(Y_PUB[:YK]), Y_PUB[YK:])], first=25),
        "expect": "reported",
        "note": "前の行が「，」で終わる数字だけの行は、続きの行とみなさない（行全体でしか一致させない）。docx の「2018」を消して"
                "はいけない（直せないなら 13 章に出す）。DESIGN 4.4 は「直されていれば直さずに 13 章に出す（HEAD_WHY）」と書く。",
    },
    {
        "name": "rvB8p_year_end_fixed_pagebreak",
        "angle": "edit",
        "item": "new",
        "paras": [("見出し", H1), ("本文", P1), ("引用文献見出し", RH), ("引用文献", Y_END)],
        "truth": {3: Y_PUB},
        "pages": flow([front(), H1, P1, RH, Raw(*wrap(Y_PUB[:YK])), BREAK, Raw(Y_PUB[YK:])], first=25),
        "expect": "reported",
        "note": "同じ形で、年が次のページの最初の行（「（26）」の次）。",
    },
    {
        "name": "rvB8p_slide_short_line",
        "angle": "edit",
        "item": "new",
        "paras": [("見出し", H1), ("本文", B2), ("引用文献見出し", RH), ("引用文献", REF)],
        "truth": {1: P2},
        # 足された「記述の」を行の境目にそろえると、3 文字の行「の記述」だけになる
        "pages": flow([front(), H1, Raw(*wrap(P2[:A2]), P2[A2:A2 + 3], *wrap(P2[A2 + 3:])), RH, REF], first=25),
        "expect": "reported",
        "note": "校正で足された文字で、行の途中から始まるもの。0.19.0 と直す前の版は足す。足せないなら 13 章に出す。",
    },
    {
        "name": "rvB8p_slide_page_top",
        "angle": "edit",
        "item": "new",
        "paras": [("見出し", H1), ("本文", B3), ("引用文献見出し", RH), ("引用文献", REF)],
        "truth": {1: P3},
        # 足された「時間と数学の」を行の境目にそろえると、ページの最初の行「数学の時間と」だけになる
        "pages": flow([front(), H1, Raw(*wrap(P3[:A3])), BREAK, Raw(P3[A3:Z3], *wrap(P3[Z3:])), RH, REF], first=25),
        "expect": "reported",
        "note": "同じ形で、ページの最初の行（ページの端の行）。",
    },
]

# (3) ページの途中の数字だけの行（行全体でしか一致させない）のすぐ前の文字が、出版版で直されている
B4 = "教職経験は大学卒27年目と院卒16年目である。二人とも架空の授業の記録を担当した。"
P4 = B4.replace("院卒16", "院修了16")
K4 = P4.index("16")
# (4) 「p.」の改行の後の、段落の最後の数字が出版版で直されている（DESIGN 4.4 の限界にある形）
R5 = "架空三郎（2017）．「架空の図の研究」．『架空数学研究』，第30号，p.16"
R5P = R5.replace("p.16", "p.17")
CASES += [
    {
        "name": "rvB8p_digit_line_prev_fixed",
        "angle": "edit",
        "item": "new",
        "paras": [("見出し", H1), ("本文", B4), ("引用文献見出し", RH), ("引用文献", REF)],
        "truth": {1: P4},
        "pages": flow([front(), H1, Raw(P4[:K4], "16", P4[K4 + 2:]), RH, REF], first=25),
        "expect": "reported",
        "note": "表を本文に書いた段落の数字が PDF では 1 行（本誌の 27 巻 47 の形）。すぐ前の「卒」が「修了」に直されている。"
                "docx の「16」は PDF にもあるので消してはいけない。",
    },
    {
        "name": "rvB8p_ref_p_end_fixed",
        "angle": "edit",
        "item": "new",
        "paras": [("見出し", H1), ("本文", P1), ("引用文献見出し", RH), ("引用文献", R5)],
        "truth": {3: R5P},
        "pages": flow([front(), H1, P1, RH, Raw(R5P[:-2], R5P[-2:])], first=25),
        "expect": "reported",
        "note": "DESIGN 4.4 の限界（「p.」の改行の後の段落の最後の数字が直されているときは消すことがある。0.19.0 と同じ）。"
                "消したときに 13 章に出るか。",
    },
]
