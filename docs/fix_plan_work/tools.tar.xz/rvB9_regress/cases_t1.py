"""rvB9_regress: 3 回目の点検の修正（段落の最初・最後の docx の文字の位置に同じ行の PDF の文字がなく、すぐ隣の行が照合に使わない
行なら、消さずに HEAD_WHY にする）の、引き換えの形（校正で段落の最初・最後の文字が消された）を、すぐ隣の行の種類ごとに確かめる
（架空の文字）。"""
TITLE = "ページ番号の判定の検証用文書"
FRONT = [TITLE, "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
END_DOCX = "本稿では，架空の授業の記録を観点ごとに整理し，その特徴を三つに分けて考察した。以上"
END_PDF = END_DOCX[:-2]
START_DOCX = "なお，本稿では，架空の授業の記録を観点ごとに整理し，その特徴を三つに分けて考察した。"
START_PDF = START_DOCX[3:]
PREV = "前の段落は図の前にある本文の段落であり，照合の確かめに使うものである。"
NEXT = "次の段落は図の後ろに続く本文の段落であり，照合の確かめに使う。"
DATE = "2025年８月31日投稿受付，2025年11月24日採用決定"


def one(*lines):
    return ["\n".join(["（1）", *FRONT, *lines, "引用および参考文献", REF, *EN])]


def two(first, second):
    return ["\n".join(["（1）", *FRONT, *first]), "\n".join(["（2）", *second, "引用および参考文献", REF, *EN])]


h = len(END_PDF) // 2
CASES = {}
END_LAYOUTS = {
    "end_next_para": one(END_PDF[:h], END_PDF[h:], NEXT),
    "end_short_labels": one(END_PDF[:h], END_PDF[h:], "A", "B", NEXT),
    "end_digit_tick": one(END_PDF[:h], END_PDF[h:], "10", NEXT),
    "end_fig_text_mid": one(END_PDF[:h], END_PDF[h:], "得点の平均の変化", NEXT),
    "end_page_top_fig_text": two([END_PDF[:h], END_PDF[h:]], ["得点の平均の変化", NEXT]),
    "end_page_top_next_para": two([END_PDF[:h], END_PDF[h:]], [NEXT]),
    "end_date_line": one(END_PDF[:h], END_PDF[h:], DATE, NEXT),
}
for name, pages in END_LAYOUTS.items():
    CASES[name] = dict(title=TITLE, body=[("body", END_DOCX), ("body", NEXT)], pages=pages, truth={END_DOCX: END_PDF})
h2 = len(START_PDF) // 2
START_LAYOUTS = {
    "start_prev_para": one(PREV, START_PDF[:h2], START_PDF[h2:]),
    "start_short_labels": one(PREV, "A", "B", START_PDF[:h2], START_PDF[h2:]),
    "start_digit_tick": one(PREV, "10", START_PDF[:h2], START_PDF[h2:]),
    "start_fig_text_mid": one(PREV, "得点の平均の変化", START_PDF[:h2], START_PDF[h2:]),
    "start_date_line": one(PREV, DATE, START_PDF[:h2], START_PDF[h2:]),
    "start_page_bottom_fig_text": two([PREV, "得点の平均の変化"], [START_PDF[:h2], START_PDF[h2:]]),
}
for name, pages in START_LAYOUTS.items():
    CASES[name] = dict(title=TITLE, body=[("body", PREV), ("body", START_DOCX)], pages=pages, truth={START_DOCX: START_PDF})
