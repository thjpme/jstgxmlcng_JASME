"""rvB9_regress: 段落の最後の行が、行全体でしか一致させない何ページにも出る行（3 ページ以上の端に出る「ことが明らかになった。」）で、
出版版でその行が少し直されている形と、段落の最後の年の行の後ろに照合に使わない短い行が続く形（架空の文字）。"""
TITLE = "ページ番号の判定の検証用文書"
FRONT = [TITLE, "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
LAST = "ことが明らかになった。"
P1 = "第一の観点から授業の記録を読み直すと，生徒の記述に変化が見られる" + LAST
P2 = "第二の観点から授業の記録を読み直すと，教師の発問に変化が見られる" + LAST
P3 = "第三の観点から授業の記録を読み直すと，学級の議論に変化が見られる" + LAST
P2_DOCX = P2.replace("明らかに", "明らかと")


def split(p):
    k = len(p) - len(LAST)
    return [p[:k // 2], p[k // 2:k], LAST]


pages = ["\n".join(["（1）", *FRONT, *split(P1)]), "\n".join(["（2）", *split(P2)]),
         "\n".join(["（3）", *split(P3), "引用および参考文献", REF, *EN])]
CASES = {
    "repeated_last_same": dict(title=TITLE, body=[("body", P1), ("body", P2), ("body", P3)], pages=pages, truth={}),
    "repeated_last_changed": dict(title=TITLE, body=[("body", P1), ("body", P2_DOCX), ("body", P3)], pages=pages,
                                  truth={P2_DOCX: P2}),
}
Y_END = "架空二郎（2021）．「架空の比の研究」．『架空教育研究』，第12巻，2018"
k = Y_END.index("巻，") + 2
PUB = Y_END.replace("2018", "2019")
BODY = "本文の段落の途中に，表の数字だけの行が入る場合を確かめる。"
CASES["year_end_then_label_pagebreak"] = dict(
    title=TITLE, body=[("body", BODY)], refs=[Y_END],
    pages=["\n".join(["（1）", *FRONT, BODY, "引用および参考文献", REF, PUB[:k], PUB[k:]]), "\n".join(["（2）", "A", *EN])],
    truth={Y_END: PUB})
CASES["year_end_same_then_label_pagebreak"] = dict(
    title=TITLE, body=[("body", BODY)], refs=[Y_END],
    pages=["\n".join(["（1）", *FRONT, BODY, "引用および参考文献", REF, Y_END[:k], Y_END[k:]]), "\n".join(["（2）", "A", *EN])],
    truth={})
