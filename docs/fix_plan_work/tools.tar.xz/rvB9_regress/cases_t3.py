"""rvB9_regress: 校正で段落の最後の文字が置き換えられ、置き換えた文字が PDF では段落の最後の短い行（照合に使わない行）だけに
なる形（架空の文字）。3 回目の点検の修正の規則を狭めた試作（narrow）との違いを確かめる。"""
TITLE = "ページ番号の判定の検証用文書"
FRONT = [TITLE, "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
DOCX = "本稿では，架空の授業の記録を観点ごとに整理し，その特徴を三つに分けて考察した。以上"
PDF = DOCX[:-2] + "終わり"
NEXT = "次の段落は図の後ろに続く本文の段落であり，照合の確かめに使う。"
h = len(DOCX[:-2]) // 2


def one(*lines):
    return ["\n".join(["（1）", *FRONT, *lines, "引用および参考文献", REF, *EN])]


CASES = {
    "end_replaced_short_last_line": dict(title=TITLE, body=[("body", DOCX), ("body", NEXT)],
                                         pages=one(PDF[:h], PDF[h:-3], PDF[-3:], NEXT), truth={DOCX: PDF}),
}
