"""rvB9_regress: 表のキャプションの最後の文字が校正で消され、すぐ後ろが docx にない表（画像の表）の数字のセルの行のとき（架空の文字）。"""
TITLE = "ページ番号の判定の検証用文書"
FRONT = [TITLE, "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
BODY = "本稿では，架空の授業の記録を観点ごとに整理し，その特徴を三つに分けて考察した。"
CAP = "表１　架空の組ごとの得点と人数と平均の一覧（点）"
CAP_PDF = "表１　架空の組ごとの得点と人数と平均の一覧"
NEXT = "次の段落は表の後ろに続く本文の段落であり，照合の確かめに使う。"
CELLS = ["1組", "26", "31", "2組", "27", "29"]
CASES = {
    "table_caption_tail_deleted": dict(
        title=TITLE, body=[("body", BODY), ("tab_cap", CAP), ("body", NEXT)],
        pages=["\n".join(["（1）", *FRONT, BODY, CAP_PDF, *CELLS, NEXT, "引用および参考文献", REF, *EN])], truth={CAP: CAP_PDF}),
}
