"""rvB9_regress: 段落を分断する行（docx にない図の中の題目の行）の最初の文字が、その後ろの本文の行の最初の文字と同じで、
その行のすぐ前に行全体でしか一致させない行（数字だけの行・何ページにも出る柱）がある形（架空の文字）。difflib はその 1 文字を
分断する行と一致させ、その 1 文字は前の一致と別の塊になるので、_slide_inserts の「前後の一致を 1 文字以上残す」条件でずらせない。"""
TITLE = "ページ番号の判定の検証用文書"
FRONT = [TITLE, "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
BODY = "試験の結果は，数学的な活動に，述べた。架空の生徒は，式による表現を分析した。教師の発問は，観点ごとの特徴を28件比べた。"
k = BODY.index("との特徴")
L1, L2, L3 = BODY[:24], BODY[24:k], BODY[k:]
FIG = "と　架空の図の題目"
CASES = {
    # 同じページの途中: 数字だけの行（図の目盛り）→ 図の中の題目 → 目盛り → 本文
    "digit_then_fig_title_mid": dict(title=TITLE, body=[("body", BODY)],
        pages=["\n".join(["（1）", *FRONT, L1, L2, "27", FIG, "35", L3, "引用および参考文献", REF, *EN])], truth={}),
    # 比べる形: 目盛りが題目の後ろだけ
    "fig_title_then_digit_mid": dict(title=TITLE, body=[("body", BODY)],
        pages=["\n".join(["（1）", *FRONT, L1, L2, FIG, "35", L3, "引用および参考文献", REF, *EN])], truth={}),
}
