"""rvB9p: 引用文献 A の最後の行が「，」の後ろの年だけで、出版版で直されている（「2018」→「2019」）。すぐ後ろに文献 B が続く形（架空の文字）。
B の書き出しの年の数字が A の年と一部同じとき（「（2015）」）・同じとき（「（2019）」）・数字がないとき・英文の文献のとき。"""
FRONT = ["ページ番号の判定の検証用文書", "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
BODY = "本文の段落の途中に，表の数字だけの行が入る場合を確かめる。"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
A = "架空二郎（2021）．「架空の比の研究」．『架空教育研究』，第12巻，2018"
AP = "架空三郎（2017）．「架空の図の研究」．『架空数学研究』，第30号，p.16"
BS = {
    "b2015": "見本四郎（2015）．「見本の題目」．『見本誌』，第3巻，pp.5-8．",
    "b2019": "見本四郎（2019）．「見本の題目」．『見本誌』，第3巻，pp.5-8．",
    "b1998": "見本四郎（1998）．「見本の題目」．『見本誌』，第3巻，pp.5-8．",
    "bnodigit": "見本四郎．「見本の題目」．『見本誌』，第三巻．",
    "ben": "Smith, J. (2015). A fictional study of ratio. Fictional Journal, 3, 5-8.",
    "b2017": "見本四郎（2017）．「見本の題目」．『見本誌』，第3巻，pp.5-8．",
}
CASES = {}
for bk, b in BS.items():
    for ak, a, old, new in [("year", A, "2018", "2019"), ("page", AP, "16", "17")]:
        pub = a[:-len(old)] + new
        k = len(a) - len(old)
        for fixed in (True, False):
            p = pub if fixed else a
            lines = [p[:k], p[k:]]
            name = f"{ak}_{bk}_{'fixed' if fixed else 'same'}"
            CASES[name] = dict(body=[("body", BODY)], refs=[a, b],
                               pages=["\n".join(["（1）", *FRONT, BODY, "引用および参考文献", REF, *lines, b, *EN])],
                               truth={a: p} if fixed else {})
            # 次のページの最初の行
            CASES[name + "_pt"] = dict(body=[("body", BODY)], refs=[a, b],
                                       pages=["\n".join(["（1）", *FRONT, BODY, "引用および参考文献", REF, lines[0]]),
                                              "\n".join(["（2）", lines[1], b, *EN])],
                                       truth={a: p} if fixed else {})
