"""rvB9p: 校正で段落の最後の 1 文字（「。」「．」）が消され、すぐ後ろの段落の書き出しのあたりに同じ文字がある（架空の文字）。"""
FRONT = ["ページ番号の判定の検証用文書", "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF0 = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
B1 = "本研究では，架空の教室で行われた比の授業を取り上げた。"
B2 = "第一の場面では，生徒は表の横の並びに着目していた。二つの量が同じ割合で増えることを説明しようとした。"
CAP = "図１　架空の授業の流れ"
RA = "架空二郎（2021）．「架空の比の研究」．『架空教育研究』，第12巻，pp.33-47"
RB = "見本四郎（2015）．「見本の題目」．『見本誌』，第3巻，pp.5-8．"
def wrap(t, width=24):
    out, cur, n = [], "", 0.0
    for c in t:
        w = 0.5 if ord(c) < 0x2000 else 1.0
        if cur and n + w > width and c not in "，。．、）」』":
            out.append(cur); cur, n = "", 0.0
        cur += c; n += w
    if cur: out.append(cur)
    return out
CASES = {}
# 図のキャプションの最後の「。」が消された（次は本文の段落）
for k, extra in [("cap_period", "。"), ("cap_none", "")]:
    CASES[k] = dict(title=FRONT[0], body=[("body", B1), ("fig_cap", CAP + extra), ("body", B2)], refs=[RB],
                    pages=["\n".join(["（1）", *FRONT, *wrap(B1), CAP, *wrap(B2), "引用および参考文献", *wrap(REF0), *wrap(RB), *EN])],
                    truth={CAP + extra: CAP} if extra else {})
# 引用文献の最後の「．」が消された（次は別の文献）
for k, extra in [("ref_period", "．"), ("ref_none", "")]:
    CASES[k] = dict(title=FRONT[0], body=[("body", B1)], refs=[RA + extra, RB],
                    pages=["\n".join(["（1）", *FRONT, *wrap(B1), "引用および参考文献", *wrap(REF0), *wrap(RA), *wrap(RB), *EN])],
                    truth={RA + extra: RA} if extra else {})
# 本文の段落の最後の「。」が重なっていた（「。。」→「。」）
CASES["body_double"] = dict(title=FRONT[0], body=[("body", B1[:-1] + "。。"), ("body", B2)], refs=[RB],
                            pages=["\n".join(["（1）", *FRONT, *wrap(B1), *wrap(B2), "引用および参考文献", *wrap(REF0), *wrap(RB), *EN])],
                            truth={B1[:-1] + "。。": B1})
