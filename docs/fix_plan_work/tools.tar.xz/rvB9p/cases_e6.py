"""rvB9p: 校正で段落の最後・最初に文字が足された（PDF にだけある文字が段落の切れ目にある。架空の文字）。"""
FRONT = ["ページ番号の判定の検証用文書", "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF0 = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]
B1 = "本研究では，架空の教室で行われた比の授業を取り上げ，その特徴を考察した。"
B2 = "第一の場面では，生徒は表の横の並びに着目していた。二つの量が同じ割合で増えることを説明しようとした。"
RB = "見本四郎（2015）．「見本の題目」．『見本誌』，第3巻，pp.5-8．"
def wrap(t, width=24):
    out, cur, n = [], "", 0.0
    for c in t:
        w = 0.5 if ord(c) < 0x2000 else 1.0
        if cur and n + w > width and c not in "，。．、）」』":
            out.append(cur); cur, n = "", 0.0
        cur += c; n += w
    if cur: out.append(cur)
    return out
CASES = {}
for k, p1, p2 in [("end_added", B1 + "なお，詳細は別稿で述べる。", B2), ("start_added", B1, "さらに，" + B2),
                  ("end_added_short", B1[:-1] + "とした。", B2), ("mid_added", B1.replace("その特徴", "その主な特徴"), B2)]:
    CASES[k] = dict(title=FRONT[0], body=[("body", B1), ("body", B2)], refs=[RB],
                    pages=["\n".join(["（1）", *FRONT, *wrap(p1), *wrap(p2), "引用および参考文献", *wrap(REF0), *wrap(RB), *EN])],
                    truth={B1: p1, B2: p2})
# docx の段落の最後に「。」がなく、PDF にはある（同じ行）
CASES["end_period_added"] = dict(title=FRONT[0], body=[("body", B1[:-1]), ("body", B2)], refs=[RB],
                                 pages=["\n".join(["（1）", *FRONT, *wrap(B1), *wrap(B2), "引用および参考文献", *wrap(REF0), *wrap(RB), *EN])],
                                 truth={B1[:-1]: B1})
