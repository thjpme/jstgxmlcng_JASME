"""rvB9p（単位 B の 3 回目の修正の後の原則の点検）の反例。文字はすべて架空。

引用文献の最後の行が「，」の後ろの年（数字だけの行）で、出版版で直されている（「2018」→「2019」）。そのすぐ後ろに、別の文献が続く
（本誌の引用文献の並びの、いちばんふつうの形）。前の点検の指摘（段落の最後の年の行で docx の数字を消す）の直しが、最後の文献
以外でも効くか。

  python run_all.py <src> .../rvB9p/cases_rvB9p_e1.py --name rvB9p_e1_xxx
"""
from runner import (BREAK, DEFAULTS, Join, Raw, flow, journal_line, wrap)  # noqa: F401

H1 = "１．はじめに"
RH = "引用および参考文献"


def front(first_page=25):
    return Raw(journal_line(fp=first_page, lp=first_page + 11), DEFAULTS["題目"], DEFAULTS["副題"], "試験　五郎")


Y_END = "架空二郎（2021）．「架空の比の研究」．『架空教育研究』，第12巻，2018"
Y_PUB = Y_END.replace("2018", "2019")
YK = Y_PUB.index("巻，") + 2
P_END = "架空三郎（2017）．「架空の図の研究」．『架空数学研究』，第30号，p.16"
P_PUB = P_END[:-2] + "17"
PK = len(P_END) - 2
P1 = ("本研究の目的は，架空の教室で行われた比の授業において，生徒が二つの量の関係をどのように捉えたかを，"
      "発話の記録と記述の分析によって明らかにすることである。")
NEXTS = {
    "y2015": "見本四郎（2015）．「見本の題目」．『見本誌』，第3巻，pp.5-8．",
    "en": "Smith, J. (2015). A fictional study of ratio. Fictional Journal, 3, 5-8.",
}
CASES = []
for nk, nxt in NEXTS.items():
    for kind, docx, pubt, k in [("year", Y_END, Y_PUB, YK), ("page", P_END, P_PUB, PK)]:
        for pb in (False, True):
            tail = [Raw(*wrap(pubt[:k])), BREAK, Raw(pubt[k:])] if pb else [Raw(*wrap(pubt[:k]), pubt[k:])]
            CASES.append({
                "name": f"rvB9p_{kind}_end_fixed_next_{nk}{'_pagebreak' if pb else ''}",
                "angle": "edit",
                "item": "new",
                "paras": [("見出し", H1), ("本文", P1), ("引用文献見出し", RH), ("引用文献", docx), ("引用文献", nxt)],
                "truth": {3: pubt},
                "pages": flow([front(), H1, P1, RH, *tail, nxt], first=25),
                "expect": "reported",
                "note": "段落の最後の、行全体でしか一致させない数字の行が出版版で直されている。すぐ後ろに別の文献が続く。"
                        "docx の数字を消してはいけない。直せないなら 13 章に出す（DESIGN 4.4 は HEAD_WHY で出すと書く）。",
            })
