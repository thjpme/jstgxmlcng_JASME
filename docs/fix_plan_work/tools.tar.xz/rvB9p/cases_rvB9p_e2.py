"""rvB9p（単位 B の 3 回目の修正の後の原則の点検）の反例。文字はすべて架空。

引用文献 A の最後の行が「，」の後ろの年（数字だけの行）で、出版版で直されている（「2018」→「2019」）。すぐ後ろの文献 B の
書き出しの年が A の年と最初の 2 文字だけ同じ（「（2009）」）。0.19.0 と同じく、A の年の後ろの 2 文字を消して「20」にする
（「1」は出版版の「2019」にもある）か。

  python run_all.py <src> .../rvB9p/cases_rvB9p_e2.py --name rvB9p_e2_xxx
"""
from runner import (BREAK, DEFAULTS, Join, Raw, flow, journal_line, wrap)  # noqa: F401

H1 = "１．はじめに"
RH = "引用および参考文献"


def front(first_page=25):
    return Raw(journal_line(fp=first_page, lp=first_page + 11), DEFAULTS["題目"], DEFAULTS["副題"], "試験　五郎")


Y_END = "架空二郎（2021）．「架空の比の研究」．『架空教育研究』，第12巻，2018"
Y_PUB = Y_END.replace("2018", "2019")
YK = Y_PUB.index("巻，") + 2
P1 = ("本研究の目的は，架空の教室で行われた比の授業において，生徒が二つの量の関係をどのように捉えたかを，"
      "発話の記録と記述の分析によって明らかにすることである。")
NEXT = "架空五郎（2009）．『架空の算数の授業』．架空書房．"
CASES = [
    {
        "name": "rvB9p_year_end_fixed_next_2009",
        "angle": "edit",
        "item": "N10",
        "paras": [("見出し", H1), ("本文", P1), ("引用文献見出し", RH), ("引用文献", Y_END), ("引用文献", NEXT)],
        "truth": {3: Y_PUB},
        "pages": flow([front(), H1, P1, RH, Raw(*wrap(Y_PUB[:YK]), Y_PUB[YK:]), NEXT], first=25),
        "expect": "reported",
        "note": "段落の最後の、行全体でしか一致させない年の行が出版版で直されている。すぐ後ろの文献の年が「（2009）」。"
                "docx の「2018」の「1」（出版版の「2019」にもある）を消してはいけない。",
    },
]
