"""rvB9p（単位 B の 3 回目の修正の後の原則の点検）の反例。文字はすべて架空。

校正で段落の最初・最後の文字が消され（「なお，」「云々」）、段落のすぐ隣の PDF の行が、docx にない表のセルの行・図の中の点の
名前の行・投稿受付日の行（照合に使わない行）のとき。3 回目の修正で、消さずに直さない違い（HEAD_WHY）として 13 章に出るように
なった形（0.19.0 と直す前の版は正しく消す）。13 章に出るか。

  python run_all.py <src> .../rvB9p/cases_rvB9p_e3.py --name rvB9p_e3_xxx
"""
from runner import (BREAK, DEFAULTS, Join, Raw, flow, journal_line, received_line, wrap)  # noqa: F401

H1 = "１．はじめに"
RH = "引用および参考文献"
REF = "架空一郎（2019）．「架空の数の研究」．『架空数学研究』，第29号，pp.11-16．"


def front(first_page=25):
    return Raw(journal_line(fp=first_page, lp=first_page + 11), DEFAULTS["題目"], DEFAULTS["副題"], "試験　五郎")


P1 = "本研究では，架空の教室で行われた比の授業を取り上げ，生徒の発話の記録を観点ごとに整理して，その特徴を考察した。"
P2 = "以上の結果から，対応の見方と変化の見方を行き来する活動が，比例の理解を深めるうえで重要であると考えられる。"
TABLE = Raw("表１　架空の組ごとの得点", "1組", "26", "2組", "73")
LABELS = Raw("A", "B", "O")
CASES = []
for nk, sep in [("table", TABLE), ("labels", LABELS), ("date", Raw(received_line()))]:
    CASES.append({
        "name": f"rvB9p_start_deleted_after_{nk}",
        "angle": "edit", "item": "new",
        "paras": [("見出し", H1), ("本文", P1), ("本文", "なお，" + P2), ("引用文献見出し", RH), ("引用文献", REF)],
        "truth": {2: P2},
        "pages": flow([front(), H1, P1, sep, P2, RH, REF], first=25),
        "expect": "reported",
        "note": "段落の最初の「なお，」が校正で消された。すぐ前の PDF の行は照合に使わない行。消すか、13 章に出す。",
    })
    CASES.append({
        "name": f"rvB9p_end_deleted_before_{nk}",
        "angle": "edit", "item": "new",
        "paras": [("見出し", H1), ("本文", P1 + "云々"), ("本文", P2), ("引用文献見出し", RH), ("引用文献", REF)],
        "truth": {1: P1},
        "pages": flow([front(), H1, P1, sep, P2, RH, REF], first=25),
        "expect": "reported",
        "note": "段落の最後の「云々」が校正で消された。すぐ後ろの PDF の行は照合に使わない行。消すか、13 章に出す。",
    })
