"""rvB9p（単位 B の 3 回目の修正の後の原則の点検）の反例。文字はすべて架空。

校正で段落の最後の文字が消され（docx「…考察した。以上」、PDF「…考察した。」）、すぐ後ろの段落の書き出しが同じ文字
（「以上の結果から，…」）。段落の後ろが窓の中のほかの文字と並べられる不具合（N10）の仲間で、違いにならず黙って残るか。

  python run_all.py <src> .../rvB9p/cases_rvB9p_e4.py --name rvB9p_e4_xxx
"""
from runner import (BREAK, DEFAULTS, Join, Raw, flow, journal_line, wrap)  # noqa: F401

H1 = "１．はじめに"
RH = "引用および参考文献"
REF = "架空一郎（2019）．「架空の数の研究」．『架空数学研究』，第29号，pp.11-16．"


def front(first_page=25):
    return Raw(journal_line(fp=first_page, lp=first_page + 11), DEFAULTS["題目"], DEFAULTS["副題"], "試験　五郎")


P1 = "本研究では，架空の教室で行われた比の授業を取り上げ，生徒の発話の記録を観点ごとに整理して，その特徴を考察した。"
P2 = "以上の結果から，対応の見方と変化の見方を行き来する活動が，比例の理解を深めるうえで重要であると考えられる。"
CASES = []
for nk, mid in [("plain", []), ("pagebreak", [BREAK])]:
    CASES.append({
        "name": f"rvB9p_end_deleted_same_as_next_{nk}",
        "angle": "edit", "item": "N10",
        "paras": [("見出し", H1), ("本文", P1 + "以上"), ("本文", P2), ("引用文献見出し", RH), ("引用文献", REF)],
        "truth": {1: P1},
        "pages": flow([front(), H1, P1, *mid, P2, RH, REF], first=25),
        "expect": "reported",
        "note": "段落の最後の「以上」が校正で消された。すぐ後ろの段落の書き出しも「以上」。消すか、13 章に出す。",
    })
