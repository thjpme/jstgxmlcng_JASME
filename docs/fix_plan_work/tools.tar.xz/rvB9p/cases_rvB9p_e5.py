"""rvB9p（単位 B の 3 回目の修正の後の原則の点検）の反例。文字はすべて架空。

校正で段落の最後の 1 文字が消された（図のキャプションの最後の「。」、引用文献の最後の「．」）。すぐ後ろの段落の書き出しの
あたりにも同じ文字がある。段落の後ろが窓の中のほかの文字と並べられる不具合（N10）の仲間で、違いにならず黙って残るか。

  python run_all.py <src> .../rvB9p/cases_rvB9p_e5.py --name rvB9p_e5_xxx
"""
from runner import (BREAK, DEFAULTS, Join, Raw, flow, journal_line, wrap)  # noqa: F401

H1 = "１．はじめに"
RH = "引用および参考文献"


def front(first_page=25):
    return Raw(journal_line(fp=first_page, lp=first_page + 11), DEFAULTS["題目"], DEFAULTS["副題"], "試験　五郎")


B1 = "本研究では，架空の教室で行われた比の授業を取り上げた。"
B2 = "第一の場面では，生徒は表の横の並びに着目していた。二つの量が同じ割合で増えることを説明しようとした。"
CAP = "図１　架空の授業の流れ"
RA = "架空二郎（2021）．「架空の比の研究」．『架空教育研究』，第12巻，pp.33-47"
RB = "見本四郎（2015）．「見本の題目」．『見本誌』，第3巻，pp.5-8．"
CASES = [
    {
        "name": "rvB9p_caption_period_deleted",
        "angle": "edit", "item": "N10",
        "paras": [("見出し", H1), ("本文", B1), ("図キャプション", CAP + "。"), ("本文", B2), ("引用文献見出し", RH), ("引用文献", RB)],
        "truth": {2: CAP},
        "pages": flow([front(), H1, B1, CAP, B2, RH, RB], first=25),
        "expect": "reported",
        "note": "図のキャプションの最後の「。」が出版版にない。すぐ後ろの本文の段落の最初の文にも「。」がある。消すか、13 章に出す。",
    },
    {
        "name": "rvB9p_reference_period_deleted",
        "angle": "edit", "item": "N10",
        "paras": [("見出し", H1), ("本文", B1), ("引用文献見出し", RH), ("引用文献", RA + "．"), ("引用文献", RB)],
        "truth": {3: RA},
        "pages": flow([front(), H1, B1, RH, RA, RB], first=25),
        "expect": "reported",
        "note": "引用文献の最後の「．」が出版版にない。すぐ後ろの文献の書き出しの年の後ろにも「．」がある。消すか、13 章に出す。",
    },
]
