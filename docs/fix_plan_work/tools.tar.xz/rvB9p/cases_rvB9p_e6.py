"""rvB9p（単位 B の 3 回目の修正の後の原則の点検）の反例。文字はすべて架空。

校正で段落の最後・最初に文字が足された（PDF にだけある文字が段落の切れ目にある。同じ行）。pdfmatch._classify は段落の前後の
PDF にだけある文字（insert）を、別の段落の文字かもしれないので使わない。13 章に出るか。

  python run_all.py <src> .../rvB9p/cases_rvB9p_e6.py --name rvB9p_e6_xxx
"""
from runner import (BREAK, DEFAULTS, Join, Raw, flow, journal_line, wrap)  # noqa: F401

H1 = "１．はじめに"
RH = "引用および参考文献"
RB = "見本四郎（2015）．「見本の題目」．『見本誌』，第3巻，pp.5-8．"


def front(first_page=25):
    return Raw(journal_line(fp=first_page, lp=first_page + 11), DEFAULTS["題目"], DEFAULTS["副題"], "試験　五郎")


B1 = "本研究では，架空の教室で行われた比の授業を取り上げ，その特徴を考察した。"
B2 = "第一の場面では，生徒は表の横の並びに着目していた。二つの量が同じ割合で増えることを説明しようとした。"
CASES = []
for name, d1, p1, d2, p2 in [
        ("rvB9p_sentence_added_at_end", B1, B1 + "なお，詳細は別稿で述べる。", B2, B2),
        ("rvB9p_period_added_at_end", B1[:-1], B1, B2, B2),
        ("rvB9p_words_added_at_start", B1, B1, B2, "さらに，" + B2)]:
    CASES.append({
        "name": name, "angle": "edit", "item": "new",
        "paras": [("見出し", H1), ("本文", d1), ("本文", d2), ("引用文献見出し", RH), ("引用文献", RB)],
        "truth": {k: v for k, (d, v) in {1: (d1, p1), 2: (d2, p2)}.items() if d != v},
        "pages": flow([front(), H1, p1, p2, RH, RB], first=25),
        "expect": "reported",
        "note": "校正で段落の最後（最初）に文字が足された。PDF にだけある文字は段落の切れ目にある。足すか、13 章に出す。",
    })
