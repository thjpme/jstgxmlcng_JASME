"""単位 B の点検（rvB_regress）の実験: 架空の docx と、extract_pages の代わりの PDF の文字で、照合とルート2 の直す箇所を
変更前（HEAD）と変更後（作業ツリー）で比べる（scratchpad だけ。実際の論文の文字は使わない）。

  python -I rvB_regress_exp.py            # 両方のコードで全部の実験を実行して比べる
  python -I rvB_regress_exp.py --worker SRC 実験名...   # 1 つのコードで実行して JSON を出す（内部用）
"""
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
TESTS = HERE / "rvB_regress_mut" / "tests"       # tests/ の写し（make_fixtures・conftest）
WORK = HERE / "rvB_regress_exp_out"
HEAD_SRC = HERE / "rvB_regress_head" / "src"
WT_SRC = Path("/home/user/jstgxmlcng_JASME/src")

FRONT = ["ページ番号の判定の検証用文書", "―検証用の小さな論文―", "架空大学　試験　六郎", "１．はじめに"]
REF = "試験六郎（2024）．「小さな論文」．『架空誌』，第5巻，pp.9-10．"
EN = ["A Small Article", "For Checking", "Rokuro SHIKEN", "Fictional University", "Abstract", "Small article abstract."]

# 架空の本文（200 文字ほど。数字を含まない）
LONG = ("本稿では，架空の授業における生徒の発話を記録し，その特徴を三つの観点から整理する。第一の観点は，"
        "生徒が問題の条件をどのように読み取ったかであり，第二の観点は，読み取った条件をどのように表したかである。"
        "第三の観点は，表したものをどのように検討し直したかである。これらの観点を順に用いて，授業の記録を分析した結果を"
        "以下に示す。分析の手続きは次の節で述べる。")
NEXT = "次に，分析の手続きを述べる。記録は授業ごとに整理し，発話の番号を付けた。"


def digits(n, start=10):
    """数字だけの行（表のセルの想定）n 行。"""
    return [str(start + (k * 7) % 89) for k in range(n)]


def exp_docx(name, body):
    sys.path.insert(0, str(TESTS))
    import make_fixtures as mf
    path = WORK / f"{name}.docx"
    mf.make_article(path, FRONT[0], lambda b: [mf.para(mf.S["sec1"], FRONT[3])] + [mf.para(mf.S["body"], t) for t in body])
    return path


EXPS = {}


def exp(f):
    EXPS[f.__name__] = f
    return f


@exp
def numeric_table_splits_paragraph():
    """長い段落の終わり近く（ページの途中）を、数字だけのセルの大きな表（300 行）が分断する。0.19.0 は数字の行を除いていた。"""
    cut = len(LONG) - 22
    pages = ["\n".join(["（1）", *FRONT, LONG[:cut], *digits(300), LONG[cut:], NEXT, "引用および参考文献", REF, *EN[:3]]),
             "\n".join(["（2）", *EN[3:]])]
    return [LONG, NEXT], pages


@exp
def numeric_table_splits_paragraph_small():
    """同じ形で、表が小さい（60 行）。"""
    cut = len(LONG) - 22
    pages = ["\n".join(["（1）", *FRONT, LONG[:cut], *digits(60), LONG[cut:], NEXT, "引用および参考文献", REF, *EN[:3]]),
             "\n".join(["（2）", *EN[3:]])]
    return [LONG, NEXT], pages


@exp
def repeated_line_splits_paragraph():
    """長い段落の終わり近く（ページの途中）を、3 ページ以上に出る 8 文字以上の行（表の見出しの行の想定）を多く含む表が分断する。
    0.19.0 はその行をどこでも除いていた。"""
    cut = len(LONG) - 22
    hdr = ["区分の見出しの行その一", "区分の見出しの行その二", "区分の見出しの行その三"]
    table = [x for _ in range(15) for x in hdr]
    pages = ["\n".join(["（1）", *FRONT, LONG[:cut], *table, LONG[cut:], NEXT]),
             "\n".join(["（2）", *hdr, "引用および参考文献", REF]),
             "\n".join(["（3）", *hdr, *EN])]
    return [LONG, NEXT], pages


@exp
def head_shares_char_with_correction():
    """ページの最初の行の柱（8 文字未満の著者名「架空六郎」）の直後で、校正の直しがあり、docx の直される文字が柱と同じ文字を
    含む（docx「六つの」→ PDF「三つの」）。柱の行が 1 文字の偶然の一致で段落に当たったことになり、柱の文字が docx に入らないか。"""
    body = "本稿では，架空の授業の記録を六つの観点から整理し，その特徴を述べる。観点ごとに発話の例を示す。"
    pub = body.replace("六つの", "三つの")
    cut = pub.index("三つの")
    pages = ["\n".join(["（1）", *FRONT, pub[:cut]]),
             "\n".join(["（2）", "架空六郎", pub[cut:], "引用および参考文献", REF, *EN])]
    return [body], pages


@exp
def head_shares_char_with_correction2():
    """同じ形で、柱が 2 文字以上 docx の直される文字と重なる（柱「数学の研究」、docx「数学の授業」→ PDF「算数の授業」）。"""
    body = "本稿は，架空の学校における数学の授業を対象として，生徒の発話の特徴を整理するものである。"
    pub = body.replace("数学の授業", "算数の授業")
    cut = pub.index("算数の授業")
    pages = ["\n".join(["（1）", *FRONT, pub[:cut]]),
             "\n".join(["（2）", "数学の研究", pub[cut:], "引用および参考文献", REF, *EN])]
    return [body], pages


@exp
def footnote_mark_line():
    """ページの途中に、注の番号「1)」だけの行がある（上付きの注番号が別の行として取り出された想定）。0.19.0 はページ番号として除いていた。"""
    body = "本稿は架空の授業を対象とする。授業は二回行った。記録の方法は次の節で述べる。"
    pages = ["\n".join(["（1）", *FRONT, body[:15], "1)", body[15:], "引用および参考文献", REF, *EN])]
    return [body], pages


@exp
def digit_line_at_correction():
    """校正の直し（docx「授業は1回行った」→ PDF「授業は２回行った」）の位置に、ページの途中の数字だけの行（表のセル「16」）が
    ある。0.19.0 は数字の行を除いていた。"""
    body = "本稿は架空の授業を対象とする。授業は1回行った。記録の方法は次の節で述べる。"
    pub = body.replace("1回", "２回")
    cut = pub.index("２回")
    pages = ["\n".join(["（1）", *FRONT, pub[:cut], "16", pub[cut:], "引用および参考文献", REF, *EN])]
    return [body], pages


@exp
def digit_line_at_correction2():
    """同じ形で、表のセルが「1」だけ（docx「1回」→ PDF「２回」）。"""
    body = "本稿は架空の授業を対象とする。授業は1回行った。記録の方法は次の節で述べる。"
    pub = body.replace("1回", "２回")
    cut = pub.index("２回")
    pages = ["\n".join(["（1）", *FRONT, pub[:cut], "1", pub[cut:], "引用および参考文献", REF, *EN])]
    return [body], pages


def worker(src, names):
    sys.path.insert(0, str(src))
    import jasme_jats
    from jasme_jats.config import JournalConfig
    from jasme_jats.pdfdocx import plan_fixes
    from jasme_jats.pdfmatch import compare
    from jasme_jats.pipeline import _mechanical
    assert Path(jasme_jats.__file__).resolve().is_relative_to(Path(src).resolve())
    j = JournalConfig.load()
    out = {}
    for name in names:
        body, pages = EXPS[name]()
        _, plan, _ = _mechanical(WORK / f"{name}.docx", j)
        pc = compare(plan, pages)
        src_of = {p.src: p.plain() for p in plan.paras.values()}
        out[name] = {
            "unmatched": [src_of[s][:20] for s in pc.unmatched],
            "diffs": [(d.src, d.docx, d.pdf, d.fixable, getattr(d, "why", "")[:10]) for d in pc.diffs],
            "fixes": [(f.src, f.kind, f.old, f.new, f.reason[:20]) for f in plan_fixes(plan, pc) if f.kind == "text"],
            "ignored": [list(x) for x in getattr(pc, "ignored_lines", [])],
        }
    print(json.dumps(out, ensure_ascii=False))


def main():
    names = [a for a in sys.argv[1:]] or list(EXPS)
    WORK.mkdir(exist_ok=True)
    for name in names:
        body, _ = EXPS[name]()
        exp_docx(name, body)
    res = {}
    for tag, src in (("0.19.0", HEAD_SRC), ("作業ツリー", WT_SRC)):
        p = subprocess.run([sys.executable, "-I", __file__, "--worker", str(src), *names], capture_output=True, text=True)
        if p.returncode:
            print(p.stderr)
            raise SystemExit(1)
        res[tag] = json.loads(p.stdout)
    for name in names:
        print(f"## {name}")
        for tag in res:
            r = res[tag][name]
            print(f"  [{tag}] unmatched={r['unmatched']}")
            print(f"      diffs={r['diffs']}")
            print(f"      fixes={r['fixes']}")
            print(f"      ignored={r['ignored']}")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--worker":
        worker(sys.argv[2], sys.argv[3:])
    else:
        main()
